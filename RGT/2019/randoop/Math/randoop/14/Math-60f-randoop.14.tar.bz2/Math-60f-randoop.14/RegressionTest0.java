import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.0f, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.log((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 1, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        java.lang.Number number9 = outOfRangeException7.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) -1, (-57.29577951308232d), (double) ' ', (int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta((double) 10.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.377");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) Double.POSITIVE_INFINITY, false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-17.400345834260023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution1 = null;
        try {
            int int2 = randomDataImpl0.nextInversionDeviate(integerDistribution1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution4 = null;
//        try {
//            double double5 = randomDataImpl0.nextInversionDeviate(continuousDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-6.304516897899679d) + "'", double3 == (-6.304516897899679d));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) 0L, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6449340668481562d + "'", double1 == 1.6449340668481562d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0E-9d, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-9d + "'", double2 == 1.0E-9d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextF((double) 97L, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double2 = org.apache.commons.math.util.FastMath.min((double) ' ', (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-57.29577951308232d) + "'", double2 == (-57.29577951308232d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4965075614664802d + "'", double1 == 3.4965075614664802d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.special.Erf.erf(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.6390614603967022d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2640737523317456d + "'", double1 == 2.2640737523317456d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-6.325965039186377d) + "'", double3 == (-6.325965039186377d));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-6.529228100140307d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.869048683494323d) + "'", double1 == (-1.869048683494323d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.min(10.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.6390614603967022d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.special.Gamma.digamma(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8049262717364689d + "'", double1 == 0.8049262717364689d);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            randomDataImpl0.setSecureAlgorithm("hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.291017406672424d + "'", double3 == 33.291017406672424d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.8813735870195429d), (-4.746766670733608d), (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.747 is smaller than, or equal to, the minimum (0): standard deviation (-4.747)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            double double8 = randomDataImpl0.nextWeibull(3.4657359027997265d, (-0.6390614603967022d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.639 is smaller than, or equal to, the minimum (0): scale (-0.639)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.83757566572826d + "'", double3 == 37.83757566572826d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextZipf((int) (byte) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            int int8 = randomDataImpl0.nextZipf((int) (short) 1, (double) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): exponent (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-24.61661160780565d) + "'", double3 == (-24.61661160780565d));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        try {
//            java.lang.String str11 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.932523699090511d + "'", double3 == 15.932523699090511d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-27.751302643879953d) + "'", double6 == (-27.751302643879953d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.6390614603967022d), 22.048169007888973d, 14.138341662366225d, (int) (byte) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.1279968624272825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.cos(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3387904745834194d + "'", double1 == 0.3387904745834194d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 48.49877948001509d + "'", double8 == 48.49877948001509d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNull(localizable31);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.3071898789116161d + "'", double0 == 0.3071898789116161d);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-21.486355222344105d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.07244619726107E9d) + "'", double1 == (-1.07244619726107E9d));
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 100.0d, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 57.29577951308232d, (java.lang.Number) 100.00000000000001d, false);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 20.53573111903292d + "'", double8 == 20.53573111903292d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(47.59321336587365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 47.59321336587366d + "'", double1 == 47.59321336587366d);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
//        boolean boolean55 = numberIsTooSmallException53.getBoundIsAllowed();
//        boolean boolean56 = numberIsTooSmallException53.getBoundIsAllowed();
//        boolean boolean57 = numberIsTooSmallException53.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 12.658680817582567d + "'", double8 == 12.658680817582567d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        try {
//            long long9 = randomDataImpl0.nextLong((long) 0, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.579387916336117d + "'", double3 == 5.579387916336117d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 77.82230873529483d + "'", double6 == 77.82230873529483d);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.25915288370211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0111115017970183d + "'", double1 == 1.0111115017970183d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(29.419799498875037d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.419799498875033d + "'", double2 == 29.419799498875033d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        try {
//            double[] doubleArray3 = normalDistributionImpl0.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.054815449795579625d) + "'", double1 == (-0.054815449795579625d));
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int10 = randomDataImpl0.nextPascal((int) (byte) 100, 1.0111115017970183d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.011 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-29.5594749215952d) + "'", double3 == (-29.5594749215952d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 85.47243039436061d + "'", double6 == 85.47243039436061d);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException85 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException89 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException85.addSuppressed((java.lang.Throwable) outOfRangeException89);
//        java.lang.Object[] objArray94 = new java.lang.Object[] { outOfRangeException89, (-1), (short) 100, 3.4657359027997265d };
//        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException("", objArray94);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray94);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray94);
//        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException(throwable0, "", objArray94);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-3.1350566166228564d) + "'", double23 == (-3.1350566166228564d));
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertNotNull(objArray94);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.cosh(14.138341662366225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 690516.0404842675d + "'", double1 == 690516.0404842675d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.acos(29.419799498875033d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(9.930007471917667d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("c", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.rint((-4.746766670733608d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.0d) + "'", double1 == (-5.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.0d + "'", double1 == 23.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double10 = randomDataImpl0.nextCauchy(0.0d, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9733846136598605d + "'", double3 == 0.9733846136598605d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 167.48419441510515d + "'", double6 == 167.48419441510515d);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 10.0d, true);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        try {
//            randomDataImpl0.setSecureAlgorithm("hi!", "c");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.871284857071684d + "'", double3 == 2.871284857071684d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-32.995235612023876d) + "'", double6 == (-32.995235612023876d));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.rint(28.34092087784644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.0d + "'", double1 == 28.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
        try {
            int int8 = randomDataImpl1.nextHypergeometric((int) (byte) 1, (-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(29.419799498875033d, (-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) 10L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        try {
//            double double8 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.184615979252138d + "'", double3 == 11.184615979252138d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-52.84432456035985d) + "'", double6 == (-52.84432456035985d));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3387904745834194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.057940522963217d + "'", double1 == 1.057940522963217d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.ulp(23.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.log(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 32.0f, 4.605170185988092d, 1.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999999999999999d + "'", double4 == 0.9999999999999999d);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        try {
//            long long6 = randomDataImpl0.nextLong(0L, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.818995342239376d + "'", double3 == 33.818995342239376d);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        try {
//            int[] intArray8 = randomDataImpl1.nextPermutation((int) ' ', (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (32): permutation size (97) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Number number54 = numberIsTooSmallException53.getMin();
//        java.lang.Number number55 = numberIsTooSmallException53.getMin();
//        boolean boolean56 = numberIsTooSmallException53.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-21.623445016801128d) + "'", double8 == (-21.623445016801128d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 32.0f + "'", number54.equals(32.0f));
//        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 32.0f + "'", number55.equals(32.0f));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double2 = randomDataImpl0.nextT((-1.9664577172556257d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.966 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.966)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        try {
//            int[] intArray8 = randomDataImpl1.nextPermutation((int) (short) -1, 23);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 23 is larger than the maximum (-1): permutation size (23) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int11 = randomDataImpl0.nextHypergeometric(0, (int) (byte) 0, 52);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-5.084046649928152d) + "'", double3 == (-5.084046649928152d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81.18741089932698d + "'", double6 == 81.18741089932698d);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double2 = org.apache.commons.math.util.FastMath.max((-22.968708748781847d), (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        try {
//            double double11 = randomDataImpl0.nextUniform(1.0E-9d, (-13.008398151443906d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-13.008): lower bound (0) must be strictly less than upper bound (-13.008)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-26.731370690895663d) + "'", double3 == (-26.731370690895663d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-27.47101866395535d) + "'", double6 == (-27.47101866395535d));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 23);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 23.0f + "'", float1 == 23.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double2 = org.apache.commons.math.util.FastMath.pow(57.29577951308232d, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0416077003882071d + "'", double2 == 0.0416077003882071d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.atan(7.4401283747656155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.437190734846794d + "'", double1 == 1.437190734846794d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.428182669496151d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.1279968624272825d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(28.0d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "c");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-51.92212054107445d) + "'", double3 == (-51.92212054107445d));
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.031743366520231894d + "'", double1 == 0.031743366520231894d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
        try {
            int int9 = randomDataImpl1.nextPascal(0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
        } catch (org.apache.commons.math.MathException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a" + "'", str6.equals("a"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Object[] objArray7 = numberIsTooLargeException5.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("c", objArray7);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        java.lang.Throwable throwable9 = null;
        try {
            outOfRangeException3.addSuppressed(throwable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 32.0d, (java.lang.Number) 0.0d, (java.lang.Number) 3.552713678800501E-15d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.5572730314344172d, (-35.337174945557074d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -35.337 is smaller than, or equal to, the minimum (0): standard deviation (-35.337)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(28.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0365889718756627d + "'", double1 == 3.0365889718756627d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(87.70102319954509d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.364882444512856d + "'", double1 == 9.364882444512856d);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        try {
//            int int9 = randomDataImpl0.nextZipf(0, 3.552713678800501E-15d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-26.14817708588483d) + "'", double3 == (-26.14817708588483d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 86.82908384401995d + "'", double6 == 86.82908384401995d);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '4', (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.984137914278307E171d + "'", double2 == 3.984137914278307E171d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.0d), 0.3071898789116161d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.ceil(31.07048615652774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "f8e761610a5d06d3d7e1c76");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f8e761610a5d06d3d7e1c76");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-8.327345708974262d) + "'", double3 == (-8.327345708974262d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-55.412508229870745d) + "'", double6 == (-55.412508229870745d));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double2 = org.apache.commons.math.util.FastMath.max(3.984137914278307E171d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.984137914278307E171d + "'", double2 == 3.984137914278307E171d);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(23);
//        try {
//            double double13 = randomDataImpl0.nextUniform(47.59321336587365d, 1.5707963267948966d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 47.593 is larger than, or equal to, the maximum (1.571): lower bound (47.593) must be strictly less than upper bound (1.571)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.2793236943598405d) + "'", double3 == (-2.2793236943598405d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-31.0900289625116d) + "'", double6 == (-31.0900289625116d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "362db3162f93ab1c2a9a384" + "'", str10.equals("362db3162f93ab1c2a9a384"));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.888237470923471d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.888237470923471d + "'", double1 == 7.888237470923471d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        double double9 = randomDataImpl6.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { double9, (-21.486355222344105d), outOfRangeException27 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable5, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException36.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException42.addSuppressed((java.lang.Throwable) outOfRangeException46);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { outOfRangeException46 };
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable38, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable37, objArray48);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray57 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray57);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable37, objArray57);
//        java.lang.String str60 = mathException0.getPattern();
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-27.033422635799923d) + "'", double9 == (-27.033422635799923d));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{0}" + "'", str60.equals("{0}"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.density(0.0416077003882071d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3985971052310144d + "'", double6 == 0.3985971052310144d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.signum((-17.400345834260023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.signum(11.331125335478156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.8534087943986295d, 14.138341662366225d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4094441360486166E-4d + "'", double2 == 3.4094441360486166E-4d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
        mathException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException14);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long1 = org.apache.commons.math.util.FastMath.round(1.6449340668481562d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-15.892342545699124d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.4599729445524856d) + "'", double1 == (-3.4599729445524856d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-45.24581447173601d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.233456810064802E19d + "'", double1 == 2.233456810064802E19d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        try {
//            java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.885508889931916d) + "'", double3 == (-11.885508889931916d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-31.857367507668066d) + "'", double6 == (-31.857367507668066d));
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 44.771820384373534d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        try {
//            double double6 = randomDataImpl0.nextGamma(Double.POSITIVE_INFINITY, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-3.9875846005121307d) + "'", double3 == (-3.9875846005121307d));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5491895702039902d + "'", double1 == 0.5491895702039902d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-6.529228100140307d), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.5292281001403065d) + "'", double2 == (-6.5292281001403065d));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1.0f, (double) 0.0f, Double.NaN, 3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.asin((-22.94725916282399d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.605170185988092d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        double double13 = randomDataImpl0.nextUniform(0.0416077003882071d, 0.4623429156838056d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-34.987099605805355d) + "'", double3 == (-34.987099605805355d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 31.738634766505562d + "'", double6 == 31.738634766505562d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97b11488d23440bdbe684e25f8d5bdc6fb0d92434d7cc5192c7d9e2f0585c69dc8f1a01120dada43bcd98a52fc81fb19e" + "'", str8.equals("97b11488d23440bdbe684e25f8d5bdc6fb0d92434d7cc5192c7d9e2f0585c69dc8f1a01120dada43bcd98a52fc81fb19e"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.34756860739267614d + "'", double13 == 0.34756860739267614d);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        try {
//            int[] intArray13 = randomDataImpl0.nextPermutation((int) '4', (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (52): permutation size (97) exceeds permuation domain (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-13.847579625976696d) + "'", double3 == (-13.847579625976696d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 31.034515987578786d + "'", double6 == 31.034515987578786d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dea2a2f8f90418e8f9131e855415a37423491f2c1299353b6ab4319b8d206e0fb30789481b097635b9e3643a00a6736ac" + "'", str8.equals("dea2a2f8f90418e8f9131e855415a37423491f2c1299353b6ab4319b8d206e0fb30789481b097635b9e3643a00a6736ac"));
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
//        double double11 = randomDataImpl8.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException16.addSuppressed((java.lang.Throwable) outOfRangeException20);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException25.addSuppressed((java.lang.Throwable) outOfRangeException29);
//        outOfRangeException16.addSuppressed((java.lang.Throwable) outOfRangeException29);
//        java.lang.Object[] objArray32 = new java.lang.Object[] { double11, (-21.486355222344105d), outOfRangeException29 };
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException6, localizable7, objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooLargeException38.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException44.addSuppressed((java.lang.Throwable) outOfRangeException48);
//        java.lang.Object[] objArray50 = new java.lang.Object[] { outOfRangeException48 };
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable40, objArray50);
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException6, localizable39, objArray50);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray59 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray59);
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, localizable39, objArray59);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl67 = new org.apache.commons.math.random.RandomDataImpl();
//        double double70 = randomDataImpl67.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException75.addSuppressed((java.lang.Throwable) outOfRangeException79);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException88 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException84.addSuppressed((java.lang.Throwable) outOfRangeException88);
//        outOfRangeException75.addSuppressed((java.lang.Throwable) outOfRangeException88);
//        java.lang.Object[] objArray91 = new java.lang.Object[] { double70, (-21.486355222344105d), outOfRangeException88 };
//        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException65, localizable66, objArray91);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable39, objArray91);
//        java.lang.Object[] objArray94 = maxIterationsExceededException93.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException("maximal number of iterations ({0}) exceeded", objArray94);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-38.285891167572395d) + "'", double11 == (-38.285891167572395d));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray50);
//        org.junit.Assert.assertNotNull(objArray59);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-2.7358276959765746d) + "'", double70 == (-2.7358276959765746d));
//        org.junit.Assert.assertNotNull(objArray91);
//        org.junit.Assert.assertNotNull(objArray94);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-38.285891167572395d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6682148579343544d) + "'", double1 == (-0.6682148579343544d));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        int int10 = randomDataImpl0.nextZipf((int) (short) 1, (double) 1);
//        try {
//            long long12 = randomDataImpl0.nextPoisson((-1.5574077246549023d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.557 is smaller than, or equal to, the minimum (0): mean (-1.557)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-24.86268735212017d) + "'", double3 == (-24.86268735212017d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-146.26809117320508d) + "'", double6 == (-146.26809117320508d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 100.0d, false);
//        java.lang.Number number58 = numberIsTooSmallException57.getArgument();
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException57);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number65 = outOfRangeException64.getArgument();
//        java.lang.Object[] objArray70 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray70);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException75.addSuppressed((java.lang.Throwable) outOfRangeException79);
//        java.lang.Object[] objArray82 = new java.lang.Object[] { (-1), maxIterationsExceededException71, outOfRangeException75, (byte) -1 };
//        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException64, "", objArray82);
//        org.apache.commons.math.exception.util.Localizable localizable84 = null;
//        org.apache.commons.math.exception.util.Localizable localizable85 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException89 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException93 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException89.addSuppressed((java.lang.Throwable) outOfRangeException93);
//        java.lang.Object[] objArray95 = new java.lang.Object[] { outOfRangeException93 };
//        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException(localizable85, objArray95);
//        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException64, localizable84, objArray95);
//        java.lang.Class<?> wildcardClass98 = objArray95.getClass();
//        org.apache.commons.math.ConvergenceException convergenceException99 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException59, "f8e761610a5d06d3d7e1c76", objArray95);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-39.72126166450941d) + "'", double8 == (-39.72126166450941d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1L) + "'", number58.equals((-1L)));
//        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 1.0f + "'", number65.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertNotNull(objArray82);
//        org.junit.Assert.assertNotNull(objArray95);
//        org.junit.Assert.assertNotNull(wildcardClass98);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        java.lang.Number number9 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0d + "'", number9.equals(0.0d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.special.Erf.erf((-1.869048683494323d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9917881738119619d) + "'", double1 == (-0.9917881738119619d));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100.0d, true);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
//        double double19 = randomDataImpl16.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException33.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { double19, (-21.486355222344105d), outOfRangeException37 };
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14, localizable15, objArray40);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable10, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooLargeException47.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable53 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl54 = new org.apache.commons.math.random.RandomDataImpl();
//        double double57 = randomDataImpl54.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException71.addSuppressed((java.lang.Throwable) outOfRangeException75);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException75);
//        java.lang.Object[] objArray78 = new java.lang.Object[] { double57, (-21.486355222344105d), outOfRangeException75 };
//        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException52, localizable53, objArray78);
//        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable48, objArray78);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray78);
//        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "f8e761610a5d06d3d7e1c76", objArray78);
//        org.apache.commons.math.exception.util.Localizable localizable83 = numberIsTooLargeException3.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-11.794040996526578d) + "'", double19 == (-11.794040996526578d));
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double57 + "' != '" + (-29.75055055925605d) + "'", double57 == (-29.75055055925605d));
//        org.junit.Assert.assertNotNull(objArray78);
//        org.junit.Assert.assertNull(localizable83);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.6390614603967022d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.189988202394336d + "'", double1 == 11.189988202394336d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability(1833.4649444186343d, 1.7763568394002505E-15d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 46);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        try {
            double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, (-53.81316849087429d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.asinh(67.68572946751985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.90807711203479d + "'", double1 == 4.90807711203479d);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        double double8 = randomDataImpl0.nextExponential((double) 10L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-44.93838891034371d) + "'", double3 == (-44.93838891034371d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 25.28976648764677d + "'", double6 == 25.28976648764677d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 38.856604899005376d + "'", double8 == 38.856604899005376d);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        randomDataImpl0.reSeed((long) 'a');
//        try {
//            double double11 = randomDataImpl0.nextF(35.55071304099612d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-24.018427179797484d) + "'", double3 == (-24.018427179797484d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 33.12383385937949d + "'", double6 == 33.12383385937949d);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        randomDataImpl0.reSeed((long) 'a');
//        int int11 = randomDataImpl0.nextSecureInt((-1), (int) 'a');
//        try {
//            int int14 = randomDataImpl0.nextPascal((int) (short) -1, 1.7182818284590453d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-59.18972118719376d) + "'", double3 == (-59.18972118719376d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 28.527424313854347d + "'", double6 == 28.527424313854347d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 82 + "'", int11 == 82);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-3.354585234655074d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-14.299400799032094d) + "'", double1 == (-14.299400799032094d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(87.70102319954509d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5024.898488312853d + "'", double1 == 5024.898488312853d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextPascal((int) ' ', Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: ∞ out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.signum((-45.24581447173601d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double8 = randomDataImpl1.nextT(4.9E-324d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument -1 p = 0.887");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = maxIterationsExceededException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-57.29577951308232d), (-39.72126166450941d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math.random.RandomDataImpl();
//        double double21 = randomDataImpl18.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException30);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException35.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        java.lang.Object[] objArray42 = new java.lang.Object[] { double21, (-21.486355222344105d), outOfRangeException39 };
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable17, objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooLargeException48.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException54.addSuppressed((java.lang.Throwable) outOfRangeException58);
//        java.lang.Object[] objArray60 = new java.lang.Object[] { outOfRangeException58 };
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable50, objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable49, objArray60);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable12, objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException68.addSuppressed((java.lang.Throwable) outOfRangeException72);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { outOfRangeException72 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable64, objArray74);
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable12, objArray74);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException83 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException83.addSuppressed((java.lang.Throwable) outOfRangeException87);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { outOfRangeException87, (-1), (short) 100, 3.4657359027997265d };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException("", objArray92);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray92);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray92);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException99 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (-0.9917881738119619d), (java.lang.Number) 37.323824837263125d, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.727497750802033d) + "'", double21 == (-3.727497750802033d));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertNotNull(objArray92);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-44.93838891034371d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.251752586176186d + "'", double1 == 2.251752586176186d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2147483647, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(41.56841073072807d, 26.217304647033266d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.56841073072806d + "'", double2 == 41.56841073072806d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010362601570467945d + "'", double1 == 0.010362601570467945d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(33);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-29.75055055925605d), 44.771820384373534d, (double) 0L, (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-29.75055055925605d), 1833.4649444186343d, 3.0365889718756627d, (int) (short) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.tanh(87.70102319954509d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        try {
//            int int8 = randomDataImpl1.nextInt((int) ' ', (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (0): lower bound (32) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0416077003882071d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.041595696213777324d + "'", double1 == 0.041595696213777324d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-7.981796571613402d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.998481895605531d) + "'", double1 == (-1.998481895605531d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.tan((-3.354585234655074d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21627298366004982d) + "'", double1 == (-0.21627298366004982d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong((long) 3, (long) 23);
//        try {
//            double double8 = randomDataImpl1.nextWeibull((double) (byte) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9L + "'", long5 == 9L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(117.41872726393613d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008552897619382271d + "'", double1 == 0.008552897619382271d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.984137914278307E171d, (-5.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 23);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (-0.6390614603967022d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.639 is smaller than, or equal to, the minimum (0): standard deviation (-0.639)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl49 = new org.apache.commons.math.random.RandomDataImpl();
//        double double52 = randomDataImpl49.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException57.addSuppressed((java.lang.Throwable) outOfRangeException61);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException66.addSuppressed((java.lang.Throwable) outOfRangeException70);
//        outOfRangeException57.addSuppressed((java.lang.Throwable) outOfRangeException70);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { double52, (-21.486355222344105d), outOfRangeException70 };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException47, localizable48, objArray73);
//        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(localizable43, objArray73);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray73);
//        java.lang.Class<?> wildcardClass77 = localizable5.getClass();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 12.030081469349339d + "'", double14 == 12.030081469349339d);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 23.240092259911513d + "'", double52 == 23.240092259911513d);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(41.56841073072807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.447356879429591d + "'", double1 == 6.447356879429591d);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        java.lang.Object[] objArray2 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray2);
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException47.addSuppressed((java.lang.Throwable) outOfRangeException51);
//        java.lang.Object[] objArray53 = new java.lang.Object[] { outOfRangeException51 };
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable42, objArray53);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray62 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray62);
//        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable42, objArray62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl();
//        double double73 = randomDataImpl70.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException78.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException91 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException87.addSuppressed((java.lang.Throwable) outOfRangeException91);
//        outOfRangeException78.addSuppressed((java.lang.Throwable) outOfRangeException91);
//        java.lang.Object[] objArray94 = new java.lang.Object[] { double73, (-21.486355222344105d), outOfRangeException91 };
//        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException68, localizable69, objArray94);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable42, objArray94);
//        java.lang.Object[] objArray97 = null;
//        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable42, objArray97);
//        org.apache.commons.math.ConvergenceException convergenceException99 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException98);
//        org.junit.Assert.assertNotNull(objArray2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.87842008390203d + "'", double14 == 35.87842008390203d);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.1256810541161046d + "'", double73 == 1.1256810541161046d);
//        org.junit.Assert.assertNotNull(objArray94);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        try {
//            int[] intArray9 = randomDataImpl0.nextPermutation((int) '#', 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (35): permutation size (100) exceeds permuation domain (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-32.24206022014485d) + "'", double3 == (-32.24206022014485d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 26.986609751652477d + "'", double6 == 26.986609751652477d);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.1279968624272825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6049908287387529d) + "'", double1 == (-1.6049908287387529d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(11.189988202394336d, 3.8534087943986295d, 0.3071898789116161d, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
//        double double12 = randomDataImpl9.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException17.addSuppressed((java.lang.Throwable) outOfRangeException21);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException30);
//        outOfRangeException17.addSuppressed((java.lang.Throwable) outOfRangeException30);
//        java.lang.Object[] objArray33 = new java.lang.Object[] { double12, (-21.486355222344105d), outOfRangeException30 };
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7, localizable8, objArray33);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException45.addSuppressed((java.lang.Throwable) outOfRangeException49);
//        java.lang.Object[] objArray51 = new java.lang.Object[] { outOfRangeException49 };
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable41, objArray51);
//        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7, localizable40, objArray51);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray60 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray60);
//        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3, localizable40, objArray60);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable67 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl68 = new org.apache.commons.math.random.RandomDataImpl();
//        double double71 = randomDataImpl68.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException76.addSuppressed((java.lang.Throwable) outOfRangeException80);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException85 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException89 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException85.addSuppressed((java.lang.Throwable) outOfRangeException89);
//        outOfRangeException76.addSuppressed((java.lang.Throwable) outOfRangeException89);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { double71, (-21.486355222344105d), outOfRangeException89 };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException66, localizable67, objArray92);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable40, objArray92);
//        java.lang.Object[] objArray95 = maxIterationsExceededException94.getArguments();
//        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException(throwable0, "maximal number of iterations ({0}) exceeded", objArray95);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-21.186494001264858d) + "'", double12 == (-21.186494001264858d));
//        org.junit.Assert.assertNotNull(objArray33);
//        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray51);
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-25.28369966782005d) + "'", double71 == (-25.28369966782005d));
//        org.junit.Assert.assertNotNull(objArray92);
//        org.junit.Assert.assertNotNull(objArray95);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(35.87842008390203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.989859771639235d + "'", double1 == 5.989859771639235d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.sin((-43.36923799997844d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5753722020923162d + "'", double1 == 0.5753722020923162d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(7.4401283747656155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1438420397929913d + "'", double1 == 0.1438420397929913d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.330835323696633d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.087048061332903d) + "'", double1 == (-4.087048061332903d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double2 = org.apache.commons.math.util.FastMath.max((-30.33492650841293d), (-4.087048061332903d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.087048061332903d) + "'", double2 == (-4.087048061332903d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.000000000000004d + "'", double1 == 16.000000000000004d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.cos(38.856604899005376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4016366462400668d + "'", double1 == 0.4016366462400668d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double2 = org.apache.commons.math.util.FastMath.pow(100.00000000000001d, (-29.75055055925605d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.154270116608051E-60d + "'", double2 == 3.154270116608051E-60d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.sin(23.90900527672878d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9403766436866177d) + "'", double1 == (-0.9403766436866177d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.NEGATIVE_INFINITY, (double) 16L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5961722400471147d) + "'", double1 == (-0.5961722400471147d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            long long2 = randomDataImpl0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-39.45149093996467d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.8004056954635872E16d + "'", double1 == 6.8004056954635872E16d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.expm1(23.240092259911513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.238921607534573E10d + "'", double1 == 1.238921607534573E10d);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        int int13 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 0, (int) (short) 10);
//        try {
//            long long15 = randomDataImpl1.nextPoisson((-1.5703979398765098d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.57 is smaller than, or equal to, the minimum (0): mean (-1.57)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong((long) 3, (long) 23);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl1.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Object[] objArray8 = numberIsTooLargeException6.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray8);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        try {
//            double double9 = randomDataImpl0.nextBeta((-7.981796571613402d), (-1.5703979398765098d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.273");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-27.612756347546235d) + "'", double3 == (-27.612756347546235d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-45.38419114062624d) + "'", double6 == (-45.38419114062624d));
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-69.00793782111205d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeed((long) '#');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl0.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 46, 25.170350785539537d, (-5.396474542125383d), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (100) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5491895702039902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5219961460822345d + "'", double1 == 0.5219961460822345d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException12.addSuppressed((java.lang.Throwable) outOfRangeException16);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException16);
        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException16.getSpecificPattern();
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0, (double) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        try {
//            int[] intArray9 = randomDataImpl0.nextPermutation(0, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0): permutation size (100) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-26.496427864656013d) + "'", double3 == (-26.496427864656013d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 75.92035042924395d + "'", double6 == 75.92035042924395d);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.888237470923471d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1332.8708530961976d + "'", double1 == 1332.8708530961976d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(32.0d, 29.703125919808457d, 1.5707963267948966d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.rint(13.386197013275423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math.random.RandomDataImpl();
//        double double21 = randomDataImpl18.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException30);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException35.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        java.lang.Object[] objArray42 = new java.lang.Object[] { double21, (-21.486355222344105d), outOfRangeException39 };
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable17, objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooLargeException48.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException54.addSuppressed((java.lang.Throwable) outOfRangeException58);
//        java.lang.Object[] objArray60 = new java.lang.Object[] { outOfRangeException58 };
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable50, objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable49, objArray60);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable12, objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException68.addSuppressed((java.lang.Throwable) outOfRangeException72);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { outOfRangeException72 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable64, objArray74);
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable12, objArray74);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException83 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException83.addSuppressed((java.lang.Throwable) outOfRangeException87);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { outOfRangeException87, (-1), (short) 100, 3.4657359027997265d };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException("", objArray92);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray92);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray92);
//        java.lang.String str96 = mathIllegalArgumentException95.toString();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-52.544276585217055d) + "'", double21 == (-52.544276585217055d));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertNotNull(objArray92);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1): org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1)" + "'", str96.equals("org.apache.commons.math.exception.MathIllegalArgumentException: org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1): org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1)"));
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        double double12 = randomDataImpl0.nextChiSquare(6.447356879429591d);
//        try {
//            double double15 = randomDataImpl0.nextF((-52.544276585217055d), 1.5707963267948966d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -52.544 is smaller than, or equal to, the minimum (0): degrees of freedom (-52.544)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-7.6265484077366095d) + "'", double3 == (-7.6265484077366095d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.472819983898617d + "'", double6 == 21.472819983898617d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8ef6393dffe5d9b4fb9fc7d76b68f839e784b7a3acd8690e8c82740f0bbd07e20244ee82020be0a9e36aa4cf35e6b779b" + "'", str8.equals("8ef6393dffe5d9b4fb9fc7d76b68f839e784b7a3acd8690e8c82740f0bbd07e20244ee82020be0a9e36aa4cf35e6b779b"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.079818826648577d + "'", double12 == 8.079818826648577d);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-1.869048683494323d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 16.000000000000004d, 0.0d, (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric((-1), (int) (short) -1, 23);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-12.150854283665707d) + "'", double3 == (-12.150854283665707d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 26.6154340632935d + "'", double6 == 26.6154340632935d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5aede3742757d74ce1cd63b1e3160804f0137a555e9c4797b2801d472d0caba47873969c47ae557aaf58afaba9ba8dced" + "'", str8.equals("5aede3742757d74ce1cd63b1e3160804f0137a555e9c4797b2801d472d0caba47873969c47ae557aaf58afaba9ba8dced"));
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 9L, 23.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 23.0f + "'", float2 == 23.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.exp(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        double double9 = randomDataImpl6.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { double9, (-21.486355222344105d), outOfRangeException27 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable5, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException36.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException42.addSuppressed((java.lang.Throwable) outOfRangeException46);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { outOfRangeException46 };
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable38, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable37, objArray48);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray57 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray57);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable37, objArray57);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 9L, (java.lang.Number) 1.0f);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-34.215033486187366d) + "'", double9 == (-34.215033486187366d));
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray57);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100.0d, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number8 = outOfRangeException7.getArgument();
//        java.lang.Object[] objArray13 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray13);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException18.addSuppressed((java.lang.Throwable) outOfRangeException22);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), maxIterationsExceededException14, outOfRangeException18, (byte) -1 };
//        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, "", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray38 = new java.lang.Object[] { outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable28, objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7, localizable27, objArray38);
//        java.lang.Object[] objArray42 = null;
//        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40, "", objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
//        double double53 = randomDataImpl50.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { double53, (-21.486355222344105d), outOfRangeException71 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable49, objArray74);
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException80 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable76, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable81 = numberIsTooLargeException80.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable82 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException86.addSuppressed((java.lang.Throwable) outOfRangeException90);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { outOfRangeException90 };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable82, objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable81, objArray92);
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable44, objArray92);
//        java.lang.Throwable throwable96 = null;
//        try {
//            numberIsTooLargeException3.addSuppressed(throwable96);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertNotNull(localizable44);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 31.25610810297345d + "'", double53 == 31.25610810297345d);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray92);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
//        double double22 = randomDataImpl19.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException27.addSuppressed((java.lang.Throwable) outOfRangeException31);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException36.addSuppressed((java.lang.Throwable) outOfRangeException40);
//        outOfRangeException27.addSuppressed((java.lang.Throwable) outOfRangeException40);
//        java.lang.Object[] objArray43 = new java.lang.Object[] { double22, (-21.486355222344105d), outOfRangeException40 };
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException17, localizable18, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooLargeException49.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException55.addSuppressed((java.lang.Throwable) outOfRangeException59);
//        java.lang.Object[] objArray61 = new java.lang.Object[] { outOfRangeException59 };
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable51, objArray61);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException17, localizable50, objArray61);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable13, objArray61);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(throwable0, localizable6, objArray61);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 46.83418683220712d + "'", double22 == 46.83418683220712d);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray61);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(12.030081469349339d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.03008146934934d + "'", double1 == 12.03008146934934d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int2 = org.apache.commons.math.util.FastMath.max(9, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9403766436866177d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6095192644456385d) + "'", double1 == (-0.6095192644456385d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            double double16 = normalDistributionImpl9.cumulativeProbability(1.247957232467248E-289d, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.68569372874651d + "'", double3 == 39.68569372874651d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Number number37 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0.0d + "'", number37.equals(0.0d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(2147483647);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.abs(20.53573111903292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.53573111903292d + "'", double1 == 20.53573111903292d);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure((long) 3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.869048683494323d), (-0.6682148579343544d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.668 is smaller than, or equal to, the minimum (0): standard deviation (-0.668)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (short) 100, 3.0365889718756627d, 0.008552897619382271d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.18471098751617E-112d + "'", double4 == 9.18471098751617E-112d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int2 = org.apache.commons.math.util.FastMath.max(52, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(9.18471098751617E-112d, (-1.330835323696633d), (-14.299400799032094d), (int) '#');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-21.486355222344105d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.486355222344102d) + "'", double1 == (-21.486355222344102d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5572730314344172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999606770605203d + "'", double1 == 0.9999606770605203d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.3071898789116161d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9531870602827999d + "'", double1 == 0.9531870602827999d);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeed();
//        try {
//            double double8 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number6 = outOfRangeException5.getArgument();
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray11);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException16.addSuppressed((java.lang.Throwable) outOfRangeException20);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), maxIterationsExceededException12, outOfRangeException16, (byte) -1 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, "", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException30.addSuppressed((java.lang.Throwable) outOfRangeException34);
        java.lang.Object[] objArray36 = new java.lang.Object[] { outOfRangeException34 };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable26, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable25, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray36);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0f + "'", number6.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.10516633568161556d, number1, true);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        java.lang.Object[] objArray71 = convergenceException70.getArguments();
//        java.lang.Throwable throwable72 = null;
//        try {
//            convergenceException70.addSuppressed(throwable72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 17.47652633555757d + "'", double15 == 17.47652633555757d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(objArray71);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 3L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.0365889718756627d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.atanh(23.593087987224425d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5961722400471147d), (-0.6682148579343544d), (double) 10L, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.log10((-3.727497750802033d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 8, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        double double9 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(1);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6" + "'", str11.equals("6"));
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
        try {
            double double7 = randomDataImpl1.nextCauchy((-3.727497750802033d), (-1.6049908287387529d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.605 is smaller than, or equal to, the minimum (0): scale (-1.605)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.23866189121683237d) + "'", double1 == (-0.23866189121683237d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        long long1 = org.apache.commons.math.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-25.28369966782005d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, 16L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double2 = org.apache.commons.math.util.FastMath.max(13.386197013275423d, (-1.6049908287387529d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.386197013275423d + "'", double2 == 13.386197013275423d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        int int10 = randomDataImpl0.nextZipf((int) (short) 1, (double) 1);
//        try {
//            int int14 = randomDataImpl0.nextHypergeometric(1, (int) ' ', 9);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (1): number of successes (32) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.37694921286197d + "'", double3 == 31.37694921286197d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 86.70925424272744d + "'", double6 == 86.70925424272744d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.141592653589793d, (-25.28369966782005d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0179725674573565d + "'", double2 == 3.0179725674573565d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 8, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.8049262717364689d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14733359807178958d + "'", double1 == 0.14733359807178958d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.656612876329999E-10d + "'", double1 == 4.656612876329999E-10d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599457d + "'", double1 == 0.6931471805599457d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5491895702039902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7318489070211762d + "'", double1 == 1.7318489070211762d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
        try {
            double double7 = randomDataImpl1.nextWeibull((-39.45149093996467d), (-35.73223002348827d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -39.451 is smaller than, or equal to, the minimum (0): shape (-39.451)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double5 = randomDataImpl0.nextExponential(41.56841073072807d);
//        try {
//            int int8 = randomDataImpl0.nextBinomial(0, 37.323824837263125d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 37.324 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.27749977712661d + "'", double3 == 35.27749977712661d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 16.804245945475145d + "'", double5 == 16.804245945475145d);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.asin(35.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(35.55071304099612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.53527122245521d + "'", double1 == 90.53527122245521d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.7358276959765746d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2203625969295993d) + "'", double1 == (-1.2203625969295993d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) (short) 100, (-9.240301173036697d), 8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.894103403691348d, (java.lang.Number) 29.419799498875033d, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-52.544276585217055d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.7454885381344782d) + "'", double1 == (-3.7454885381344782d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.07244619726107E9d), 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.07244619726107E9d) + "'", double2 == (-1.07244619726107E9d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(18.56057086370086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1063.4423758435444d + "'", double1 == 1063.4423758435444d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 23L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.ceil(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextT(1.0111115017970183d);
//        try {
//            int int11 = randomDataImpl1.nextPascal((int) (byte) 100, (double) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.8626808107167012d) + "'", double8 == (-0.8626808107167012d));
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException47.addSuppressed((java.lang.Throwable) outOfRangeException51);
//        java.lang.Object[] objArray53 = new java.lang.Object[] { outOfRangeException51 };
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable42, objArray53);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray62 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray62);
//        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable42, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 39.74029672841412d + "'", double14 == 39.74029672841412d);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(objArray62);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.atan(36.7557957675102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543596442919934d + "'", double1 == 1.543596442919934d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 16L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.lang.Object[] objArray2 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray2);
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException47.addSuppressed((java.lang.Throwable) outOfRangeException51);
//        java.lang.Object[] objArray53 = new java.lang.Object[] { outOfRangeException51 };
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable42, objArray53);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray62 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray62);
//        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable42, objArray62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl();
//        double double73 = randomDataImpl70.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException78.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException91 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException87.addSuppressed((java.lang.Throwable) outOfRangeException91);
//        outOfRangeException78.addSuppressed((java.lang.Throwable) outOfRangeException91);
//        java.lang.Object[] objArray94 = new java.lang.Object[] { double73, (-21.486355222344105d), outOfRangeException91 };
//        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException68, localizable69, objArray94);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable42, objArray94);
//        java.lang.Object[] objArray97 = null;
//        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable42, objArray97);
//        org.apache.commons.math.exception.util.Localizable localizable99 = maxIterationsExceededException3.getGeneralPattern();
//        org.junit.Assert.assertNotNull(objArray2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 40.39680236847813d + "'", double14 == 40.39680236847813d);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 51.73638337272564d + "'", double73 == 51.73638337272564d);
//        org.junit.Assert.assertNotNull(objArray94);
//        org.junit.Assert.assertNotNull(localizable99);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(12.03008146934934d, 29.419799498875037d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.030081469349343d + "'", double2 == 12.030081469349343d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.atanh(38.856604899005376d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.984137914278307E171d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.984137914278307E171d + "'", double1 == 3.984137914278307E171d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.247957232467248E-289d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong(0L, 9L);
//        try {
//            int int7 = randomDataImpl1.nextInt(46, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 46 is larger than, or equal to, the maximum (0): lower bound (46) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (-1.2203625969295993d), false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(25.28976648764677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.441389692269958d + "'", double1 == 0.441389692269958d);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            randomDataImpl1.setSecureAlgorithm("3035ea3a17", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "c" + "'", str6.equals("c"));
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.sin((-30.33492650841293d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8824287071219132d + "'", double1 == 0.8824287071219132d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math.util.FastMath.pow(8.079818826648577d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextT(1.0111115017970183d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("c", "97b11488d23440bdbe684e25f8d5bdc6fb0d92434d7cc5192c7d9e2f0585c69dc8f1a01120dada43bcd98a52fc81fb19e");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 97b11488d23440bdbe684e25f8d5bdc6fb0d92434d7cc5192c7d9e2f0585c69dc8f1a01120dada43bcd98a52fc81fb19e");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2313885007197392d + "'", double8 == 1.2313885007197392d);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.7853981633974483d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
//        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
//        double double19 = randomDataImpl16.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException33.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { double19, (-21.486355222344105d), outOfRangeException37 };
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14, localizable15, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException46.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException52.addSuppressed((java.lang.Throwable) outOfRangeException56);
//        java.lang.Object[] objArray58 = new java.lang.Object[] { outOfRangeException56 };
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable48, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14, localizable47, objArray58);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable10, objArray58);
//        org.apache.commons.math.exception.util.Localizable localizable62 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException66.addSuppressed((java.lang.Throwable) outOfRangeException70);
//        java.lang.Object[] objArray72 = new java.lang.Object[] { outOfRangeException70 };
//        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException(localizable62, objArray72);
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable10, objArray72);
//        java.lang.Object[] objArray75 = convergenceException74.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "hi!", objArray75);
//        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
//        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 5.7537169569494555d + "'", double19 == 5.7537169569494555d);
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertNotNull(objArray72);
//        org.junit.Assert.assertNotNull(objArray75);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.428182669496151d), 0.3985971052310144d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3985971052310144d + "'", double2 == 0.3985971052310144d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97L, (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        int[] intArray10 = randomDataImpl1.nextPermutation(9, 1);
//        try {
//            double double13 = randomDataImpl1.nextGaussian(51.73638337272564d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 24.6871949692047d + "'", double7 == 24.6871949692047d);
//        org.junit.Assert.assertNotNull(intArray10);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0f, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-25.28369966782005d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.9236979313786837d) + "'", double1 == (-3.9236979313786837d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.ceil(51.73638337272564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0416077003882071d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        try {
//            int int10 = randomDataImpl1.nextBinomial((int) (byte) 100, 12.030081469349343d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 12.03 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 23.470921247786922d + "'", double7 == 23.470921247786922d);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.005000000000024d + "'", double1 == 50.005000000000024d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException5.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Object[] objArray11 = new java.lang.Object[] { outOfRangeException9 };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable1, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("00e2f389208e19f223414c9", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 23.0f, (java.lang.Number) 0, true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (-1), 87.70102319954509d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (-0.428182669496151d), (java.lang.Number) (-1), (java.lang.Number) (-53.66088876942466d));
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 36.45014802004433d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 117.41872726393613d, (java.lang.Number) 47.59321336587365d, (java.lang.Number) 1332.8708530961976d);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 15.799477191576866d + "'", double15 == 15.799477191576866d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeed();
//        try {
//            double double9 = randomDataImpl1.nextBeta((double) (byte) 0, (-38.285891167572395d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.88");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.23866189121683237d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 16.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.6049908287387529d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0135957911625109d) + "'", double1 == (-1.0135957911625109d));
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int10 = randomDataImpl0.nextSecureInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5425311286897351d + "'", double3 == 0.5425311286897351d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 74.34514966723447d + "'", double6 == 74.34514966723447d);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.asin(5.298342365610589d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-24.53836859378115d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray37 = convergenceException36.getArguments();
        java.lang.Class<?> wildcardClass38 = objArray37.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        try {
//            java.lang.String str11 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 45.17997330880596d + "'", double3 == 45.17997330880596d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-40.45064088617185d) + "'", double6 == (-40.45064088617185d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) (short) 100);
        java.lang.String str43 = notStrictlyPositiveException42.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): " + "'", str43.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): "));
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        int[] intArray10 = randomDataImpl1.nextPermutation(9, 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((-35.337174945557074d), 48.49877948001509d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 26.82468675505176d + "'", double7 == 26.82468675505176d);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-53.27157646179201d) + "'", double14 == (-53.27157646179201d));
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double10 = randomDataImpl0.nextUniform(0.5772156649015329d, 0.3948363911875286d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.577 is larger than, or equal to, the maximum (0.395): lower bound (0.577) must be strictly less than upper bound (0.395)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.334671320173232d + "'", double3 == 29.334671320173232d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 70.89739656291572d + "'", double6 == 70.89739656291572d);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-18.161832063446543d), 4.656612876329999E-10d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(103.39325843506825d, (double) 100.0f, 13.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 48.49877948001509d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.tan(12.030081469349343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5943965714711189d) + "'", double1 == (-0.5943965714711189d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.8004056954635872E16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100.0d, true);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
//        double double19 = randomDataImpl16.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException33.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { double19, (-21.486355222344105d), outOfRangeException37 };
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14, localizable15, objArray40);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable10, objArray40);
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooLargeException47.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable53 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl54 = new org.apache.commons.math.random.RandomDataImpl();
//        double double57 = randomDataImpl54.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException71.addSuppressed((java.lang.Throwable) outOfRangeException75);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException75);
//        java.lang.Object[] objArray78 = new java.lang.Object[] { double57, (-21.486355222344105d), outOfRangeException75 };
//        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException52, localizable53, objArray78);
//        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable48, objArray78);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray78);
//        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "f8e761610a5d06d3d7e1c76", objArray78);
//        boolean boolean83 = numberIsTooLargeException3.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.357519157026735d + "'", double19 == 8.357519157026735d);
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 9.418630700694559d + "'", double57 == 9.418630700694559d);
//        org.junit.Assert.assertNotNull(objArray78);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            java.lang.String str2 = randomDataImpl0.nextSecureHexString((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 46L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.0d + "'", double1 == 46.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math.util.FastMath.atan2(47.59321336587365d, (-1.998481895605531d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6127625736021807d + "'", double2 == 1.6127625736021807d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, (long) 23);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double10 = randomDataImpl1.nextCauchy(0.7615941559557649d, (-3.7454885381344782d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.745 is smaller than, or equal to, the minimum (0): scale (-3.745)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "d" + "'", str6.equals("d"));
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextLong((long) 8, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 8 is larger than, or equal to, the maximum (0): lower bound (8) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(9.18471098751617E-112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1854111554711522E222d + "'", double1 == 1.1854111554711522E222d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
        randomDataImpl1.reSeedSecure();
        try {
            long long9 = randomDataImpl1.nextPoisson((-1.330835323696633d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.331 is smaller than, or equal to, the minimum (0): mean (-1.331)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1256810541161046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.10516633568161556d, (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.45812191139469804d + "'", double3 == 0.45812191139469804d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.1438420397929913d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException53.getSpecificPattern();
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException53);
//        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-37.757761579131284d) + "'", double8 == (-37.757761579131284d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 23L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 23.0f + "'", float1 == 23.0f);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
//        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        double double18 = randomDataImpl15.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray39 = new java.lang.Object[] { double18, (-21.486355222344105d), outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException13, localizable14, objArray39);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable9, objArray39);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "", objArray39);
//        int int43 = maxIterationsExceededException1.getMaxIterations();
//        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-34.47168563173826d) + "'", double18 == (-34.47168563173826d));
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, (float) 46);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 46.0f + "'", float2 == 46.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.5572730314344172d, (-45.24581447173601d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.special.Erf.erf(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999779095030014d + "'", double1 == 0.9999779095030014d);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextT(0.4016366462400668d);
//        try {
//            double double11 = randomDataImpl0.nextF((double) (short) 1, (-39.45149093996467d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -39.451 is smaller than, or equal to, the minimum (0): degrees of freedom (-39.451)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-16.292027990131054d) + "'", double3 == (-16.292027990131054d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 121.3518792059642d + "'", double6 == 121.3518792059642d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.448937303878159d + "'", double8 == 1.448937303878159d);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double2 = org.apache.commons.math.util.FastMath.pow((-3.354585234655074d), (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1538686558283915E27d + "'", double2 == 2.1538686558283915E27d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int1 = org.apache.commons.math.util.FastMath.abs(33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 46 + "'", int1 == 46);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-34.215033486187366d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        try {
//            int int13 = randomDataImpl0.nextPascal((int) (short) 10, (double) 32.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 32 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-43.7810110926091d) + "'", double3 == (-43.7810110926091d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 26.119858106330238d + "'", double6 == 26.119858106330238d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "83df6eb37d96667313d66a71e859d5d9a447362c797c7f03e1e1ba2ea66328890324f291b5196ec0ccd820f7987a1c264" + "'", str8.equals("83df6eb37d96667313d66a71e859d5d9a447362c797c7f03e1e1ba2ea66328890324f291b5196ec0ccd820f7987a1c264"));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 46L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.2640737523317456d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.264073752331746d + "'", double1 == 2.264073752331746d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.cos(26.84435564551039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14035315365929818d) + "'", double1 == (-0.14035315365929818d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(48.49877948001509d, (-15.892342545699124d), 11.331125335478156d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -15.892 is smaller than, or equal to, the minimum (0): standard deviation (-15.892)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 1063.4423758435444d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-14.80219205628759d) + "'", double8 == (-14.80219205628759d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        long long5 = randomDataImpl1.nextSecureLong((long) 3, (long) 23);
//        try {
//            int int9 = randomDataImpl1.nextHypergeometric(3, 46, 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 46 is larger than the maximum (3): number of successes (46) must be less than or equal to population size (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 21L + "'", long5 == 21L);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-30.33492650841293d), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-30.334926508412927d) + "'", double2 == (-30.334926508412927d));
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double13 = normalDistributionImpl10.cumulativeProbability(0.0d, 0.0d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(37.01830674542887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6460913362209602d + "'", double1 == 0.6460913362209602d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.tan((-2.561084565363064d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6558948735501228d + "'", double1 == 0.6558948735501228d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        long long2 = org.apache.commons.math.util.FastMath.min(2147483647L, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong(0L, 9L);
//        try {
//            int int8 = randomDataImpl1.nextHypergeometric(10, (int) (short) 10, 33);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 33 is larger than the maximum (10): sample size (33) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 35.0d, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than, or equal to, the maximum (35)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than, or equal to, the maximum (35)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
//        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray63 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray63);
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6, localizable43, objArray63);
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray63);
//        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable0, objArray63);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 24.27920069666071d + "'", double15 == 24.27920069666071d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray63);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1L);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeed((long) '#');
//        java.lang.String str13 = randomDataImpl0.nextHexString((int) (short) 10);
//        double double16 = randomDataImpl0.nextUniform(3.552713678800501E-15d, (double) ' ');
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3035ea3a17" + "'", str13.equals("3035ea3a17"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 15.885206432474726d + "'", double16 == 15.885206432474726d);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.acos((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-27.058819921025353d), (java.lang.Number) (-35.73223002348827d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-35.73223002348827d) + "'", number4.equals((-35.73223002348827d)));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.special.Erf.erf(1.3520933719397079E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5256739928646914E-9d + "'", double1 == 1.5256739928646914E-9d);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        java.lang.Object[] objArray71 = convergenceException70.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable72 = convergenceException70.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 56.25545913130665d + "'", double15 == 56.25545913130665d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(objArray71);
//        org.junit.Assert.assertNull(localizable72);
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double4 = normalDistributionImpl3.getMean();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double double6 = normalDistributionImpl3.getStandardDeviation();
//        double double7 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.40568855600302195d + "'", double7 == 0.40568855600302195d);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.3071898789116161d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0053614748158103956d + "'", double1 == 0.0053614748158103956d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        double double10 = randomDataImpl7.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException19);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { double10, (-21.486355222344105d), outOfRangeException28 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable6, objArray31);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
//        java.lang.Object[] objArray45 = new java.lang.Object[] { outOfRangeException43 };
//        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable35, objArray45);
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException33, "3035ea3a17", objArray45);
//        int int48 = maxIterationsExceededException33.getMaxIterations();
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 62.803410882230985d + "'", double10 == 62.803410882230985d);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(objArray45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 52 + "'", int48 == 52);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(22025.465794806718d, 8.079818826648577d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22025.465794806714d + "'", double2 == 22025.465794806714d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int1 = org.apache.commons.math.util.FastMath.abs(55);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 55 + "'", int1 == 55);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6558948735501228d, 0.3387904745834194d, 0.0d, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (100) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(53.979877037373456d, 46.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.13592273487762063d + "'", double2 == 0.13592273487762063d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double15 = normalDistributionImpl9.cumulativeProbability((double) '#');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.04372362352729d + "'", double3 == 9.04372362352729d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        double double12 = randomDataImpl0.nextChiSquare(6.447356879429591d);
//        try {
//            long long14 = randomDataImpl0.nextPoisson((-11.794040996526578d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -11.794 is smaller than, or equal to, the minimum (0): mean (-11.794)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.899445296945723d + "'", double3 == 8.899445296945723d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 23.462257935714877d + "'", double6 == 23.462257935714877d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "045391b22557368887396b1d14a1a16e51d7c84b1f0b7f88788daddc462fba679669f5a216d54a368db378434e114fea5" + "'", str8.equals("045391b22557368887396b1d14a1a16e51d7c84b1f0b7f88788daddc462fba679669f5a216d54a368db378434e114fea5"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.079818826648577d + "'", double12 == 8.079818826648577d);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(13.539695208827096d, (double) 24, (-0.7853981633974483d), 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 24 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }
}

