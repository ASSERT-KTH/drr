import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        int int1 = org.apache.commons.math.util.FastMath.abs(48);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.0365889718756627d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.052998475588979806d + "'", double1 == 0.052998475588979806d);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        double double1 = org.apache.commons.math.util.FastMath.exp((-11.692389533925372d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.357179786238688E-6d + "'", double1 == 8.357179786238688E-6d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException12.addSuppressed((java.lang.Throwable) outOfRangeException16);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException16);
        java.lang.Number number19 = outOfRangeException16.getHi();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.5961722400471147d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5509163809555423d + "'", double1 == 0.5509163809555423d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 23.90900527672878d, (java.lang.Number) 24);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [23.909, 24] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [23.909, 24] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) 2);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8008435583001444d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2664165549094419E-14d + "'", double1 == 1.2664165549094419E-14d);
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long12 = randomDataImpl0.nextLong(1L, (long) '4');
//        long long15 = randomDataImpl0.nextSecureLong((long) 2, (long) '#');
//        java.lang.String str17 = randomDataImpl0.nextSecureHexString(100);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 18L + "'", long12 == 18L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 13L + "'", long15 == 13L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ce00b185fd6e34827a844f74e42e1b34b4e688848861cde500fc7b5287deb213ef5aab48f11769efbe8ca968525fdac986b3" + "'", str17.equals("ce00b185fd6e34827a844f74e42e1b34b4e688848861cde500fc7b5287deb213ef5aab48f11769efbe8ca968525fdac986b3"));
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        long long2 = org.apache.commons.math.util.FastMath.min(41L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 41L + "'", long2 == 41L);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test12");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 1.057940522963217d);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-41.854623715326646d) + "'", double15 == (-41.854623715326646d));
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        java.lang.Number number84 = numberIsTooLargeException4.getMax();
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4);
//        java.lang.Object[] objArray86 = numberIsTooLargeException4.getArguments();
//        java.lang.Number number87 = numberIsTooLargeException4.getMax();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-39.61059197374597d) + "'", double23 == (-39.61059197374597d));
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (-1.0d) + "'", number84.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(objArray86);
//        org.junit.Assert.assertTrue("'" + number87 + "' != '" + (-1.0d) + "'", number87.equals((-1.0d)));
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) (short) -1);
        double[] doubleArray7 = normalDistributionImpl3.sample(8);
        double double8 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 12.801827480081469d, (java.lang.Number) (-9.240301173036697d), false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-34.47168563173826d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.233495780039839d) + "'", double1 == (-4.233495780039839d));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.872401723124452E9d + "'", double1 == 4.872401723124452E9d);
    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test18");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        double double12 = randomDataImpl0.nextChiSquare(6.447356879429591d);
//        try {
//            double double14 = randomDataImpl0.nextT((-24.6121107377563d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -24.612 is smaller than, or equal to, the minimum (0): degrees of freedom (-24.612)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.315299405945783d) + "'", double3 == (-0.315299405945783d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.9526215903774d + "'", double6 == 21.9526215903774d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "d915af750c6d5ed0304576dc5a9f2665f77b213fd0c0a73cc7f242aa857cf42db939622b8e44ec046be96339eff462b1a" + "'", str8.equals("d915af750c6d5ed0304576dc5a9f2665f77b213fd0c0a73cc7f242aa857cf42db939622b8e44ec046be96339eff462b1a"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.079818826648577d + "'", double12 == 8.079818826648577d);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.888237470923471d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.990642745075813d + "'", double1 == 1.990642745075813d);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test20");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        long long10 = randomDataImpl0.nextPoisson(46.0d);
//        try {
//            int int13 = randomDataImpl0.nextInt((int) (byte) 100, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-24.284263460077934d) + "'", double3 == (-24.284263460077934d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-31.95799097548612d) + "'", double6 == (-31.95799097548612d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 41L + "'", long10 == 41L);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        double double1 = org.apache.commons.math.util.FastMath.rint((-11.435041730035293d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11.0d) + "'", double1 == (-11.0d));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        double double1 = org.apache.commons.math.util.FastMath.ceil(234.70172344281826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 235.0d + "'", double1 == 235.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1647428954245884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.758550800399407d + "'", double1 == 1.758550800399407d);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.density((-0.8813735870195429d));
        double[] doubleArray9 = normalDistributionImpl3.sample(22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27053650577353006d + "'", double7 == 0.27053650577353006d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test25");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        long long10 = randomDataImpl0.nextPoisson(46.0d);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(24);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-26.56865994130547d) + "'", double3 == (-26.56865994130547d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-42.87785430109899d) + "'", double6 == (-42.87785430109899d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 41L + "'", long10 == 41L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5cd196d5f22925a965fb4f32" + "'", str12.equals("5cd196d5f22925a965fb4f32"));
//    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeedSecure((-1L));
        try {
            long long7 = randomDataImpl1.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(66);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-13.951916564959916d) + "'", double3 == (-13.951916564959916d));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "46ea409325bcfa05143a8a466fd3ddd1a3e85ff6f267431d02d74d22daf37f125d" + "'", str7.equals("46ea409325bcfa05143a8a466fd3ddd1a3e85ff6f267431d02d74d22daf37f125d"));
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.869048683494323d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 60, (long) 16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60L + "'", long2 == 60L);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        java.lang.Number number84 = outOfRangeException82.getArgument();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-12.337014878054646d) + "'", double23 == (-12.337014878054646d));
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 29.419799498875037d + "'", number84.equals(29.419799498875037d));
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        double double1 = org.apache.commons.math.util.FastMath.ulp(23.07421056216998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        double double1 = org.apache.commons.math.special.Gamma.digamma(50.005000000000024d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.902090672328277d + "'", double1 == 3.902090672328277d);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test33");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        randomDataImpl0.reSeed((long) 9);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-12.82183506880006d) + "'", double3 == (-12.82183506880006d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-45.139096336523615d) + "'", double6 == (-45.139096336523615d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        double double2 = org.apache.commons.math.util.FastMath.min((-21.486355222344102d), 8.442956197375528d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-21.486355222344102d) + "'", double2 == (-21.486355222344102d));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        double double1 = org.apache.commons.math.util.FastMath.sinh(90.53527122245521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0421703515352069E39d + "'", double1 == 1.0421703515352069E39d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        double double1 = org.apache.commons.math.special.Erf.erf(28.635537529586227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.6127625736021807d, (-7.730555100289406d), 1.586013452313431E15d, (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.5780369654501218d, (java.lang.Number) (-35.04534510850654d), false);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        double double1 = org.apache.commons.math.util.FastMath.exp(97.81559706275728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0253390172074904E42d + "'", double1 == 3.0253390172074904E42d);
    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test40");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long6 = randomDataImpl0.nextLong((long) 3, (long) '#');
//        long long8 = randomDataImpl0.nextPoisson(4.502005384096932d);
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric((int) (byte) -1, 30, 22);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.2891035209703343d) + "'", double3 == (-2.2891035209703343d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 20L + "'", long6 == 20L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
//    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextExponential(809.2800123129819d);
//        randomDataImpl0.reSeed(6L);
//        int int13 = randomDataImpl0.nextBinomial(60, 0.6483608274590866d);
//        java.lang.String str15 = randomDataImpl0.nextHexString(9);
//        try {
//            long long17 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-25.929699308532552d) + "'", double3 == (-25.929699308532552d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 72.26805813148245d + "'", double6 == 72.26805813148245d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 19.830046441364523d + "'", double8 == 19.830046441364523d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 41 + "'", int13 == 41);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "e5d1e214e" + "'", str15.equals("e5d1e214e"));
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 28L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.446257064290475E12d + "'", double1 == 1.446257064290475E12d);
    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test43");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(23);
//        try {
//            long long13 = randomDataImpl0.nextLong((long) 5, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (0): lower bound (5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-15.586297925367532d) + "'", double3 == (-15.586297925367532d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-55.42276374095881d) + "'", double6 == (-55.42276374095881d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c2bbd7f9a301523e118b791" + "'", str10.equals("c2bbd7f9a301523e118b791"));
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (-0.9403766436866177d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test45");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeed((long) '#');
//        double double13 = randomDataImpl0.nextChiSquare(0.008552897619382271d);
//        int int16 = randomDataImpl0.nextSecureInt(0, (int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0d) + "'", double9 == (-2.0d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.3520933719397079E-9d + "'", double13 == 1.3520933719397079E-9d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 690516.0404842675d, (java.lang.Number) 1.057940522963217d, (java.lang.Number) 10.894103403691348d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number9 = outOfRangeException8.getArgument();
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), maxIterationsExceededException15, outOfRangeException19, (byte) -1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException8, "", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "f8e761610a5d06d3d7e1c76", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException28.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(localizable30);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        double double6 = normalDistributionImpl3.sample();
        double[] doubleArray8 = normalDistributionImpl3.sample(5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-53.66088876942466d) + "'", double6 == (-53.66088876942466d));
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 33, (float) 13L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test49");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "e" + "'", str6.equals("e"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3758916972695625d + "'", double8 == 0.3758916972695625d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.010176273414244d + "'", double9 == 2.010176273414244d);
//    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(16.000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.000000000000007d + "'", double1 == 16.000000000000007d);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(23);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double14 = randomDataImpl0.nextGaussian(29.703125919808457d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.41940152839381d + "'", double3 == 34.41940152839381d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-31.275419289796d) + "'", double6 == (-31.275419289796d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3aa82c5b7df4507e1849cf4" + "'", str10.equals("3aa82c5b7df4507e1849cf4"));
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        double double2 = org.apache.commons.math.util.FastMath.min(3.754590486863095d, (-37.421876280564334d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-37.421876280564334d) + "'", double2 == (-37.421876280564334d));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        long long2 = org.apache.commons.math.util.FastMath.max(6L, 46L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 46L + "'", long2 == 46L);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        double double1 = org.apache.commons.math.special.Erf.erf(4.656612876329999E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.254424958879477E-10d + "'", double1 == 5.254424958879477E-10d);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        java.lang.Object[] objArray13 = numberIsTooLargeException11.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "4455daa291e1bd6973f839c", objArray13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test56");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextExponential(809.2800123129819d);
//        randomDataImpl0.reSeed(6L);
//        int int13 = randomDataImpl0.nextBinomial(60, 0.6483608274590866d);
//        double double15 = randomDataImpl0.nextExponential(307.55711343113023d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.042872606642417d) + "'", double3 == (-11.042872606642417d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81.47596274544769d + "'", double6 == 81.47596274544769d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 28.977694882991724d + "'", double8 == 28.977694882991724d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 41 + "'", int13 == 41);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 167.73352357682458d + "'", double15 == 167.73352357682458d);
//    }

//    @Test
//    public void test57() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test57");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
//        double double19 = randomDataImpl16.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException33.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { double19, (-21.486355222344105d), outOfRangeException37 };
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14, localizable15, objArray40);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable10, objArray40);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray40);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl52 = new org.apache.commons.math.random.RandomDataImpl();
//        double double55 = randomDataImpl52.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException60.addSuppressed((java.lang.Throwable) outOfRangeException64);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException69.addSuppressed((java.lang.Throwable) outOfRangeException73);
//        outOfRangeException60.addSuppressed((java.lang.Throwable) outOfRangeException73);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { double55, (-21.486355222344105d), outOfRangeException73 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException50, localizable51, objArray76);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray76);
//        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException43, "00e2f389208e19f223414c9", objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("6", objArray76);
//        java.lang.String str81 = convergenceException80.toString();
//        org.junit.Assert.assertNotNull(localizable4);
//        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-15.55898617762543d) + "'", double19 == (-15.55898617762543d));
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-4.872297318073479d) + "'", double55 == (-4.872297318073479d));
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "org.apache.commons.math.ConvergenceException: 6" + "'", str81.equals("org.apache.commons.math.ConvergenceException: 6"));
//    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 59);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 59 + "'", int1 == 59);
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test59");
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) (-2.561084565363064d), false);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
//        java.lang.Object[] objArray10 = numberIsTooLargeException8.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException8.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException17.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl24 = new org.apache.commons.math.random.RandomDataImpl();
//        double double27 = randomDataImpl24.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { double27, (-21.486355222344105d), outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException22, localizable23, objArray48);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable50, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException54.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException60.addSuppressed((java.lang.Throwable) outOfRangeException64);
//        java.lang.Object[] objArray66 = new java.lang.Object[] { outOfRangeException64 };
//        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable56, objArray66);
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException22, localizable55, objArray66);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable18, objArray66);
//        org.apache.commons.math.exception.util.Localizable localizable70 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException74.addSuppressed((java.lang.Throwable) outOfRangeException78);
//        java.lang.Object[] objArray80 = new java.lang.Object[] { outOfRangeException78 };
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable70, objArray80);
//        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(localizable18, objArray80);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) outOfRangeException86);
//        java.lang.Number number88 = numberIsTooLargeException8.getMax();
//        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException8);
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.222881330833432d + "'", double27 == 3.222881330833432d);
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray66);
//        org.junit.Assert.assertNotNull(objArray80);
//        org.junit.Assert.assertTrue("'" + number88 + "' != '" + (-1.0d) + "'", number88.equals((-1.0d)));
//    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        int int2 = org.apache.commons.math.util.FastMath.min(41, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (-2.5536182031411174d), (java.lang.Number) (-27.939602077669555d), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        double double1 = org.apache.commons.math.special.Erf.erf((-2.561084565363064d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9997075760334299d) + "'", double1 == (-0.9997075760334299d));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-46.00780212784453d), (java.lang.Number) 0.6931471805599457d, (java.lang.Number) 23.523135811885126d);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException12.addSuppressed((java.lang.Throwable) outOfRangeException16);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException16);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number23 = outOfRangeException22.getArgument();
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException33.addSuppressed((java.lang.Throwable) outOfRangeException37);
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), maxIterationsExceededException29, outOfRangeException33, (byte) -1 };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException22, "", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException47.addSuppressed((java.lang.Throwable) outOfRangeException51);
        java.lang.Object[] objArray53 = new java.lang.Object[] { outOfRangeException51 };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray53);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException22, localizable42, objArray53);
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException55, "", objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException58.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable59, (java.lang.Number) 7.4401283747656155d, (java.lang.Number) 3, true);
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException65);
        java.lang.Object[] objArray67 = outOfRangeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1.0f + "'", number23.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(localizable59);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.40568855600302195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.740282675061427d + "'", double1 == 0.740282675061427d);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.5943965714711189d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-34.05641490234131d) + "'", double1 == (-34.05641490234131d));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 4.9E-324d, number11, (java.lang.Number) (-39.72126166450941d));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 35.87842008390203d);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray16);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        double double1 = org.apache.commons.math.util.FastMath.asin((-2.561084565363064d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test69() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test69");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeed((long) '#');
//        try {
//            double double14 = randomDataImpl0.nextBeta(18.718921847872362d, (double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.728");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
//    }

//    @Test
//    public void test70() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test70");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("4", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl();
//        double double20 = randomDataImpl17.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException25.addSuppressed((java.lang.Throwable) outOfRangeException29);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException34.addSuppressed((java.lang.Throwable) outOfRangeException38);
//        outOfRangeException25.addSuppressed((java.lang.Throwable) outOfRangeException38);
//        java.lang.Object[] objArray41 = new java.lang.Object[] { double20, (-21.486355222344105d), outOfRangeException38 };
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException15, localizable16, objArray41);
//        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable11, objArray41);
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("f8e761610a5d06d3d7e1c76", objArray41);
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, "a0aa585da7", objArray41);
//        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("9435cabc81e4661e478dfc9175036b5bf2b9a56b4c2ead", objArray41);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-37.434139401049904d) + "'", double20 == (-37.434139401049904d));
//        org.junit.Assert.assertNotNull(objArray41);
//    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test71");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        double double5 = randomDataImpl1.nextGaussian(0.0d, 3.8534087943986295d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.4019752598726116d + "'", double5 == 3.4019752598726116d);
//    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        int int2 = org.apache.commons.math.util.FastMath.min(55, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test73() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test73");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10L, (java.lang.Number) (short) -1, false);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
//        org.apache.commons.math.exception.util.Localizable localizable45 = maxIterationsExceededException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooLargeException51.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math.random.RandomDataImpl();
//        double double61 = randomDataImpl58.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException66.addSuppressed((java.lang.Throwable) outOfRangeException70);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException75.addSuppressed((java.lang.Throwable) outOfRangeException79);
//        outOfRangeException66.addSuppressed((java.lang.Throwable) outOfRangeException79);
//        java.lang.Object[] objArray82 = new java.lang.Object[] { double61, (-21.486355222344105d), outOfRangeException79 };
//        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException56, localizable57, objArray82);
//        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable52, objArray82);
//        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException44, "", objArray82);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException86 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable42, objArray82);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) (-11.042872606642417d));
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.906438853844823d) + "'", double14 == (-1.906438853844823d));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
//        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-1.348281028446879d) + "'", double61 == (-1.348281028446879d));
//        org.junit.Assert.assertNotNull(objArray82);
//    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.7982333814282114d, false);
    }

//    @Test
//    public void test75() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test75");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) (byte) 0, 9L);
//        int int7 = randomDataImpl1.nextZipf(60, (double) '4');
//        double double9 = randomDataImpl1.nextExponential(11.428649551460696d);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3L + "'", long4 == 3L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 21.498810184029146d + "'", double9 == 21.498810184029146d);
//    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 100.0f, (double) 'a', 2.3258674091854363d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test77() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test77");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        double double18 = randomDataImpl15.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray39 = new java.lang.Object[] { double18, (-21.486355222344105d), outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException13, localizable14, objArray39);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable9, objArray39);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray39);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
//        double double53 = randomDataImpl50.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { double53, (-21.486355222344105d), outOfRangeException71 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable49, objArray74);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray74);
//        org.apache.commons.math.exception.util.Localizable localizable78 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException82.addSuppressed((java.lang.Throwable) outOfRangeException86);
//        java.lang.Object[] objArray88 = new java.lang.Object[] { outOfRangeException86 };
//        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(localizable78, objArray88);
//        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException76, "3035ea3a17", objArray88);
//        java.lang.Object[] objArray91 = maxIterationsExceededException76.getArguments();
//        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException(localizable3, objArray91);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException96 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) 1.758550800399407d, (java.lang.Number) (-7.567186883855711d), (java.lang.Number) 2.5165725158734602E36d);
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-15.837191370550341d) + "'", double18 == (-15.837191370550341d));
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 8.691009405748627d + "'", double53 == 8.691009405748627d);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertNotNull(objArray88);
//        org.junit.Assert.assertNotNull(objArray91);
//    }
//}

