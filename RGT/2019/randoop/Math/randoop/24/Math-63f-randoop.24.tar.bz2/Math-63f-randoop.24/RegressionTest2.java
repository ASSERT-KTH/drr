import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35, (float) 195);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 195.0f + "'", float2 == 195.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1017118916));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.433387055957464d) + "'", double1 == (-21.433387055957464d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 68);
        java.math.BigInteger bigInteger13 = null;
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double2 = org.apache.commons.math.util.FastMath.pow(49.0d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.844126526089617d + "'", double2 == 14.844126526089617d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.311231547115194E15d, (-1.7752069378299702E7d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1583251731L), 1260250250L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2843501981L) + "'", long2 == (-2843501981L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1950, 9154068480L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9154066530L) + "'", long2 == (-9154066530L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.0064206193d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        java.lang.String str11 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.006 >= 1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.006 >= 1)"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (long) 16000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str7 = nonMonotonousSequenceException6.toString();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str14 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        java.lang.String str24 = nonMonotonousSequenceException21.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException21.getStrict();
        int int32 = nonMonotonousSequenceException21.getIndex();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        boolean boolean34 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.80675696E8f), (-1104039972), orderDirection35, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        java.lang.String str43 = nonMonotonousSequenceException41.toString();
        nonMonotonousSequenceException37.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        java.lang.Throwable[] throwableArray45 = nonMonotonousSequenceException37.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.8813735870195429d) + "'", number16.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 10.0d + "'", number42.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0149280275816275d + "'", double1 == 1.0149280275816275d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 68, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2097151999));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (long) 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1069449216));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-180675682L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 101, 5, 1950);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35, (double) (-35.0f), 160);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1076101120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 400L, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 400.0d + "'", double2 == 400.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 16000L, (-35));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4194304.0d + "'", double1 == 4194304.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 101);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 101L + "'", long1 == 101L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        int[] intArray20 = new int[] { '4', (-36), 398478411 };
        int[] intArray21 = new int[] {};
        int[] intArray27 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray35);
        int[] intArray38 = new int[] {};
        int[] intArray44 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray52 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray52);
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray44);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 398478401 + "'", int56 == 398478401);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1017118721, 9700L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1017118721L + "'", long2 == 1017118721L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-101L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-101L) + "'", long1 == (-101L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0L, 1.8151424220741028d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-2097151999), 1950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(9.0d, (double) 1017118720, (double) (-1806503139));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str24 = nonMonotonousSequenceException23.toString();
        java.lang.Number number25 = nonMonotonousSequenceException23.getPrevious();
        java.lang.String str26 = nonMonotonousSequenceException23.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException23.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        java.lang.Number number35 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-0.8813735870195429d) + "'", number35.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1.01711872E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0171187200000001E9d + "'", double1 == 1.0171187200000001E9d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-10));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 900, 172.70234343568234d, 2.1017612416682803d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.5707963267948966d), (double) 5, 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection12, true);
        double[] doubleArray16 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass18 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass20 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection22, true);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray6);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1079574559 + "'", int27 == 1079574559);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2097151999, (-1069449216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8834864931005E-310d + "'", double1 == 3.8834864931005E-310d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5613483159465477E9d, (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1079574559, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 3628800.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1104039972), (float) 1017118653);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.10403994E9f) + "'", float2 == (-1.10403994E9f));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double2 = org.apache.commons.math.util.FastMath.max(1100865.3094543158d, 0.0064206193d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1100865.3094543158d + "'", double2 == 1100865.3094543158d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 68, 900.0000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 900.0000000000001d + "'", double2 == 900.0000000000001d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 36L, 12.999999999999998d, (double) (-128));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1017118653, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.520543522634296d, 13.117797295600862d, (double) 1260250251);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.asin(4443057.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-52330332), (int) (byte) 10, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1017118721);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.136228346192656E274d), (java.lang.Number) 100.0d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.136228346192656E274d) + "'", number4.equals((-1.136228346192656E274d)));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1104039936L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass8 = orderDirection7.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1069449216) + "'", int6 == (-1069449216));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass12 = doubleArray8.getClass();
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.006420707498838454d);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray15);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection30, true);
        double[] doubleArray34 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray34.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        java.lang.Class<?> wildcardClass38 = doubleArray34.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection40, true);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray34);
        double[] doubleArray46 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        double[] doubleArray48 = null;
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.006420707498838454d);
        double[] doubleArray53 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        java.lang.Class<?> wildcardClass55 = doubleArray53.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        java.lang.Class<?> wildcardClass57 = doubleArray53.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection59, true);
        double[] doubleArray63 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        java.lang.Class<?> wildcardClass65 = doubleArray63.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        java.lang.Class<?> wildcardClass67 = doubleArray63.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection69, true);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray63);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray63);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray51);
        double[] doubleArray76 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        java.lang.Class<?> wildcardClass78 = doubleArray76.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray82 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray82);
        java.lang.Class<?> wildcardClass84 = doubleArray82.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray82);
        java.lang.Class<?> wildcardClass86 = doubleArray82.getClass();
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray82);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray76);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1079574559 + "'", int22 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 99.99357929250117d + "'", double73 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 99.99357929250117d + "'", double74 == 99.99357929250117d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.0d + "'", double80 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 99.99357929250117d + "'", double89 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.1805254859572636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18252582355595404d + "'", double1 == 0.18252582355595404d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int[] intArray3 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray4 = new int[] {};
        int[] intArray10 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray18);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray22 = new int[] {};
        int[] intArray28 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray36);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray45);
        int[] intArray57 = new int[] {};
        int[] intArray63 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray71 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray71);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray63);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray28);
        int[] intArray76 = new int[] {};
        int[] intArray82 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray82);
        int[] intArray84 = new int[] {};
        int[] intArray90 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray82, intArray90);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray82);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.5613483159465477E9d + "'", double21 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.FastMath.atan2(655.4848567108893d, 0.006420707498838454d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707865314389355d + "'", double2 == 1.5707865314389355d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2979.3805346802806d, 3.925693717026842d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.569478706773049d + "'", double2 == 1.569478706773049d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1.58325171E9f, 1.569478706773049d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.583251712E9d + "'", double2 == 1.583251712E9d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078964d + "'", double1 == 0.8414709848078964d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1017118721, (long) (-1017118721));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2097151999), 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4398046513201152001L + "'", long2 == 4398046513201152001L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.0f, (double) 9154068480L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 16L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass7 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-1905511648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 68);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.081655101917348d + "'", double1 == 4.081655101917348d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.46858222228961d + "'", double1 == 88.46858222228961d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9155494254642262d, (double) 1806503139, 16000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-35));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-35.0d) + "'", double1 == (-35.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.cosh(14.844126526089617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1398595.8759233463d + "'", double1 == 1398595.8759233463d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 10, (-1184773320L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray33);
        double[] doubleArray45 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.006420707498838454d);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass56 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection58, true);
        double[] doubleArray62 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        java.lang.Class<?> wildcardClass64 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        java.lang.Class<?> wildcardClass66 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection68, true);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray62);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray62);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray50);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 400L);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1079574559 + "'", int21 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 99.99357929250117d + "'", double72 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 99.99357929250117d + "'", double73 == 99.99357929250117d);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.3754263876807227d, (-2.322537803101629d), (double) 35.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray23);
        int[] intArray38 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray45);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray45);
        int[] intArray61 = new int[] { '4', (-36), 398478411 };
        int[] intArray62 = new int[] {};
        int[] intArray68 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray68);
        int[] intArray70 = new int[] {};
        int[] intArray76 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray76);
        int[] intArray79 = new int[] {};
        int[] intArray85 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray79, intArray85);
        int[] intArray87 = new int[] {};
        int[] intArray93 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray93);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray85);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray68);
        try {
            int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.5613483159465477E9d + "'", double56 == 1.5613483159465477E9d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 398478401 + "'", int97 == 398478401);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(8.973392787999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double2 = org.apache.commons.math.util.FastMath.atan2(197.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.626065009182742d + "'", double1 == 4.626065009182742d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.8414709848078964d, 1.0911052960943117d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.505152509464594d) + "'", double2 == (-0.505152509464594d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int1 = org.apache.commons.math.util.FastMath.abs((-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.NaN, 0.32657918471542563d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        float float2 = org.apache.commons.math.util.FastMath.min(35.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.8390715290764524d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2097151999), (-36));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.311231547115194E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1079574559);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 9.9999995E-33f, (double) 100L, 197.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3628800L, (float) 1406204839);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4062048E9f + "'", float2 == 1.4062048E9f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1069449217));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 9154068470L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(20.799832874547413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.560683378019944d + "'", double1 == 4.560683378019944d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1.4062048E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.48422910166014005d) + "'", double1 == (-0.48422910166014005d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger4, (java.lang.Number) 4.574710978503383d, 160, orderDirection17, true);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1072693248, 1586880531);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8414709848078964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 9.9999995E-33f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.99999950273831E-33d + "'", double1 == 9.99999950273831E-33d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.POSITIVE_INFINITY, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1260250251), (double) (-1184773320L), 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(160);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray32 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray34);
        double[] doubleArray37 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray39);
        double[] doubleArray42 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        java.lang.Class<?> wildcardClass44 = doubleArray42.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        java.lang.Class<?> wildcardClass46 = doubleArray42.getClass();
        java.lang.Class<?> wildcardClass47 = doubleArray42.getClass();
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray42);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray42);
        double[] doubleArray51 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        java.lang.Class<?> wildcardClass53 = doubleArray51.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        java.lang.Class<?> wildcardClass55 = doubleArray51.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection57, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection57, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double[] doubleArray64 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        java.lang.Class<?> wildcardClass66 = doubleArray64.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        java.lang.Class<?> wildcardClass68 = doubleArray64.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection70, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection70, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection70, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection70, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection70, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1079574559 + "'", int21 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1017118721));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1069449216) + "'", int6 == (-1069449216));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4L, (float) (-180673732));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.80673728E8f) + "'", float2 == (-1.80673728E8f));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.acosh(836.7907795824698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.422720898115055d + "'", double1 == 7.422720898115055d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1069449216) + "'", int5 == (-1069449216));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int2 = org.apache.commons.math.util.FastMath.max(101, (-1017118653));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(10, 1472955156);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1), (-36), (-180675692));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-36), 1950);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.25d + "'", double1 == 1.25d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1079574559);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 9154068480L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger22);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 1260250250L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 160);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 128L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray40 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray40);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray23);
        int[] intArray53 = new int[] {};
        int[] intArray59 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray59);
        int[] intArray61 = new int[] {};
        int[] intArray67 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray67);
        int[] intArray70 = new int[] {};
        int[] intArray76 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray76);
        int[] intArray78 = new int[] {};
        int[] intArray84 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray78, intArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray84);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray59, intArray76);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray76);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 99L, 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int int2 = org.apache.commons.math.util.MathUtils.pow(36, 550L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        java.lang.Number number13 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        boolean boolean15 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-0.8813735870195429d) + "'", number14.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.380534680281d + "'", double1 == 2979.380534680281d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7581226324091722d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int2 = org.apache.commons.math.util.FastMath.max((-180673732), 1104039936);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104039936 + "'", int2 == 1104039936);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1806503139), 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6257157546474471761L + "'", long2 == 6257157546474471761L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray21);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        java.lang.Class<?> wildcardClass29 = doubleArray24.getClass();
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection39, false);
        double[] doubleArray47 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        java.lang.Class<?> wildcardClass49 = doubleArray47.getClass();
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 97L);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray51);
        double[] doubleArray54 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        double[] doubleArray56 = null;
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray56);
        double[] doubleArray59 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray61);
        double[] doubleArray64 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        java.lang.Class<?> wildcardClass66 = doubleArray64.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        java.lang.Class<?> wildcardClass68 = doubleArray64.getClass();
        java.lang.Class<?> wildcardClass69 = doubleArray64.getClass();
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray64);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray64);
        double[] doubleArray73 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
        java.lang.Class<?> wildcardClass75 = doubleArray73.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
        java.lang.Class<?> wildcardClass77 = doubleArray73.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73, orderDirection79, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection79, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        double[] doubleArray86 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86);
        java.lang.Class<?> wildcardClass88 = doubleArray86.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86);
        java.lang.Class<?> wildcardClass90 = doubleArray86.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection92 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86, orderDirection92, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection92, false);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52 == 3.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertTrue("'" + orderDirection92 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection92.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.827660991974851E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1177807277321348d) + "'", double1 == (-1.1177807277321348d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double2 = org.apache.commons.math.util.FastMath.pow(62.64819060740832d, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000588d + "'", double2 == 1.0000000000000588d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.01711872E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.004389296250625549d) + "'", double1 == (-0.004389296250625549d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3818891261280042d) + "'", double1 == (-1.3818891261280042d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double2 = org.apache.commons.math.util.FastMath.min(7.422720898115055d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.7853981633974483d);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray8);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray13);
        try {
            double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int1 = org.apache.commons.math.util.MathUtils.sign(68);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        java.lang.Class<?> wildcardClass16 = doubleArray11.getClass();
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        java.lang.Class<?> wildcardClass22 = doubleArray20.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        java.lang.Class<?> wildcardClass24 = doubleArray20.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection26, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray39 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray39.getClass();
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 97L);
        java.lang.Class<?> wildcardClass44 = doubleArray39.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray39);
        double[] doubleArray48 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray48.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray54 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        java.lang.Class<?> wildcardClass56 = doubleArray54.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray54.getClass();
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray54);
        double[] doubleArray61 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        double[] doubleArray63 = null;
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 0.006420707498838454d);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray61);
        double[] doubleArray69 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        double[] doubleArray71 = null;
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray54, doubleArray69);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray69);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 100.0d + "'", double52 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 16000, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.07610112E9d, (-52330332));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5163576781017895E58d + "'", double2 == 2.5163576781017895E58d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.8813735870195429d) + "'", number8.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-0.8813735870195429d) + "'", number9.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1806503139));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1806503170, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 653.8768842833172d + "'", double2 == 653.8768842833172d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.asin(68.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.529429087511423d + "'", double2 == 5.529429087511423d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(194.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11172.677005051051d + "'", double1 == 11172.677005051051d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 4398046513201152001L, 0, (-35));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, (-1069449217));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (-101L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1104039936L, 0, 1806503139);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.009592355105102075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(100, 398478411);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1017118721L), (double) (-52330332), (double) 5L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection12, true);
        double[] doubleArray16 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass18 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass20 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection22, true);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray6);
        java.lang.Number number30 = null;
        double[] doubleArray34 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray34.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        java.lang.Class<?> wildcardClass38 = doubleArray34.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection40, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number30, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection40, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 836.7907795824698d, (java.lang.Number) 1.5613483159465477E9d, 68, orderDirection40, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection40, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10.0f, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(4.605170185988092d, (-180675682));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.6122916919639853E279d) + "'", double2 == (-2.6122916919639853E279d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.560683378019944d, 5.272999558563747d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.718281828459045d, 4443057.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4443056.677288958d + "'", double2 == 4443056.677288958d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (byte) 0, 2147483647, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5200L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5200.0f + "'", float1 == 5200.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 8625328718985890577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9368909954211597E9d + "'", double1 == 2.9368909954211597E9d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        java.lang.Number number14 = nonMonotonousSequenceException3.getArgument();
        int int15 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-0.8813735870195429d) + "'", number14.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double[] doubleArray4 = new double[] { (-0.02051113020245179d), (-0.3821138948910999d), 1.1416876847493498d, 19.028157807631057d };
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        java.lang.Class<?> wildcardClass9 = doubleArray6.getClass();
        try {
            double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int2 = org.apache.commons.math.util.FastMath.max((-180673732), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1079574559);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 9154068480L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger22);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-180675682L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-180675680) + "'", int1 == (-180675680));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.1177807277321348d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-35), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-40.0d) + "'", double2 == (-40.0d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2147483647, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9223372026117357569L) + "'", long2 == (-9223372026117357569L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1017118884));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.733400859738384d) + "'", double1 == (-0.733400859738384d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 398478411, 1079574560L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 430187155224824160L + "'", long2 == 430187155224824160L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.07195258896067d + "'", double1 == 19.07195258896067d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-52330332));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass12 = doubleArray8.getClass();
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 101);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 550L, 68, (-52330332));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-160000.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-160000L) + "'", long1 == (-160000L));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        int int10 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException3.getSuppressed();
        int int12 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.3246090892520057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9241412930528897d + "'", double1 == 0.9241412930528897d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double2 = org.apache.commons.math.util.FastMath.max(1.569478706773049d, 1.4551915228366852E-11d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.569478706773049d + "'", double2 == 1.569478706773049d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-2097151999));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1806503170, (-1017118884));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1806503139), (-2097151999));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) -1, 101L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-101L) + "'", long2 == (-101L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.6253287189859062E18d, 0.36787944117144233d, 1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1260250251, (double) 5235L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.260250251E9d + "'", double2 == 1.260250251E9d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(95.24777960769379d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.566866188740386d + "'", double1 == 4.566866188740386d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(398478401, (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 398478437 + "'", int2 == 398478437);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1), (long) 1079574559);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574558L + "'", long2 == 1079574558L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-180675682), (-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1950, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2050 + "'", int2 == 2050);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(1.07610112E9f, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1069449216) + "'", int6 == (-1069449216));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.670710403452705E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000355d + "'", double1 == 1.0000000000000355d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-36L), (-180675692));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-180675680), (long) 195);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-180675485L) + "'", long2 == (-180675485L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray11);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass18 = doubleArray14.getClass();
        java.lang.Class<?> wildcardClass19 = doubleArray14.getClass();
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection29, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray36 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        java.lang.Class<?> wildcardClass38 = doubleArray36.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        java.lang.Class<?> wildcardClass40 = doubleArray36.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection42, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection42, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection42, true);
        boolean boolean49 = nonMonotonousSequenceException48.getStrict();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.973392787999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int2 = org.apache.commons.math.util.FastMath.min(900, 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.7853981633974483d);
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray11);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        java.lang.Class<?> wildcardClass21 = doubleArray19.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        java.lang.Class<?> wildcardClass23 = doubleArray19.getClass();
        java.lang.Class<?> wildcardClass24 = doubleArray19.getClass();
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray19);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray19);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 8973392788L, 0.9155494254642262d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2097151999, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2097151964 + "'", int2 == 2097151964);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 2097151964);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.017118553E9d, 3.618502788666131E75d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1017118884));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1005.6740390560919d) + "'", double1 == (-1005.6740390560919d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-35), (-1905511648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        java.lang.Class<?> wildcardClass17 = doubleArray12.getClass();
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 1950);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1017118916));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.017521095452147056d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-4522783837087858687L), (-160000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4522783837087698687L) + "'", long2 == (-4522783837087698687L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 398478437);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) '4', (long) 398478437);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20720878724L + "'", long2 == 20720878724L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1260250251L, 1.01711872E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.260250251E9d + "'", double2 == 1.260250251E9d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-180675682L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 195L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.96424004376894d + "'", double1 == 13.96424004376894d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.01711872E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.util.MathUtils.log(655.4848567108893d, 1.569478706773049d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06950153481474758d + "'", double2 == 0.06950153481474758d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1017118721L, (long) (-180675682));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-109299957228L), (double) 99L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        long long2 = org.apache.commons.math.util.FastMath.min(1017118756L, (-101L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-101L) + "'", long2 == (-101L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(4398046513201152001L, (-1017118884));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1806503139));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.007806026724577d) + "'", double1 == (-22.007806026724577d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.FastMath.max(5, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) (-180675680));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.8067568E8f) + "'", float2 == (-1.8067568E8f));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 398478411, (-9223372026117357569L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9223372026117357569L) + "'", long2 == (-9223372026117357569L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) -1, 1472955156, 1017118721);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-180675682));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-180675682) + "'", int2 == (-180675682));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2097151999), 0.024005719083840586d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.1164953397656396d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-36L), 1017118721L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36616273956L + "'", long2 == 36616273956L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.599310885968812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16753958088268972d + "'", double1 == 0.16753958088268972d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6420149920119999d + "'", double1 == 0.6420149920119999d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1654238625, (-1017118721));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1069449217));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1069449217 + "'", int2 == 1069449217);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.18252582355595404d, (double) (-180675485L), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4711276743037345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.99999999999999d + "'", double1 == 9.99999999999999d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        java.lang.Number number13 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        boolean boolean15 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException9.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-0.8813735870195429d) + "'", number14.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1017118653));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5140097177418461d) + "'", double1 == (-0.5140097177418461d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1017118653);
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray9.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray15 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        java.lang.Class<?> wildcardClass17 = doubleArray15.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        java.lang.Class<?> wildcardClass19 = doubleArray15.getClass();
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray15);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double[] doubleArray24 = null;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 0.006420707498838454d);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray22);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray31 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        java.lang.Class<?> wildcardClass33 = doubleArray31.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        java.lang.Class<?> wildcardClass35 = doubleArray31.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection37, true);
        double[] doubleArray41 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        java.lang.Class<?> wildcardClass43 = doubleArray41.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        java.lang.Class<?> wildcardClass45 = doubleArray41.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection47, true);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray41);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray41);
        double[] doubleArray53 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 0.006420707498838454d);
        double[] doubleArray60 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60);
        java.lang.Class<?> wildcardClass62 = doubleArray60.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60);
        java.lang.Class<?> wildcardClass64 = doubleArray60.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60, orderDirection66, true);
        double[] doubleArray70 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        java.lang.Class<?> wildcardClass72 = doubleArray70.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        java.lang.Class<?> wildcardClass74 = doubleArray70.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70, orderDirection76, true);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray70);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray70);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray58);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 400L);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray41);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1079574559 + "'", int29 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 99.99357929250117d + "'", double80 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 99.99357929250117d + "'", double81 == 99.99357929250117d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.017118553E9d + "'", double84 == 1.017118553E9d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1079574559 + "'", int85 == 1079574559);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-180675682));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1.58325171E9f, (double) (-9154066530L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.583251712E9d + "'", double2 == 1.583251712E9d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int int1 = org.apache.commons.math.util.FastMath.abs(1472955156);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1472955156 + "'", int1 == 1472955156);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-2.6122916919639853E279d), 48.49484536082474d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1017118721L), (double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.017118721E9d) + "'", double2 == (-1.017118721E9d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-35));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9700L, 1950, (-1069449216));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.Number number0 = null;
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass6 = doubleArray4.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection10, true);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (52 >= null)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (52 >= null)"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9996159447946292d + "'", double1 == 0.9996159447946292d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-35));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1586880531, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586880531L + "'", long2 == 1586880531L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass6 = doubleArray4.getClass();
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 97L);
        java.lang.Number number12 = null;
        double[] doubleArray16 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass18 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass20 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 836.7907795824698d, (java.lang.Number) 1.5613483159465477E9d, 68, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1260250251), (java.lang.Number) (-1017118916), 1406204839, orderDirection22, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.9459198719785213d, 1.017118553E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0171185533043058E9d + "'", double2 == 1.0171185533043058E9d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1410065408);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.410065408E9d + "'", double1 == 1.410065408E9d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-36));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.3019272488946267d) + "'", double1 == (-3.3019272488946267d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.560683378019944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.FastMath.acosh(99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.29822815326323d + "'", double1 == 5.29822815326323d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-36L), 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 102.23007675795088d + "'", double2 == 102.23007675795088d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1654238625, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 0, 1017118721L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1017118721L) + "'", long2 == (-1017118721L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int[] intArray3 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray4 = new int[] {};
        int[] intArray10 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray18);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray25 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray26 = new int[] {};
        int[] intArray32 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray40 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray40);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray32);
        int[] intArray44 = new int[] {};
        int[] intArray50 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray50);
        int[] intArray52 = new int[] {};
        int[] intArray58 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray58);
        int[] intArray61 = new int[] {};
        int[] intArray67 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray67);
        int[] intArray69 = new int[] {};
        int[] intArray75 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray75);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray67);
        int[] intArray79 = new int[] {};
        int[] intArray85 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray79, intArray85);
        int[] intArray87 = new int[] {};
        int[] intArray93 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray93);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray85);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray50);
        double double98 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray50);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.5613483159465477E9d + "'", double21 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.5613483159465477E9d + "'", double43 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 97L);
        java.lang.Class<?> wildcardClass16 = doubleArray15.getClass();
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.3818891261280042d), 12.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3818891261280042d) + "'", double2 == (-1.3818891261280042d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.9241412930528897d, 398478401, (-1260250251));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection8, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException14.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection17, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0d + "'", number15.equals(10.0d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 5200.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.094947017729282E-13d + "'", double1 == 9.094947017729282E-13d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.01711872E9d, (java.lang.Number) (-0.48422910166014005d), (-180675680));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', 1079574560L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 8.6253287189858898E18d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7615941559557649d, (java.lang.Number) 1.0064412756298708d, (int) (short) 100);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.027419984278345425d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.027413114388728267d) + "'", double1 == (-0.027413114388728267d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int1 = org.apache.commons.math.util.MathUtils.hash(62.64819060740832d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1465556826) + "'", int1 == (-1465556826));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1017118721);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5439905310925515d + "'", double1 == 0.5439905310925515d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.2602502509999998E9d), (double) (-1806503139));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.806503139E9d) + "'", double2 == (-1.806503139E9d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1017118720L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, 398478401);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 32L, (-0.5063656411097588d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 333548014, (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 68, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1406204839, 1410065408);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2213764959311634431L) + "'", long2 == (-2213764959311634431L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.4062048E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double2 = org.apache.commons.math.util.FastMath.max(2.6881171418161356E43d, (-1.1164953397656396d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) ' ', (-9154066530L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-292930128960L) + "'", long2 == (-292930128960L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.48422910166014005d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(195, 16000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3120000 + "'", int2 == 3120000);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int2 = org.apache.commons.math.util.MathUtils.pow(398478437, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 883419577 + "'", int2 == 883419577);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-11L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.0064206193d, (int) (short) 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(number10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(194.99999999999997d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2212554774328055d + "'", double2 == 0.2212554774328055d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1104039936, (float) (-1260250251));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.26025024E9f) + "'", float2 == (-1.26025024E9f));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5440680443502757d, 4.626065009182742d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.626065009182742d + "'", double2 == 4.626065009182742d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray28 = new int[] { '4', (-36), 398478411 };
        int[] intArray29 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray35);
        int[] intArray37 = new int[] {};
        int[] intArray43 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray43);
        int[] intArray46 = new int[] {};
        int[] intArray52 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray60 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray52);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray35);
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray35);
        try {
            int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 398478401 + "'", int64 == 398478401);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(35, 1654238625);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        int int15 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-0.8813735870195429d) + "'", number12.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1806503139));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.035050055418351E11d) + "'", double1 == (-1.035050055418351E11d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.569478706773049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        java.lang.Number number16 = nonMonotonousSequenceException14.getPrevious();
        java.lang.String str17 = nonMonotonousSequenceException14.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str24 = nonMonotonousSequenceException14.toString();
        java.lang.Number number25 = nonMonotonousSequenceException14.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        int int27 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0 + "'", number16.equals(0));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-0.8813735870195429d) + "'", number25.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 100, 0, 3120000);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number14 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0 + "'", number14.equals(0));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.688117141816136E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-2.6122916919639853E279d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 3120000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.8010443814797708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8895032590730141d + "'", double1 == 0.8895032590730141d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.529429087511423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 252.00000000000003d + "'", double1 == 252.00000000000003d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        long long1 = org.apache.commons.math.util.FastMath.abs(1079574560L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1079574560L + "'", long1 == 1079574560L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 9.1540685E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.6306114405925d + "'", double1 == 23.6306114405925d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.136228346192656E274d), (java.lang.Number) 100.0d, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.136228346192656E274d) + "'", number12.equals((-1.136228346192656E274d)));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0d + "'", number15.equals(100.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3120000, (-100L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3120000L + "'", long2 == 3120000L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-35), 3120000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21840000 + "'", int2 == 21840000);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5440680443502757d, (double) 1017118721L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1079574559);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1017118721, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int2 = org.apache.commons.math.util.FastMath.min((-10), (-2038431743));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2038431743) + "'", int2 == (-2038431743));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 97L);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 0.7853981633974483d);
        double[] doubleArray16 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        double[] doubleArray18 = null;
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double[] doubleArray23 = null;
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray23);
        double[] doubleArray26 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass28 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        java.lang.Class<?> wildcardClass31 = doubleArray26.getClass();
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray26);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray26);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 1.3246090892520057d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        try {
            int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.3818891261280042d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-2038431743));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.038431743E9d + "'", double1 == 2.038431743E9d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.math.util.FastMath.min((-180675680), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-180675680) + "'", int2 == (-180675680));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.585786437626905d) + "'", double1 == (-0.585786437626905d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray11);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass18 = doubleArray14.getClass();
        java.lang.Class<?> wildcardClass19 = doubleArray14.getClass();
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection29, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7372146681639586d, (java.lang.Number) 0.0299910048568779d, 1654238625, orderDirection29, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException35.getDirection();
        boolean boolean37 = nonMonotonousSequenceException35.getStrict();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1465556826));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 68);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 35);
        double[] doubleArray18 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        java.lang.Class<?> wildcardClass20 = doubleArray18.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray24);
        double[] doubleArray31 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        double[] doubleArray33 = null;
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 0.006420707498838454d);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray46 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        java.lang.Class<?> wildcardClass48 = doubleArray46.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass56 = doubleArray52.getClass();
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        double[] doubleArray59 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray61);
        double[] doubleArray64 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        double[] doubleArray66 = null;
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray66);
        double[] doubleArray69 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        java.lang.Class<?> wildcardClass71 = doubleArray69.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        java.lang.Class<?> wildcardClass73 = doubleArray69.getClass();
        java.lang.Class<?> wildcardClass74 = doubleArray69.getClass();
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray69);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray69);
        double[] doubleArray78 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
        java.lang.Class<?> wildcardClass80 = doubleArray78.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
        java.lang.Class<?> wildcardClass82 = doubleArray78.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78, orderDirection84, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection84, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection84, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection84, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException94 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) bigInteger11, 1072693248, orderDirection84, true);
        java.math.BigInteger bigInteger96 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 2147483647);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.0d + "'", double50 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger96);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.17453292519943295d, (-10), (-1069449216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1260250251), (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1260250287) + "'", int2 == (-1260250287));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1017118916), (long) 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        long long2 = org.apache.commons.math.util.FastMath.min(195L, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        int int11 = nonMonotonousSequenceException8.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1069449216) + "'", int11 == (-1069449216));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.569478706773049d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 16000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 0, (int) (byte) 10, 398478437);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        long long2 = org.apache.commons.math.util.FastMath.max(1104039936L, 1104039936L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104039936L + "'", long2 == 1104039936L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 1.0911052960943117d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1260250251), (-160000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 201640040160000L + "'", long2 == 201640040160000L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection7, true);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection17, true);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray21);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1);
        try {
            double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-4522783837087858687L), (double) 1017118720L, 16000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1806503139), (int) (byte) 1, (-52330332));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1017118721L, (float) (-2097151999));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.097152E9f) + "'", float2 == (-2.097152E9f));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 1472955156);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 1079574559);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 9154068480L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger23);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 1079574559);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 9154068480L);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger36);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger36);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger26);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, (long) 1017118720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        java.lang.Class<?> wildcardClass6 = doubleArray1.getClass();
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1076101120L);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 9167.324722093172d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, (long) 333548014);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1104039936, 1260250251L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-156210315L) + "'", long2 == (-156210315L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1806503139, (long) 1069449217);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1931963367511592163L + "'", long2 == 1931963367511592163L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7815786833057918d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6634070667145121d + "'", double1 == 0.6634070667145121d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1410065408, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.1752011936438014d), 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7453292519943295d + "'", double2 == 1.7453292519943295d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1406204839, 1654238625);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-248033786) + "'", int2 == (-248033786));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str24 = nonMonotonousSequenceException23.toString();
        java.lang.Number number25 = nonMonotonousSequenceException23.getPrevious();
        java.lang.String str26 = nonMonotonousSequenceException23.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException23.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        boolean boolean35 = nonMonotonousSequenceException23.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 17);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double[] doubleArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 0.006420707498838454d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray24);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double[] doubleArray43 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass45 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass47 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection49, true);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray43);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 0L);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 0L);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, 0L);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 0L);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, bigInteger64);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException71.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger59, (java.lang.Number) 4.574710978503383d, 160, orderDirection72, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection72, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079574559 + "'", int7 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1079574559 + "'", int31 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1406204839, 1654238625);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 21840000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21840000 + "'", int1 == 21840000);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int2 = org.apache.commons.math.util.MathUtils.pow(5, 197L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-953922251) + "'", int2 == (-953922251));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6320021414540531d + "'", double1 == 0.6320021414540531d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-292930128960L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.1556157735575975E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.25d + "'", double1 == 0.25d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1072693248, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693248L + "'", long2 == 1072693248L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1586880531L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1017118720, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1017118820L + "'", long2 == 1017118820L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.ceil(655.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 655.0d + "'", double1 == 655.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1069449216L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(10.0d, (-953922251));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.801671039719116E-215d + "'", double2 == 5.801671039719116E-215d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(32.0d, 0.020615910632835112d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.Number number6 = null;
        double[] doubleArray10 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray10.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        java.lang.Class<?> wildcardClass14 = doubleArray10.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection16, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection16, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 836.7907795824698d, (java.lang.Number) 1.5613483159465477E9d, 68, orderDirection16, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3120000, (java.lang.Number) (-1260250287), (int) (byte) -1, orderDirection16, true);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 333548014, 0.006420707498838454d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.006420707498838454d + "'", double2 == 0.006420707498838454d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        java.lang.Class<?> wildcardClass11 = doubleArray6.getClass();
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        java.lang.Class<?> wildcardClass22 = doubleArray20.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        java.lang.Class<?> wildcardClass24 = doubleArray20.getClass();
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray20);
        double[] doubleArray27 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        double[] doubleArray29 = null;
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 0.006420707498838454d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray27);
        double[] doubleArray35 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        double[] doubleArray37 = null;
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray35);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 97.0f);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 195L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.278114659230517d + "'", double1 == 5.278114659230517d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1260250251);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 17);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double[] doubleArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 0.006420707498838454d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray24);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double[] doubleArray43 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass45 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass47 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection49, true);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray43);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079574559 + "'", int7 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1079574559 + "'", int31 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-0.7325119202378503d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray31);
        int[] intArray38 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray45);
        int[] intArray57 = new int[] {};
        int[] intArray63 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray71 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray71);
        int[] intArray74 = new int[] {};
        int[] intArray80 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray80);
        int[] intArray82 = new int[] {};
        int[] intArray88 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray82, intArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray88);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray88);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray88);
        java.lang.Class<?> wildcardClass93 = intArray88.getClass();
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray88);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.5613483159465477E9d + "'", double56 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1069449216));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection13, true);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection23, true);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray28 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray28.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        java.lang.Class<?> wildcardClass32 = doubleArray28.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection34, true);
        double[] doubleArray38 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        java.lang.Class<?> wildcardClass40 = doubleArray38.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        java.lang.Class<?> wildcardClass42 = doubleArray38.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection44, true);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray28);
        double[] doubleArray50 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        double[] doubleArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 0.006420707498838454d);
        double[] doubleArray57 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57);
        java.lang.Class<?> wildcardClass59 = doubleArray57.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57);
        java.lang.Class<?> wildcardClass61 = doubleArray57.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57, orderDirection63, true);
        double[] doubleArray67 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        java.lang.Class<?> wildcardClass69 = doubleArray67.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        java.lang.Class<?> wildcardClass71 = doubleArray67.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection73, true);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray67);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray67);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray55);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1069449216L));
        try {
            double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 99.99357929250117d + "'", double77 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1079574559 + "'", int79 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1260250251, 17L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1260250268L + "'", long2 == 1260250268L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.006420751615786778d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999793870451602d + "'", double1 == 0.9999793870451602d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6634070667145121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8144980458629181d + "'", double1 == 0.8144980458629181d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1260250251), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.FastMath.max(97.0d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.exp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 550L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7403626894942437d + "'", double1 == 2.7403626894942437d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        float float2 = org.apache.commons.math.util.FastMath.max((-2.097152E9f), (float) (-1017118916));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.01711891E9f) + "'", float2 == (-1.01711891E9f));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1586880531L, 0.9443504370351303d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5868805309999998E9d + "'", double2 == 1.5868805309999998E9d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610271965545d + "'", double1 == 20.796610271965545d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1806503139), 1069449217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1079574560L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        double[] doubleArray10 = null;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1950);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-2097151999));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str20 = nonMonotonousSequenceException8.toString();
        java.lang.String str21 = nonMonotonousSequenceException8.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        java.lang.Number number6 = null;
        java.lang.Number number9 = null;
        double[] doubleArray13 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray13.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        java.lang.Class<?> wildcardClass17 = doubleArray13.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection19, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number9, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection19, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 0.8813735870195428d, 160, orderDirection19, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection19, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.136228346192656E274d), (java.lang.Number) 100.0d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.136228346192656E274d) + "'", number4.equals((-1.136228346192656E274d)));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.9459198719785213d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9809170849695142d) + "'", double1 == (-0.9809170849695142d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1005.6740390560919d), (-36), 21840000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1806503170, (-1017118916));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-9223372026117357569L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1017118721), (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5L, 9700.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.atanh(13.000000000000002d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-156210315L), (long) 1017118720);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 860908405L + "'", long2 == 860908405L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '4', (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 36, (-0.9171523356672744d), 1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        long long2 = org.apache.commons.math.util.FastMath.min((-2213764959311634431L), 550L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2213764959311634431L) + "'", long2 == (-2213764959311634431L));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7224284372420832d), 0.7372146681639586d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(8973392788L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1.4062048E9f, (double) (-1905511648), 0.32657918471542563d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6487212707001282d + "'", double1 == 1.6487212707001282d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 21840000);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1069449216) + "'", int6 == (-1069449216));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9613974918795568d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.432614653463764d) + "'", double1 == (-1.432614653463764d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 398478437);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-740011332), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) (-2.6122916919639853E279d), (-1465556826));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str7 = nonMonotonousSequenceException6.toString();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str14 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        java.lang.String str24 = nonMonotonousSequenceException21.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException21.getStrict();
        int int32 = nonMonotonousSequenceException21.getIndex();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        boolean boolean34 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.80675696E8f), (-1104039972), orderDirection35, false);
        java.lang.String str38 = nonMonotonousSequenceException37.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.8813735870195429d) + "'", number16.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,104,039,973 and -1,104,039,972 are not increasing (-180,675,696 > null)" + "'", str38.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,104,039,973 and -1,104,039,972 are not increasing (-180,675,696 > null)"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438012d) + "'", double1 == (-1.1752011936438012d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 97L);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass18 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection20, true);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection30, true);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray24);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray14);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7372146681639586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8058305363429619d + "'", double1 == 0.8058305363429619d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1806503170, (-1806503139));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1806503139), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-7.4001133E8f), 2.6881171418161356E43d, 2050);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-7.4001133E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(9154068480L, 400L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9154068880L + "'", long2 == 9154068880L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(102.23007675795088d, 2.688117141816136E43d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-160000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-35), (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = org.apache.commons.math.util.FastMath.min((-1017118884), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1017118884) + "'", int2 == (-1017118884));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection18, true);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection28, true);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray22);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray12);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray7);
        java.lang.Number number34 = null;
        double[] doubleArray38 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        java.lang.Class<?> wildcardClass40 = doubleArray38.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        java.lang.Class<?> wildcardClass42 = doubleArray38.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection44, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number34, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection44, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection44, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1260250251);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1079574559 + "'", int14 == 1079574559);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09247264651318214d + "'", double1 == 0.09247264651318214d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }
}

