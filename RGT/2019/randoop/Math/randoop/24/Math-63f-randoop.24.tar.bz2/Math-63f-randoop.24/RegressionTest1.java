import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1950 + "'", int2 == 1950);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1410065408, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065408 + "'", int2 == 1410065408);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-8.09574038883227E-285d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-2038431743));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9341263038511088d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 9700L, (float) (-740011332));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.4001133E8f) + "'", float2 == (-7.4001133E8f));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 9223372036854775807L, 1410065408);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-180675692), 1260250251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = org.apache.commons.math.util.FastMath.max((-180675692), 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.log(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.520543522634296d + "'", double1 == 1.520543522634296d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1079574559);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int2 = org.apache.commons.math.util.MathUtils.pow(900, (long) 160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-2.322537803101629d), (-0.9341263038511088d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-35), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.abs(21.43338686423945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.43338686423945d + "'", double1 == 21.43338686423945d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.expm1(36.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.311231547115194E15d + "'", double1 == 4.311231547115194E15d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1104039936, (-180675682));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 9154068470L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2091.8861867103615d + "'", double1 == 2091.8861867103615d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1260250251, (long) 900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1260250251L + "'", long2 == 1260250251L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.rint(4443056.833513324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4443057.0d + "'", double1 == 4443057.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-35L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 9700.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.006420619268033628d, 4443055.26025388d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.log(19.028157807631057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9459198719785213d + "'", double1 == 2.9459198719785213d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) -1, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1104039936);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 900.0000000000001d + "'", double1 == 900.0000000000001d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3628800L, 1.4516290508338701E284d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1017118756L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.43338689865038d + "'", double1 == 21.43338689865038d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.7453292519943295d, (double) Float.NaN, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-180675692), 9154068480L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8973392788L + "'", long2 == 8973392788L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1950, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.3614195558365d + "'", double1 == 44.3614195558365d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-180675682));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.atan(400.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5682963320032104d + "'", double1 == 1.5682963320032104d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1076101120);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(32, 160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-128) + "'", int2 == (-128));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 4.311231547115194E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-35L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1069449216) + "'", int1 == (-1069449216));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.tan(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Number number0 = null;
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray11);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass18 = doubleArray14.getClass();
        java.lang.Class<?> wildcardClass19 = doubleArray14.getClass();
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection29, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray36 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        java.lang.Class<?> wildcardClass38 = doubleArray36.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        java.lang.Class<?> wildcardClass40 = doubleArray36.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection42, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection42, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 9700L, (int) (byte) 100, orderDirection42, true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.586880531E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1017118721));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.017118721E9d) + "'", double1 == (-1.017118721E9d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.006420619268033628d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-2038431743), 160);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1586880531);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray31);
        int[] intArray35 = new int[] {};
        int[] intArray41 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray49);
        int[] intArray52 = new int[] {};
        int[] intArray58 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray58);
        int[] intArray60 = new int[] {};
        int[] intArray66 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray66);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray58);
        int[] intArray70 = new int[] {};
        int[] intArray76 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray76);
        int[] intArray78 = new int[] {};
        int[] intArray84 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray78, intArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray84);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray76);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray76);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1586880531, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 398478411 + "'", int2 == 398478411);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1806503139 + "'", int1 == 1806503139);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.006420707498838454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.006420619268761072d + "'", double1 == 0.006420619268761072d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1017118720, 1017118720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.FastMath.min((-740011332), (-1069449216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1069449216) + "'", int2 == (-1069449216));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1260250251, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1260250250L + "'", long2 == 1260250250L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.07610112E9f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.120327294217057E-250d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        java.lang.Class<?> wildcardClass11 = doubleArray6.getClass();
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        double[] doubleArray13 = null;
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.02051113020245179d), (-180675692));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.136228346192656E274d) + "'", double2 == (-1.136228346192656E274d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8625328718985906577L, (float) (-180675692));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.80675696E8f) + "'", float2 == (-1.80675696E8f));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1069449216), 1017118721);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.964543937616722d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.8813847243447673E19d, 2.1017612416682803d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1260250251);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.220702051260265E10d + "'", double1 == 7.220702051260265E10d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 10L, 7.220702051260265E10d, (double) 1104039936L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1950, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 172.70234343568234d + "'", double2 == 172.70234343568234d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 100L, 0, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-1260250251));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int2 = org.apache.commons.math.util.FastMath.min((-35), 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 1017118721);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1017118721L) + "'", long2 == (-1017118721L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 10, 8625328718985906577L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 1, (long) 1079574559);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574560L + "'", long2 == 1079574560L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.17453292519943295d, (double) (-1069449216L), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 398478411, (-1069449216L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 17);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.9E-324d, (-0.9613974918795568d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.7615941559557649d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (-180675682));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-180675682L) + "'", long2 == (-180675682L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1260250251));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2602502509999998E9d) + "'", double1 == (-1.2602502509999998E9d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-36), (-101L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36L) + "'", long2 == (-36L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray7 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray15 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray15);
        int[] intArray18 = new int[] {};
        int[] intArray24 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray32 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray32);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray32);
        try {
            int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 400L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1017118756L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1017118756L + "'", long1 == 1017118756L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1017118756L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 160, 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.223372036854776E18d + "'", double1 == 9.223372036854776E18d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        long long1 = org.apache.commons.math.util.FastMath.abs(8973392788L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8973392788L + "'", long1 == 8973392788L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(13513.541880327715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (short) 1, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1260250251), 9154068470L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1260250250L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        java.lang.Number number13 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        boolean boolean15 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int17 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-0.8813735870195429d) + "'", number14.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.8189894035458565E-12d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean13 = nonMonotonousSequenceException3.getStrict();
        int int14 = nonMonotonousSequenceException3.getIndex();
        int int15 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 10, (double) 68);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 68.0d + "'", double2 == 68.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(44.3614195558365d, (-1.1752011936438014d), 248861.08172391923d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-180675692), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.80675696E8f) + "'", float2 == (-1.80675696E8f));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(3628800L, (long) 1586880531);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1583251731L) + "'", long2 == (-1583251731L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7224284372420832d) + "'", double1 == (-0.7224284372420832d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 195L, (-2038431743), 16000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.6253287189859062E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7261280914296674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0670616196974443d + "'", double1 == 1.0670616196974443d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1950, (-180675682));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-180673732) + "'", int2 == (-180673732));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1017118721), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.7853981633974483d, 0, 900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1069449216), 0.0064206193d, (double) (-740011332));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.1447298858494d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7299512698867918d + "'", double1 == 1.7299512698867918d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1069449216), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1069449217) + "'", int2 == (-1069449217));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str19 = nonMonotonousSequenceException18.toString();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        java.lang.String str21 = nonMonotonousSequenceException18.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str26 = nonMonotonousSequenceException25.toString();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        boolean boolean28 = nonMonotonousSequenceException18.getStrict();
        int int29 = nonMonotonousSequenceException18.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean31 = nonMonotonousSequenceException10.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str37 = nonMonotonousSequenceException36.toString();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        java.lang.String str39 = nonMonotonousSequenceException36.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str44 = nonMonotonousSequenceException43.toString();
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number46 = nonMonotonousSequenceException43.getArgument();
        java.lang.String str47 = nonMonotonousSequenceException43.toString();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number49 = nonMonotonousSequenceException43.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str37.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0 + "'", number38.equals(0));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str39.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-0.8813735870195429d) + "'", number46.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str47.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-0.8813735870195429d) + "'", number49.equals((-0.8813735870195429d)));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1260250250L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long1 = org.apache.commons.math.util.MathUtils.sign(355687428096000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.8813735870195429d) + "'", number5.equals((-0.8813735870195429d)));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1.80675696E8f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math.util.FastMath.max(1.8151424220741028d, (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-180673732), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number15 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-0.8813735870195429d) + "'", number12.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1069449217));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4424808105122744d) + "'", double1 == (-0.4424808105122744d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.5063656411097588d), (int) (short) -1, (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray5 = new int[] {};
        int[] intArray11 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray23 = new int[] {};
        int[] intArray29 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray29);
        int[] intArray31 = new int[] {};
        int[] intArray37 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray37);
        int[] intArray40 = new int[] {};
        int[] intArray46 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray54 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray46);
        int[] intArray58 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray64);
        int[] intArray66 = new int[] {};
        int[] intArray72 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray72);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray64);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray29);
        try {
            int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.5613483159465477E9d + "'", double22 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97L, (float) 1017118720);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.01711872E9f + "'", float2 == 1.01711872E9f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 17L, (int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999546000702375d) + "'", double1 == (-0.9999546000702375d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(195, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5440211108893698d + "'", double1 == 0.5440211108893698d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (-1069449216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1069449216) + "'", int2 == (-1069449216));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 8973392788L, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.973392787999998E9d + "'", double2 == 8.973392787999998E9d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.6881171418161356E43d, 0.006420619268033628d, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7853981633974483d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6108652381980153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 19.028157807631057d, (-0.5309649148733837d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-36), 32L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-740011332));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 1806503139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1806503139) + "'", int2 == (-1806503139));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4443055.260253992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1017118720);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.01711872E9d + "'", double1 == 1.01711872E9d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.sinh(14.60475425404424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1100865.3094543158d + "'", double1 == 1100865.3094543158d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 100, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int[] intArray3 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray4 = new int[] {};
        int[] intArray10 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray18);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray22 = new int[] {};
        int[] intArray28 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray36);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray53);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray53);
        int[] intArray58 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray64);
        try {
            int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.5613483159465477E9d + "'", double21 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 1, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.027419984278345425d) + "'", double2 == (-0.027419984278345425d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1556157735575975E15d + "'", double1 == 2.1556157735575975E15d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.3821138948910999d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.027419984278345425d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9117339147869651d) + "'", double1 == (-0.9117339147869651d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-36), 160);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.688117141816136E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.688117141816136E43d + "'", double1 == 2.688117141816136E43d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.ceil(8.673617379884035E-19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        float float1 = org.apache.commons.math.util.FastMath.abs(9700.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9700.0f + "'", float1 == 9700.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-1.0d), (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 5235L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.718916686014861d + "'", double1 == 3.718916686014861d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5607966601082315d, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5607966601082315d + "'", double2 == 1.5607966601082315d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.024005719083840586d + "'", double1 == 0.024005719083840586d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1905511648) + "'", int1 == (-1905511648));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1806503139, 4.311231547115194E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8065031390000002E9d + "'", double2 == 1.8065031390000002E9d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-7.4001133E8f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.428182669496151d), (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.tanh(13513.541880327715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1069449216));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.5440211108893698d), (double) (byte) 100, 97.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1.01711872E9f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.01711872E9d + "'", double2 == 1.01711872E9d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5309649148733837d), (java.lang.Number) (-2.0d), 1017118720);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.01711872E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.01711872E9f + "'", float1 == 1.01711872E9f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(13.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.000000000000002d + "'", double1 == 13.000000000000002d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0911052960943117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        java.lang.Class<?> wildcardClass22 = doubleArray17.getClass();
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray17);
        double[] doubleArray26 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass28 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection32, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray39 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass43 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection45, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection45, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection45, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 1.0d, 1410065408, orderDirection45, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 5235L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.56331312702979d + "'", double1 == 8.56331312702979d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(16000, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.680344001221918d + "'", double2 == 9.680344001221918d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-35L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1017118756L, 655.0d, 17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9155494254642262d + "'", double1 == 0.9155494254642262d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int1 = org.apache.commons.math.util.FastMath.abs(160);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 160 + "'", int1 == 160);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1017118721), 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1017118916) + "'", int2 == (-1017118916));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1583251731L), (-1905511648), 1586880531);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9155494254642262d, 1.2893511559113684E39d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2893511559113684E39d + "'", double2 == 1.2893511559113684E39d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) Float.NaN);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-36), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 3628800L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 36L, 5, 16000);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException3.getArgument();
        int int10 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.8813735870195429d) + "'", number8.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-0.8813735870195429d) + "'", number9.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0038848218538872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.18120467008033d + "'", double1 == 1.18120467008033d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double2 = org.apache.commons.math.util.FastMath.max(13.000000000000002d, (double) 197L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 197.0d + "'", double2 == 197.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1079574560L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.799832874547413d + "'", double1 == 20.799832874547413d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(68, (-1017118721));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1017118653) + "'", int2 == (-1017118653));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.027419984278345425d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.80675696E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1104039936);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.2893511559113684E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2893511559113684E39d + "'", double1 == 1.2893511559113684E39d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1017118721L), (long) 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4522783837087858687L) + "'", long2 == (-4522783837087858687L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2038431743), (-36L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(400.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1104039936);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.042984783239863d + "'", double1 == 9.042984783239863d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (-1017118653));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-36), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-36) + "'", int2 == (-36));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long1 = org.apache.commons.math.util.FastMath.round(9.680344001221918d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-128));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.006420619268761072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0064412756298708d + "'", double1 == 1.0064412756298708d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1905511648), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.FastMath.pow(363.7393755555636d, 1.0038848218538872d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 372.16757365268984d + "'", double2 == 372.16757365268984d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 5235L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 16000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16000L + "'", long2 == 16000L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(16000L, (long) (-10));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-160000L) + "'", long2 == (-160000L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection12, true);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 100L, 0, orderDirection19, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection19, true);
        java.lang.Class<?> wildcardClass24 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass10 = doubleArray8.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Class<?> wildcardClass12 = doubleArray8.getClass();
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.006420707498838454d);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray15);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray23);
        try {
            double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 195L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.272999558563747d + "'", double1 == 5.272999558563747d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.18120467008033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020615910632835112d + "'", double1 == 0.020615910632835112d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 5235L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5235L + "'", long1 == 5235L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2038431743), 1950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2097151999) + "'", int2 == (-2097151999));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 398478411, (-1583251731L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1184773320L) + "'", long2 == (-1184773320L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1583251731L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(8625328718985906577L, (long) 16000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8625328718985890577L + "'", long2 == 8625328718985890577L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.0d), (-1104039972), (-1017118916));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-180673732));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1447298858494002d, 1.0670616196974443d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1551536133291418d + "'", double2 == 1.1551536133291418d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray5);
        double[] doubleArray7 = null;
        try {
            double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.7299512698867918d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.2250738585072014E-308d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 17);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double[] doubleArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 0.006420707498838454d);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray24);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double[] doubleArray43 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass45 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass47 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection49, true);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray43);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079574559 + "'", int7 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1079574559 + "'", int31 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.4422623365952054d), (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4422623365952054d) + "'", double2 == (-1.4422623365952054d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long long2 = org.apache.commons.math.util.FastMath.min(355687428096000L, 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.01711872E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.827660991974851E10d + "'", double1 == 5.827660991974851E10d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-35L), (-2097151999));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1806503139));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8065031389999998E9d) + "'", double1 == (-1.8065031389999998E9d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int2 = org.apache.commons.math.util.FastMath.max((-10), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1076101120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-100L), 197L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-19700L) + "'", long2 == (-19700L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 16000);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 100, (long) (-2038431743));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1260250251);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1950);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8010443814797708d + "'", double1 == 0.8010443814797708d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1104039972));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.104039972E9d) + "'", double1 == (-1.104039972E9d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9613974918795568d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1164953397656396d) + "'", double1 == (-1.1164953397656396d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) -1, 160, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 9223372036854775807L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.223372036854776E18d + "'", double2 == 9.223372036854776E18d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 8973392788L, 1.5613483159465477E9d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.136228346192656E274d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9930840092769248d) + "'", double1 == (-0.9930840092769248d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1017118653));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7752069378299702E7d) + "'", double1 == (-1.7752069378299702E7d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1260250250L, (-2.322537803101629d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.322537803101629d) + "'", double2 == (-2.322537803101629d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long1 = org.apache.commons.math.util.FastMath.round((-2.322537803101629d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', (-2038431743));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-160000L), (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-160000.0f) + "'", float2 == (-160000.0f));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 195L, 13.117797295600862d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 194.99999999999997d + "'", double2 == 194.99999999999997d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1583251731L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.58325171E9f + "'", float1 == 1.58325171E9f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.9341263038511088d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7325119202378503d) + "'", double1 == (-0.7325119202378503d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.3754263876807227d, (double) Float.NaN, 0.9443504370351303d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.math.util.FastMath.min(35, (-2038431743));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2038431743) + "'", int2 == (-2038431743));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.006420707498838454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5643755751791097d + "'", double1 == 1.5643755751791097d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 97L);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 0.7853981633974483d);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.7765997770389093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-160000L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 16L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.tan(2091.8861867103615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4400163594084265d) + "'", double1 == (-0.4400163594084265d));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.7853981633974483d);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1806503170 + "'", int8 == 1806503170);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(13.0d, 1.8151424220741028d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.999999999999998d + "'", double2 == 12.999999999999998d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double2 = org.apache.commons.math.util.FastMath.min(13.117797295600862d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.117797295600862d + "'", double2 == 13.117797295600862d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(900, (-1104039972));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(52, 1586880531);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.49484536082474d + "'", double1 == 48.49484536082474d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9443504370351303d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4800374208664644d + "'", double1 == 1.4800374208664644d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(836.7907795824698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1806503139), (-11L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1806503150L) + "'", long2 == (-1806503150L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9117339147869651d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5643755751791097d, 172.70234343568234d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (-1069449216L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32803.98024630548d + "'", double1 == 32803.98024630548d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int int2 = org.apache.commons.math.util.MathUtils.pow(17, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1654238625 + "'", int2 == 1654238625);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.017118721E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.8813735870195429d) + "'", number8.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection7, true);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection17, true);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray21);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double[] doubleArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray29.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        java.lang.Class<?> wildcardClass33 = doubleArray29.getClass();
        java.lang.Class<?> wildcardClass34 = doubleArray29.getClass();
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray29);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 9700.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32657918471542563d + "'", double1 == 0.32657918471542563d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.024005719083840586d, (-128));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double2 = org.apache.commons.math.util.FastMath.pow(14.60475425404424d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.64819060740832d + "'", double2 == 62.64819060740832d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.4400163594084265d), (-1.2602502509999998E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592653240643d) + "'", double2 == (-3.141592653240643d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.7752069378299702E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1017118916));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.01711891E9f) + "'", float2 == (-1.01711891E9f));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(655.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4516290508338701E284d + "'", double1 == 1.4516290508338701E284d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1076101120, 160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160 + "'", int2 == 160);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1017118916), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1017118884) + "'", int2 == (-1017118884));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5235L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(9700L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        java.lang.Number number13 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        boolean boolean15 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-0.8813735870195429d) + "'", number14.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0 + "'", number18.equals(0));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 197L, (double) 1017118721);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.925693717026842d + "'", double2 == 3.925693717026842d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1069449217));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double2 = org.apache.commons.math.util.FastMath.atan2(6.283185307179586d, 655.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009592355105102075d + "'", double2 == 0.009592355105102075d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.floor(9.042984783239863d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-128));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-128) + "'", int2 == (-128));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        int int10 = nonMonotonousSequenceException3.getIndex();
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) ' ');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 0.0064206193d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-4522783837087858687L), 4443056.833513324d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Throwable throwable20 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.3821138948910999d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray16 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        double[] doubleArray18 = null;
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double[] doubleArray23 = null;
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray23);
        double[] doubleArray26 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass28 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        java.lang.Class<?> wildcardClass31 = doubleArray26.getClass();
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray26);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray26);
        double[] doubleArray35 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Class<?> wildcardClass37 = doubleArray35.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Class<?> wildcardClass39 = doubleArray35.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection41, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection41, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        double[] doubleArray48 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        java.lang.Class<?> wildcardClass50 = doubleArray48.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        java.lang.Class<?> wildcardClass52 = doubleArray48.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48, orderDirection54, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection54, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection54, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection54, true);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-2097151999), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2097151999 + "'", int2 == 2097151999);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1017118653));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1017118653 + "'", int1 == 1017118653);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.4711276743037345d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 333548014 + "'", int1 == 333548014);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-180675682));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        java.lang.Class<?> wildcardClass16 = doubleArray11.getClass();
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray11);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-2.322537803101629d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int int1 = org.apache.commons.math.util.FastMath.round(Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1806503150L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1260250251));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1260250251L) + "'", long1 == (-1260250251L));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(5L, 110L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 550L + "'", long2 == 550L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9171523356672744d) + "'", double1 == (-0.9171523356672744d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1583251731L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97L, (float) 1104039936);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.136228346192656E274d), (-0.9171523356672744d), 3.718916686014861d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 9.9999995E-33f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.1805254859572636d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5643755751791097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943298d + "'", double1 == 0.17453292519943298d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 52, (-1184773320L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1104039936);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1017118653), 1076101120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.8010443814797708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1806503139));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-128), 1079574559);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-11L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 225.95084645419513d + "'", double1 == 225.95084645419513d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-10));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-36));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1017118653), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1260250251, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.ceil(48.49484536082474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.0d + "'", double1 == 49.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (-180675682L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) -1, (-100L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 195L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 195L + "'", long1 == 195L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.7581226324091722d), (double) 9700.0f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0299910048568779d + "'", double2 == 0.0299910048568779d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int2 = org.apache.commons.math.util.FastMath.min((-1069449216), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1069449216) + "'", int2 == (-1069449216));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray33);
        double[] doubleArray45 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        double[] doubleArray50 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        double[] doubleArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
        java.lang.Class<?> wildcardClass57 = doubleArray55.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
        java.lang.Class<?> wildcardClass59 = doubleArray55.getClass();
        java.lang.Class<?> wildcardClass60 = doubleArray55.getClass();
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray55);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray55);
        double[] doubleArray64 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        java.lang.Class<?> wildcardClass66 = doubleArray64.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        java.lang.Class<?> wildcardClass68 = doubleArray64.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection70, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection70, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
        double[] doubleArray77 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        java.lang.Class<?> wildcardClass79 = doubleArray77.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        java.lang.Class<?> wildcardClass81 = doubleArray77.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77, orderDirection83, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection83, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection83, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1079574559 + "'", int21 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(12.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.605551275463989d + "'", double1 == 3.605551275463989d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double2 = org.apache.commons.math.util.FastMath.min(372.16757365268984d, 3.718916686014861d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.718916686014861d + "'", double2 == 3.718916686014861d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1806503170, 333548014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1472955156 + "'", int2 == 1472955156);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1069449216), (-1017118884));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52330332) + "'", int2 == (-52330332));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-128), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 128L + "'", long2 == 128L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1447298858494002d, 68.0d, 0.8813735870195428d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.7372146681639586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7372146681639588d + "'", double1 == 0.7372146681639588d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0927837451120071d + "'", double1 == 0.0927837451120071d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.58325171E9f, (java.lang.Number) 16000, 1586880531);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1586880531 + "'", int4 == 1586880531);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        long long2 = org.apache.commons.math.util.FastMath.max(1260250250L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1260250250L + "'", long2 == 1260250250L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-100L), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-100.0f) + "'", float2 == (-100.0f));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray8 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        double[] doubleArray10 = null;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.006420707498838454d);
        double[] doubleArray15 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        java.lang.Class<?> wildcardClass17 = doubleArray15.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        java.lang.Class<?> wildcardClass19 = doubleArray15.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection21, true);
        double[] doubleArray25 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray25.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        java.lang.Class<?> wildcardClass29 = doubleArray25.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection31, true);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray25);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray25);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 99.99357929250117d + "'", double35 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1079574559);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4419647419307422d + "'", double1 == 1.4419647419307422d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1104039936L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        float float2 = org.apache.commons.math.util.FastMath.max(9.9999995E-33f, (float) (-2038431743));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.03843174E9f) + "'", float2 == (-2.03843174E9f));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.FastMath.ulp(92217.62949712273d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4551915228366852E-11d + "'", double1 == 1.4551915228366852E-11d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.006420619268761072d, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.670710403452705E-7d + "'", double2 == 2.670710403452705E-7d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-4522783837087858687L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int2 = org.apache.commons.math.util.FastMath.min((-10), (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.29670597283903605d + "'", double1 == 0.29670597283903605d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(52, 1806503139);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 550L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.599310885968812d + "'", double1 == 9.599310885968812d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 17L, (double) 52, 0.8010443814797708d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-3.141592653240643d), 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963266203215d) + "'", double2 == (-1.5707963266203215d));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1260250251L), 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2091.8861867103615d, 2.120327294217057E-250d, (double) 550L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(17, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 'a', (double) 1586880531, 9.599310885968812d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int[] intArray3 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray4 = new int[] {};
        int[] intArray10 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray18);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray22 = new int[] {};
        int[] intArray28 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray36);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray53);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray53);
        int[] intArray58 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray64);
        int[] intArray66 = new int[] {};
        int[] intArray72 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray72);
        int[] intArray75 = new int[] {};
        int[] intArray81 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray81);
        int[] intArray83 = new int[] {};
        int[] intArray89 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray83, intArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray89);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray81);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray64);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.5613483159465477E9d + "'", double21 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(99L, (long) (-1104039972));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-109299957228L) + "'", long2 == (-109299957228L));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1, 16L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 900.0000000000001d, 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray33);
        double[] doubleArray45 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.006420707498838454d);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass56 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection58, true);
        double[] doubleArray62 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        java.lang.Class<?> wildcardClass64 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        java.lang.Class<?> wildcardClass66 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection68, true);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray62);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray62);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray50);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1079574559 + "'", int21 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 99.99357929250117d + "'", double72 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 99.99357929250117d + "'", double73 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1079574559 + "'", int74 == 1079574559);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1184773320L), 8.673617379884035E-19d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1847733199999998E9d) + "'", double2 == (-1.1847733199999998E9d));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(14.60475425404424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1100865.3094543158d + "'", double1 == 1100865.3094543158d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414213562373095d + "'", double1 == 1.414213562373095d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        java.lang.Class<?> wildcardClass22 = doubleArray17.getClass();
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray17);
        double[] doubleArray26 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass28 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7372146681639586d, (java.lang.Number) 0.0299910048568779d, 1654238625, orderDirection32, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.7752069378299702E7d), (java.lang.Number) 0.009592355105102075d, (-1017118721), orderDirection32, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection12, true);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray6);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 97L);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 0.7853981633974483d);
        double[] doubleArray25 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray27);
        double[] doubleArray30 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray30);
        double[] doubleArray32 = null;
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray32);
        double[] doubleArray35 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Class<?> wildcardClass37 = doubleArray35.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Class<?> wildcardClass39 = doubleArray35.getClass();
        java.lang.Class<?> wildcardClass40 = doubleArray35.getClass();
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray35);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray35);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray35);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.FastMath.signum(4443057.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49203441069488424d + "'", double1 == 0.49203441069488424d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1017118721);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double2 = org.apache.commons.math.util.FastMath.min(100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.Number number0 = null;
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        java.lang.Class<?> wildcardClass22 = doubleArray17.getClass();
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray17);
        double[] doubleArray26 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass28 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        java.lang.Class<?> wildcardClass30 = doubleArray26.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection32, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection32, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray39 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass43 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection45, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection45, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection45, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.4711276743037345d, (int) (byte) 1, orderDirection45, false);
        int int54 = nonMonotonousSequenceException53.getIndex();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.7752069378299702E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.util.FastMath.log(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 10, 101);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 97L, (double) 36L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 36.0d + "'", double2 == 36.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1905511648), (int) '4', 195);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-180675682L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.4711276743037347d, 655.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0022459926726870424d + "'", double2 == 0.0022459926726870424d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        int int2 = org.apache.commons.math.util.FastMath.min((-10), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8414709848078965d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 8625328718985890577L, (double) 9.9999995E-33f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.6253287189858898E18d + "'", double2 == 8.6253287189858898E18d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0038848218538872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017521095452147056d + "'", double1 == 0.017521095452147056d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1806503150L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1654238625);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.919753875164847d + "'", double1 == 21.919753875164847d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.006420707498838454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.006420751615786778d + "'", double1 == 0.006420751615786778d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.9341263038511088d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0760299614477853d) + "'", double1 == (-1.0760299614477853d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.1847733199999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1260250251), 1079574560L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1260250251L) + "'", long2 == (-1260250251L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1586880531, (-180675692));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1406204839 + "'", int2 == 1406204839);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 97L);
        java.lang.Class<?> wildcardClass12 = doubleArray7.getClass();
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(8.6253287189858898E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.941949325108723E20d + "'", double1 == 4.941949325108723E20d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1806503139);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6108652381980153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7815786833057918d + "'", double1 == 0.7815786833057918d);
    }
}

