import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(21840000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 100L, 0, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 8973392788L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.7372146681639586d, (double) (-7.4001133E8f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926525935722d + "'", double2 == 3.1415926525935722d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.8813735870195429d) + "'", number8.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.49203441069488424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6356404017596787d + "'", double1 == 0.6356404017596787d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 9154068480L, (double) 5200L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2350469597522027d + "'", double1 == 2.2350469597522027d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-2.097152E9f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.097152E9d) + "'", double2 == (-2.097152E9d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double[] doubleArray24 = null;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray22);
        double[] doubleArray28 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray28.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray37 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray39);
        double[] doubleArray42 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double[] doubleArray44 = null;
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray44);
        double[] doubleArray47 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        java.lang.Class<?> wildcardClass49 = doubleArray47.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        java.lang.Class<?> wildcardClass51 = doubleArray47.getClass();
        java.lang.Class<?> wildcardClass52 = doubleArray47.getClass();
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray47);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray47);
        double[] doubleArray56 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        java.lang.Class<?> wildcardClass58 = doubleArray56.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        java.lang.Class<?> wildcardClass60 = doubleArray56.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection62, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection62, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        double[] doubleArray69 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        java.lang.Class<?> wildcardClass71 = doubleArray69.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        java.lang.Class<?> wildcardClass73 = doubleArray69.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection75, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection75, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection75, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection75, true);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        long long2 = org.apache.commons.math.util.FastMath.max(97L, 1017118720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1017118720L + "'", long2 == 1017118720L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.0064206193d, (int) (short) 0);
        try {
            java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-52330332));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 5, (double) (-35.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32.69911184307752d) + "'", double2 == (-32.69911184307752d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.529429087511423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.411309973016966d + "'", double1 == 2.411309973016966d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2L, 0.9681892072024199d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9681892072024199d + "'", double2 == 0.9681892072024199d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 8625328718985890577L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.6253287189858908E18d + "'", double1 == 8.6253287189858908E18d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1), 1806503170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1806503169 + "'", int2 == 1806503169);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.75d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9241412930528897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7278506656032296d + "'", double1 == 0.7278506656032296d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.311231547115195E15d + "'", double1 == 4.311231547115195E15d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1950, 1260250251);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-180673732), (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6323580620L) + "'", long2 == (-6323580620L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.07610112E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07610112E9d + "'", double1 == 1.07610112E9d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(8973392788L, (long) (-36));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8973392824L + "'", long2 == 8973392824L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        long long1 = org.apache.commons.math.util.FastMath.abs((-109299957228L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 109299957228L + "'", long1 == 109299957228L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.4422623365952054d), 100.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2097151964, (long) 1017118720);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2097151964L + "'", long2 == 2097151964L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray21);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        java.lang.Class<?> wildcardClass29 = doubleArray24.getClass();
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection39, false);
        double[] doubleArray47 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        java.lang.Class<?> wildcardClass49 = doubleArray47.getClass();
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 97L);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray51);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52 == 3.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-2.097152E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.097152E9d) + "'", double1 == (-2.097152E9d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1260250287));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1260250287 + "'", int1 == 1260250287);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str24 = nonMonotonousSequenceException23.toString();
        java.lang.Number number25 = nonMonotonousSequenceException23.getPrevious();
        java.lang.String str26 = nonMonotonousSequenceException23.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException23.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.02517222645109304d), 6.38905609893065d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.025172226451093037d) + "'", double2 == (-0.025172226451093037d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 68, (-1017118884));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.907968004580309E-48d + "'", double2 == 2.907968004580309E-48d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 109299957228L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass6 = doubleArray4.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray10 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray10.getClass();
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 97L);
        java.lang.Class<?> wildcardClass15 = doubleArray10.getClass();
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray10);
        double[] doubleArray19 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        java.lang.Class<?> wildcardClass21 = doubleArray19.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray25 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray25.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        java.lang.Class<?> wildcardClass29 = doubleArray25.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray25);
        double[] doubleArray32 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 0.006420707498838454d);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray40);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray40);
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1017118653, (double) (-19700L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0171186529999999E9d + "'", double2 == 1.0171186529999999E9d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 9700L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.8895032590730141d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.050852456354836165d) + "'", double1 == (-0.050852456354836165d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1104039936, (float) 4398046513201152001L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.10403994E9f + "'", float2 == 1.10403994E9f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.18120467008033d, 0.6420149920119999d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.9999546000702375d), (double) 5.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double1 = org.apache.commons.math.util.FastMath.log10(13.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1139433523068367d + "'", double1 == 1.1139433523068367d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 5200L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1017118653), 333548014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-683570639) + "'", int2 == (-683570639));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8813735870195429d) + "'", number7.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.8813735870195429d) + "'", number8.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 16000L, (java.lang.Number) 15.104412573075516d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray23 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection29, true);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass37 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection39, true);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray33);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1079574559 + "'", int21 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 36);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-3.3019272488946267d), (double) (-180673732));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.301927248894627d) + "'", double2 == (-3.301927248894627d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-740011332), 9700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 197L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 197.0f + "'", float1 == 197.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1806503139, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1806503139L + "'", long2 == 1806503139L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        double[] doubleArray29 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray29.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray35 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Class<?> wildcardClass37 = doubleArray35.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Class<?> wildcardClass39 = doubleArray35.getClass();
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray35);
        double[] doubleArray42 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double[] doubleArray44 = null;
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray44);
        double[] doubleArray47 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray49);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass56 = doubleArray52.getClass();
        java.lang.Class<?> wildcardClass57 = doubleArray52.getClass();
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray52);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray52);
        double[] doubleArray61 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        java.lang.Class<?> wildcardClass63 = doubleArray61.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        java.lang.Class<?> wildcardClass65 = doubleArray61.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61, orderDirection67, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection67, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection67, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection67, true);
        double[] doubleArray77 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        java.lang.Class<?> wildcardClass79 = doubleArray77.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double[] doubleArray83 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray83);
        java.lang.Class<?> wildcardClass85 = doubleArray83.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray83);
        java.lang.Class<?> wildcardClass87 = doubleArray83.getClass();
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray83);
        double[] doubleArray90 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray90);
        double[] doubleArray92 = null;
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray90, doubleArray92);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, 0.006420707498838454d);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray90);
        int int97 = org.apache.commons.math.util.MathUtils.hash(doubleArray83);
        int int98 = org.apache.commons.math.util.MathUtils.hash(doubleArray83);
        double double99 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 100.0d + "'", double81 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1079574559 + "'", int97 == 1079574559);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 1079574559 + "'", int98 == 1079574559);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(195L, (long) 1017118653);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 68);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 35);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 4);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1079574559 + "'", int13 == 1079574559);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        java.lang.String str24 = nonMonotonousSequenceException21.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getArgument();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str37 = nonMonotonousSequenceException36.toString();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        java.lang.String str39 = nonMonotonousSequenceException36.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str44 = nonMonotonousSequenceException43.toString();
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        boolean boolean46 = nonMonotonousSequenceException36.getStrict();
        int int47 = nonMonotonousSequenceException36.getIndex();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        boolean boolean49 = nonMonotonousSequenceException28.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = nonMonotonousSequenceException28.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number15, (java.lang.Number) (-1.80675696E8f), (-1104039972), orderDirection50, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number57 = nonMonotonousSequenceException56.getArgument();
        java.lang.String str58 = nonMonotonousSequenceException56.toString();
        nonMonotonousSequenceException52.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException56);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-0.8813735870195429d) + "'", number31.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str37.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0 + "'", number38.equals(0));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str39.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 10.0d + "'", number57.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str58.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (-1104039972));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1406204839);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        long long2 = org.apache.commons.math.util.FastMath.min(201640040160000L, (long) 1017118653);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1017118653L + "'", long2 == 1017118653L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, 2097151964);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(160, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 161 + "'", int2 == 161);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) (-248033786));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 5200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7827895444060654d + "'", double1 == 0.7827895444060654d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1410065408, (-180675692));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        java.lang.Class<?> wildcardClass16 = doubleArray11.getClass();
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray11);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        java.lang.Class<?> wildcardClass22 = doubleArray20.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        java.lang.Class<?> wildcardClass24 = doubleArray20.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection26, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        double[] doubleArray38 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        java.lang.Class<?> wildcardClass40 = doubleArray38.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        java.lang.Class<?> wildcardClass42 = doubleArray38.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection44, true);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double[] doubleArray50 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        java.lang.Class<?> wildcardClass52 = doubleArray50.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray56 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        java.lang.Class<?> wildcardClass58 = doubleArray56.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        java.lang.Class<?> wildcardClass60 = doubleArray56.getClass();
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray56);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray56);
        double[] doubleArray64 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        double[] doubleArray66 = null;
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, 0.006420707498838454d);
        double[] doubleArray71 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        java.lang.Class<?> wildcardClass73 = doubleArray71.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        java.lang.Class<?> wildcardClass75 = doubleArray71.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71, orderDirection77, true);
        double[] doubleArray81 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81);
        java.lang.Class<?> wildcardClass83 = doubleArray81.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81);
        java.lang.Class<?> wildcardClass85 = doubleArray81.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection87 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81, orderDirection87, true);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray81);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray81);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray81);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.0d + "'", double54 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertTrue("'" + orderDirection87 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection87.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 99.99357929250117d + "'", double91 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 100.0d + "'", double92 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 1.7299512698867918d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int1 = org.apache.commons.math.util.MathUtils.sign(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.18120467008033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8895032590730141d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray12.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass16 = doubleArray12.getClass();
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray6);
        double[] doubleArray21 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        java.lang.Class<?> wildcardClass23 = doubleArray21.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray27 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray27.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        java.lang.Class<?> wildcardClass31 = doubleArray27.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray27);
        double[] doubleArray34 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.006420707498838454d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray34);
        double[] doubleArray42 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        java.lang.Class<?> wildcardClass44 = doubleArray42.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        java.lang.Class<?> wildcardClass46 = doubleArray42.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection49, false);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray42);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1069449216));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        long long1 = org.apache.commons.math.util.FastMath.abs(1017118653L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1017118653L + "'", long1 == 1017118653L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.004389296250625549d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.004389282156774848d) + "'", double1 == (-0.004389282156774848d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 333548014);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int2 = org.apache.commons.math.util.FastMath.min(5, 900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double2 = org.apache.commons.math.util.FastMath.max(4.440892098500626E-16d, 1.5707865314389355d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707865314389355d + "'", double2 == 1.5707865314389355d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, 1260250268L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-944468047) + "'", int2 == (-944468047));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1017118653);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double2 = org.apache.commons.math.util.FastMath.min(3.925693717026842d, (-1.1752011936438012d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1752011936438012d) + "'", double2 == (-1.1752011936438012d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray7 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray15 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray15);
        int[] intArray18 = new int[] {};
        int[] intArray24 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray32 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray32);
        int[] intArray35 = new int[] {};
        int[] intArray41 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray41);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray24);
        try {
            int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        float float1 = org.apache.commons.math.util.FastMath.abs(197.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 197.0f + "'", float1 == 197.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1260250251), 1017118653L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-243131598L) + "'", long2 == (-243131598L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 17);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        java.lang.Class<?> wildcardClass16 = doubleArray11.getClass();
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection28, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9700L, (java.lang.Number) 1.4800374208664644d, (-1017118884), orderDirection28, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection28, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079574559 + "'", int7 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1079574559 + "'", int17 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 900, 1260250287);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1017118653);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.asinh(194.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.966153313680814d + "'", double1 == 5.966153313680814d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-9154066530L), 9154068880L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2350L + "'", long2 == 2350L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int int1 = org.apache.commons.math.util.MathUtils.sign(36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1260250251L), (double) 1017118756L, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(333548014, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1017118721L), (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-683570639));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.3818891261280042d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8656570386088638d) + "'", double1 == (-1.8656570386088638d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.0064206193d, (int) (short) 0);
        boolean boolean10 = nonMonotonousSequenceException9.getStrict();
        int int11 = nonMonotonousSequenceException9.getIndex();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.006 >= 1)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.006 >= 1)"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) -1, 1017118720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1017118719 + "'", int2 == 1017118719);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.925693717026842d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 17);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 836.7907795824698d);
        double[] doubleArray13 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 0.006420707498838454d);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079574559 + "'", int7 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.tan((-40.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.117214930923896d + "'", double1 == 1.117214930923896d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, (long) 333548014);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-160000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.676076274785675d) + "'", double1 == (-12.676076274785675d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray6 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection12, true);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray6);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
        double[] doubleArray18 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        java.lang.Class<?> wildcardClass20 = doubleArray18.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass28 = doubleArray24.getClass();
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray24);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        long long2 = org.apache.commons.math.util.FastMath.max(99L, (long) 9700);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1260250251), (-1017118721));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.000000000000004d + "'", double1 == 17.000000000000004d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1072693248L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.3818891261280042d), (double) 8625328718985906577L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.311231547115195E15d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.311231547115195E15d + "'", double2 == 4.311231547115195E15d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-180675692));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str19 = nonMonotonousSequenceException18.toString();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        java.lang.String str21 = nonMonotonousSequenceException18.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str26 = nonMonotonousSequenceException25.toString();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        boolean boolean28 = nonMonotonousSequenceException18.getStrict();
        int int29 = nonMonotonousSequenceException18.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean31 = nonMonotonousSequenceException10.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str36 = nonMonotonousSequenceException35.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str41 = nonMonotonousSequenceException40.toString();
        java.lang.Number number42 = nonMonotonousSequenceException40.getPrevious();
        java.lang.String str43 = nonMonotonousSequenceException40.toString();
        java.lang.Number number44 = nonMonotonousSequenceException40.getArgument();
        java.lang.Number number45 = nonMonotonousSequenceException40.getArgument();
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        int int47 = nonMonotonousSequenceException35.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException35.getDirection();
        java.lang.String str50 = nonMonotonousSequenceException35.toString();
        java.lang.String str51 = nonMonotonousSequenceException35.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str36.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str41.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0 + "'", number42.equals(0));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (-0.8813735870195429d) + "'", number44.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-0.8813735870195429d) + "'", number45.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str50.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str51.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2050);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str19 = nonMonotonousSequenceException18.toString();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        java.lang.String str21 = nonMonotonousSequenceException18.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str26 = nonMonotonousSequenceException25.toString();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        boolean boolean28 = nonMonotonousSequenceException18.getStrict();
        int int29 = nonMonotonousSequenceException18.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException18.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        long long1 = org.apache.commons.math.util.FastMath.round(0.32657918471542563d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 17L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1079525407 + "'", int6 == 1079525407);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Class<?> wildcardClass16 = doubleArray14.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        java.lang.Class<?> wildcardClass21 = doubleArray19.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        java.lang.Class<?> wildcardClass23 = doubleArray19.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection25, true);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        double[] doubleArray31 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        java.lang.Class<?> wildcardClass33 = doubleArray31.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray37 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        java.lang.Class<?> wildcardClass39 = doubleArray37.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        java.lang.Class<?> wildcardClass41 = doubleArray37.getClass();
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray37);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray37);
        double[] doubleArray45 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.006420707498838454d);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass56 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection58, true);
        double[] doubleArray62 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        java.lang.Class<?> wildcardClass64 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        java.lang.Class<?> wildcardClass66 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection68, true);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray62);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray62);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray62);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 99.99357929250117d + "'", double72 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 100.0d + "'", double73 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3120000);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3120000.0f + "'", float1 == 3120000.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray40 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray40);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray23);
        int[] intArray53 = new int[] {};
        int[] intArray59 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray59);
        int[] intArray61 = new int[] {};
        int[] intArray67 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray67);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24491866240370913d + "'", double1 == 0.24491866240370913d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1465556826), (long) (-740011332));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.136228346192656E274d), (java.lang.Number) 100.0d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.136228346192656E274d) + "'", number4.equals((-1.136228346192656E274d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= -11,362,283,461,926,560,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= -11,362,283,461,926,560,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1104039972));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9269132585026007E7d) + "'", double1 == (-1.9269132585026007E7d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 9700, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.7765997770389093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.001027973179058d + "'", double1 == 8.001027973179058d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8010443814797708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9287215568451568d + "'", double1 == 0.9287215568451568d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 860908405L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.FastMath.rint(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.0d + "'", double1 == 115.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.569478706773049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (byte) 100, (-740011332));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07610112E9d + "'", double1 == 1.07610112E9d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int1 = org.apache.commons.math.util.MathUtils.hash(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1023410176 + "'", int1 == 1023410176);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6632456843634444d + "'", double1 == 0.6632456843634444d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.atan(4443057.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707961017246352d + "'", double1 == 1.5707961017246352d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection13, true);
        double[] doubleArray17 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass21 = doubleArray17.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection23, true);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray29 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray29.getClass();
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 97L);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.7853981633974483d);
        double[] doubleArray37 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray39);
        double[] doubleArray42 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        double[] doubleArray44 = null;
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray44);
        double[] doubleArray47 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        java.lang.Class<?> wildcardClass49 = doubleArray47.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        java.lang.Class<?> wildcardClass51 = doubleArray47.getClass();
        java.lang.Class<?> wildcardClass52 = doubleArray47.getClass();
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray47);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray47);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray47);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray47);
        double[] doubleArray57 = null;
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1L, 109299957228L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-109299957227L) + "'", long2 == (-109299957227L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6632456843634444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1069449217), 68);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 10L, 900);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.9269132585026007E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(201640040160000L, (long) 883419577);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 201639156740423L + "'", long2 == 201639156740423L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.18252582355595404d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int2 = org.apache.commons.math.util.FastMath.min((-2038431743), (-52330332));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2038431743) + "'", int2 == (-2038431743));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str24 = nonMonotonousSequenceException23.toString();
        java.lang.Number number25 = nonMonotonousSequenceException23.getPrevious();
        java.lang.String str26 = nonMonotonousSequenceException23.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str31 = nonMonotonousSequenceException30.toString();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        boolean boolean33 = nonMonotonousSequenceException23.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        java.lang.Number number35 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-0.8813735870195429d) + "'", number35.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-35.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1079574559);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger19);
        double[] doubleArray24 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray24.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray33 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray35);
        double[] doubleArray38 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double[] doubleArray40 = null;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray40);
        double[] doubleArray43 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass45 = doubleArray43.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        java.lang.Class<?> wildcardClass47 = doubleArray43.getClass();
        java.lang.Class<?> wildcardClass48 = doubleArray43.getClass();
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray43);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray43);
        double[] doubleArray52 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        java.lang.Class<?> wildcardClass56 = doubleArray52.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection58, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection58, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        double[] doubleArray65 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        java.lang.Class<?> wildcardClass67 = doubleArray65.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        java.lang.Class<?> wildcardClass69 = doubleArray65.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection71, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection71, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2979.3805346802806d, (java.lang.Number) 0.006420619268761072d, 10, orderDirection71, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection71, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger19, (java.lang.Number) 48.49484536082474d, 0, orderDirection71, true);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection29, false);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray22);
        double[] doubleArray33 = null;
        try {
            double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double[] doubleArray24 = null;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int[] intArray3 = new int[] { (-1104039972), 10, (-1104039972) };
        int[] intArray4 = new int[] {};
        int[] intArray10 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray18);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray22 = new int[] {};
        int[] intArray28 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray36);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray53);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray53);
        int[] intArray58 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray64);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.5613483159465477E9d + "'", double21 == 1.5613483159465477E9d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(4, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 9154068480L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1472955156);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 1079574559);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 9154068480L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 1079574559);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 9154068480L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger29);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger29);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        try {
            java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (-944468047));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1472955156, 4443055.260253992d, (-1.7752069378299702E7d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0475930126492587d + "'", double1 == 1.0475930126492587d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1.4062048E9f, 2.038431743E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0384317421559925E9d + "'", double2 == 2.0384317421559925E9d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double2 = org.apache.commons.math.util.FastMath.pow(172.70234343568234d, 0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 107.27720864413814d + "'", double2 == 107.27720864413814d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1260250287, 21840000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1823774719) + "'", int2 == (-1823774719));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-0.9809170849695142d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 16000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13100706618943186d + "'", double1 == 0.13100706618943186d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int[] intArray3 = new int[] { 900, (byte) -1, 1410065408 };
        int[] intArray4 = new int[] {};
        int[] intArray10 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray18);
        int[] intArray21 = new int[] {};
        int[] intArray27 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray35);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray27);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray53 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray53);
        int[] intArray56 = new int[] {};
        int[] intArray62 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray62);
        int[] intArray64 = new int[] {};
        int[] intArray70 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray64, intArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray70);
        int[] intArray73 = new int[] {};
        int[] intArray79 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray79);
        int[] intArray81 = new int[] {};
        int[] intArray87 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray87);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray79);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray62);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray62);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray27);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1410065398 + "'", int93 == 1410065398);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) -1, (-180673732));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 180673732 + "'", int2 == 180673732);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str19 = nonMonotonousSequenceException18.toString();
        java.lang.Number number20 = nonMonotonousSequenceException18.getPrevious();
        java.lang.String str21 = nonMonotonousSequenceException18.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str26 = nonMonotonousSequenceException25.toString();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        boolean boolean28 = nonMonotonousSequenceException18.getStrict();
        int int29 = nonMonotonousSequenceException18.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean31 = nonMonotonousSequenceException10.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str37 = nonMonotonousSequenceException36.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str42 = nonMonotonousSequenceException41.toString();
        java.lang.Number number43 = nonMonotonousSequenceException41.getPrevious();
        java.lang.String str44 = nonMonotonousSequenceException41.toString();
        java.lang.Number number45 = nonMonotonousSequenceException41.getArgument();
        java.lang.Number number46 = nonMonotonousSequenceException41.getArgument();
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        int int48 = nonMonotonousSequenceException36.getIndex();
        java.lang.Number number49 = nonMonotonousSequenceException36.getArgument();
        java.lang.Number number50 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.8813735870195429d) + "'", number13.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str37.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str42.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0 + "'", number43.equals(0));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str44.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-0.8813735870195429d) + "'", number45.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-0.8813735870195429d) + "'", number46.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-0.8813735870195429d) + "'", number49.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0 + "'", number50.equals(0));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-2L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.02517222645109304d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02516956884974919d) + "'", double1 == (-0.02516956884974919d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-100L), 1079574560L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5397872800L + "'", long2 == 5397872800L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.01711872E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.77520705476703E7d + "'", double1 == 1.77520705476703E7d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.8813735870195429d) + "'", number4.equals((-0.8813735870195429d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str7 = nonMonotonousSequenceException6.toString();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str14 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        java.lang.String str24 = nonMonotonousSequenceException21.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException21.getStrict();
        int int32 = nonMonotonousSequenceException21.getIndex();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        boolean boolean34 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.80675696E8f), (-1104039972), orderDirection35, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        java.lang.String str43 = nonMonotonousSequenceException41.toString();
        nonMonotonousSequenceException37.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        int int45 = nonMonotonousSequenceException37.getIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.8813735870195429d) + "'", number16.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 10.0d + "'", number42.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1104039972) + "'", int45 == (-1104039972));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2147483647, (-1823774719));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0171187200000001E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.77520705476703E7d + "'", double1 == 1.77520705476703E7d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass6 = doubleArray4.getClass();
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 97L);
        java.lang.Number number12 = null;
        double[] doubleArray16 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass18 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        java.lang.Class<?> wildcardClass20 = doubleArray16.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 52.0d, (int) (byte) -1, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 836.7907795824698d, (java.lang.Number) 1.5613483159465477E9d, 68, orderDirection22, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.004389282156774848d), (java.lang.Number) 2979.380534680281d, 0, orderDirection22, true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1072693248L, (-1583251731L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1931963367511592163L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 9154068470L, 333548014);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1069449216));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double[] doubleArray4 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass6 = doubleArray4.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        java.lang.Class<?> wildcardClass8 = doubleArray4.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9700L, (java.lang.Number) 1.4800374208664644d, (-1017118884), orderDirection10, true);
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException14.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray40 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray40);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int[] intArray53 = null;
        try {
            double double54 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.311231547115194E15d, 1.586880531E9d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0299910048568779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.029995501012477988d + "'", double1 == 0.029995501012477988d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.027413114388728267d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection7, true);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.math.util.FastMath.max(32, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 101L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 101.0f + "'", float1 == 101.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.9459198719785213d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.945919871978522d + "'", double1 == 2.945919871978522d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1072693248, 1586880531);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 550L, 160, 9700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2350L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2350.0d + "'", double1 == 2350.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass5 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection7, true);
        double[] doubleArray11 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Class<?> wildcardClass15 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection17, true);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection28, true);
        double[] doubleArray32 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        java.lang.Class<?> wildcardClass34 = doubleArray32.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        java.lang.Class<?> wildcardClass36 = doubleArray32.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection38, true);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray32);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray22);
        double[] doubleArray44 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        java.lang.Class<?> wildcardClass46 = doubleArray44.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray50 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        java.lang.Class<?> wildcardClass52 = doubleArray50.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        java.lang.Class<?> wildcardClass54 = doubleArray50.getClass();
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray50);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1551536133291418d, 4194304.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7541008313396275E-7d + "'", double2 == 2.7541008313396275E-7d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1017118721L, (long) 1017118721);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1017118721L + "'", long2 == 1017118721L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(152, (-1465556826));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 5L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.16753958088268972d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.1805254859572636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003150764113717037d + "'", double1 == 0.003150764113717037d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int int2 = org.apache.commons.math.util.FastMath.max(152, (-248033786));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-953922251), (-2038431743));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(655.4848567108893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.440368946568267d + "'", double1 == 11.440368946568267d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.8189894035458565E-12d, (-944468047));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.009265538105056E-36d + "'", double2 == 3.009265538105056E-36d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 9154068470L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.15406847E9d + "'", double2 == 9.15406847E9d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1806503139, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray14 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray31 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray23);
        int[] intArray35 = new int[] {};
        int[] intArray41 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray41);
        int[] intArray53 = new int[] {};
        int[] intArray59 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray59);
        int[] intArray61 = new int[] {};
        int[] intArray67 = new int[] { (byte) 10, (short) 0, 10, ' ', 100 };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray67);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray59);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1069449217, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1069449217L + "'", long2 == 1069449217L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 9154068470L, (double) (-953922251), 1100865.3094543158d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1410065408);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065408 + "'", int2 == 1410065408);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-292930128960L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-27.096347130372166d) + "'", double1 == (-27.096347130372166d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1076101120, (-180675682));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-22.007806026724577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 110L, 1.260250251E9d, 0.024005719083840586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int1 = org.apache.commons.math.util.MathUtils.sign(152);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1806503139);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42502.97800154714d + "'", double1 == 42502.97800154714d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-180675682), 17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double2 = org.apache.commons.math.util.FastMath.max(8.6253287189858908E18d, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.6253287189858908E18d + "'", double2 == 8.6253287189858908E18d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray13 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray13.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        java.lang.Class<?> wildcardClass17 = doubleArray13.getClass();
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray13);
        double[] doubleArray20 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 0.006420707498838454d);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray29 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray29.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        java.lang.Class<?> wildcardClass33 = doubleArray29.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection35, true);
        double[] doubleArray39 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass41 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        java.lang.Class<?> wildcardClass43 = doubleArray39.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection45, true);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray39);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray39);
        double[] doubleArray51 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        double[] doubleArray53 = null;
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 0.006420707498838454d);
        double[] doubleArray58 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        java.lang.Class<?> wildcardClass60 = doubleArray58.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        java.lang.Class<?> wildcardClass62 = doubleArray58.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection64, true);
        double[] doubleArray68 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
        java.lang.Class<?> wildcardClass70 = doubleArray68.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
        java.lang.Class<?> wildcardClass72 = doubleArray68.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68, orderDirection74, true);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray68);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray68);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray56);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection81, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1079574559 + "'", int27 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 99.99357929250117d + "'", double78 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 99.99357929250117d + "'", double79 == 99.99357929250117d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 99.99357929250117d + "'", double80 == 99.99357929250117d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str7 = nonMonotonousSequenceException6.toString();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str14 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.7752069378299702E7d), (java.lang.Number) (-0.5063656411097588d), 0, orderDirection18, true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.8813735870195429d) + "'", number16.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(52, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 83 + "'", int2 == 83);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str20 = nonMonotonousSequenceException3.toString();
        int int21 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 97L);
        java.lang.Class<?> wildcardClass6 = doubleArray5.getClass();
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5613483159465477E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.rint(2979.380534680281d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.0d + "'", double1 == 2979.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1017118820L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, (long) 9700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass26 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection29, false);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray22);
        double[] doubleArray34 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray34.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray40 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray40.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        java.lang.Class<?> wildcardClass44 = doubleArray40.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray40);
        double[] doubleArray47 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 0.006420707498838454d);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray47);
        double[] doubleArray55 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
        double[] doubleArray57 = null;
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str7 = nonMonotonousSequenceException6.toString();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str14 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number16 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        java.lang.Number number23 = nonMonotonousSequenceException21.getPrevious();
        java.lang.String str24 = nonMonotonousSequenceException21.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str29 = nonMonotonousSequenceException28.toString();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean31 = nonMonotonousSequenceException21.getStrict();
        int int32 = nonMonotonousSequenceException21.getIndex();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        boolean boolean34 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.80675696E8f), (-1104039972), orderDirection35, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) -1, (-1069449216));
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        java.lang.String str43 = nonMonotonousSequenceException41.toString();
        nonMonotonousSequenceException37.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException41.getDirection();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.8813735870195429d) + "'", number16.equals((-0.8813735870195429d)));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 10.0d + "'", number42.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)" + "'", str43.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,069,449,217 and -1,069,449,216 are not strictly increasing (-1 >= 10)"));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.025172226451093037d), (java.lang.Number) (-180675485L), (-180673732), orderDirection3, false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        long long2 = org.apache.commons.math.util.FastMath.min(3628800L, (long) 1017118719);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1950, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1950L + "'", long2 == 1950L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 161);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-109299957227L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.004389282156774848d), (double) (-180675680), (double) 1260250251L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection13, true);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double[] doubleArray19 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        java.lang.Class<?> wildcardClass21 = doubleArray19.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray25 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray25.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        java.lang.Class<?> wildcardClass29 = doubleArray25.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray25);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 14.60475425404424d);
        try {
            double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.8065031389999998E9d), (double) 52, (double) 2097151999);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-180675680));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.80675681E8d) + "'", double1 == (-1.80675681E8d));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) 550L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2050);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570545d) + "'", double1 == (-0.16299078079570545d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.136228346192656E274d), (java.lang.Number) 100.0d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.136228346192656E274d) + "'", number4.equals((-1.136228346192656E274d)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-180673732), (-1465556826));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1284883094 + "'", int2 == 1284883094);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(398478411, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 398478421 + "'", int2 == 398478421);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-35));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.0d) + "'", double1 == (-36.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 101L, (float) 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 101.0f + "'", float2 == 101.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1079574559);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9154068480L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1079574559);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 9154068480L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger22);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (-683570639));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.7325119202378503d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-41.96984147265241d) + "'", double1 == (-41.96984147265241d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.272999558563747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 333548014);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5607966601082315d, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.99822295029797d + "'", double2 == 2.99822295029797d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 883419577);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1905511648), 1017118653);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-36L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.0d) + "'", double1 == (-36.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        long long1 = org.apache.commons.math.util.MathUtils.sign(16000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-1.8065031389999998E9d), (double) 4L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0911052960943117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0445598575928101d + "'", double1 == 1.0445598575928101d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, 398478437);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str9 = nonMonotonousSequenceException8.toString();
        java.lang.Number number10 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean18 = nonMonotonousSequenceException8.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str20 = nonMonotonousSequenceException8.toString();
        boolean boolean21 = nonMonotonousSequenceException8.getStrict();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.8834864931005E-310d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.88348649310057E-310d + "'", double1 == 3.88348649310057E-310d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.120327294217057E-250d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3628800L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.5707963266203215d), 225.95084645419513d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963266203213d) + "'", double2 == (-1.5707963266203213d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-2.0d), (double) 1806503139, 1.6487212707001282d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 36616273956L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.6616274E10f + "'", float2 == 3.6616274E10f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-944468047));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.670710403452705E-7d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.670710403452705E-7d + "'", double2 == 2.670710403452705E-7d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray7 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray7.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray16 = null;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.006420707498838454d);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray22 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        java.lang.Class<?> wildcardClass24 = doubleArray22.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1079574558L);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1079574559 + "'", int28 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-3.3019272488946267d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.600877130650263d + "'", double1 == 13.600877130650263d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-1069449216));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-100.0f), 2.688117141816136E43d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-248033786), 333548014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.16299078079570545d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1637134086956773d) + "'", double1 == (-0.1637134086956773d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1472955156, 83);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1472955073 + "'", int2 == 1472955073);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) (-0.964543937616722d), 5);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-101L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 0, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= -0.881)"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1079574559);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-180675680), (-1017118721), 160);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double[] doubleArray1 = new double[] { 100.0f };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 0.006420707498838454d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 17);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 836.7907795824698d);
        double[] doubleArray12 = null;
        try {
            double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079574559 + "'", int7 == 1079574559);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1931963367511592163L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(9.99999999999999d, 9.094947017729282E-13d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-683570639), 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1017118721L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9809170849695142d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9809170849695142d) + "'", double2 == (-0.9809170849695142d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 9154068480L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1472955156);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 1079574559);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 9154068480L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 1079574559);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 9154068480L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger29);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger29);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1069449217);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 100L, 0, orderDirection42, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger36, (java.lang.Number) 1.5430806348152437d, 3628800, orderDirection42, true);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }
}

