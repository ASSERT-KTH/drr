import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int[] intArray3 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        long long5 = mersenneTwister4.nextLong();
        int int6 = mersenneTwister4.nextInt();
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(10L);
        byte[] byteArray9 = new byte[] {};
        mersenneTwister8.nextBytes(byteArray9);
        mersenneTwister4.nextBytes(byteArray9);
        mersenneTwister4.setSeed((long) (byte) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister14.nextBytes(byteArray17);
        mersenneTwister4.nextBytes(byteArray17);
        long long20 = mersenneTwister4.nextLong();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7176213359200201386L + "'", long5 == 7176213359200201386L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-829274945) + "'", int6 == (-829274945));
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 6704147859145430661L + "'", long20 == 6704147859145430661L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25 + "'", int1 == 25);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        int int8 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField10.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField10.setRoundingMode(roundingMode13);
        dfpField1.setRoundingMode(roundingMode13);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField8.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 2);
        boolean boolean26 = dfp21.greaterThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        boolean boolean39 = dfp34.greaterThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp30, dfp34);
        double[] doubleArray41 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp4.dotrap((int) (byte) 10, "0.5773502691896257645091487805019574556476017512701268760186023264839776723029333456937153955857495252", dfp15, dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp46 = dfp15.divide(dfp45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        boolean boolean15 = dfp10.greaterThan(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        boolean boolean28 = dfp23.greaterThan(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeLn(dfp10, dfp19, dfp23);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp19.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        boolean boolean39 = dfp34.greaterThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp30.multiply(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp6.nextAfter(dfp44);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.rint();
        boolean boolean12 = dfp8.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp13 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.divide(4);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-2.0407088024575145E20d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-47.45814624013451d) + "'", double1 == (-47.45814624013451d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.4174215479739581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4174215479739581d + "'", double1 == 0.4174215479739581d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 2);
        boolean boolean18 = dfp13.greaterThan(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.getZero();
        boolean boolean20 = dfp19.isNaN();
        int int21 = dfp19.intValue();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((byte) 2);
        boolean boolean44 = dfp39.greaterThan(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp((byte) 2);
        boolean boolean57 = dfp52.greaterThan(dfp56);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeLn(dfp39, dfp48, dfp52);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp52.ceil();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp19.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp31, dfp59);
        int int61 = dfp60.log10();
        java.lang.Class<?> wildcardClass62 = dfp60.getClass();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp9.subtract(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode68 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField67.setRoundingMode(roundingMode68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = dfpField67.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField67.getOne();
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray78 = dfpField75.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField75.getTwo();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp79.floor();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.sqrt();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp9.dotrap(97, "32.", dfp73, dfp79);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + roundingMode68 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode68.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfpArray78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 0);
        int int7 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        int int4 = dfp3.log10K();
        int int5 = dfp3.intValue();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp3.getField();
        int int7 = dfp3.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-2.1850398632615162d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.389264860334713d) + "'", double1 == (-4.389264860334713d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister2.nextBytes(byteArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister7.nextBytes(byteArray10);
        mersenneTwister2.nextBytes(byteArray10);
        mersenneTwister1.nextBytes(byteArray10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        long long1 = org.apache.commons.math.util.FastMath.round(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 793006726156715L + "'", long1 == 793006726156715L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210804127942926d + "'", double1 == 1.4210804127942926d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.028563657838759995d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.028563657838759995d) + "'", double2 == (-0.028563657838759995d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp7.divide(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField16.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = dfpField16.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField16.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 2);
        boolean boolean33 = dfp28.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.getZero();
        boolean boolean35 = dfp34.isNaN();
        int int36 = dfp34.intValue();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 2);
        boolean boolean47 = dfp42.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 2);
        boolean boolean59 = dfp54.greaterThan(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.newDfp((byte) 2);
        boolean boolean72 = dfp67.greaterThan(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeLn(dfp54, dfp63, dfp67);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp67.ceil();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp34.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp46, dfp74);
        int int76 = dfp75.log10();
        java.lang.Class<?> wildcardClass77 = dfp75.getClass();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp24.subtract(dfp75);
        boolean boolean79 = dfp13.unequal(dfp24);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp24.multiply((int) (short) 1);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp81);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        int int4 = dfp3.log10K();
        int int5 = dfp3.intValue();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.newInstance(4);
        int int8 = dfp7.getRadixDigits();
        int int9 = dfp7.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        boolean boolean15 = dfp10.greaterThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.getZero();
        boolean boolean17 = dfp16.isNaN();
        int int18 = dfp16.intValue();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 2);
        boolean boolean29 = dfp24.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 2);
        boolean boolean41 = dfp36.greaterThan(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((byte) 2);
        boolean boolean54 = dfp49.greaterThan(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeLn(dfp36, dfp45, dfp49);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp49.ceil();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp16.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp28, dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.newDfp((byte) 2);
        boolean boolean66 = dfp61.greaterThan(dfp65);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField72.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((byte) 2);
        boolean boolean79 = dfp74.greaterThan(dfp78);
        org.apache.commons.math.dfp.Dfp dfp80 = org.apache.commons.math.dfp.DfpField.computeLn(dfp61, dfp70, dfp74);
        java.lang.Class<?> wildcardClass81 = dfp70.getClass();
        org.apache.commons.math.dfp.Dfp dfp83 = dfp70.divide((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp70.floor();
        org.apache.commons.math.dfp.DfpField dfpField86 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField86.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField90 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField90.newDfp((byte) 2);
        boolean boolean93 = dfp88.greaterThan(dfp92);
        org.apache.commons.math.dfp.Dfp dfp94 = new org.apache.commons.math.dfp.Dfp(dfp88);
        int int95 = dfp88.intValue();
        org.apache.commons.math.dfp.Dfp dfp96 = org.apache.commons.math.dfp.DfpField.computeLn(dfp28, dfp70, dfp88);
        org.apache.commons.math.dfp.Dfp dfp97 = dfp6.divide(dfp88);
        org.apache.commons.math.dfp.Dfp dfp99 = dfp88.divide((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 2 + "'", int95 == 2);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertNotNull(dfp97);
        org.junit.Assert.assertNotNull(dfp99);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100);
        boolean boolean11 = notStrictlyPositiveException10.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        boolean boolean18 = notStrictlyPositiveException17.getBoundIsAllowed();
        java.lang.Object[] objArray19 = notStrictlyPositiveException17.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray19);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10, localizable13, localizable14, objArray19);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException5, localizable6, localizable7, objArray19);
        java.lang.Object[] objArray23 = mathRuntimeException22.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable24 = mathRuntimeException22.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1841834327) + "'", int2 == (-1841834327));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp3);
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 2);
        boolean boolean19 = dfp14.greaterThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp14, dfp23, dfp27);
        java.lang.Class<?> wildcardClass34 = dfp23.getClass();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp23.divide((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp23.floor();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp3.subtract(dfp23);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5707963118937354d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9442156998997342d + "'", double1 == 0.9442156998997342d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) ' ');
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister2.nextBytes(byteArray5);
        java.lang.Object obj7 = new java.lang.Object();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        boolean boolean10 = notStrictlyPositiveException9.getBoundIsAllowed();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) 10, byteArray5, obj7, boolean10, 7176213359200201386L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray12);
        java.lang.Object[] objArray14 = mathIllegalArgumentException13.getArguments();
        java.lang.Object[] objArray15 = mathIllegalArgumentException13.getArguments();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-8474271314106775063L));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int[] intArray1 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        mersenneTwister3.setSeed(0L);
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits(10000);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        boolean boolean10 = dfp9.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance((byte) 100, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField15.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField15.getRoundingMode();
        boolean boolean21 = dfp13.equals((java.lang.Object) roundingMode20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp13.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        double[] doubleArray9 = dfp3.toSplitDouble();
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp3.newInstance(97);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((int) ' ');
        java.lang.String str27 = dfp26.toString();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 2);
        boolean boolean36 = dfp31.greaterThan(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = new org.apache.commons.math.dfp.Dfp(dfp31);
        int int38 = dfp31.intValue();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp31.floor();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp26.remainder(dfp31);
        boolean boolean41 = dfp3.greaterThan(dfp31);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "32." + "'", str27.equals("32."));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.87166497E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        double double23 = dfp16.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4, number1, false);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number4);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, number8);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, number12);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getTwo();
        dfpField16.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField16.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable14, (java.lang.Object[]) dfpArray21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (byte) 3, (java.lang.Number) 0.4174215479739581d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, number28);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable10, localizable30, objArray31);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int[] intArray3 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        long long5 = mersenneTwister4.nextLong();
        mersenneTwister4.setSeed((long) (byte) 1);
        int int9 = mersenneTwister4.nextInt((int) '#');
        int int11 = mersenneTwister4.nextInt((int) (byte) 2);
        int int12 = mersenneTwister4.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7176213359200201386L + "'", long5 == 7176213359200201386L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 23 + "'", int9 == 23);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1794561286 + "'", int12 == 1794561286);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField8.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 2);
        boolean boolean26 = dfp21.greaterThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        boolean boolean39 = dfp34.greaterThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp30, dfp34);
        double[] doubleArray41 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp4.dotrap((int) (byte) 10, "0.5773502691896257645091487805019574556476017512701268760186023264839776723029333456937153955857495252", dfp15, dfp43);
        org.apache.commons.math.dfp.DfpField dfpField45 = dfp43.getField();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode47 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField45.setRoundingMode(roundingMode47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField45.getLn5Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpField45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + roundingMode47 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode47.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 35.0f, (java.lang.Number) (-0.13352640702153587d), false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 35 is smaller than, or equal to, the minimum (-0.134)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 35 is smaller than, or equal to, the minimum (-0.134)"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.211102550927979d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.38905609893065d + "'", double1 == 7.38905609893065d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField8.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 2);
        boolean boolean26 = dfp21.greaterThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        boolean boolean39 = dfp34.greaterThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp30, dfp34);
        double[] doubleArray41 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp4.dotrap((int) (byte) 10, "0.5773502691896257645091487805019574556476017512701268760186023264839776723029333456937153955857495252", dfp15, dfp43);
        org.apache.commons.math.dfp.DfpField dfpField45 = dfp43.getField();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpField45);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.96802914f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6327505637969355d + "'", double1 == 1.6327505637969355d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 16, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 77.8802336483881d + "'", double2 == 77.8802336483881d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        int int9 = dfp7.intValue();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9227673888116064d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.8706768512125d + "'", double1 == 52.8706768512125d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        boolean boolean10 = dfp9.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.newInstance((byte) 100, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.newInstance(1);
        org.apache.commons.math.dfp.Dfp dfp18 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance(dfp18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp24.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = dfpField25.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1871665037753387902L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.87166497E18f + "'", float1 == 1.87166497E18f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4677992676220695d + "'", double1 == 1.4677992676220695d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int1 = org.apache.commons.math.util.FastMath.abs(338087802);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 338087802 + "'", int1 == 338087802);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.158638853279167d);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 100);
        boolean boolean7 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        boolean boolean14 = notStrictlyPositiveException13.getBoundIsAllowed();
        java.lang.Object[] objArray15 = notStrictlyPositiveException13.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable9, localizable10, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, objArray15);
        java.lang.Throwable[] throwableArray19 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField12.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.3512278965683085d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2961766633460685d) + "'", double1 == (-0.2961766633460685d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray5 = new int[] { 1, 10, 4, (short) 0 };
        mersenneTwister0.setSeed(intArray5);
        mersenneTwister0.setSeed((long) 100);
        int int9 = mersenneTwister0.nextInt();
        mersenneTwister0.setSeed(35);
        float float12 = mersenneTwister0.nextFloat();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 338087802 + "'", int9 == 338087802);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.4580549f + "'", float12 == 0.4580549f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        double[] doubleArray23 = dfp22.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.power10(1794561286);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField10.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField20.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField20.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) -1, "hi!", dfp18, dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.negate();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp19.getField();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp7.remainder(dfp21);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14550003380861354d) + "'", double1 == (-0.14550003380861354d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        dfpField9.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField9.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, (java.lang.Object[]) dfpArray14);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray16);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int2 = org.apache.commons.math.util.FastMath.max(8, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.max(3.6268604078470186d, 10000.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10000.0d + "'", double2 == 10000.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getESplit();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = null;
        dfpField1.setRoundingMode(roundingMode3);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray6 = notStrictlyPositiveException5.getArguments();
        java.lang.Object[] objArray7 = notStrictlyPositiveException5.getArguments();
        java.lang.String str8 = notStrictlyPositiveException5.toString();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 1.5707531289249566d, false);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Throwable[] throwableArray15 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.446685590101804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.46305736808123804d + "'", double1 == 0.46305736808123804d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        dfpField9.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField9.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, (java.lang.Object[]) dfpArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (byte) 3, (java.lang.Number) 0.4174215479739581d, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, number21);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, number25);
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        dfpField29.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField29.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable27, (java.lang.Object[]) dfpArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister38 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray41 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister38.nextBytes(byteArray41);
        java.lang.Object obj43 = new java.lang.Object();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        boolean boolean46 = notStrictlyPositiveException45.getBoundIsAllowed();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (byte) 10, byteArray41, obj43, boolean46, 7176213359200201386L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField53.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException49, localizable50, localizable51, (java.lang.Object[]) dfpArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable23, (java.lang.Object[]) dfpArray56);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpArray56);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number6 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.power10K(97);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp16.power10K((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(6480552030174106886L);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 35);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double2 = org.apache.commons.math.util.FastMath.max(7.930067261567154E14d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.930067261567154E14d + "'", double2 == 7.930067261567154E14d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707531289249563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.810269583077343d + "'", double1 == 3.810269583077343d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3574158419544757d + "'", double1 == 1.3574158419544757d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.915504000358302E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.915504000358302E22d + "'", double1 == 1.915504000358302E22d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        int int4 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.power10((int) (byte) 1);
        boolean boolean8 = dfp6.equals((java.lang.Object) 1490.479161252178d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField10.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField20.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField20.getLn5();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField20.newDfp((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.dotrap((int) (byte) -1, "hi!", dfp18, dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp5.newInstance((byte) 10);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 19, (java.lang.Number) (-2.1850398632615162d), true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '#', (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49714987269413385d + "'", double1 == 0.49714987269413385d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int[] intArray3 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        long long5 = mersenneTwister4.nextLong();
        long long6 = mersenneTwister4.nextLong();
        double double7 = mersenneTwister4.nextGaussian();
        double double8 = mersenneTwister4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7176213359200201386L + "'", long5 == 7176213359200201386L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3561708767731417745L) + "'", long6 == (-3561708767731417745L));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.5476820005515561d) + "'", double7 == (-1.5476820005515561d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.561977393562664d + "'", double8 == 0.561977393562664d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        boolean boolean10 = dfp9.isNaN();
        int int11 = dfp9.intValue();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        boolean boolean22 = dfp17.greaterThan(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 2);
        boolean boolean34 = dfp29.greaterThan(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 2);
        boolean boolean47 = dfp42.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp29, dfp38, dfp42);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp42.ceil();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp21, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp21.power10(2);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((byte) 2);
        boolean boolean61 = dfp56.greaterThan(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((byte) 2);
        boolean boolean74 = dfp69.greaterThan(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = org.apache.commons.math.dfp.DfpField.computeLn(dfp56, dfp65, dfp69);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp65.getTwo();
        int int77 = dfp76.classify();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp52.add(dfp76);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        boolean boolean17 = dfp12.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.getZero();
        boolean boolean19 = dfp18.isNaN();
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 2);
        boolean boolean31 = dfp26.greaterThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 2);
        boolean boolean43 = dfp38.greaterThan(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.newDfp((byte) 2);
        boolean boolean56 = dfp51.greaterThan(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp38, dfp47, dfp51);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp51.ceil();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp18.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp30, dfp58);
        boolean boolean60 = dfp8.lessThan(dfp58);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 2);
        boolean boolean19 = dfp14.greaterThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp14, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp36 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp10.newInstance(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 2);
        boolean boolean46 = dfp41.greaterThan(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 2);
        boolean boolean59 = dfp54.greaterThan(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeLn(dfp41, dfp50, dfp54);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp50.getTwo();
        int int62 = dfp61.classify();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 2);
        boolean boolean71 = dfp66.greaterThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp70.newInstance((byte) 2, (byte) 100);
        boolean boolean75 = dfp61.lessThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp70.newInstance(32L);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp10.divide(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = new org.apache.commons.math.dfp.Dfp(dfp78);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.getTwo();
        java.lang.String str24 = dfp23.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2." + "'", str24.equals("2."));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1004575035323076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.005540754962196d + "'", double1 == 2.005540754962196d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32.0f);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        boolean boolean17 = dfp12.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance((byte) 2, (byte) 100);
        boolean boolean21 = dfp8.greaterThan(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 2);
        boolean boolean45 = dfp40.greaterThan(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.DfpField.computeLn(dfp27, dfp36, dfp40);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp27.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.rint();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp27.power10(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp23.nextAfter(dfp51);
        int int53 = dfp52.getRadixDigits();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 25 + "'", int53 == 25);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.598150033144236d + "'", double1 == 53.598150033144236d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.6327505637969355d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-0.14550003380861354d));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.2961766633460685d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.30532339975933903d) + "'", double1 == (-0.30532339975933903d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        boolean boolean10 = dfp9.isNaN();
        int int11 = dfp9.intValue();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 2);
        boolean boolean20 = dfp15.greaterThan(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.getZero();
        boolean boolean22 = dfp9.greaterThan(dfp19);
        double double23 = dfp9.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField25.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField25.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getLn2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField33.setRoundingMode(roundingMode34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp31.divide(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp9.divide(dfp38);
        boolean boolean40 = dfp39.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int[] intArray3 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        long long5 = mersenneTwister4.nextLong();
        int int6 = mersenneTwister4.nextInt();
        mersenneTwister4.setSeed((long) 4);
        mersenneTwister4.setSeed((long) 25);
        int int11 = mersenneTwister4.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7176213359200201386L + "'", long5 == 7176213359200201386L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-829274945) + "'", int6 == (-829274945));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1056485738 + "'", int11 == 1056485738);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 3, (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8474271314106775063L) + "'", long2 == (-8474271314106775063L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1804233386);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3L, 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        int int5 = dfp4.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 32768L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32768.0d + "'", double1 == 32768.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03490658503988659d + "'", double1 == 0.03490658503988659d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        int[] intArray12 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        long long14 = mersenneTwister13.nextLong();
        int int15 = mersenneTwister13.nextInt();
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(10L);
        byte[] byteArray18 = new byte[] {};
        mersenneTwister17.nextBytes(byteArray18);
        mersenneTwister13.nextBytes(byteArray18);
        mersenneTwister13.setSeed((long) (byte) 0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray26 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister23.nextBytes(byteArray26);
        mersenneTwister13.nextBytes(byteArray26);
        double double29 = mersenneTwister13.nextGaussian();
        boolean boolean30 = dfp8.equals((java.lang.Object) double29);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 7176213359200201386L + "'", long14 == 7176213359200201386L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-829274945) + "'", int15 == (-829274945));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.3358343618944353d) + "'", double29 == (-1.3358343618944353d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-714784598), 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.1478458E8f) + "'", float2 == (-7.1478458E8f));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((-714784598));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 2);
        boolean boolean14 = dfp9.greaterThan(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.sqrt();
        boolean boolean17 = dfp5.lessThan(dfp9);
        org.apache.commons.math.dfp.Dfp dfp18 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp19 = dfp9.divide(dfp18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5711645232847797d + "'", double2 == 0.5711645232847797d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.9999999999999999d), 0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999998d) + "'", double2 == (-0.9999999999999998d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp3);
        int int10 = dfp3.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField13.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField13.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.newDfp("0.5773502691896257645091487805019574556476017512701268760186023264839776723029333456937153955857495252");
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField13.newDfp((double) ' ');
        boolean boolean24 = dfp3.equals((java.lang.Object) dfp23);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32.0f);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        boolean boolean17 = dfp12.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance((byte) 2, (byte) 100);
        boolean boolean21 = dfp8.greaterThan(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 2);
        boolean boolean45 = dfp40.greaterThan(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.DfpField.computeLn(dfp27, dfp36, dfp40);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp27.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.rint();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp27.power10(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp23.nextAfter(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance((long) ' ');
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(55.46398424938743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.813616529367669d + "'", double1 == 3.813616529367669d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        java.lang.Class<?> wildcardClass23 = dfp12.getClass();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.divide((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp12.floor();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.ceil();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode32 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField31.setRoundingMode(roundingMode32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode36 = dfpField31.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance((long) 35);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp26.divide(dfp37);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + roundingMode32 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode32.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + roundingMode36 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode36.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.4677992676220695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4677992676220697d + "'", double1 == 1.4677992676220697d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-47.45814624013451d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        dfpField12.setIEEEFlagsBits(23);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.power10K(97);
        boolean boolean25 = dfp24.isNaN();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance((long) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.floor(55.46398424938743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55.0d + "'", double1 == 55.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.158638853279167d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(11.548739357257746d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.548739357257745d + "'", double2 == 11.548739357257745d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.021825671f + "'", float2 == 0.021825671f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        boolean boolean10 = dfp9.isNaN();
        int int11 = dfp9.intValue();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        boolean boolean22 = dfp17.greaterThan(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 2);
        boolean boolean34 = dfp29.greaterThan(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 2);
        boolean boolean47 = dfp42.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp29, dfp38, dfp42);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp42.ceil();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp21, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp21.power10((-1));
        double[] doubleArray53 = dfp21.toSplitDouble();
        boolean boolean54 = dfp21.isNaN();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp21.power10((-829274945));
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.multiply(0);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        java.lang.Class<?> wildcardClass23 = dfp12.getClass();
        int int24 = dfp12.log10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 2);
        boolean boolean33 = dfp28.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.newInstance();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp12.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 2);
        int int41 = dfp40.log10K();
        int int42 = dfp40.intValue();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp40.newInstance(4);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp12.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.newInstance();
        boolean boolean47 = dfp45.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 32.0f, (double) 1.87166497E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2204460492503128E-16d + "'", double1 == 2.2204460492503128E-16d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.389056098930651d + "'", double1 == 7.389056098930651d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5707658017643813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.301222310629803d + "'", double1 == 2.301222310629803d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 2);
        boolean boolean21 = dfp16.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp12, dfp16);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.getTwo();
        int int24 = dfp23.classify();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 2);
        boolean boolean33 = dfp28.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.newInstance((byte) 2, (byte) 100);
        boolean boolean37 = dfp23.lessThan(dfp32);
        double double38 = dfp23.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(25);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(6480552030174106886L);
        int int10 = dfp9.log10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray6 = notStrictlyPositiveException5.getArguments();
        java.lang.Object[] objArray7 = notStrictlyPositiveException5.getArguments();
        java.lang.String str8 = notStrictlyPositiveException5.toString();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException5);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 1.5707531289249566d, false);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooSmallException13.getArgument();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 1 + "'", number15.equals((short) 1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-8.2927494E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.751395434714769E10d) + "'", double1 == (-4.751395434714769E10d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.00000000000001d, number2, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.ulp(11.548739357257746d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) 35);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField11.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField11.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField11.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        double double23 = dfp21.toDouble();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp7.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.floor();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6976949568754303d + "'", double1 == 2.6976949568754303d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        boolean boolean10 = dfp9.isNaN();
        int int11 = dfp9.intValue();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        boolean boolean22 = dfp17.greaterThan(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((byte) 2);
        boolean boolean34 = dfp29.greaterThan(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((byte) 2);
        boolean boolean47 = dfp42.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp29, dfp38, dfp42);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp42.ceil();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp21, dfp49);
        java.lang.String str51 = dfp49.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2." + "'", str51.equals("2."));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.3870042820753498d));
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField5.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField12.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((double) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 2);
        boolean boolean30 = dfp25.greaterThan(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((byte) 2);
        boolean boolean43 = dfp38.greaterThan(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp34, dfp38);
        double[] doubleArray45 = dfp44.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp8.dotrap((int) (byte) 10, "0.5773502691896257645091487805019574556476017512701268760186023264839776723029333456937153955857495252", dfp19, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField49 = dfp47.getField();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode51 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField49.setRoundingMode(roundingMode51);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField49.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, (java.lang.Object[]) dfpArray53);
        java.lang.Throwable[] throwableArray55 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpField49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + roundingMode51 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode51.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.sqrt();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 2);
        boolean boolean19 = dfp14.greaterThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp14, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp36 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp10.newInstance(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 2);
        boolean boolean46 = dfp41.greaterThan(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 2);
        boolean boolean59 = dfp54.greaterThan(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeLn(dfp41, dfp50, dfp54);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp50.getTwo();
        int int62 = dfp61.classify();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 2);
        boolean boolean71 = dfp66.greaterThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp70.newInstance((byte) 2, (byte) 100);
        boolean boolean75 = dfp61.lessThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp70.newInstance(32L);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp10.divide(dfp77);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp10.newInstance(97);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp80);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32.0f);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        boolean boolean17 = dfp12.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance((byte) 2, (byte) 100);
        boolean boolean21 = dfp8.greaterThan(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 2);
        boolean boolean45 = dfp40.greaterThan(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.DfpField.computeLn(dfp27, dfp36, dfp40);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp27.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.rint();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp27.power10(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp23.nextAfter(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance((long) (short) -1);
        int int55 = dfp51.log10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getPi();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField8.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 2);
        boolean boolean26 = dfp21.greaterThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        boolean boolean39 = dfp34.greaterThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp30, dfp34);
        double[] doubleArray41 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp4.dotrap((int) (byte) 10, "0.5773502691896257645091487805019574556476017512701268760186023264839776723029333456937153955857495252", dfp15, dfp43);
        org.apache.commons.math.dfp.DfpField dfpField45 = dfp43.getField();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpField45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10(32760);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.negate();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        int int10 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getTwo();
        dfpField9.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField9.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, (java.lang.Object[]) dfpArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (byte) 3, (java.lang.Number) 0.4174215479739581d, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, number21);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, number25);
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        dfpField29.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField29.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable27, (java.lang.Object[]) dfpArray34);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable27, objArray36);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfpArray34);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-0.3512278965683085d));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(1.5707531289249563d);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.211102550927979d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9319707960570336d + "'", double1 == 1.9319707960570336d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.623014125017576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((byte) 2);
        boolean boolean19 = dfp14.greaterThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeLn(dfp14, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp36 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp10.newInstance(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 2);
        boolean boolean46 = dfp41.greaterThan(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 2);
        boolean boolean59 = dfp54.greaterThan(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeLn(dfp41, dfp50, dfp54);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp50.getTwo();
        int int62 = dfp61.classify();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 2);
        boolean boolean71 = dfp66.greaterThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp70.newInstance((byte) 2, (byte) 100);
        boolean boolean75 = dfp61.lessThan(dfp70);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp70.newInstance(32L);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp10.divide(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp77.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.negate();
        int int15 = dfp14.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField7.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.ceil();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField17.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 2);
        boolean boolean32 = dfp27.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp27);
        int int34 = dfp27.intValue();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.floor();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp23.nextAfter(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 2);
        boolean boolean45 = dfp40.greaterThan(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.getZero();
        boolean boolean47 = dfp46.isNaN();
        int int48 = dfp46.intValue();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((byte) 2);
        boolean boolean59 = dfp54.greaterThan(dfp58);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp58.newInstance((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((byte) 2);
        boolean boolean71 = dfp66.greaterThan(dfp70);
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField77.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField81.newDfp((byte) 2);
        boolean boolean84 = dfp79.greaterThan(dfp83);
        org.apache.commons.math.dfp.Dfp dfp85 = org.apache.commons.math.dfp.DfpField.computeLn(dfp66, dfp75, dfp79);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp79.ceil();
        org.apache.commons.math.dfp.Dfp dfp87 = dfp46.dotrap(10, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", dfp58, dfp86);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp58.power10((-1));
        double[] doubleArray90 = dfp58.toSplitDouble();
        boolean boolean91 = dfp58.isNaN();
        org.apache.commons.math.dfp.Dfp dfp93 = dfp58.power10((-829274945));
        org.apache.commons.math.dfp.Dfp dfp94 = dfp36.subtract(dfp93);
        boolean boolean95 = dfp15.unequal(dfp94);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 7.930067261567154E14d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray8 = notStrictlyPositiveException7.getArguments();
        java.lang.Object[] objArray9 = notStrictlyPositiveException7.getArguments();
        java.lang.Number number10 = notStrictlyPositiveException7.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 100);
        boolean boolean17 = notStrictlyPositiveException16.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException16);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        boolean boolean24 = notStrictlyPositiveException23.getBoundIsAllowed();
        java.lang.Object[] objArray25 = notStrictlyPositiveException23.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray25);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException16, localizable19, localizable20, objArray25);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11, localizable12, localizable13, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 2.005540754962196d, (java.lang.Number) 2.6976949568754303d, false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7.930067261567154E14d + "'", number4.equals(7.930067261567154E14d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField3.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField3.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField3.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField3.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray5 = new int[] { 1, 10, 4, (short) 0 };
        mersenneTwister0.setSeed(intArray5);
        mersenneTwister0.setSeed((long) 100);
        int int9 = mersenneTwister0.nextInt();
        mersenneTwister0.setSeed(35);
        boolean boolean12 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 338087802 + "'", int9 == 338087802);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 0);
        int int7 = dfpField1.getIEEEFlags();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        java.lang.String str6 = dfp5.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(97);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2." + "'", str6.equals("2."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-3561708767731417745L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.3870042820753498d));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray5 = new int[] { 1, 10, 4, (short) 0 };
        mersenneTwister0.setSeed(intArray5);
        mersenneTwister0.setSeed((long) 100);
        boolean boolean9 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        dfpField1.setIEEEFlags(338087802);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.util.FastMath.max(3.813616529367669d, (double) (-4));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.813616529367669d + "'", double2 == 3.813616529367669d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) ' ');
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) (byte) 2);
        int int10 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.08101100767034625d, (double) 32760);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4728634819957606E-6d + "'", double2 == 2.4728634819957606E-6d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int2 = org.apache.commons.math.util.FastMath.max(1056485738, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1056485738 + "'", int2 == 1056485738);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 0);
        int int7 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 7789087874861426141L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int[] intArray3 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        int int6 = mersenneTwister4.nextInt();
        long long7 = mersenneTwister4.nextLong();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1670842375 + "'", int5 == 1670842375);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1804233386 + "'", int6 == 1804233386);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3561708767731417745L) + "'", long7 == (-3561708767731417745L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField8.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField8.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode12);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode6);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance((byte) 2, (byte) 100);
        int int12 = dfp11.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("0.");
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField9.newDfp((double) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.multiply((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister0.nextBytes(byteArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 1 };
        mersenneTwister5.nextBytes(byteArray8);
        mersenneTwister0.nextBytes(byteArray8);
        mersenneTwister0.setSeed(23);
        double double13 = mersenneTwister0.nextDouble();
        mersenneTwister0.setSeed((long) 19);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5172978888317512d + "'", double13 == 0.5172978888317512d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 2);
        boolean boolean8 = dfp3.greaterThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 2);
        boolean boolean18 = dfp13.greaterThan(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 2);
        boolean boolean31 = dfp26.greaterThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeLn(dfp13, dfp22, dfp26);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp26.ceil();
        int int34 = dfp26.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp9.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp9.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 32760);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlags((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-280369966), (float) (-280369966));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.80369952E8f) + "'", float2 == (-2.80369952E8f));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4210804127942926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1915228302975085d + "'", double1 == 2.1915228302975085d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.6268604078470186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.810599496642514d + "'", double1 == 18.810599496642514d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.divide((int) (short) 1);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.158638853279167d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getOne();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField15.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.negate();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 32.0f);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        boolean boolean17 = dfp12.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance((byte) 2, (byte) 100);
        boolean boolean21 = dfp8.greaterThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.divide((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.rint();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((byte) 2);
        boolean boolean33 = dfp28.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.getZero();
        boolean boolean35 = dfp34.isNaN();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp34.newInstance((byte) 100, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode41 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField40.setRoundingMode(roundingMode41);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField40.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.getOne();
        int int45 = dfp44.log10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp34.newInstance(dfp44);
        int int47 = dfp44.log10();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp24.newInstance(dfp44);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp24.newInstance((-714784576));
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + roundingMode41 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode41.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        boolean boolean6 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number9 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.Object[] objArray7 = notStrictlyPositiveException6.getArguments();
        java.lang.Object[] objArray8 = notStrictlyPositiveException6.getArguments();
        java.lang.Number number9 = notStrictlyPositiveException6.getMin();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        boolean boolean11 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int[] intArray3 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        long long5 = mersenneTwister4.nextLong();
        mersenneTwister4.setSeed((long) (byte) 1);
        int[] intArray11 = new int[] { (byte) 100, (byte) 100, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        long long13 = mersenneTwister12.nextLong();
        int int14 = mersenneTwister12.nextInt();
        int[] intArray16 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister12.setSeed(intArray16);
        mersenneTwister4.setSeed(intArray16);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7176213359200201386L + "'", long5 == 7176213359200201386L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7176213359200201386L + "'", long13 == 7176213359200201386L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-829274945) + "'", int14 == (-829274945));
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 0);
        int int7 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(6480552030174106886L);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 2);
        boolean boolean18 = dfp13.greaterThan(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.getZero();
        boolean boolean20 = dfp19.isNaN();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp9.multiply(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getPiSplit();
        boolean boolean25 = dfp19.equals((java.lang.Object) dfpArray24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField27.setRoundingMode(roundingMode28);
        dfpField27.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField27.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField27.newDfp((double) 32.0f);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp19.newInstance(dfp34);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }
}

