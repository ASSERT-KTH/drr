import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5198420997897464d + "'", double1 == 2.5198420997897464d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10.0f, 0.7718364247257369d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double double2 = org.apache.commons.math.util.FastMath.min((double) '#', 1.0E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-9d + "'", double2 == 1.0E-9d);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test06");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
//        long long11 = randomDataImpl8.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray13 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray13);
//        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray13);
//        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException16 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray13);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(1.0E-323d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray13);
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 72L + "'", long11 == 72L);
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(illegalArgumentException14);
//        org.junit.Assert.assertNotNull(noSuchElementException15);
//        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException16);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 19L, (java.lang.Number) 191.4651073145975d, false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl();
//        long long16 = randomDataImpl13.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException19 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray18);
//        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray18);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException("", objArray18);
//        double[] doubleArray23 = new double[] { (byte) -1 };
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray32 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray32);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { localizedFormats25, (short) 0, ' ' };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException21, doubleArray23, "hi!", objArray36);
//        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray36);
//        java.lang.IllegalArgumentException illegalArgumentException39 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray36);
//        java.lang.NullPointerException nullPointerException40 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray36);
//        java.lang.IllegalStateException illegalStateException41 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("b55755d2e8ccbec629ff5b7eebaeefbf5bef6aaaf5327e6ec066", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray36);
//        java.util.NoSuchElementException noSuchElementException43 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray36);
//        java.lang.IllegalArgumentException illegalArgumentException44 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("73a6a89edeb09cc7a4dcd6a932379f05be3981938d7e6e4996af", objArray36);
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
//        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
//        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 69L + "'", long16 == 69L);
//        org.junit.Assert.assertNotNull(objArray18);
//        org.junit.Assert.assertNotNull(illegalArgumentException19);
//        org.junit.Assert.assertNotNull(noSuchElementException20);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertNotNull(nullPointerException38);
//        org.junit.Assert.assertNotNull(illegalArgumentException39);
//        org.junit.Assert.assertNotNull(nullPointerException40);
//        org.junit.Assert.assertNotNull(illegalStateException41);
//        org.junit.Assert.assertNotNull(noSuchElementException43);
//        org.junit.Assert.assertNotNull(illegalArgumentException44);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test10");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException((double) 15L, "", objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
//        long long22 = randomDataImpl19.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException25 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray24);
//        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray24);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException("", objArray24);
//        double[] doubleArray29 = new double[] { (byte) -1 };
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray38 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray38);
//        java.lang.Object[] objArray42 = new java.lang.Object[] { localizedFormats31, (short) 0, ' ' };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException27, doubleArray29, "hi!", objArray42);
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException11, localizable12, objArray42);
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 21L + "'", long22 == 21L);
//        org.junit.Assert.assertNotNull(objArray24);
//        org.junit.Assert.assertNotNull(illegalArgumentException25);
//        org.junit.Assert.assertNotNull(noSuchElementException26);
//        org.junit.Assert.assertNotNull(doubleArray29);
//        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertNotNull(objArray42);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        double[] doubleArray3 = new double[] { 0.45050180361087017d, 0.5909541151420059d, 48.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.148283155648077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.570132176458268d + "'", double1 == 8.570132176458268d);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong(10L, (long) (byte) 100);
//        randomDataImpl0.reSeed(72L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 77L, 100.0d, 0.0d);
//        double double10 = normalDistributionImpl9.getStandardDeviation();
//        double[] doubleArray12 = normalDistributionImpl9.sample((int) (byte) 1);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            double double18 = randomDataImpl0.nextGamma(0.5794104219615868d, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 90L + "'", long3 == 90L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.63159605577684d + "'", double13 == 136.63159605577684d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "443191c2831e61ad51bf590746eafd689b2ff594f6808248c90f" + "'", str15.equals("443191c2831e61ad51bf590746eafd689b2ff594f6808248c90f"));
//    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test14");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        long long13 = randomDataImpl10.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray15 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray15);
//        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray15);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException("", objArray15);
//        java.lang.IllegalArgumentException illegalArgumentException19 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray15);
//        java.lang.UnsupportedOperationException unsupportedOperationException20 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray15);
//        java.io.EOFException eOFException21 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
//        java.lang.IllegalStateException illegalStateException22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray15);
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 65L + "'", long13 == 65L);
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertNotNull(illegalArgumentException16);
//        org.junit.Assert.assertNotNull(noSuchElementException17);
//        org.junit.Assert.assertNotNull(illegalArgumentException19);
//        org.junit.Assert.assertNotNull(unsupportedOperationException20);
//        org.junit.Assert.assertNotNull(eOFException21);
//        org.junit.Assert.assertNotNull(illegalStateException22);
//    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double[] doubleArray3 = new double[] { 43L, 25L, 1.4210854715202004E-14d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 33L, (double) 80L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.39123557912717416d + "'", double2 == 0.39123557912717416d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 56L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8258623655447783d + "'", double1 == 3.8258623655447783d);
    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        long long9 = randomDataImpl6.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray11);
//        java.util.NoSuchElementException noSuchElementException13 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray11);
//        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
//        java.lang.Object[] objArray15 = mathException14.getArguments();
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(illegalArgumentException12);
//        org.junit.Assert.assertNotNull(noSuchElementException13);
//        org.junit.Assert.assertNotNull(objArray15);
//    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.1959789343880396d + "'", double0 == 0.1959789343880396d);
//    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
//        java.lang.Throwable throwable1 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
//        long long19 = randomDataImpl16.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray21);
//        java.util.NoSuchElementException noSuchElementException23 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray21);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math.random.RandomDataImpl();
//        long long33 = randomDataImpl30.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException36 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray35);
//        java.util.NoSuchElementException noSuchElementException37 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray35);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException("", objArray35);
//        double[] doubleArray40 = new double[] { (byte) -1 };
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray49 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray49);
//        java.lang.Object[] objArray53 = new java.lang.Object[] { localizedFormats42, (short) 0, ' ' };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException38, doubleArray40, "hi!", objArray53);
//        java.lang.Object[] objArray56 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException23, doubleArray40, "", objArray56);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl();
//        long long68 = randomDataImpl65.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray70 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException71 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray70);
//        java.util.NoSuchElementException noSuchElementException72 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats60, objArray70);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException("", objArray70);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException10, doubleArray40, (org.apache.commons.math.exception.util.Localizable) localizedFormats58, objArray70);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl81 = new org.apache.commons.math.random.RandomDataImpl();
//        long long84 = randomDataImpl81.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray86 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException87 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray86);
//        java.util.NoSuchElementException noSuchElementException88 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray86);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray40, (org.apache.commons.math.exception.util.Localizable) localizedFormats75, objArray86);
//        java.lang.Throwable[] throwableArray90 = functionEvaluationException89.getSuppressed();
//        org.apache.commons.math.MathRuntimeException mathRuntimeException91 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray90);
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 55L + "'", long19 == 55L);
//        org.junit.Assert.assertNotNull(objArray21);
//        org.junit.Assert.assertNotNull(illegalArgumentException22);
//        org.junit.Assert.assertNotNull(noSuchElementException23);
//        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 78L + "'", long33 == 78L);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(illegalArgumentException36);
//        org.junit.Assert.assertNotNull(noSuchElementException37);
//        org.junit.Assert.assertNotNull(doubleArray40);
//        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray49);
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
//        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 57L + "'", long68 == 57L);
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertNotNull(illegalArgumentException71);
//        org.junit.Assert.assertNotNull(noSuchElementException72);
//        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats75.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 37L + "'", long84 == 37L);
//        org.junit.Assert.assertNotNull(objArray86);
//        org.junit.Assert.assertNotNull(illegalArgumentException87);
//        org.junit.Assert.assertNotNull(noSuchElementException88);
//        org.junit.Assert.assertNotNull(throwableArray90);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
//        java.lang.Throwable throwable6 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        long long24 = randomDataImpl21.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray26);
//        java.util.NoSuchElementException noSuchElementException28 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray26);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math.random.RandomDataImpl();
//        long long38 = randomDataImpl35.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException41 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray40);
//        java.util.NoSuchElementException noSuchElementException42 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray40);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.MathRuntimeException("", objArray40);
//        double[] doubleArray45 = new double[] { (byte) -1 };
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray54 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, objArray54);
//        java.lang.Object[] objArray58 = new java.lang.Object[] { localizedFormats47, (short) 0, ' ' };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException43, doubleArray45, "hi!", objArray58);
//        java.lang.Object[] objArray61 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException28, doubleArray45, "", objArray61);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl();
//        long long73 = randomDataImpl70.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray75 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException76 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray75);
//        java.util.NoSuchElementException noSuchElementException77 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats65, objArray75);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.MathRuntimeException("", objArray75);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException15, doubleArray45, (org.apache.commons.math.exception.util.Localizable) localizedFormats63, objArray75);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats80 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl86 = new org.apache.commons.math.random.RandomDataImpl();
//        long long89 = randomDataImpl86.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray91 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException92 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray91);
//        java.util.NoSuchElementException noSuchElementException93 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray91);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException94 = new org.apache.commons.math.FunctionEvaluationException(throwable6, doubleArray45, (org.apache.commons.math.exception.util.Localizable) localizedFormats80, objArray91);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray91);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException96 = new org.apache.commons.math.FunctionEvaluationException(10.0d, "evaluation failed for argument = {0}", objArray91);
//        java.util.NoSuchElementException noSuchElementException97 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("evaluation failed for argument = {0}", objArray91);
//        java.lang.Object[] objArray98 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray91);
//        java.io.EOFException eOFException99 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray91);
//        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
//        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 94L + "'", long24 == 94L);
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(illegalArgumentException27);
//        org.junit.Assert.assertNotNull(noSuchElementException28);
//        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 86L + "'", long38 == 86L);
//        org.junit.Assert.assertNotNull(objArray40);
//        org.junit.Assert.assertNotNull(illegalArgumentException41);
//        org.junit.Assert.assertNotNull(noSuchElementException42);
//        org.junit.Assert.assertNotNull(doubleArray45);
//        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
//        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 10L + "'", long73 == 10L);
//        org.junit.Assert.assertNotNull(objArray75);
//        org.junit.Assert.assertNotNull(illegalArgumentException76);
//        org.junit.Assert.assertNotNull(noSuchElementException77);
//        org.junit.Assert.assertTrue("'" + localizedFormats80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats80.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 78L + "'", long89 == 78L);
//        org.junit.Assert.assertNotNull(objArray91);
//        org.junit.Assert.assertNotNull(illegalArgumentException92);
//        org.junit.Assert.assertNotNull(noSuchElementException93);
//        org.junit.Assert.assertNotNull(noSuchElementException97);
//        org.junit.Assert.assertNotNull(objArray98);
//        org.junit.Assert.assertNotNull(eOFException99);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong(10L, (long) (byte) 100);
//        randomDataImpl0.reSeed(72L);
//        long long7 = randomDataImpl0.nextPoisson((double) 45L);
//        randomDataImpl0.reSeed(0L);
//        try {
//            java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 36L + "'", long3 == 36L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 41L + "'", long7 == 41L);
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.2849488284703571d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        long long9 = randomDataImpl6.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray11);
//        java.util.NoSuchElementException noSuchElementException13 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        long long23 = randomDataImpl20.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException26 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray25);
//        java.util.NoSuchElementException noSuchElementException27 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray25);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray25);
//        double[] doubleArray30 = new double[] { (byte) -1 };
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
//        java.lang.Object[] objArray39 = new java.lang.Object[] { (byte) 100, (byte) 1, 0, 10.0d, 1, (short) -1 };
//        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray39);
//        java.lang.Object[] objArray43 = new java.lang.Object[] { localizedFormats32, (short) 0, ' ' };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException28, doubleArray30, "hi!", objArray43);
//        java.lang.Object[] objArray46 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException13, doubleArray30, "", objArray46);
//        java.lang.Throwable[] throwableArray48 = noSuchElementException13.getSuppressed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl52 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 77L, 100.0d, 0.0d);
//        double double53 = normalDistributionImpl52.getStandardDeviation();
//        double[] doubleArray55 = normalDistributionImpl52.sample((int) (byte) 1);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math.random.RandomDataImpl();
//        long long66 = randomDataImpl63.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException69 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray68);
//        java.util.NoSuchElementException noSuchElementException70 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats58, objArray68);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException71 = new org.apache.commons.math.MathRuntimeException("", objArray68);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException13, doubleArray55, "07884a62014eea75f7b23ffce58967fbae1315d51df1db5f4d18ce7e934d479ef5575a39f4ee7cc1f56dcaf20c24e3394fba", objArray68);
//        java.lang.NullPointerException nullPointerException73 = org.apache.commons.math.MathRuntimeException.createNullPointerException("478f1772c7c3328b7ef44b49a078df9a166c904dc089630c93f4", objArray68);
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertNotNull(illegalArgumentException12);
//        org.junit.Assert.assertNotNull(noSuchElementException13);
//        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 92L + "'", long23 == 92L);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(illegalArgumentException26);
//        org.junit.Assert.assertNotNull(noSuchElementException27);
//        org.junit.Assert.assertNotNull(doubleArray30);
//        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 100.0d + "'", double53 == 100.0d);
//        org.junit.Assert.assertNotNull(doubleArray55);
//        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 37L + "'", long66 == 37L);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(illegalArgumentException69);
//        org.junit.Assert.assertNotNull(noSuchElementException70);
//        org.junit.Assert.assertNotNull(nullPointerException73);
//    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test25");
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) 100.0f, (double) '4', 1);
//        double double5 = poissonDistributionImpl3.cumulativeProbability(100);
//        double double6 = poissonDistributionImpl3.getMean();
//        double double7 = poissonDistributionImpl3.getMean();
//        int int8 = poissonDistributionImpl3.sample();
//        double double10 = poissonDistributionImpl3.probability((double) 76L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9605336665255937d + "'", double5 == 0.9605336665255937d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 88 + "'", int8 == 88);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0019729973108562407d + "'", double10 == 0.0019729973108562407d);
//    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) 100.0f, (double) '4', 1);
        double double5 = poissonDistributionImpl3.cumulativeProbability(100);
        double double6 = poissonDistributionImpl3.getMean();
        double double7 = poissonDistributionImpl3.getMean();
        try {
            int int9 = poissonDistributionImpl3.inverseCumulativeProbability(1.0251532120868618E-30d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: Continued fraction convergents failed to converge for value 100");
        } catch (org.apache.commons.math.FunctionEvaluationException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9605336665255937d + "'", double5 == 0.9605336665255937d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong(10L, (long) (byte) 100);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 89L + "'", long3 == 89L);
//    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sample size ({0}) must be less than or equal to population size ({1})" + "'", str1.equals("sample size ({0}) must be less than or equal to population size ({1})"));
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test30");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math.random.RandomDataImpl();
//        long long12 = randomDataImpl9.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException15 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray14);
//        java.util.NoSuchElementException noSuchElementException16 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray14);
//        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray14);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl();
//        long long29 = randomDataImpl26.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException32 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray31);
//        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray31);
//        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray31);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { mathException17, 1.0E-9d, (byte) 1, localizedFormats20 };
//        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException("", objArray35);
//        java.lang.IllegalArgumentException illegalArgumentException37 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray35);
//        try {
//            java.lang.IllegalArgumentException illegalArgumentException38 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable0, objArray35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
//        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 39L + "'", long12 == 39L);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertNotNull(illegalArgumentException15);
//        org.junit.Assert.assertNotNull(noSuchElementException16);
//        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 46L + "'", long29 == 46L);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(illegalArgumentException32);
//        org.junit.Assert.assertNotNull(noSuchElementException33);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertNotNull(illegalArgumentException37);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.21088864676286517d, (int) (byte) 1);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 54L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.830753303274694E23d + "'", double1 == 2.830753303274694E23d);
    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test35");
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        long long13 = randomDataImpl10.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray15 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray15);
//        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray15);
//        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray15);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl();
//        long long30 = randomDataImpl27.nextSecureLong(10L, (long) (byte) 100);
//        java.lang.Object[] objArray32 = new java.lang.Object[] { 0.0f, 100L, "", 10L, (-1L) };
//        java.lang.IllegalArgumentException illegalArgumentException33 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray32);
//        java.util.NoSuchElementException noSuchElementException34 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray32);
//        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { mathException18, 1.0E-9d, (byte) 1, localizedFormats21 };
//        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException("", objArray36);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray36);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray36);
//        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA));
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
//        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 33L + "'", long13 == 33L);
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertNotNull(illegalArgumentException16);
//        org.junit.Assert.assertNotNull(noSuchElementException17);
//        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 63L + "'", long30 == 63L);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertNotNull(illegalArgumentException33);
//        org.junit.Assert.assertNotNull(noSuchElementException34);
//        org.junit.Assert.assertNotNull(objArray36);
//    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) 100.0f, (double) '4', 1);
        double double5 = poissonDistributionImpl3.cumulativeProbability(100);
        double double6 = poissonDistributionImpl3.getMean();
        int[] intArray8 = poissonDistributionImpl3.sample((int) ' ');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9605336665255937d + "'", double5 == 0.9605336665255937d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 77L, 100.0d, 0.0d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double6 = normalDistributionImpl3.inverseCumulativeProbability((double) 97L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }
}

