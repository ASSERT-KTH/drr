import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D2, 0.0d, vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D4.normalize();
        double double7 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        boolean boolean8 = vector1D0.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray11 = vector2D10.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean17 = vector2D16.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray19 = vector2D18.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D18, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D20, (double) (byte) -1);
        line15.reset(vector2D16, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = line15.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = line15.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D31, 0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D33.normalize();
        double double36 = vector1D29.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        boolean boolean37 = vector1D29.isNaN();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.5574077246549023d, vector1D26, 0.0d, vector1D29, 35.0d, vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D0.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line25);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        float float2 = org.apache.commons.math3.util.FastMath.max(1.0000001f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int1 = org.apache.commons.math3.util.FastMath.abs((-1023));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1023 + "'", int1 == 1023);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, false);
        boolean boolean16 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D21.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, false);
        boolean boolean26 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double28 = intervalsSet27.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D31, 0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D33.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint37 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D33, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D39, 0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = vector1D41.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D41, false);
        boolean boolean46 = orientedPoint37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint45);
        orientedPoint37.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D49, 0.0d, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D51.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint55 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D51, false);
        boolean boolean56 = orientedPoint37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint55);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet57 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double58 = intervalsSet57.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint59 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint55, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet57);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane60 = subOrientedPoint29.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint55);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion61 = subOrientedPoint29.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.POSITIVE_INFINITY + "'", double58 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane60);
        org.junit.Assert.assertNotNull(euclidean1DRegion61);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D8, 0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D10.normalize();
        double double13 = vector1D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D17, 0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D19.normalize();
        double double22 = vector1D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D10.subtract((-0.428182669496151d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        double double24 = vector1D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D26, 0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D32, 0.0d, vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D34.normalize();
        double double37 = vector1D30.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D26, vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D41, 0.0d, vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D43.normalize();
        double double46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D39, vector1D45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = vector1D39.negate();
        double double48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D30, vector1D47);
        boolean boolean49 = vector1D30.isNaN();
        java.lang.Class<?> wildcardClass50 = vector1D30.getClass();
        double double51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D5, vector1D30);
        double double52 = vector1D30.getX();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        boolean boolean2 = vector3D1.isNaN();
        double double3 = vector3D1.getNorm1();
        try {
            double double4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D0, vector3D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, number1);
        java.lang.Number number3 = notPositiveException2.getArgument();
        boolean boolean4 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneCollection0 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DSubHyperplaneCollection0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str16 = vector3D15.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D17, (double) 10.0f, vector3D21, (double) 100L, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str29 = vector3D28.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str33 = vector3D32.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D32.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str37 = vector3D36.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D30, (double) 10.0f, vector3D34, (double) 100L, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D10, (double) (short) -1, vector3D25, Double.NaN, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str42 = vector3D41.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D41.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str46 = vector3D45.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D45.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str50 = vector3D49.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D43, (double) 10.0f, vector3D47, (double) 100L, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D10.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 'a', vector3D1, 0.36787944117144233d, vector3D5, 0.0d, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str55 = vector3D54.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D54.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine57 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(vector3D52, vector3D56);
        boolean boolean58 = vector3D56.isNaN();
        double double59 = vector3D56.getAlpha();
        boolean boolean60 = vector3D56.isNaN();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{-1; 0; 0}" + "'", str16.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{-1; 0; 0}" + "'", str29.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{-1; 0; 0}" + "'", str33.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{-1; 0; 0}" + "'", str37.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{-1; 0; 0}" + "'", str42.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "{-1; 0; 0}" + "'", str46.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{-1; 0; 0}" + "'", str50.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{-1; 0; 0}" + "'", str55.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.141592653589793d + "'", double59 == 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        double double4 = vector3D3.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D3.scalarMultiply((double) 'a');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D3.normalize();
        double double8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D0, vector3D3);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(4.0d, 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str7 = vector3D6.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D8, (double) 10.0f, vector3D12, (double) 100L, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D21, (double) 10.0f, vector3D25, (double) 100L, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D1, (double) (short) -1, vector3D16, Double.NaN, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        boolean boolean32 = vector3D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        double double34 = vector3D33.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double41 = vector3D40.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str44 = vector3D43.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D43.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D36, 1.000000059604643d, vector3D38, 2.718281828459045d, vector3D40, Double.NEGATIVE_INFINITY, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str49 = vector3D48.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D48.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str53 = vector3D52.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D50, (double) 10.0f, vector3D54, (double) 100L, vector3D56);
        double double59 = vector3D45.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        double double60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D33, vector3D58);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{-1; 0; 0}" + "'", str7.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{-1; 0; 0}" + "'", str44.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{-1; 0; 0}" + "'", str49.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{-1; 0; 0}" + "'", str53.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 110.0d + "'", double59 == 110.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.5707963267948966d + "'", double60 == 1.5707963267948966d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100, (double) 0, 11013.232920103323d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean1 = vector2D0.isNaN();
        java.text.NumberFormat numberFormat2 = null;
        java.lang.String str3 = vector2D0.toString(numberFormat2);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double5 = intervalsSet4.getSup();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList6 = intervalsSet4.asList();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList7 = intervalsSet4.asList();
        boolean boolean8 = vector2D0.equals((java.lang.Object) intervalList7);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(NaN); (NaN)}" + "'", str3.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(intervalList6);
        org.junit.Assert.assertNotNull(intervalList7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, false);
        boolean boolean16 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint18 = orientedPoint7.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane19 = subOrientedPoint18.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion20 = euclidean1DAbstractSubHyperplane19.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(subOrientedPoint18);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane19);
        org.junit.Assert.assertNull(euclidean1DRegion20);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D17, 0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D19.normalize();
        double double22 = vector1D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D26, 0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = vector1D28.normalize();
        double double31 = vector1D24.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D19.subtract((-0.428182669496151d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D32, (double) (-1023));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D34.negate();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 1023, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math3.util.FastMath.log10(3.814697265625E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.418539921951662d) + "'", double1 == (-5.418539921951662d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D27, 0.0d, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D33, 0.0d, vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = vector1D35.normalize();
        double double38 = vector1D31.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        double double39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D27, vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D42, 0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D44.normalize();
        double double47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D40, vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = vector1D40.negate();
        double double49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D31, vector1D48);
        double double50 = vector1D21.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D48);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D6, vector2D24);
        org.apache.commons.math3.geometry.Space space29 = vector2D24.getSpace();
        double double30 = vector2D24.getX();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray2 = vector2D1.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean8 = vector2D7.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray10 = vector2D9.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, (double) (byte) -1);
        line6.reset(vector2D7, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.1752011936438014d), vector2D7);
        boolean boolean18 = vector2D16.equals((java.lang.Object) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray20 = vector2D19.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line24 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D21, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean26 = vector2D25.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray28 = vector2D27.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D27, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Line line32 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D29, (double) (byte) -1);
        line24.reset(vector2D25, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = line24.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray36 = vector2D35.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray38 = vector2D37.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D37, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean44 = vector2D43.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray46 = vector2D45.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line50 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D47, (double) (byte) -1);
        line42.reset(vector2D43, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray53 = vector2D52.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D52, vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Line line57 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D54, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D43, vector2D54);
        line34.reset(vector2D35, vector2D54);
        boolean boolean60 = vector2D54.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean62 = vector2D61.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean64 = vector2D63.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D63.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D63.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean69 = vector2D68.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray71 = vector2D70.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D70, vector2D72);
        org.apache.commons.math3.geometry.euclidean.twod.Line line75 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D72, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean77 = vector2D76.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray79 = vector2D78.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D78, vector2D80);
        org.apache.commons.math3.geometry.euclidean.twod.Line line83 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D80, (double) (byte) -1);
        line75.reset(vector2D76, vector2D80);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray86 = vector2D85.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double88 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D85, vector2D87);
        org.apache.commons.math3.geometry.euclidean.twod.Line line90 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D87, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line91 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D76, vector2D87);
        double double92 = vector2D68.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Line line93 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D67, vector2D68);
        double double94 = vector2D67.getNorm();
        double double95 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D61, vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D96 = vector2D54.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D97 = vector2D16.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertEquals((double) double88, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double95, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D96);
        org.junit.Assert.assertNotNull(vector2D97);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D3, (double) 10.0f, vector3D7, (double) 100L, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D9, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str17 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str22 = vector3D21.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D21.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str26 = vector3D25.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str30 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D23, (double) 10.0f, vector3D27, (double) 100L, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str35 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str39 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D36, (double) 10.0f, vector3D40, (double) 100L, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D16, (double) (short) -1, vector3D31, Double.NaN, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str48 = vector3D47.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str53 = vector3D52.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D54, (double) 10.0f, vector3D58, (double) 100L, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str66 = vector3D65.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D65.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str70 = vector3D69.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D69.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D67, (double) 10.0f, vector3D71, (double) 100L, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D47, (double) (short) -1, vector3D62, Double.NaN, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D45.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D9.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double80 = vector3D78.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = vector3D79.orthogonal();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{-1; 0; 0}" + "'", str17.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{-1; 0; 0}" + "'", str22.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{-1; 0; 0}" + "'", str26.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{-1; 0; 0}" + "'", str30.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{-1; 0; 0}" + "'", str35.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{-1; 0; 0}" + "'", str39.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{-1; 0; 0}" + "'", str48.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{-1; 0; 0}" + "'", str53.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{-1; 0; 0}" + "'", str66.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{-1; 0; 0}" + "'", str70.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 9901.0d + "'", double80 == 9901.0d);
        org.junit.Assert.assertNotNull(vector3D81);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1022.99994f, number2, true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1022.99994f + "'", number5.equals(1022.99994f));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean1 = vector2D0.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D0.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean6 = vector2D5.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray8 = vector2D7.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D7, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line12 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean14 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        line12.reset(vector2D13, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, vector2D24);
        double double29 = vector2D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray32 = vector2D31.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D31, vector2D33);
        double double35 = vector2D4.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.Space space36 = vector2D31.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space36);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        java.lang.Class<?> wildcardClass4 = vector2D0.getClass();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D6, 0.0d, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D8.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D13, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D18, 0.0d, vector1D20);
        double double22 = vector1D13.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D24, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D29, 0.0d, vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D34, 0.0d, vector1D36);
        double double38 = vector1D29.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        boolean boolean39 = vector1D26.equals((java.lang.Object) double38);
        double double40 = vector1D21.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D8.add(Double.NEGATIVE_INFINITY, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        boolean boolean42 = vector2D0.equals((java.lang.Object) vector1D8);
        java.text.NumberFormat numberFormat43 = null;
        try {
            java.lang.String str44 = vector2D0.toString(numberFormat43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = spaceBSPTree0.getCut();
        org.junit.Assert.assertNull(spaceSubHyperplane1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(Double.NEGATIVE_INFINITY, 110.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str1 = vector3D0.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.orthogonal();
        double double3 = vector3D2.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(vector3D2, vector3D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1; 0; 0}" + "'", str1.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D6, vector2D24);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion29 = subLine28.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray31 = vector2D30.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D30, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean37 = vector2D36.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray39 = vector2D38.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D38, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Line line43 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D40, (double) (byte) -1);
        line35.reset(vector2D36, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = line35.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = line35.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane48 = subLine28.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray50 = vector2D49.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D49, vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Line line54 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D51, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean56 = vector2D55.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray58 = vector2D57.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D57, vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Line line62 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D59, (double) (byte) -1);
        line54.reset(vector2D55, vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Line line64 = line54.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine65 = line64.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray67 = vector2D66.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D66, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D68, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean73 = vector2D72.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray75 = vector2D74.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D74, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Line line79 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D76, (double) (byte) -1);
        line71.reset(vector2D72, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Line line81 = line71.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine82 = line81.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane83 = subLine65.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine82);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = subLine28.intersection(subLine82, false);
        java.util.List<org.apache.commons.math3.geometry.euclidean.twod.Segment> segmentList86 = subLine28.getSegments();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean1DRegion29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line64);
        org.junit.Assert.assertNotNull(subLine65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line81);
        org.junit.Assert.assertNotNull(subLine82);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane83);
        org.junit.Assert.assertNull(vector2D85);
        org.junit.Assert.assertNotNull(segmentList86);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D17, 0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D19.normalize();
        double double22 = vector1D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D26, 0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = vector1D28.normalize();
        double double31 = vector1D24.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D19.subtract((-0.428182669496151d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D32, (double) (-1023));
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = line5.getReverse();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(line35);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 52, 10.000001f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 202, (java.lang.Number) 32.000004f, (int) (byte) 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getPrevious();
        int int7 = nonMonotonicSequenceException5.getIndex();
        int int8 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32.000004f + "'", number6.equals(32.000004f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-0.014573901108156187d), 2.220446049250313E-16d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D6, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray30 = vector2D29.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean36 = vector2D35.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray38 = vector2D37.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D37, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, (double) (byte) -1);
        line34.reset(vector2D35, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line44 = line34.copySelf();
        line44.setAngle((double) (byte) 1);
        line44.setAngle((double) 10L);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray50 = vector2D49.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D49, vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Line line54 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D51, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean56 = vector2D55.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray58 = vector2D57.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D57, vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Line line62 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D59, (double) (byte) -1);
        line54.reset(vector2D55, vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Line line64 = line54.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = line54.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D68, 0.0d, vector1D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = line54.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D70);
        boolean boolean73 = line44.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray75 = vector2D74.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D74, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Line line79 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D76, (double) (byte) -1);
        double double80 = line44.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Line line81 = line44.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane82 = subLine28.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line81);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line44);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line64);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line81);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane82);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean1 = vector2D0.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D0.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean6 = vector2D5.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray8 = vector2D7.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D7, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line12 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean14 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        line12.reset(vector2D13, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, vector2D24);
        double double29 = vector2D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D5.normalize();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D31.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray34 = vector2D33.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D33, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D35, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean40 = vector2D39.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray42 = vector2D41.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D41, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D43, (double) (byte) -1);
        line38.reset(vector2D39, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray49 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D48, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Line line53 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D50, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean55 = vector2D54.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray57 = vector2D56.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D56, vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Line line61 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D58, (double) (byte) -1);
        line53.reset(vector2D54, vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray64 = vector2D63.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D63, vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Line line68 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D65, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line69 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D54, vector2D65);
        double double70 = vector2D43.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        double double71 = vector2D31.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double72 = vector2D43.getNormSq();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D6, 0.0d, vector1D8);
        double double10 = vector1D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D12, 0.0d, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D17, 0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D22, 0.0d, vector1D24);
        double double26 = vector1D17.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        boolean boolean27 = vector1D14.equals((java.lang.Object) double26);
        double double28 = vector1D9.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str31 = vector3D30.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str36 = vector3D35.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D35.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str40 = vector3D39.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D39.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str44 = vector3D43.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D37, (double) 10.0f, vector3D41, (double) 100L, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str49 = vector3D48.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D48.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str53 = vector3D52.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D50, (double) 10.0f, vector3D54, (double) 100L, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D30, (double) (short) -1, vector3D45, Double.NaN, vector3D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray61 = vector2D60.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D60, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Line line65 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D62, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean67 = vector2D66.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray69 = vector2D68.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D68, vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Line line73 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D70, (double) (byte) -1);
        line65.reset(vector2D66, vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Line line75 = line65.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = line65.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D76);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D81 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D79, 0.0d, vector1D81);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = line65.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D81);
        boolean boolean84 = vector3D56.equals((java.lang.Object) vector1D81);
        double double85 = vector1D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D81);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint87 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D81, false);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{-1; 0; 0}" + "'", str31.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{-1; 0; 0}" + "'", str36.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{-1; 0; 0}" + "'", str40.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{-1; 0; 0}" + "'", str44.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{-1; 0; 0}" + "'", str49.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{-1; 0; 0}" + "'", str53.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line75);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertNotNull(vector1D81);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.0d + "'", double85 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, false);
        boolean boolean16 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint18 = orientedPoint7.wholeHyperplane();
        double double19 = subOrientedPoint18.getSize();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(subOrientedPoint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 1, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray3 = vector2D2.toArray();
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray1, doubleArray3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray6 = vector2D5.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray8 = vector2D7.toArray();
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray6, doubleArray8);
        double double10 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray3, doubleArray6);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D14.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str19 = vector3D18.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D18.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str23 = vector3D22.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D16, (double) 10.0f, vector3D20, (double) 100L, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D22, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str30 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D29.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str35 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str39 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D36, (double) 10.0f, vector3D40, (double) 100L, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str48 = vector3D47.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str52 = vector3D51.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D51.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str56 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D49, (double) 10.0f, vector3D53, (double) 100L, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D29, (double) (short) -1, vector3D44, Double.NaN, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D60.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str66 = vector3D65.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D65.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str70 = vector3D69.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D69.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D67, (double) 10.0f, vector3D71, (double) 100L, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str79 = vector3D78.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = vector3D78.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str83 = vector3D82.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = vector3D82.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str87 = vector3D86.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D80, (double) 10.0f, vector3D84, (double) 100L, vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D60, (double) (short) -1, vector3D75, Double.NaN, vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D90 = vector3D58.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = vector3D22.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        double[] doubleArray92 = vector3D75.toArray();
        double[] doubleArray93 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray92);
        double double94 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray12, doubleArray93);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{-1; 0; 0}" + "'", str19.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{-1; 0; 0}" + "'", str23.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{-1; 0; 0}" + "'", str30.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{-1; 0; 0}" + "'", str35.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{-1; 0; 0}" + "'", str39.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{-1; 0; 0}" + "'", str48.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{-1; 0; 0}" + "'", str52.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{-1; 0; 0}" + "'", str56.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{-1; 0; 0}" + "'", str66.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{-1; 0; 0}" + "'", str70.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{-1; 0; 0}" + "'", str79.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "{-1; 0; 0}" + "'", str83.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(vector3D86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "{-1; 0; 0}" + "'", str87.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D90);
        org.junit.Assert.assertNotNull(vector3D91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 100.0d + "'", double94 == 100.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 7.930067261567154E14d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.95994243609855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9599424360985501d + "'", double1 == 0.9599424360985501d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray18 = vector2D17.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D19, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean24 = vector2D23.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray26 = vector2D25.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D27, (double) (byte) -1);
        line22.reset(vector2D23, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.1752011936438014d), vector2D23);
        double double33 = line5.distance(vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D36, 0.0d, vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D42, 0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D44.normalize();
        double double47 = vector1D40.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        double double48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D36, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D51, 0.0d, vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D53.normalize();
        double double56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D49, vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = vector1D49.negate();
        double double58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D40, vector1D57);
        boolean boolean59 = vector1D40.isNaN();
        java.lang.Class<?> wildcardClass60 = vector1D40.getClass();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = line34.getPointAt(vector1D40, (double) 10L);
        double[] doubleArray63 = vector2D62.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int[] intArray5 = new int[] { (byte) -1, (byte) 100, (byte) -1, 'a', '#' };
        int[] intArray11 = new int[] { 0, (-1), 0, ' ', (byte) 1 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray11);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree13 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) intArray11);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree14 = spaceBSPTree13.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane15 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree16 = spaceBSPTree14.split(spaceSubHyperplane15);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree17 = spaceBSPTree16.getParent();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 202 + "'", int12 == 202);
        org.junit.Assert.assertNotNull(spaceBSPTree14);
        org.junit.Assert.assertNotNull(spaceBSPTree16);
        org.junit.Assert.assertNull(spaceBSPTree17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray3 = new long[] { (byte) 1, (short) 10 };
        long[] longArray6 = new long[] { (byte) 1, (short) 10 };
        long[][] longArray7 = new long[][] { longArray3, longArray6 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray7);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) longArray7);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        java.lang.Class<?> wildcardClass4 = vector2D0.getClass();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D6, 0.0d, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D8.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D13, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D18, 0.0d, vector1D20);
        double double22 = vector1D13.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D24, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D29, 0.0d, vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D34, 0.0d, vector1D36);
        double double38 = vector1D29.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        boolean boolean39 = vector1D26.equals((java.lang.Object) double38);
        double double40 = vector1D21.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D8.add(Double.NEGATIVE_INFINITY, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        boolean boolean42 = vector2D0.equals((java.lang.Object) vector1D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray44 = vector2D43.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D43, vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Line line48 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D45, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean50 = vector2D49.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray52 = vector2D51.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D51, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Line line56 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, (double) (byte) -1);
        line48.reset(vector2D49, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = line48.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = line48.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D62, 0.0d, vector1D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = line48.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray69 = vector2D68.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D68, vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Line line73 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D70, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean75 = vector2D74.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray77 = vector2D76.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D76, vector2D78);
        org.apache.commons.math3.geometry.euclidean.twod.Line line81 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D78, (double) (byte) -1);
        line73.reset(vector2D74, vector2D78);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray84 = vector2D83.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double86 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D83, vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Line line88 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D85, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line89 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D74, vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray91 = vector2D90.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D92 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double93 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D90, vector2D92);
        org.apache.commons.math3.geometry.euclidean.twod.Line line95 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D92, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine96 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D74, vector2D92);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D97 = vector2D66.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        double double98 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D0, vector2D74);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line58);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertEquals((double) double79, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(vector2D92);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D97);
        org.junit.Assert.assertEquals((double) double98, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        boolean boolean6 = vector1D5.isInfinite();
        double double7 = vector1D5.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        double double14 = vector1D5.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray17 = vector2D16.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D16, vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D18, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean23 = vector2D22.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray25 = vector2D24.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D24, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line29 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, (double) (byte) -1);
        line21.reset(vector2D22, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = line21.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = line21.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D35, 0.0d, vector1D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = line21.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D42, 0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D44.normalize();
        double double47 = vector1D40.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = line21.getPointAt(vector1D44, 0.18417772639238725d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        boolean boolean51 = vector1D50.isNaN();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = vector1D50.normalize();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(vector1D52);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1.0000001f, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000041723335897d + "'", double2 == 1.0000041723335897d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.geometry.euclidean.threed.Line line0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector2 = null;
        org.apache.commons.math3.geometry.partitioning.Region.Location location3 = intervalsSet1.checkPoint(euclidean1DVector2);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine4 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line0, intervalsSet1);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet1.copySelf();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector6 = intervalsSet1.getBarycenter();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion7 = intervalsSet1.copySelf();
        org.junit.Assert.assertTrue("'" + location3 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location3.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(euclidean1DVector6);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D3, (double) 10.0f, vector3D7, (double) 100L, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D7.getZero();
        boolean boolean13 = vector3D12.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.negate();
        double double15 = vector3D12.getDelta();
        double[] doubleArray16 = vector3D12.toArray();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9913289158005998d + "'", double1 == 0.9913289158005998d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long[] longArray2 = new long[] { (byte) 1, (short) 10 };
        long[] longArray5 = new long[] { (byte) 1, (short) 10 };
        long[][] longArray6 = new long[][] { longArray2, longArray5 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean1 = vector2D0.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D0.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean6 = vector2D5.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray8 = vector2D7.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D7, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line12 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean14 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        line12.reset(vector2D13, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, vector2D24);
        double double29 = vector2D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D5.normalize();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray33 = vector2D32.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D34, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean39 = vector2D38.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray41 = vector2D40.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D42, (double) (byte) -1);
        line37.reset(vector2D38, vector2D42);
        boolean boolean47 = vector2D38.isInfinite();
        java.text.NumberFormat numberFormat48 = null;
        java.lang.String str49 = vector2D38.toString(numberFormat48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line50 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray52 = vector2D51.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D51, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray56 = vector2D55.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = vector2D57.negate();
        double double62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D51, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D5.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{(NaN); (NaN)}" + "'", str49.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D63);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double6 = vector3D5.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str9 = vector3D8.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D8.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D1, 1.000000059604643d, vector3D3, 2.718281828459045d, vector3D5, Double.NEGATIVE_INFINITY, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str14 = vector3D13.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D13.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str19 = vector3D18.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D18.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str23 = vector3D22.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D22.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str27 = vector3D26.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D20, (double) 10.0f, vector3D24, (double) 100L, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str32 = vector3D31.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str36 = vector3D35.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D35.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str40 = vector3D39.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D33, (double) 10.0f, vector3D37, (double) 100L, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D13, (double) (short) -1, vector3D28, Double.NaN, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str45 = vector3D44.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D44.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str50 = vector3D49.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D49.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str54 = vector3D53.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D53.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str58 = vector3D57.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D51, (double) 10.0f, vector3D55, (double) 100L, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str63 = vector3D62.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D62.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str67 = vector3D66.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D66.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str71 = vector3D70.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D64, (double) 10.0f, vector3D68, (double) 100L, vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D44, (double) (short) -1, vector3D59, Double.NaN, vector3D70);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D42.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double81 = vector3D80.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str84 = vector3D83.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D83.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D76, 1.000000059604643d, vector3D78, 2.718281828459045d, vector3D80, Double.NEGATIVE_INFINITY, vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = vector3D74.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D10, vector3D87);
        java.lang.Class<?> wildcardClass89 = vector3D10.getClass();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{-1; 0; 0}" + "'", str9.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{-1; 0; 0}" + "'", str14.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{-1; 0; 0}" + "'", str19.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{-1; 0; 0}" + "'", str23.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{-1; 0; 0}" + "'", str27.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{-1; 0; 0}" + "'", str32.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{-1; 0; 0}" + "'", str36.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{-1; 0; 0}" + "'", str40.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{-1; 0; 0}" + "'", str45.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{-1; 0; 0}" + "'", str50.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "{-1; 0; 0}" + "'", str54.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{-1; 0; 0}" + "'", str58.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "{-1; 0; 0}" + "'", str63.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "{-1; 0; 0}" + "'", str67.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "{-1; 0; 0}" + "'", str71.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "{-1; 0; 0}" + "'", str84.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertNotNull(vector3D88);
        org.junit.Assert.assertNotNull(wildcardClass89);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D3, (double) 10.0f, vector3D7, (double) 100L, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D7.getZero();
        boolean boolean13 = vector3D12.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str16 = vector3D15.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D17, (double) 10.0f, vector3D21, (double) 100L, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D12, vector3D17);
        double double27 = vector3D26.getAlpha();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{-1; 0; 0}" + "'", str16.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray3 = vector2D2.toArray();
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray1, doubleArray3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray7 = vector2D6.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { 35.0f };
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray12);
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray7, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray3, doubleArray15);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = orientedPoint25.wholeSpace();
        double double27 = intervalsSet26.getInf();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion28 = intervalsSet26.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray30 = vector2D29.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean36 = vector2D35.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray38 = vector2D37.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D37, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, (double) (byte) -1);
        line34.reset(vector2D35, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Line line44 = line34.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = line34.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D48, 0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = line34.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint54 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D50, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet55 = orientedPoint54.wholeSpace();
        boolean boolean56 = orientedPoint54.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = orientedPoint54.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint58 = orientedPoint54.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion59 = subOrientedPoint58.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane60 = intervalsSet26.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint58);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(intervalsSet26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(intervalsSet55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(subOrientedPoint58);
        org.junit.Assert.assertNull(euclidean1DRegion59);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane60);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray17 = vector2D16.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray19 = vector2D18.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D18, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D20, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean25 = vector2D24.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray27 = vector2D26.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D26, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, (double) (byte) -1);
        line23.reset(vector2D24, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray34 = vector2D33.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D33, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D35, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, vector2D35);
        line15.reset(vector2D16, vector2D35);
        boolean boolean41 = vector2D35.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean43 = vector2D42.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean45 = vector2D44.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = vector2D44.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D44.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean50 = vector2D49.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray52 = vector2D51.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D51, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Line line56 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean58 = vector2D57.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray60 = vector2D59.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D59, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Line line64 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D61, (double) (byte) -1);
        line56.reset(vector2D57, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray67 = vector2D66.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D66, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D68, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line72 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, vector2D68);
        double double73 = vector2D49.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line74 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D48, vector2D49);
        double double75 = vector2D48.getNorm();
        double double76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D42, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = vector2D35.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line79 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D35, 1.5574077246549023d);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double75, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D77);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = line15.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray18 = vector2D17.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D19, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean24 = vector2D23.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray26 = vector2D25.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D27, (double) (byte) -1);
        line22.reset(vector2D23, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray33 = vector2D32.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D34, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray40 = vector2D39.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D39, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Line line44 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine45 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D23, vector2D41);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion46 = subLine45.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray48 = vector2D47.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D47, vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Line line52 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D49, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean54 = vector2D53.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray56 = vector2D55.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, (double) (byte) -1);
        line52.reset(vector2D53, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line62 = line52.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = line52.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D63);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane65 = subLine45.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line52);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = line52.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray68 = vector2D67.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D67, vector2D69);
        org.apache.commons.math3.geometry.euclidean.twod.Line line72 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D69, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = vector2D69.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray75 = vector2D74.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D74, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Line line79 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D76, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean81 = vector2D80.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray83 = vector2D82.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D82, vector2D84);
        org.apache.commons.math3.geometry.euclidean.twod.Line line87 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D84, (double) (byte) -1);
        line79.reset(vector2D80, vector2D84);
        org.apache.commons.math3.geometry.euclidean.twod.Line line89 = line79.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D91 = line79.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D90);
        double double92 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D73, vector2D91);
        double double93 = vector2D91.getY();
        double[] doubleArray94 = vector2D91.toArray();
        boolean boolean95 = line52.contains(vector2D91);
        boolean boolean96 = line15.isParallelTo(line52);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(subLine16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean1DRegion46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line62);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane65);
        org.junit.Assert.assertNotNull(line66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertEquals((double) double85, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line89);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertNotNull(vector2D91);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = orientedPoint25.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint27 = orientedPoint25.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = orientedPoint27.getLocation();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(intervalsSet26);
        org.junit.Assert.assertNotNull(orientedPoint27);
        org.junit.Assert.assertNotNull(vector1D28);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str1 = vector3D0.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.orthogonal();
        double double3 = vector3D2.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D2.scalarMultiply((double) 'a');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double12 = vector3D11.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D14.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D7, 1.000000059604643d, vector3D9, 2.718281828459045d, vector3D11, Double.NEGATIVE_INFINITY, vector3D16);
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D2, vector3D16);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1; 0; 0}" + "'", str1.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int[] intArray5 = new int[] { (byte) -1, (byte) 100, (byte) -1, 'a', '#' };
        int[] intArray11 = new int[] { 0, (-1), 0, ' ', (byte) 1 };
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray11);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree13 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) intArray11);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree14 = spaceBSPTree13.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean22 = vector2D21.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray24 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D25, (double) (byte) -1);
        line20.reset(vector2D21, vector2D25);
        spaceBSPTree14.setAttribute((java.lang.Object) vector2D25);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 202 + "'", int12 == 202);
        org.junit.Assert.assertNotNull(spaceBSPTree14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray3 = vector2D2.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D2, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean9 = vector2D8.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray11 = vector2D10.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, (double) (byte) -1);
        line7.reset(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.1752011936438014d), vector2D8);
        boolean boolean19 = vector2D17.equals((java.lang.Object) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray22 = vector2D21.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D21, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line26 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean28 = vector2D27.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray30 = vector2D29.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, (double) (byte) -1);
        line26.reset(vector2D27, vector2D31);
        double double36 = vector2D27.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean39 = vector2D38.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D38.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D38.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean44 = vector2D43.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray46 = vector2D45.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line50 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D47, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean52 = vector2D51.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray54 = vector2D53.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D53, vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D55, (double) (byte) -1);
        line50.reset(vector2D51, vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray61 = vector2D60.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D60, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Line line65 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D62, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D51, vector2D62);
        double double67 = vector2D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Line line68 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D42, vector2D43);
        double double69 = vector2D42.getNorm();
        org.apache.commons.math3.geometry.Space space70 = vector2D42.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1L), vector2D17, Double.NaN, vector2D27, (double) 32, vector2D42);
        double double72 = vector2D17.getNorm();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space70);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-0.014573901108156187d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.734723475976807E-18d + "'", double1 == 1.734723475976807E-18d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str7 = vector3D6.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D8, (double) 10.0f, vector3D12, (double) 100L, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D21, (double) 10.0f, vector3D25, (double) 100L, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D1, (double) (short) -1, vector3D16, Double.NaN, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        boolean boolean32 = vector3D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        double double34 = vector3D33.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str36 = vector3D35.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D35.orthogonal();
        double double38 = vector3D37.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D37.scalarMultiply((double) 'a');
        double double41 = vector3D33.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{-1; 0; 0}" + "'", str7.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{-1; 0; 0}" + "'", str36.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.0d, 202, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9913289158005998d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9913289158005998d + "'", double2 == 0.9913289158005998d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double1 = intervalsSet0.getSup();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = intervalsSet0.buildNew(euclidean1DBSPTree2);
        try {
            double double4 = intervalsSet3.getBoundarySize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(intervalsSet3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 1, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray3 = vector2D2.toArray();
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray1, doubleArray3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray6 = vector2D5.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray8 = vector2D7.toArray();
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray6, doubleArray8);
        double double10 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray3, doubleArray6);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray13 = vector2D12.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray15 = vector2D14.toArray();
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray13, doubleArray15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray18 = vector2D17.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray20 = vector2D19.toArray();
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray18, doubleArray20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray25 = vector2D24.toArray();
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray23, doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray20, doubleArray23);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray28);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray11, doubleArray28);
        try {
            double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray28, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double1 = intervalsSet0.getSup();
        double double2 = intervalsSet0.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList4 = intervalsSet3.asList();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D6, 0.0d, vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D11, 0.0d, vector1D13);
        double double15 = vector1D6.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.partitioning.Region.Location location16 = intervalsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = intervalsSet3.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = intervalsSet0.buildNew(euclidean1DBSPTree18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(intervalList4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + location16 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location16.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean1DBSPTree18);
        org.junit.Assert.assertNotNull(intervalsSet19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray17 = vector2D16.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray19 = vector2D18.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D18, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D20, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean25 = vector2D24.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray27 = vector2D26.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D26, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, (double) (byte) -1);
        line23.reset(vector2D24, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray34 = vector2D33.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D33, vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D35, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, vector2D35);
        line15.reset(vector2D16, vector2D35);
        boolean boolean41 = vector2D35.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean43 = vector2D42.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean45 = vector2D44.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = vector2D44.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D44.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean50 = vector2D49.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray52 = vector2D51.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D51, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Line line56 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean58 = vector2D57.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray60 = vector2D59.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D59, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Line line64 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D61, (double) (byte) -1);
        line56.reset(vector2D57, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray67 = vector2D66.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D66, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D68, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line72 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, vector2D68);
        double double73 = vector2D49.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line74 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D48, vector2D49);
        double double75 = vector2D48.getNorm();
        double double76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D42, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = vector2D35.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine79 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D48, vector2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double75, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D77);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D8, 0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D13, 0.0d, vector1D15);
        double double17 = vector1D8.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D24, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D29, 0.0d, vector1D31);
        double double33 = vector1D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        boolean boolean34 = vector1D21.equals((java.lang.Object) double33);
        double double35 = vector1D16.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D3.add(Double.NEGATIVE_INFINITY, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        double double37 = vector1D3.getNormSq();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 100.0f, (-5.418539921951662d), 1022.9999389648439d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D3, (double) 10.0f, vector3D7, (double) 100L, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D9, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str17 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str22 = vector3D21.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D21.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str26 = vector3D25.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str30 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D23, (double) 10.0f, vector3D27, (double) 100L, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str35 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str39 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D36, (double) 10.0f, vector3D40, (double) 100L, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D16, (double) (short) -1, vector3D31, Double.NaN, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str48 = vector3D47.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str53 = vector3D52.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D54, (double) 10.0f, vector3D58, (double) 100L, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str66 = vector3D65.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D65.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str70 = vector3D69.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D69.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D67, (double) 10.0f, vector3D71, (double) 100L, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D47, (double) (short) -1, vector3D62, Double.NaN, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D45.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D9.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double80 = vector3D79.getZ();
        double double81 = vector3D62.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D79);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{-1; 0; 0}" + "'", str17.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{-1; 0; 0}" + "'", str22.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{-1; 0; 0}" + "'", str26.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{-1; 0; 0}" + "'", str30.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{-1; 0; 0}" + "'", str35.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{-1; 0; 0}" + "'", str39.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{-1; 0; 0}" + "'", str48.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{-1; 0; 0}" + "'", str53.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{-1; 0; 0}" + "'", str66.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{-1; 0; 0}" + "'", str70.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = line15.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray18 = vector2D17.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D19, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean24 = vector2D23.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray26 = vector2D25.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D27, (double) (byte) -1);
        line22.reset(vector2D23, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Line line32 = line22.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = line32.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane34 = subLine16.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine33);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane35 = subLine16.copySelf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(subLine16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line32);
        org.junit.Assert.assertNotNull(subLine33);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane34);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane35);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str7 = vector3D6.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D8, (double) 10.0f, vector3D12, (double) 100L, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D21, (double) 10.0f, vector3D25, (double) 100L, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D1, (double) (short) -1, vector3D16, Double.NaN, vector3D27);
        boolean boolean31 = vector3D27.isInfinite();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{-1; 0; 0}" + "'", str7.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D3, (double) 10.0f, vector3D7, (double) 100L, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D9, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str17 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str22 = vector3D21.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D21.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str26 = vector3D25.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str30 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D23, (double) 10.0f, vector3D27, (double) 100L, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str35 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str39 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D36, (double) 10.0f, vector3D40, (double) 100L, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D16, (double) (short) -1, vector3D31, Double.NaN, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str48 = vector3D47.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str53 = vector3D52.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D54, (double) 10.0f, vector3D58, (double) 100L, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str66 = vector3D65.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D65.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str70 = vector3D69.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D69.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D67, (double) 10.0f, vector3D71, (double) 100L, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D47, (double) (short) -1, vector3D62, Double.NaN, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D45.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D9.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        double[] doubleArray79 = vector3D62.toArray();
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -100 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{-1; 0; 0}" + "'", str17.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{-1; 0; 0}" + "'", str22.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{-1; 0; 0}" + "'", str26.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{-1; 0; 0}" + "'", str30.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{-1; 0; 0}" + "'", str35.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{-1; 0; 0}" + "'", str39.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{-1; 0; 0}" + "'", str48.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{-1; 0; 0}" + "'", str53.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{-1; 0; 0}" + "'", str66.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{-1; 0; 0}" + "'", str70.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray2 = vector2D1.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean8 = vector2D7.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray10 = vector2D9.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, (double) (byte) -1);
        line6.reset(vector2D7, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = line6.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = line6.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D20, 0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = line6.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray27 = vector2D26.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D26, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean33 = vector2D32.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray35 = vector2D34.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D34, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D36, (double) (byte) -1);
        line31.reset(vector2D32, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray42 = vector2D41.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D41, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D43, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray49 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D48, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Line line53 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D50, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine54 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D32, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = vector2D24.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 1.0f, vector2D32);
        double double57 = vector2D56.getNormInf();
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str7 = vector3D6.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D8, (double) 10.0f, vector3D12, (double) 100L, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D21, (double) 10.0f, vector3D25, (double) 100L, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D1, (double) (short) -1, vector3D16, Double.NaN, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        boolean boolean32 = vector3D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        java.lang.String str34 = vector3D33.toString();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{-1; 0; 0}" + "'", str7.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{0; -1; 0}" + "'", str34.equals("{0; -1; 0}"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(35.000000357627414d, 4.0d, 101.0d, 3.1415926535897967d, (-1.1752011936438014d), (-5.418539921951662d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 463.6687340271633d + "'", double6 == 463.6687340271633d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 1L, (float) 101, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D2.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean8 = vector2D7.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray10 = vector2D9.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean16 = vector2D15.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray18 = vector2D17.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line22 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D19, (double) (byte) -1);
        line14.reset(vector2D15, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray25 = vector2D24.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D24, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line29 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D15, vector2D26);
        double double31 = vector2D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray33 = vector2D32.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D34);
        java.lang.Class<?> wildcardClass36 = vector2D32.getClass();
        double double37 = vector2D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean40 = vector2D39.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D39.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean45 = vector2D44.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray47 = vector2D46.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D48, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean53 = vector2D52.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray55 = vector2D54.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D54, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line59 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, (double) (byte) -1);
        line51.reset(vector2D52, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray62 = vector2D61.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D61, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line67 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D52, vector2D63);
        double double68 = vector2D44.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Line line69 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D43, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray71 = vector2D70.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D70, vector2D72);
        org.apache.commons.math3.geometry.euclidean.twod.Line line75 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D72, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean77 = vector2D76.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray79 = vector2D78.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D78, vector2D80);
        org.apache.commons.math3.geometry.euclidean.twod.Line line83 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D80, (double) (byte) -1);
        line75.reset(vector2D76, vector2D80);
        double double85 = vector2D76.getNorm1();
        double double86 = vector2D44.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = vector2D15.subtract((double) 100.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        boolean boolean88 = vector2D44.isNaN();
        double double89 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D2, vector2D44);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double85, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertEquals((double) double89, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 52, 9901.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) -1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        line15.setAngle((double) (byte) 1);
        line15.setAngle((double) 10L);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray21 = vector2D20.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D20, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D22, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean27 = vector2D26.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray29 = vector2D28.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D30, (double) (byte) -1);
        line25.reset(vector2D26, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = line25.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = line25.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D39, 0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = line25.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        boolean boolean44 = line15.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line25);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = line25.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = line45.getReverse();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line35);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(line45);
        org.junit.Assert.assertNotNull(line46);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
        int[] intArray3 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, (int) (short) 1);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3, (int) 'a');
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3, 52);
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8, (int) (short) 1);
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11, (int) 'a');
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11, 52);
        int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray3, intArray15);
        int[] intArray17 = null;
        try {
            double double18 = org.apache.commons.math3.util.MathArrays.distance(intArray15, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D2.scalarMultiply(1.0d);
        boolean boolean6 = vector2D2.isInfinite();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0000041723335897d, (java.lang.Number) (-1.1752011936438014d), false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 100);
        java.lang.String str2 = notPositiveException1.toString();
        java.lang.Class<?> wildcardClass3 = notPositiveException1.getClass();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = notPositiveException1.getContext();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)" + "'", str2.equals("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, false);
        boolean boolean16 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D21.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, false);
        boolean boolean26 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double28 = intervalsSet27.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        boolean boolean30 = subOrientedPoint29.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane31 = subOrientedPoint29.getHyperplane();
        boolean boolean32 = subOrientedPoint29.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D34, 0.0d, vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = vector1D36.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint40 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D36, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D42, 0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D44.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint48 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D44, false);
        boolean boolean49 = orientedPoint40.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint48);
        boolean boolean50 = orientedPoint48.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = orientedPoint48.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet52 = orientedPoint48.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Side side53 = subOrientedPoint29.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint48);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint54 = orientedPoint48.copySelf();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(euclidean1DHyperplane31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(intervalsSet52);
        org.junit.Assert.assertTrue("'" + side53 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side53.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(orientedPoint54);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet26 = orientedPoint25.wholeSpace();
        boolean boolean27 = orientedPoint25.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D30, 0.0d, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = vector1D32.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint36 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D32, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D38, 0.0d, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = vector1D40.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint44 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D40, false);
        boolean boolean45 = orientedPoint36.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint44);
        orientedPoint36.revertSelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray48 = vector2D47.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D47, vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Line line52 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D49, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean54 = vector2D53.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray56 = vector2D55.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D57, (double) (byte) -1);
        line52.reset(vector2D53, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line62 = line52.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = line52.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D66, 0.0d, vector1D68);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = line52.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint72 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D68, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet73 = orientedPoint72.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint74 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint36, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet73);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet75 = orientedPoint36.wholeSpace();
        boolean boolean76 = orientedPoint25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint36);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(intervalsSet26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line62);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(intervalsSet73);
        org.junit.Assert.assertNotNull(intervalsSet75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 1047551.94f, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.geometry.euclidean.threed.Line line0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray2 = vector2D1.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Line line6 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D3, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean8 = vector2D7.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray10 = vector2D9.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line14 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, (double) (byte) -1);
        line6.reset(vector2D7, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = line6.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = line6.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D20, 0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = line6.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint26 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = orientedPoint26.wholeSpace();
        double double28 = intervalsSet27.getInf();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion29 = intervalsSet27.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine30 = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line0, intervalsSet27);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(intervalsSet27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.NEGATIVE_INFINITY + "'", double28 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion29);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        long long1 = org.apache.commons.math3.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D6, 0.0d, vector1D8);
        double double10 = vector1D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D12, 0.0d, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D17, 0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D22, 0.0d, vector1D24);
        double double26 = vector1D17.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        boolean boolean27 = vector1D14.equals((java.lang.Object) double26);
        double double28 = vector1D9.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D30, 0.0d, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = vector1D32.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D36, 0.0d, vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D38.normalize();
        double double41 = vector1D32.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = vector1D32.getZero();
        java.lang.Object obj43 = null;
        boolean boolean44 = vector1D32.equals(obj43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector1D45);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.36787944117144233d, 100.60318086422517d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 32.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5051500300918395d + "'", double1 == 1.5051500300918395d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 202, (java.lang.Number) 32.000004f, (int) (byte) 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonicSequenceException5.getPrevious();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = nonMonotonicSequenceException5.getContext();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32.000004f + "'", number6.equals(32.000004f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 10, (-1.0d));
        double double3 = vector2D2.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D2.getZero();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(vector2D4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str7 = vector3D6.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D8, (double) 10.0f, vector3D12, (double) 100L, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D21, (double) 10.0f, vector3D25, (double) 100L, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D1, (double) (short) -1, vector3D16, Double.NaN, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str33 = vector3D32.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D32.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str37 = vector3D36.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D36.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str41 = vector3D40.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D34, (double) 10.0f, vector3D38, (double) 100L, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D1.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        double[] doubleArray44 = vector3D43.toArray();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{-1; 0; 0}" + "'", str7.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{-1; 0; 0}" + "'", str33.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{-1; 0; 0}" + "'", str37.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{-1; 0; 0}" + "'", str41.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), 35.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str3 = vector3D2.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D2.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str8 = vector3D7.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str12 = vector3D11.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D11.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str16 = vector3D15.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D9, (double) 10.0f, vector3D13, (double) 100L, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str21 = vector3D20.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D20.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str25 = vector3D24.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D24.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str29 = vector3D28.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D22, (double) 10.0f, vector3D26, (double) 100L, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D2, (double) (short) -1, vector3D17, Double.NaN, vector3D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray33 = vector2D32.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D32, vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Line line37 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D34, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean39 = vector2D38.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray41 = vector2D40.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D42, (double) (byte) -1);
        line37.reset(vector2D38, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = line37.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = line37.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D51, 0.0d, vector1D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = line37.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        boolean boolean56 = vector3D28.equals((java.lang.Object) vector1D53);
        double double57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D0, vector3D28);
        double double58 = vector3D28.getNormInf();
        double double59 = vector3D28.getNormSq();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{-1; 0; 0}" + "'", str3.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{-1; 0; 0}" + "'", str8.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{-1; 0; 0}" + "'", str12.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{-1; 0; 0}" + "'", str16.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{-1; 0; 0}" + "'", str21.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{-1; 0; 0}" + "'", str25.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{-1; 0; 0}" + "'", str29.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line47);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D3, (double) 10.0f, vector3D7, (double) 100L, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D9, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str17 = vector3D16.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str22 = vector3D21.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D21.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str26 = vector3D25.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str30 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D23, (double) 10.0f, vector3D27, (double) 100L, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str35 = vector3D34.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str39 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D36, (double) 10.0f, vector3D40, (double) 100L, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D16, (double) (short) -1, vector3D31, Double.NaN, vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str48 = vector3D47.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str53 = vector3D52.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D54, (double) 10.0f, vector3D58, (double) 100L, vector3D60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str66 = vector3D65.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D65.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str70 = vector3D69.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D69.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D67, (double) 10.0f, vector3D71, (double) 100L, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D47, (double) (short) -1, vector3D62, Double.NaN, vector3D73);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D45.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D9.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D62);
        double[] doubleArray79 = vector3D62.toArray();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection83 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException85 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.4E-45f, (java.lang.Number) Double.NaN, 0, orderDirection83, false);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray79, orderDirection83, true, false);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{-1; 0; 0}" + "'", str17.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{-1; 0; 0}" + "'", str22.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{-1; 0; 0}" + "'", str26.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{-1; 0; 0}" + "'", str30.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{-1; 0; 0}" + "'", str35.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{-1; 0; 0}" + "'", str39.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{-1; 0; 0}" + "'", str48.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{-1; 0; 0}" + "'", str53.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{-1; 0; 0}" + "'", str66.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{-1; 0; 0}" + "'", str70.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection83.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D7, 0.0d, vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D9.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D13, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D15.normalize();
        double double18 = vector1D9.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D9.getZero();
        double double20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D19);
        double double21 = vector1D3.getX();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        int[] intArray6 = new int[] { (byte) -1, (byte) 100, (byte) -1, 'a', '#' };
        int[] intArray12 = new int[] { 0, (-1), 0, ' ', (byte) 1 };
        int int13 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray12);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree14 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) intArray12);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane15 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree16 = spaceBSPTree14.split(spaceSubHyperplane15);
        java.lang.Object obj17 = spaceBSPTree16.getAttribute();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree18 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree19 = spaceBSPTree18.getParent();
        float[] floatArray20 = new float[] {};
        float[] floatArray25 = new float[] { 1, 'a', (byte) 1, 1 };
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(floatArray20, floatArray25);
        float[] floatArray27 = null;
        float[] floatArray34 = new float[] { (byte) 100, (short) 100, 1, 10, '#', (byte) 100 };
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(floatArray27, floatArray34);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray25, floatArray34);
        float[] floatArray37 = new float[] {};
        float[] floatArray42 = new float[] { 1, 'a', (byte) 1, 1 };
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equals(floatArray37, floatArray42);
        float[] floatArray44 = null;
        float[] floatArray51 = new float[] { (byte) 100, (short) 100, 1, 10, '#', (byte) 100 };
        boolean boolean52 = org.apache.commons.math3.util.MathArrays.equals(floatArray44, floatArray51);
        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray42, floatArray51);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(floatArray25, floatArray42);
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree55 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree16, spaceBSPTree19, (java.lang.Object) floatArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 202 + "'", int13 == 202);
        org.junit.Assert.assertNotNull(spaceBSPTree16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(spaceBSPTree19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        boolean boolean1 = vector3D0.isNaN();
        double double2 = vector3D0.getNorm1();
        double double3 = vector3D0.getNorm();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str2 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str7 = vector3D6.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str11 = vector3D10.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str15 = vector3D14.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D8, (double) 10.0f, vector3D12, (double) 100L, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str20 = vector3D19.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D19.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str24 = vector3D23.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D21, (double) 10.0f, vector3D25, (double) 100L, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D1, (double) (short) -1, vector3D16, Double.NaN, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str33 = vector3D32.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D32.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str37 = vector3D36.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D36.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str42 = vector3D41.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D41.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str47 = vector3D46.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D46.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str51 = vector3D50.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D50.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str55 = vector3D54.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D48, (double) 10.0f, vector3D52, (double) 100L, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str60 = vector3D59.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D59.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str64 = vector3D63.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D63.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str68 = vector3D67.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D61, (double) 10.0f, vector3D65, (double) 100L, vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D41, (double) (short) -1, vector3D56, Double.NaN, vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str73 = vector3D72.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D72.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str77 = vector3D76.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = vector3D76.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str81 = vector3D80.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D74, (double) 10.0f, vector3D78, (double) 100L, vector3D80);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D41.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D74);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 'a', vector3D32, 0.36787944117144233d, vector3D36, 0.0d, vector3D83);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = vector3D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D84);
        double double86 = vector3D84.getDelta();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1; 0; 0}" + "'", str2.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{-1; 0; 0}" + "'", str7.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{-1; 0; 0}" + "'", str11.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{-1; 0; 0}" + "'", str15.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1; 0; 0}" + "'", str20.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{-1; 0; 0}" + "'", str24.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{-1; 0; 0}" + "'", str33.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{-1; 0; 0}" + "'", str37.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{-1; 0; 0}" + "'", str42.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{-1; 0; 0}" + "'", str47.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{-1; 0; 0}" + "'", str51.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{-1; 0; 0}" + "'", str55.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{-1; 0; 0}" + "'", str60.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "{-1; 0; 0}" + "'", str64.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{-1; 0; 0}" + "'", str68.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "{-1; 0; 0}" + "'", str73.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "{-1; 0; 0}" + "'", str77.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "{-1; 0; 0}" + "'", str81.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray3 = vector2D2.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D2, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Line line7 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean9 = vector2D8.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray11 = vector2D10.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D10, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, (double) (byte) -1);
        line7.reset(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.1752011936438014d), vector2D8);
        boolean boolean19 = vector2D17.equals((java.lang.Object) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray22 = vector2D21.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D21, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line26 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean28 = vector2D27.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray30 = vector2D29.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D29, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, (double) (byte) -1);
        line26.reset(vector2D27, vector2D31);
        double double36 = vector2D27.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean39 = vector2D38.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D38.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D38.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean44 = vector2D43.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray46 = vector2D45.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D45, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line50 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D47, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean52 = vector2D51.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray54 = vector2D53.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D53, vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Line line58 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D55, (double) (byte) -1);
        line50.reset(vector2D51, vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray61 = vector2D60.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D60, vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Line line65 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D62, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D51, vector2D62);
        double double67 = vector2D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Line line68 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D42, vector2D43);
        double double69 = vector2D42.getNorm();
        org.apache.commons.math3.geometry.Space space70 = vector2D42.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1L), vector2D17, Double.NaN, vector2D27, (double) 32, vector2D42);
        boolean boolean72 = vector2D17.isInfinite();
        double double73 = vector2D17.getNormSq();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray3 = new double[] { 3.814697265625E-6d, (-1), 0.95994243609855d };
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str6 = vector3D5.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str10 = vector3D9.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str14 = vector3D13.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D7, (double) 10.0f, vector3D11, (double) 100L, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D13, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str21 = vector3D20.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D20.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str26 = vector3D25.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str30 = vector3D29.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D29.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str34 = vector3D33.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D27, (double) 10.0f, vector3D31, (double) 100L, vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str39 = vector3D38.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D42.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str47 = vector3D46.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D40, (double) 10.0f, vector3D44, (double) 100L, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D20, (double) (short) -1, vector3D35, Double.NaN, vector3D46);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str52 = vector3D51.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D51.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str57 = vector3D56.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D60.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str65 = vector3D64.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D58, (double) 10.0f, vector3D62, (double) 100L, vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str70 = vector3D69.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D69.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D73.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str78 = vector3D77.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D71, (double) 10.0f, vector3D75, (double) 100L, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D51, (double) (short) -1, vector3D66, Double.NaN, vector3D77);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = vector3D49.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = vector3D13.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D66);
        double[] doubleArray83 = vector3D66.toArray();
        double[] doubleArray84 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray84);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection86 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray87 = new double[] {};
        double[][] doubleArray88 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray87, doubleArray88);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray84, orderDirection86, doubleArray88);
        double[] doubleArray91 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray3, doubleArray84);
        double[] doubleArray92 = null;
        try {
            double double93 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{-1; 0; 0}" + "'", str6.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1; 0; 0}" + "'", str10.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{-1; 0; 0}" + "'", str14.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{-1; 0; 0}" + "'", str21.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{-1; 0; 0}" + "'", str26.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{-1; 0; 0}" + "'", str30.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{-1; 0; 0}" + "'", str34.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{-1; 0; 0}" + "'", str39.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{-1; 0; 0}" + "'", str47.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{-1; 0; 0}" + "'", str52.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{-1; 0; 0}" + "'", str57.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "{-1; 0; 0}" + "'", str65.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{-1; 0; 0}" + "'", str70.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "{-1; 0; 0}" + "'", str78.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 100.60318086422517d + "'", double85 == 100.60318086422517d);
        org.junit.Assert.assertTrue("'" + orderDirection86 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection86.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray1 = vector2D0.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean7 = vector2D6.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray9 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D10, (double) (byte) -1);
        line5.reset(vector2D6, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = line5.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine16 = line15.wholeHyperplane();
        boolean boolean17 = subLine16.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion18 = subLine16.getRemainingRegion();
        boolean boolean19 = subLine16.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray21 = vector2D20.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D20, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D22, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean27 = vector2D26.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray29 = vector2D28.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D30, (double) (byte) -1);
        line25.reset(vector2D26, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = line25.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine36 = line35.wholeHyperplane();
        boolean boolean37 = subLine36.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray39 = vector2D38.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D38, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Line line43 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D40, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean45 = vector2D44.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray47 = vector2D46.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D48, (double) (byte) -1);
        line43.reset(vector2D44, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line53 = line43.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine54 = line53.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = subLine36.intersection(subLine54, false);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = subLine16.intersection(subLine36, true);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(subLine16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(euclidean1DRegion18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line35);
        org.junit.Assert.assertNotNull(subLine36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line53);
        org.junit.Assert.assertNotNull(subLine54);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D58);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, false);
        boolean boolean16 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint18 = orientedPoint7.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D22, 0.0d, vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = vector1D24.normalize();
        double double27 = vector1D20.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D31, 0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D33.normalize();
        double double36 = vector1D29.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = vector1D24.subtract((-0.428182669496151d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D40, 0.0d, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = vector1D42.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D46, 0.0d, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D48.normalize();
        double double51 = vector1D42.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2.0d, vector1D33, (double) 202, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D54.isNaN();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D50.subtract(2.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D54);
        double double57 = orientedPoint7.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(subOrientedPoint18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 100);
        java.lang.Throwable[] throwableArray3 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double2 = org.apache.commons.math3.util.FastMath.max(Double.POSITIVE_INFINITY, (double) 101);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 100);
        java.lang.String str2 = notPositiveException1.toString();
        java.lang.Number number3 = notPositiveException1.getMin();
        java.lang.Number number4 = notPositiveException1.getMin();
        boolean boolean5 = notPositiveException1.getBoundIsAllowed();
        java.lang.String str6 = notPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)" + "'", str2.equals("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)" + "'", str6.equals("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str3 = vector3D2.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D2.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str8 = vector3D7.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str12 = vector3D11.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D11.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str16 = vector3D15.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D9, (double) 10.0f, vector3D13, (double) 100L, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str21 = vector3D20.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D20.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str25 = vector3D24.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D24.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str29 = vector3D28.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D22, (double) 10.0f, vector3D26, (double) 100L, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D2, (double) (short) -1, vector3D17, Double.NaN, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str34 = vector3D33.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D33.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str38 = vector3D37.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D42.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str48 = vector3D47.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str52 = vector3D51.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D51.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str56 = vector3D55.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D49, (double) 10.0f, vector3D53, (double) 100L, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str61 = vector3D60.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D60.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str65 = vector3D64.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D64.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str69 = vector3D68.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D62, (double) 10.0f, vector3D66, (double) 100L, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D42, (double) (short) -1, vector3D57, Double.NaN, vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str74 = vector3D73.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = vector3D73.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str78 = vector3D77.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = vector3D77.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str82 = vector3D81.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D75, (double) 10.0f, vector3D79, (double) 100L, vector3D81);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = vector3D42.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D75);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 'a', vector3D33, 0.36787944117144233d, vector3D37, 0.0d, vector3D84);
        double double86 = vector3D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D84);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.718281828459045d, vector3D28);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{-1; 0; 0}" + "'", str3.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{-1; 0; 0}" + "'", str8.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{-1; 0; 0}" + "'", str12.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{-1; 0; 0}" + "'", str16.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{-1; 0; 0}" + "'", str21.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{-1; 0; 0}" + "'", str25.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{-1; 0; 0}" + "'", str29.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{-1; 0; 0}" + "'", str34.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{-1; 0; 0}" + "'", str38.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{-1; 0; 0}" + "'", str43.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{-1; 0; 0}" + "'", str48.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{-1; 0; 0}" + "'", str52.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{-1; 0; 0}" + "'", str56.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{-1; 0; 0}" + "'", str61.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "{-1; 0; 0}" + "'", str65.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "{-1; 0; 0}" + "'", str69.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "{-1; 0; 0}" + "'", str74.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "{-1; 0; 0}" + "'", str78.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "{-1; 0; 0}" + "'", str82.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double1 = intervalsSet0.getSup();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = intervalsSet0.buildNew(euclidean1DBSPTree2);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = intervalsSet0.getBarycenter();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(intervalsSet3);
        org.junit.Assert.assertNotNull(euclidean1DVector4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math3.util.FastMath.rint(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean1 = vector2D0.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D0.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean6 = vector2D5.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray8 = vector2D7.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D7, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line12 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean14 = vector2D13.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray16 = vector2D15.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D15, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Line line20 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, (double) (byte) -1);
        line12.reset(vector2D13, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, vector2D24);
        double double29 = vector2D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray32 = vector2D31.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D31, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Line line36 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D33, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean38 = vector2D37.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray40 = vector2D39.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D39, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Line line44 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, (double) (byte) -1);
        line36.reset(vector2D37, vector2D41);
        double double46 = vector2D37.getNorm1();
        double double47 = vector2D5.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean49 = vector2D48.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray51 = vector2D50.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D50, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Line line55 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D52, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean57 = vector2D56.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray59 = vector2D58.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D58, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Line line63 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D60, (double) (byte) -1);
        line55.reset(vector2D56, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray66 = vector2D65.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D65, vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D67, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, vector2D67);
        double double72 = vector2D48.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray74 = vector2D73.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D73, vector2D75);
        java.lang.Class<?> wildcardClass77 = vector2D73.getClass();
        double double78 = vector2D56.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D73);
        double double79 = vector2D37.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double80 = vector2D37.getY();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double79, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 10, (float) (byte) 1, (float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D1, 0.0d, vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D9, 0.0d, vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D11, false);
        boolean boolean16 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D19, 0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D21.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, false);
        boolean boolean26 = orientedPoint7.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double28 = intervalsSet27.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint29 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D31, 0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D33.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint37 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D33, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D39, 0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = vector1D41.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D41, false);
        boolean boolean46 = orientedPoint37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint45);
        orientedPoint37.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D49, 0.0d, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D51.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint55 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D51, false);
        boolean boolean56 = orientedPoint37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint55);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet57 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        double double58 = intervalsSet57.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint59 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint55, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet57);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane60 = intervalsSet27.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint59);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray62 = vector2D61.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D61, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean68 = vector2D67.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray70 = vector2D69.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D69, vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Line line74 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D71, (double) (byte) -1);
        line66.reset(vector2D67, vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Line line76 = line66.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = line66.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D82 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0.0f, vector1D80, 0.0d, vector1D82);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = line66.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D82);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint86 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D82, true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet87 = orientedPoint86.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Side side88 = subOrientedPoint59.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint86);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.POSITIVE_INFINITY + "'", double58 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(line76);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertNotNull(vector1D82);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertNotNull(intervalsSet87);
        org.junit.Assert.assertTrue("'" + side88 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side88.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray4 = vector2D3.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D3, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean10 = vector2D9.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray12 = vector2D11.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D11, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, (double) (byte) -1);
        line8.reset(vector2D9, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.1752011936438014d), vector2D9);
        boolean boolean20 = vector2D18.equals((java.lang.Object) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray23 = vector2D22.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D24, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean29 = vector2D28.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray31 = vector2D30.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D30, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D32, (double) (byte) -1);
        line27.reset(vector2D28, vector2D32);
        double double37 = vector2D28.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean40 = vector2D39.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D39.scalarMultiply((double) 0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean45 = vector2D44.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray47 = vector2D46.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D46, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D48, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        boolean boolean53 = vector2D52.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray55 = vector2D54.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D54, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line59 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, (double) (byte) -1);
        line51.reset(vector2D52, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double[] doubleArray62 = vector2D61.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        double double64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D61, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, (double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line67 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D52, vector2D63);
        double double68 = vector2D44.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Line line69 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D43, vector2D44);
        double double70 = vector2D43.getNorm();
        org.apache.commons.math3.geometry.Space space71 = vector2D43.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1L), vector2D18, Double.NaN, vector2D28, (double) 32, vector2D43);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine73 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space71);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str1 = vector3D0.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.orthogonal();
        double double3 = vector3D2.getNormInf();
        double double4 = vector3D2.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str8 = vector3D7.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str12 = vector3D11.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D11.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str16 = vector3D15.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D9, (double) 10.0f, vector3D13, (double) 100L, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D15, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str23 = vector3D22.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D22.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str28 = vector3D27.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D27.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str32 = vector3D31.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str36 = vector3D35.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D29, (double) 10.0f, vector3D33, (double) 100L, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str41 = vector3D40.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D40.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str45 = vector3D44.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D44.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str49 = vector3D48.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D42, (double) 10.0f, vector3D46, (double) 100L, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D22, (double) (short) -1, vector3D37, Double.NaN, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str54 = vector3D53.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D53.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str59 = vector3D58.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D58.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str63 = vector3D62.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D62.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str67 = vector3D66.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D60, (double) 10.0f, vector3D64, (double) 100L, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str72 = vector3D71.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D71.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D75 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str76 = vector3D75.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D75.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        java.lang.String str80 = vector3D79.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (short) 1, vector3D73, (double) 10.0f, vector3D77, (double) 100L, vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1L, vector3D53, (double) (short) -1, vector3D68, Double.NaN, vector3D79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = vector3D15.subtract((double) 1.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D85 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double86 = vector3D84.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D85);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = vector3D2.subtract(1.4711276743037347d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D85);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1; 0; 0}" + "'", str1.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.0d) + "'", double4 == (-0.0d));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{-1; 0; 0}" + "'", str8.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{-1; 0; 0}" + "'", str12.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{-1; 0; 0}" + "'", str16.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{-1; 0; 0}" + "'", str23.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{-1; 0; 0}" + "'", str28.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{-1; 0; 0}" + "'", str32.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{-1; 0; 0}" + "'", str36.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{-1; 0; 0}" + "'", str41.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{-1; 0; 0}" + "'", str45.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{-1; 0; 0}" + "'", str49.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "{-1; 0; 0}" + "'", str54.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{-1; 0; 0}" + "'", str59.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "{-1; 0; 0}" + "'", str63.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "{-1; 0; 0}" + "'", str67.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "{-1; 0; 0}" + "'", str72.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "{-1; 0; 0}" + "'", str76.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "{-1; 0; 0}" + "'", str80.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertNotNull(vector3D85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 9901.0d + "'", double86 == 9901.0d);
        org.junit.Assert.assertNotNull(vector3D87);
    }
}

