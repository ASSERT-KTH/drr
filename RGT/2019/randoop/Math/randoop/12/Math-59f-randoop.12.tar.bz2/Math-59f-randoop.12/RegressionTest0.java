import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549018d) + "'", double1 == (-1.5574077246549018d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double2 = org.apache.commons.math.util.FastMath.min(2.718281828459045d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9092974268256817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015870233978020357d + "'", double1 == 0.015870233978020357d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.8813735870195429d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.00000000000001d + "'", double1 == 35.00000000000001d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7716133340725972d) + "'", double1 == (-0.7716133340725972d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.8813735870195429d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 1, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.7932316976892416d + "'", double0 == 0.7932316976892416d);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(dfp3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.atanh(35.00000000000001d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.44412615900130886d) + "'", double1 == (-0.44412615900130886d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        boolean boolean6 = dfp5.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) '4', 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5561513324232938d + "'", double2 == 1.5561513324232938d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.566370614359173d + "'", double1 == 2.566370614359173d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.566370614359173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5663706143591734d + "'", double1 == 2.5663706143591734d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592638688632d + "'", double1 == 3.141592638688632d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.015870233978020357d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01587156656133512d + "'", double1 == 0.01587156656133512d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        double double6 = mersenneTwister4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.322715673685817d + "'", double6 == 0.322715673685817d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3010299956639812d + "'", double1 == 0.3010299956639812d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            boolean boolean7 = dfp5.lessThan(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5039722448044603d) + "'", double1 == (-0.5039722448044603d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2599210498948732d + "'", double1 == 1.2599210498948732d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        java.lang.Class<?> wildcardClass10 = mathIllegalArgumentException9.getClass();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 2, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.44412615900130886d), false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.rint();
        try {
            org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) 1.2599210498948732d, false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.3010299956639812d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.30102999566398125d + "'", double2 == 0.30102999566398125d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp25);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.ceil();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.ceil();
        org.apache.commons.math.dfp.Dfp dfp49 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp47, dfp49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.17701406236121286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1760910837807192d + "'", double1 == 0.1760910837807192d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.log(2.5663706143591734d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9424926884839085d + "'", double1 == 0.9424926884839085d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3010299956639812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.30577256643989315d + "'", double1 == 0.30577256643989315d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.5872139151569291d), (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.705026843555238d + "'", double1 == 0.705026843555238d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp25);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getE();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.subtract(dfp45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.NaN);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        mersenneTwister4.setSeed((long) (byte) 0);
        boolean boolean8 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.power10K(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 35);
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35." + "'", str11.equals("35."));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 100);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance(0.30577256643989315d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6853169696133173d) + "'", double1 == (-0.6853169696133173d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 52L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(10);
        int int4 = dfpField3.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField3.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.01587156656133512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015746930300935737d + "'", double1 == 0.015746930300935737d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        java.lang.String str9 = dfp8.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2.718281828459" + "'", str9.equals("2.718281828459"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.6853169696133173d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7402351284919576d) + "'", double1 == (-0.7402351284919576d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 16);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.5039722448044603d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (byte) 0, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        double double5 = mersenneTwister4.nextDouble();
//        mersenneTwister4.setSeed((long) (byte) 0);
//        int[] intArray8 = null;
//        mersenneTwister4.setSeed(intArray8);
//        double double10 = mersenneTwister4.nextDouble();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.17766488906100486d + "'", double10 == 0.17766488906100486d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.2599210498948732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 72.18815867866785d + "'", double1 == 72.18815867866785d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.5039722448044603d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1297047850335438d + "'", double1 == 1.1297047850335438d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(1);
        int int15 = dfp12.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        double double5 = mersenneTwister4.nextDouble();
//        mersenneTwister4.setSeed((long) (byte) 0);
//        int[] intArray8 = null;
//        mersenneTwister4.setSeed(intArray8);
//        float float10 = mersenneTwister4.nextFloat();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.86041474f + "'", float10 == 0.86041474f);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(10);
        int int6 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.newInstance(dfp9);
        int int11 = dfp9.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.015870233978020357d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998740704798709d + "'", double1 == 0.9998740704798709d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        mersenneTwister4.setSeed((long) (byte) 0);
        int int8 = mersenneTwister4.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 647325673 + "'", int8 == 647325673);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0133124297011056d + "'", double1 == 1.0133124297011056d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9016858859328668d + "'", double1 == 0.9016858859328668d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.17766488906100486d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03156481280505916d + "'", double2 == 0.03156481280505916d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        mathIllegalArgumentException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 32760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(10);
        int int6 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.newInstance(dfp9);
        double double11 = dfp3.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.609437912434d + "'", double11 == 1.609437912434d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.divide(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp11.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = null;
        try {
            boolean boolean36 = dfp33.greaterThan(dfp35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1297047850335438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.118129441963582d + "'", double1 == 2.118129441963582d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.705026843555238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6140917235649982d + "'", double1 == 0.6140917235649982d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) 32760);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.newInstance(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        int int48 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp45, dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        int int55 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp59 = dfp45.newInstance(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeExp(dfp39, dfp45);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp18.remainder(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.divide(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        int int18 = dfp16.log10K();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.6853169696133173d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-39.26576998753837d) + "'", double1 == (-39.26576998753837d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.tanh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8335762378570932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7403401633341681d + "'", double1 == 0.7403401633341681d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number7 = numberIsTooSmallException4.getArgument();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp11.isInfinite();
        java.lang.String str14 = dfp11.toString();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8." + "'", str14.equals("8."));
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        dfpField1.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.322715673685817d, 1.0133124297011056d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3083198812286399d + "'", double2 == 0.3083198812286399d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.18750655394138943d) + "'", double1 == (-0.18750655394138943d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 100);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int2 = org.apache.commons.math.util.FastMath.min((-32767), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        double double5 = mersenneTwister4.nextDouble();
//        mersenneTwister4.setSeed((long) (byte) 0);
//        int[] intArray8 = null;
//        mersenneTwister4.setSeed(intArray8);
//        long long10 = mersenneTwister4.nextLong();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1162518942126549865L) + "'", long10 == (-1162518942126549865L));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn5();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.negate();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp5.newInstance(2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp11.newInstance((long) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp25 = dfp23.subtract(dfp24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        int int8 = dfp7.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.divide(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp11.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.newInstance((double) 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        double double8 = dfp7.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.9251475365964139d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp12.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.Dfp.copysign(dfp36, dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.divide(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp12.dotrap(16, "", dfp30, dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp48.newInstance("hi!");
        boolean boolean52 = dfp48.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6140917235649982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5762164283272531d + "'", double1 == 0.5762164283272531d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2, (double) 32760);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.141592653589793d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.01587156656133512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015872232928522797d + "'", double1 == 0.015872232928522797d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException9.getSuppressed();
        java.lang.String str11 = mathIllegalArgumentException9.toString();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str11.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp19 = dfp12.multiply(dfp18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.5574077246549018d), 0.6140917235649982d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5574077246549016d) + "'", double2 == (-1.5574077246549016d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        int int7 = mersenneTwister4.nextInt();
        int[] intArray11 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister4.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        boolean boolean15 = mersenneTwister14.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1740543266) + "'", int7 == (-1740543266));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7932316976892416d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.44882845359076d + "'", double1 == 45.44882845359076d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.remainder(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10K((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8335762378570932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1997431238105127d + "'", double1 == 1.1997431238105127d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp5.newInstance("35.");
        org.apache.commons.math.dfp.Dfp dfp30 = dfp5.newInstance(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5762164283272531d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp25);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        int int45 = dfpField44.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField50.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.Dfp.copysign(dfp48, dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(10);
        int int58 = dfpField57.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.getLn5();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp62 = dfp48.newInstance(dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(10);
        int int65 = dfpField64.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField64.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(10);
        int int71 = dfpField70.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray72 = dfpField70.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField70.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp75 = org.apache.commons.math.dfp.Dfp.copysign(dfp68, dfp74);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField(10);
        int int78 = dfpField77.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField77.getLn5();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField77.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp82 = dfp68.newInstance(dfp81);
        org.apache.commons.math.dfp.Dfp dfp83 = org.apache.commons.math.dfp.DfpField.computeExp(dfp62, dfp68);
        boolean boolean84 = dfp40.unequal(dfp62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 16 + "'", int45 == 16);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfpArray52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 16 + "'", int58 == 16);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 16 + "'", int71 == 16);
        org.junit.Assert.assertNotNull(dfpArray72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 16 + "'", int78 == 16);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.atan((-39.26576998753837d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.545334356050612d) + "'", double1 == (-1.545334356050612d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        byte[] byteArray12 = new byte[] { (byte) 10, (byte) 2, (byte) -1, (byte) 1 };
        mersenneTwister4.nextBytes(byteArray12);
        boolean boolean14 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        int int7 = mersenneTwister4.nextInt();
        double double8 = mersenneTwister4.nextGaussian();
        boolean boolean9 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1740543266) + "'", int7 == (-1740543266));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.5531097991447655d + "'", double8 == 1.5531097991447655d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.apache.commons.math.util.FastMath.min(4, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int2 = org.apache.commons.math.util.FastMath.min((-32767), (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 35, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1740543266));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.cos(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1629907807957125d) + "'", double1 == (-0.1629907807957125d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681395d + "'", double1 == 0.5403023058681395d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance("hi!");
        int int22 = dfp19.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-32767) + "'", int22 == (-32767));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.015872232928522797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998740387553927d + "'", double1 == 0.9998740387553927d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9440892412430648d) + "'", double1 == (-0.9440892412430648d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        java.lang.String str5 = dfp4.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.power10K(100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(10);
        int int34 = dfpField33.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.Dfp.copysign(dfp31, dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.power10K(1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp40);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.732050807569" + "'", str5.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 16 + "'", int34 == 16);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits(32760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.545334356050612d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.451389950901778d + "'", double1 == 2.451389950901778d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("2.718281828459");
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-0.5039722448044603d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.remainder(dfp35);
        double[] doubleArray37 = dfp36.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.9440892412430648d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3890337254748026d + "'", double1 == 0.3890337254748026d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10000);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(10);
        int int6 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.newInstance(dfp9);
        int int11 = dfp9.log10K();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        int int14 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((byte) -1);
        int int18 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp9, dfp20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.Dfp.copysign(dfp27, dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.divide(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.DfpField.computeExp(dfp14, dfp53);
        boolean boolean55 = dfp8.greaterThan(dfp14);
        double double56 = dfp14.toDouble();
        java.lang.Class<?> wildcardClass57 = dfp14.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.0d + "'", double56 == 8.0d);
        org.junit.Assert.assertNotNull(wildcardClass57);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        float float8 = mersenneTwister4.nextFloat();
        double double9 = mersenneTwister4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8691945f + "'", float8 == 0.8691945f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.1805426729089165d) + "'", double9 == (-0.1805426729089165d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.ceil();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5039722448044603d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(10L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1740543266), (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.74054323E9f) + "'", float2 == (-1.74054323E9f));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        int int27 = dfp24.classify();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance(16);
        org.apache.commons.math.dfp.Dfp dfp30 = new org.apache.commons.math.dfp.Dfp(dfp29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.302585092994046d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.remainder(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 0.17701406236121286d, true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp25);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.rint();
        int int42 = dfp40.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        int int7 = mersenneTwister4.nextInt();
        int[] intArray11 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister4.setSeed(intArray11);
        mersenneTwister4.setSeed(4L);
        double double16 = mersenneTwister4.nextDouble();
        double double17 = mersenneTwister4.nextGaussian();
        mersenneTwister4.setSeed((int) (byte) 10);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1740543266) + "'", int7 == (-1740543266));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.8335762378570932d + "'", double16 == 0.8335762378570932d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.4331629886947133d + "'", double17 == 0.4331629886947133d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp28 = dfp5.add(dfp27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', (float) 32768);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (byte) 0, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.String str6 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (0)"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 2.451389950901778d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.power10K(2);
        boolean boolean28 = dfp12.unequal(dfp27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        int int9 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10000, (double) (-1162518942126549865L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        int int14 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getSqr3();
        java.lang.String str26 = dfp25.toString();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((byte) -1);
        int int34 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.getLn10();
        boolean boolean37 = dfp27.lessThan(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp5.divide(dfp36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1.732050807569" + "'", str26.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 16 + "'", int34 == 16);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9998740387553927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8812845161644749d + "'", double1 == 0.8812845161644749d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.newInstance();
        boolean boolean32 = dfp8.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp8.negate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.remainder(dfp35);
        int int37 = dfp24.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        float float2 = org.apache.commons.math.util.FastMath.max(35.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField31.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp29, dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn5();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp43 = dfp29.newInstance(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField51.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.Dfp.copysign(dfp49, dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(10);
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getLn5();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp63 = dfp49.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.DfpField.computeExp(dfp43, dfp49);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.rint();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.getLn5();
        dfpField67.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = dfpField67.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField67.getZero();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp21.dotrap(647325673, "hi!", dfp65, dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(10);
        int int77 = dfpField76.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.getLn5();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField76.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp81 = dfp80.ceil();
        int int82 = dfp81.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp83 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp81);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 16 + "'", int77 == 16);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 4 + "'", int82 == 4);
        org.junit.Assert.assertNotNull(dfp83);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField31.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp29, dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn5();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp43 = dfp29.newInstance(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField51.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.Dfp.copysign(dfp49, dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(10);
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getLn5();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp63 = dfp49.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.DfpField.computeExp(dfp43, dfp49);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.rint();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.getLn5();
        dfpField67.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = dfpField67.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField67.getZero();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp21.dotrap(647325673, "hi!", dfp65, dfp73);
        int int75 = dfp73.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 4 + "'", int75 == 4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7403401633341681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6372900940788013d + "'", double1 == 0.6372900940788013d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (byte) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        java.lang.Number number7 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (byte) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        boolean boolean7 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean8 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.asinh(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (byte) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray12);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException18);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException19);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        int[] intArray11 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        double double13 = mersenneTwister12.nextDouble();
        boolean boolean14 = mersenneTwister12.nextBoolean();
        int[] intArray18 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister(intArray18);
        double double20 = mersenneTwister19.nextDouble();
        boolean boolean21 = mersenneTwister19.nextBoolean();
        int[] intArray26 = new int[] { 10, 647325673, (byte) 100, (short) 0 };
        mersenneTwister19.setSeed(intArray26);
        mersenneTwister12.setSeed(intArray26);
        mersenneTwister4.setSeed(intArray26);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9016858859328667d + "'", double13 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.9016858859328667d + "'", double20 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3010299956639812d + "'", double1 == 0.3010299956639812d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        dfpField1.setIEEEFlagsBits((int) '#');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0);
        int int13 = dfp12.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((byte) -1);
        int int28 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField23.getLn10();
        boolean boolean31 = dfp21.lessThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = new org.apache.commons.math.dfp.Dfp(dfp30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn5();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(10);
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn5();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp((byte) -1);
        int int53 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField48.getTwo();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField48.getLn10();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField48.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp46.subtract(dfp57);
        int int59 = dfp58.classify();
        boolean boolean60 = dfp58.isInfinite();
        double double61 = dfp58.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 16 + "'", int53 == 16);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-43.0d) + "'", double61 == (-43.0d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 52.00000000000001d, (java.lang.Number) (-0.6853169696133173d), true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean18 = numberIsTooSmallException17.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean28 = numberIsTooSmallException27.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException23, localizable29, localizable36, objArray37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(10);
        int int41 = dfpField40.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField40.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.newDfp(8);
        dfpField40.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField40.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField40.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable29, (java.lang.Object[]) dfpArray48);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 16 + "'", int41 == 16);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfpArray48);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double2 = org.apache.commons.math.util.FastMath.min(100.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 647325673);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.288360085945612d + "'", double1 == 20.288360085945612d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        int int7 = dfp6.log10K();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp13.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp13.newInstance("35.");
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        int int45 = dfpField44.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp42, dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getLn5();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp49.divide(dfp53);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp49.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(10);
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField58.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.getTwo();
        boolean boolean64 = dfp56.unequal(dfp63);
        boolean boolean65 = dfp36.greaterThan(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField67.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField(10);
        int int74 = dfpField73.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray75 = dfpField73.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField73.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp78 = org.apache.commons.math.dfp.Dfp.copysign(dfp71, dfp77);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(10);
        int int81 = dfpField80.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.getLn5();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField80.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp85 = dfp71.newInstance(dfp84);
        org.apache.commons.math.dfp.Dfp dfp86 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp36, dfp71);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 16 + "'", int45 == 16);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 16 + "'", int74 == 16);
        org.junit.Assert.assertNotNull(dfpArray75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 16 + "'", int81 == 16);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        mersenneTwister4.setSeed((long) 2);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        double double7 = mersenneTwister4.nextDouble();
        int int8 = mersenneTwister4.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.594748197513173d + "'", double7 == 0.594748197513173d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1901413055 + "'", int8 == 1901413055);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 4.9E-324d, (java.lang.Number) 0.17701406236121286d, false);
        java.lang.Throwable throwable5 = null;
        try {
            numberIsTooSmallException4.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 100);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.sqrt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp13.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.rint();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp48.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp56 = dfp32.subtract(dfp55);
        boolean boolean57 = dfp7.greaterThan(dfp55);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp7.newInstance((byte) -1, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp7.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        java.lang.String str5 = dfp4.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.newInstance((-0.9251475365964139d));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.732050807569" + "'", str5.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, (java.lang.Object[]) dfpArray27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField30.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, (java.lang.Object[]) dfpArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean41 = numberIsTooSmallException40.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean51 = numberIsTooSmallException50.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException50.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(10);
        int int60 = dfpField59.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField59.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField59.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable57, (java.lang.Object[]) dfpArray64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray73 = dfpField67.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable57, (java.lang.Object[]) dfpArray73);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 8.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 16 + "'", int60 == 16);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpArray73);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        int int8 = dfp6.log10K();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-4), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.5440211108893698d), (-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5440211108893699d) + "'", double2 == (-0.5440211108893699d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13962634015954636d + "'", double1 == 0.13962634015954636d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp12.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField30.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.getOne();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        int int45 = dfpField44.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp42, dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getLn5();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp56 = dfp42.newInstance(dfp55);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.newInstance();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp36.divide(dfp59);
        boolean boolean61 = dfp12.lessThan(dfp59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 16 + "'", int45 == 16);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp();
        boolean boolean27 = dfp26.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp12.add(dfp26);
        boolean boolean29 = dfp12.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-4));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4) + "'", int1 == (-4));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5531097991447655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.53431507406488d + "'", double1 == 56.53431507406488d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfp20.newInstance(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        int int37 = dfpField36.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField36.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp47 = org.apache.commons.math.dfp.Dfp.copysign(dfp40, dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(10);
        int int50 = dfpField49.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfp40.newInstance(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeExp(dfp34, dfp40);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp60 = dfp34.divide(dfp59);
        boolean boolean61 = dfp11.greaterThan(dfp34);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp11.floor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 16 + "'", int50 == 16);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dfp62);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float2 = org.apache.commons.math.util.FastMath.min(0.8691945f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp19.newInstance((byte) 3, (byte) 1);
        int int25 = dfp19.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.82679529269723d) + "'", double1 == (-1.82679529269723d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (byte) 0, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        java.lang.Object[] objArray7 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        int int7 = mersenneTwister4.nextInt();
        int[] intArray11 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister4.setSeed(intArray11);
        mersenneTwister4.setSeed(4L);
        double double16 = mersenneTwister4.nextGaussian();
        int int18 = mersenneTwister4.nextInt((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1740543266) + "'", int7 == (-1740543266));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0479575933128131d + "'", double16 == 1.0479575933128131d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            boolean boolean5 = dfp3.lessThan(dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException9.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9);
        java.lang.String str12 = mathRuntimeException11.toString();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.30102999566398125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005253964571600727d + "'", double1 == 0.005253964571600727d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(52L);
        mersenneTwister1.setSeed((long) (short) 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.newDfp((byte) 1, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        int int36 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn5();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp((byte) -1);
        int int40 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField35.getTwo();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField35.getLn10();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField35.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp33.subtract(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp33);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp5.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp5.power10((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 16 + "'", int40 == 16);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp((byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999997749296758d + "'", double1 == 0.9999997749296758d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-32767), (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.18750655394138943d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0032726067353455964d) + "'", double1 == (-0.0032726067353455964d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField6.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.add(dfp13);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.rint();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        int int36 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.Dfp.copysign(dfp33, dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp40.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp48 = dfp24.subtract(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.getSqr3();
        int int55 = dfp54.getRadixDigits();
        boolean boolean56 = dfp48.lessThan(dfp54);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed((long) 16);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.7621956910836314d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1901413055);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43605.19527533388d + "'", double1 == 43605.19527533388d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp15, dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getSqr3();
        java.lang.String str30 = dfp29.toString();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp21.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp21.newInstance((long) 10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp6.divide(dfp33);
        double double35 = dfp34.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.732050807569" + "'", str30.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-39.26576998753837d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp12.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.Dfp.copysign(dfp36, dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.divide(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp12.dotrap(16, "", dfp30, dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp48.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance((long) 1901413055);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.220446049250313E-16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(10);
        int int6 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.negate();
        boolean boolean12 = dfp11.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        boolean boolean7 = mersenneTwister4.nextBoolean();
        int int8 = mersenneTwister4.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47736148 + "'", int8 == 47736148);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.5762164283272531d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9567046032298984d + "'", double1 == 0.9567046032298984d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(8);
        dfpField10.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.subtract(dfp19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        int int9 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((byte) -1);
        int int13 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField8.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp6.subtract(dfp17);
        double[] doubleArray19 = dfp17.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.POSITIVE_INFINITY, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32760);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn5();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(10);
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn5();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp((byte) -1);
        int int53 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField48.getTwo();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField48.getLn10();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField48.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp46.subtract(dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp60 = dfp57.add(dfp59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 16 + "'", int53 == 16);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.322715673685817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005632451053609131d + "'", double1 == 0.005632451053609131d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0000000000000002d, 0.30102999566398125d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.setIEEEFlagsBits(1);
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 17 + "'", int8 == 17);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3754263876807227d + "'", double1 == 1.3754263876807227d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField31.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp29, dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn5();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp43 = dfp29.newInstance(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField51.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.Dfp.copysign(dfp49, dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(10);
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getLn5();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp63 = dfp49.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.DfpField.computeExp(dfp43, dfp49);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.rint();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.getLn5();
        dfpField67.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode72 = dfpField67.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField67.getZero();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp21.dotrap(647325673, "hi!", dfp65, dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(10);
        int int77 = dfpField76.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.getSqr2Reciprocal();
        dfpField76.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField76.getSqr3Reciprocal();
        boolean boolean82 = dfp74.greaterThan(dfp81);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + roundingMode72 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode72.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 16 + "'", int77 == 16);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.9999999999999999d), (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999998d) + "'", double2 == (-0.9999999999999998d));
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        int int5 = mersenneTwister1.nextInt(32768);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5694 + "'", int5 == 5694);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.log(0.005632451053609131d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.179210575689573d) + "'", double1 == (-5.179210575689573d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.5574077246549016d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-74.68593339876165d) + "'", double1 == (-74.68593339876165d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((-0.44412615900130886d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getESplit();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.7615941559557649d), 1.0479575933128131d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7615941559557649d) + "'", double2 == (-0.7615941559557649d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        int int27 = dfp24.classify();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance(16);
        boolean boolean30 = dfp24.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.03156481280505916d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6536436208636119d) + "'", double1 == (-0.6536436208636119d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.sqrt();
        int int19 = dfp12.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 100, (double) 5694);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00000000000001d + "'", double2 == 100.00000000000001d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp11.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.floor();
        int int16 = dfp15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = null;
        try {
            boolean boolean18 = dfp15.unequal(dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        int int20 = dfp19.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray10 = numberIsTooSmallException9.getSuppressed();
        java.lang.Object[] objArray11 = numberIsTooSmallException9.getArguments();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean10 = numberIsTooSmallException9.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean20 = numberIsTooSmallException19.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField23.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField23.setRoundingMode(roundingMode27);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField23.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField23.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable21, (java.lang.Object[]) dfpArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        java.lang.String str5 = dfp4.toString();
        int int6 = dfp4.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.732050807569" + "'", str5.equals("1.732050807569"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        int int15 = dfp14.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100000000 + "'", int15 == 100000000);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn5();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        int int48 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(10);
        int int54 = dfpField53.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField53.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField53.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.Dfp.copysign(dfp51, dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp57.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField62.getSqr3();
        java.lang.String str66 = dfp65.toString();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp57.nextAfter(dfp65);
        boolean boolean68 = dfp45.lessThan(dfp57);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 16 + "'", int54 == 16);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1.732050807569" + "'", str66.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn5Split();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        int int9 = mersenneTwister4.nextInt(647325673);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 511936645 + "'", int9 == 511936645);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 35);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((-32767));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField10.setRoundingMode(roundingMode15);
        dfpField1.setRoundingMode(roundingMode15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 35);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        dfpField1.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.451389950901778d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        double double20 = dfp5.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9440892412430648d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        int int14 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        int int20 = dfpField19.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField19.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        int int27 = dfpField26.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp17.divide(dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.rint();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        int int48 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp45, dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        int int55 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.divide(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp52.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp60 = dfp36.subtract(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        int int63 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField62.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField62.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField62.newDfp();
        int int68 = dfp67.log10K();
        boolean boolean69 = dfp60.greaterThan(dfp67);
        org.apache.commons.math.dfp.Dfp dfp70 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp11, dfp60);
        org.apache.commons.math.dfp.Dfp dfp71 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0.86041474f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10000);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.rint();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        int int36 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.Dfp.copysign(dfp33, dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp40.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp48 = dfp24.subtract(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10K(5694);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        double[] doubleArray8 = dfp7.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.3010299956639812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005253964571600726d + "'", double1 == 0.005253964571600726d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 3, (float) 47736148);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.7736148E7f + "'", float2 == 4.7736148E7f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100000000, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-5.179210575689573d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.77411583222512d + "'", double1 == 88.77411583222512d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.6853169696133173d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 100, 0.594748197513173d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.594748197513173d + "'", double2 == 0.594748197513173d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        long long1 = org.apache.commons.math.util.FastMath.round(2.566370614359173d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException9, localizable15, localizable22, objArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 1.5561513324232938d, (java.lang.Number) 4.644483341943245d, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.1760910837807192d, number1, false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp13.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.rint();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp48.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp56 = dfp32.subtract(dfp55);
        boolean boolean57 = dfp7.greaterThan(dfp55);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp7.newInstance((byte) -1, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        int int63 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField62.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField62.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(10);
        int int69 = dfpField68.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray70 = dfpField68.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField68.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.Dfp.copysign(dfp66, dfp72);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp72.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp76 = new org.apache.commons.math.dfp.Dfp(dfp72);
        org.apache.commons.math.dfp.Dfp dfp77 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp72);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 16 + "'", int69 == 16);
        org.junit.Assert.assertNotNull(dfpArray70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1297047850335438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.052964968278617956d + "'", double1 == 0.052964968278617956d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        int int20 = dfpField19.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField19.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField25.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp23, dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp12.nextAfter(dfp32);
        int int34 = dfp33.intValue();
        boolean boolean35 = dfp33.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        int int9 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp19.divide(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.sqrt();
        boolean boolean26 = dfp6.unequal(dfp25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5039722448044603d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 5694);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1362594228314723d + "'", double1 == 0.1362594228314723d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        int int12 = dfpField1.getRadixDigits();
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, (java.lang.Object[]) dfpArray27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField30.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, (java.lang.Object[]) dfpArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean41 = numberIsTooSmallException40.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean51 = numberIsTooSmallException50.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException50.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(10);
        int int60 = dfpField59.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField59.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField59.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable57, (java.lang.Object[]) dfpArray64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray73 = dfpField67.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable57, (java.lang.Object[]) dfpArray73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(10);
        int int77 = dfpField76.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField76.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField76.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray82 = dfpField76.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, (java.lang.Object[]) dfpArray82);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 16 + "'", int60 == 16);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpArray73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 16 + "'", int77 == 16);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfpArray82);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(10);
        int int6 = dfpField5.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.newInstance(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((double) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfp18.newInstance(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(10);
        int int41 = dfpField40.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField40.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.Dfp.copysign(dfp38, dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        int int48 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.getLn5();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp52 = dfp38.newInstance(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        int int55 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField54.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(10);
        int int61 = dfpField60.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField60.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField60.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp65 = org.apache.commons.math.dfp.Dfp.copysign(dfp58, dfp64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.getLn5();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp72 = dfp58.newInstance(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeExp(dfp52, dfp58);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp31.remainder(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = org.apache.commons.math.dfp.DfpField.computeExp(dfp10, dfp74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 16 + "'", int41 == 16);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfpArray56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 16 + "'", int61 == 16);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("2.718281828459");
        boolean boolean13 = dfp12.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) 2, (byte) 1);
        boolean boolean15 = dfp8.greaterThan(dfp14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 3, (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.remainder(dfp35);
        boolean boolean38 = dfp36.equals((java.lang.Object) 2.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1740543266));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.13962634015954636d, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36274826310971975d + "'", double2 == 0.36274826310971975d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp11.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.floor();
        int int16 = dfp15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (0)");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException9, localizable15, localizable22, objArray23);
        boolean boolean25 = numberIsTooSmallException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int2 = org.apache.commons.math.util.FastMath.min(9, 47736148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        int[] intArray10 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        double double12 = mersenneTwister11.nextDouble();
        boolean boolean13 = mersenneTwister11.nextBoolean();
        int[] intArray18 = new int[] { 10, 647325673, (byte) 100, (short) 0 };
        mersenneTwister11.setSeed(intArray18);
        mersenneTwister4.setSeed(intArray18);
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray18);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9016858859328667d + "'", double12 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-4L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0d) + "'", double1 == (-4.0d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        int int14 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        int int20 = dfpField19.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField19.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        int int27 = dfpField26.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp17.divide(dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.rint();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        int int48 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp45, dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        int int55 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn5();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.divide(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp52.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp60 = dfp36.subtract(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        int int63 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField62.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField62.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField62.newDfp();
        int int68 = dfp67.log10K();
        boolean boolean69 = dfp60.greaterThan(dfp67);
        org.apache.commons.math.dfp.Dfp dfp70 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp11, dfp60);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField(10);
        int int73 = dfpField72.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField72.getLn5();
        dfpField72.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode77 = dfpField72.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField72.getZero();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField72.newDfp();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp11.nextAfter(dfp79);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 16 + "'", int42 == 16);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 16 + "'", int73 == 16);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + roundingMode77 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode77.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.3010299956639812d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 35);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        float float8 = mersenneTwister4.nextFloat();
        boolean boolean9 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8691945f + "'", float8 == 0.8691945f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.36274826310971975d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3627482631097198d + "'", double1 == 0.3627482631097198d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        int int13 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp5.newInstance();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-48.07525732566926d) + "'", double1 == (-48.07525732566926d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.17701406236121286d, number1, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 35, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2924966677897853d + "'", double2 == 1.2924966677897853d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        dfpField1.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance(dfp18);
        int int20 = dfp18.log10K();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.remainder(dfp18);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        int int7 = dfp6.log10K();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp13.divide(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        int int37 = dfpField36.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField36.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField42.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp47 = org.apache.commons.math.dfp.Dfp.copysign(dfp40, dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField51.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(10);
        int int58 = dfpField57.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField57.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp62 = org.apache.commons.math.dfp.Dfp.copysign(dfp55, dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(10);
        int int65 = dfpField64.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.getLn5();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp62.divide(dfp66);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp62.sqrt();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp46.subtract(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp13.add(dfp69);
        boolean boolean71 = dfp6.greaterThan(dfp13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 16 + "'", int58 == 16);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { '4', 1.0d, "hi!", (short) 0, 2.718281828459045d, '4' };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray9);
        java.lang.Throwable[] throwableArray11 = mathIllegalArgumentException10.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray11);
        java.lang.Object[] objArray13 = mathIllegalArgumentException12.getArguments();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5694, (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int11 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-4L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-27.289917197127753d) + "'", double1 == (-27.289917197127753d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.44412615900130886d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp12.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.Dfp.copysign(dfp36, dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.divide(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp12.dotrap(16, "", dfp30, dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField51.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(10);
        int int58 = dfpField57.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField57.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp62 = org.apache.commons.math.dfp.Dfp.copysign(dfp55, dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(10);
        int int65 = dfpField64.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField64.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(10);
        int int71 = dfpField70.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray72 = dfpField70.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField70.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp75 = org.apache.commons.math.dfp.Dfp.copysign(dfp68, dfp74);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp55.divide(dfp74);
        int int77 = dfp74.classify();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp74.newInstance(16);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField(10);
        int int82 = dfpField81.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField81.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField(10);
        int int86 = dfpField85.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField85.getLn5();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField85.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp83.newInstance(dfp89);
        org.apache.commons.math.dfp.Dfp dfp92 = dfp90.newInstance((double) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp79.nextAfter(dfp92);
        java.lang.Class<?> wildcardClass94 = dfp93.getClass();
        org.apache.commons.math.dfp.Dfp dfp95 = dfp30.add(dfp93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 16 + "'", int58 == 16);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 16 + "'", int71 == 16);
        org.junit.Assert.assertNotNull(dfpArray72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 16 + "'", int82 == 16);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 16 + "'", int86 == 16);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(wildcardClass94);
        org.junit.Assert.assertNotNull(dfp95);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextDouble();
        mersenneTwister4.setSeed((long) (byte) 0);
        byte[] byteArray8 = new byte[] {};
        mersenneTwister4.nextBytes(byteArray8);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9016858859328667d + "'", double5 == 0.9016858859328667d);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean7 = numberIsTooSmallException6.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((byte) -1);
        int int20 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField15.newDfp((byte) 2, (byte) 0);
        int int25 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField15.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable13, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 100L, (java.lang.Number) (-0.9999999999999999d), false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean39 = numberIsTooSmallException38.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooSmallException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(10);
        int int48 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.getLn5();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp((byte) -1);
        int int52 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField47.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField47.newDfp((byte) 2, (byte) 0);
        int int57 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField47.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException33, localizable34, localizable45, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 100L, (java.lang.Number) (-0.9999999999999999d), false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean68 = numberIsTooSmallException67.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable69 = numberIsTooSmallException67.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable69, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable74 = numberIsTooSmallException73.getGeneralPattern();
        java.lang.Object[] objArray75 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31, localizable45, localizable74, objArray75);
        java.lang.Number number77 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException80 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable74, number77, (java.lang.Number) 0.015870233978020357d, true);
        boolean boolean81 = numberIsTooSmallException80.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 16 + "'", int48 == 16);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 16 + "'", int52 == 16);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 16 + "'", int57 == 16);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.015746930300935737d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015746279590144345d + "'", double1 == 0.015746279590144345d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        float float1 = org.apache.commons.math.util.FastMath.abs(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.rint();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        int int36 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField35.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.Dfp.copysign(dfp33, dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        int int43 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp40.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp48 = dfp24.subtract(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = new org.apache.commons.math.dfp.Dfp(dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.multiply((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.18750655394138943d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.18862305845652283d) + "'", double1 == (-0.18862305845652283d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((double) 10000);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp15, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(10);
        int int25 = dfpField24.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.Dfp.copysign(dfp28, dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp15.divide(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn5();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField38.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp34.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(10);
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField48.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        int int55 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField54.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.Dfp.copysign(dfp52, dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp58.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp62 = org.apache.commons.math.dfp.DfpField.computeExp(dfp46, dfp61);
        boolean boolean63 = dfp7.greaterThan(dfp62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfpArray56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49182197 + "'", int2 == 49182197);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField17.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField17.setRoundingMode(roundingMode21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField17.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField17.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable15, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) (short) -1, (java.lang.Number) (-1740543266), false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 0.005632451053609131d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math.util.FastMath.log10(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException9, localizable15, localizable22, objArray23);
        java.lang.Number number25 = numberIsTooSmallException9.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 16.0d + "'", number25.equals(16.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        int int7 = dfp6.log10K();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getE();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getZero();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(10);
        int int41 = dfpField40.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField40.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.Dfp.copysign(dfp38, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp25.divide(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.rint();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(10);
        int int50 = dfpField49.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField49.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(10);
        int int56 = dfpField55.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField55.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.Dfp.copysign(dfp53, dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(10);
        int int63 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.getLn5();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp60.divide(dfp64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp60.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp68 = dfp44.subtract(dfp67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(10);
        int int71 = dfpField70.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray72 = dfpField70.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField70.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField70.newDfp();
        int int76 = dfp75.log10K();
        boolean boolean77 = dfp68.greaterThan(dfp75);
        org.apache.commons.math.dfp.Dfp dfp78 = org.apache.commons.math.dfp.DfpField.computeLn(dfp12, dfp19, dfp68);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp6.nextAfter(dfp68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 16 + "'", int41 == 16);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 16 + "'", int50 == 16);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 16 + "'", int71 == 16);
        org.junit.Assert.assertNotNull(dfpArray72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }
}

