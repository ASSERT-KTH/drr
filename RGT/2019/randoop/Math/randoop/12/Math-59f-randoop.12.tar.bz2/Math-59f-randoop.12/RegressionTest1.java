import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        int int7 = dfp6.log10K();
        java.lang.String str8 = dfp6.toString();
        double[] doubleArray9 = dfp6.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0." + "'", str8.equals("0."));
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.power10K((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.newInstance((byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.7713206f + "'", float2 == 0.7713206f);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(35);
        boolean boolean31 = dfp11.unequal(dfp28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1162518942126549865L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        int int27 = dfp24.classify();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance(16);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        int int36 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn5();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp33.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance((double) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp29.nextAfter(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        boolean boolean13 = dfp12.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField17.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField32.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.Dfp.copysign(dfp36, dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn5();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.divide(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp12.dotrap(16, "", dfp30, dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp48.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField52 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr3();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 16 + "'", int33 == 16);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfpField52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Throwable[] throwableArray10 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) mathRuntimeException15);
        boolean boolean17 = numberIsTooSmallException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        java.lang.Number number9 = numberIsTooSmallException8.getMin();
        java.lang.Number number10 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 100 + "'", number9.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0f + "'", number10.equals(1.0f));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 100, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number7 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((byte) -1);
        int int15 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField10.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField10.newDfp((byte) 2, (byte) 0);
        int int20 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField10.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) dfpArray21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(10);
        int int25 = dfpField24.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp(8);
        dfpField24.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField24.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField24.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) dfpArray32);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfpArray32);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.17701406236121286d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.17701406236121286d, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        int int13 = dfpField12.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField12.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable5, localizable10, (java.lang.Object[]) dfpArray15);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfpArray15);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.Dfp.copysign(dfp27, dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.divide(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.DfpField.computeExp(dfp14, dfp53);
        boolean boolean55 = dfp8.greaterThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp14.newInstance((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp57);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.Dfp.copysign(dfp27, dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.divide(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.DfpField.computeExp(dfp14, dfp53);
        boolean boolean55 = dfp8.greaterThan(dfp14);
        double double56 = dfp14.toDouble();
        boolean boolean57 = dfp14.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.0d + "'", double56 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp5.newInstance("35.");
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.newInstance();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField15.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField22.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp26, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp13.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.rint();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp48.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp56 = dfp32.subtract(dfp55);
        boolean boolean57 = dfp7.greaterThan(dfp55);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp7.newInstance((byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.3010299956639812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2631562551169929d + "'", double1 == 0.2631562551169929d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9092974268256817d, (java.lang.Number) 0.0d, false);
        boolean boolean14 = numberIsTooSmallException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 16.0d, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        int int23 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, (java.lang.Object[]) dfpArray27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField30.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, (java.lang.Object[]) dfpArray35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField38.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, (java.lang.Object[]) dfpArray43);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray43);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.remainder(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.rint();
        org.apache.commons.math.dfp.DfpField dfpField19 = dfp12.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpField19);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32768);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-0.5039722448044603d));
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfp5.newInstance(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        int int28 = dfpField27.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField27.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp19, dfp25);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.rint();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.ceil();
        double double43 = dfp40.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 16 + "'", int35 == 16);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) (-1740543266));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.3627482631097198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9349251482280525d + "'", double1 == 0.9349251482280525d);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        int[] intArray8 = null;
        mersenneTwister4.setSeed(intArray8);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.multiply(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.newInstance(2L);
        java.lang.String str19 = dfp14.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10000." + "'", str19.equals("10000."));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(2);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) '#');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getSqr3();
        java.lang.String str20 = dfp19.toString();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp11.newInstance((long) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getOne();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.floor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.732050807569" + "'", str20.equals("1.732050807569"));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField23.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.Dfp.copysign(dfp27, dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp14.divide(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        int int44 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField43.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.Dfp.copysign(dfp41, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.DfpField.computeExp(dfp14, dfp53);
        boolean boolean55 = dfp8.greaterThan(dfp14);
        double double56 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp14.newInstance((long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.0d + "'", double56 == 8.0d);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) -1);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("hi!");
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.floor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        int[] intArray3 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister4.setSeed(8);
        double double7 = mersenneTwister4.nextGaussian();
        float float8 = mersenneTwister4.nextFloat();
        mersenneTwister4.setSeed((int) (byte) 0);
        int[] intArray14 = new int[] { (byte) 2, '#', '4' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray14);
        double double16 = mersenneTwister15.nextDouble();
        boolean boolean17 = mersenneTwister15.nextBoolean();
        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 100 };
        mersenneTwister15.nextBytes(byteArray20);
        mersenneTwister4.nextBytes(byteArray20);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17701406236121286d + "'", double7 == 0.17701406236121286d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8691945f + "'", float8 == 0.8691945f);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9016858859328667d + "'", double16 == 0.9016858859328667d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.Dfp.copysign(dfp18, dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getLn5();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp24.remainder(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(8);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        int int45 = dfpField44.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp42, dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp48.power10K(2);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.DfpField.computeExp(dfp36, dfp51);
        int int53 = dfp36.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 16 + "'", int39 == 16);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 16 + "'", int45 == 16);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }
}

