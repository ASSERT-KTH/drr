import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test01");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(89);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 313.6528299498791d + "'", double1 == 313.6528299498791d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test02");
        int int1 = org.apache.commons.math.util.FastMath.round(1.41770637E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1417706368 + "'", int1 == 1417706368);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test03");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (short) 100, (-0.9589242746631385d), (-99));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test04");
        int int2 = org.apache.commons.math.util.FastMath.min((-127), 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-127) + "'", int2 == (-127));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test05");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 970, (java.lang.Number) 32.01562118716424d, 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32.01562118716424d + "'", number4.equals(32.01562118716424d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test06");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 90.0d, (java.lang.Number) 1.07610111794331E9d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test07");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-5.078957206595451E22d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8388608.0d + "'", double1 == 8388608.0d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test08");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1417706368);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test09");
        float float2 = org.apache.commons.math.util.FastMath.scalb(100.00001f, 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07374191E11f + "'", float2 == 1.07374191E11f);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test10");
        float[] floatArray5 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray11 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray13);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test11");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 21, (long) (-1443333376));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1443333397L + "'", long2 == 1443333397L);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test12");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test13");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int4 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test14");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray13 = new double[] { 0.0d, (byte) -1 };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (byte) 1);
        double[] doubleArray19 = new double[] { 0.0d, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray19);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1074789439) + "'", int14 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074789439) + "'", int20 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test15");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "no data" + "'", str1.equals("no data"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test16");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2910, 2.7453460413932063d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5698529091911486d + "'", double2 == 1.5698529091911486d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test17");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) ' ');
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-65));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-65)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test18");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getMaximalCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        int int6 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test19");
        double double1 = org.apache.commons.math.util.FastMath.floor(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.0d + "'", double1 == 15.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test20");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8, (int) (byte) 1);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 0.0d, (byte) -1 };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray19 = new double[] { 0.0d, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection23, false);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection23, false, true);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray8);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 15.104412573075516d);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 3200.0f);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray38, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074789439) + "'", int16 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074789439) + "'", int20 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test21");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException(number0);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test22");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 1078689792);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test23");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { 0.0d, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection10, false);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection10, false, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number22 = nonMonotonousSequenceException21.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        boolean boolean26 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection23, true, false);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074789439) + "'", int7 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0f) + "'", number22.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test24");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 1.1774215933195176d);
        double double3 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test25");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(103.70899308565303d, (double) (-1.0f), 0.017453292519943295d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test26");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 6.5663706143591725d, 0.0d, 1.07610112E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test27");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(101.00495037373169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5787.157366343153d + "'", double1 == 5787.157366343153d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test28");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(74.20994852478785d, 4.680646564964492E9d, (double) 1077936128, (double) 10.0f, 0.0d, 18300.000009536743d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.5812990192874E11d + "'", double6 == 3.5812990192874E11d);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test29");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7724655316835037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test30");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 2920);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test31");
        double double1 = org.apache.commons.math.util.FastMath.asin(281.8544890769287d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test32");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.100048367679961E12d, 6.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06462292499752105d + "'", double2 == 0.06462292499752105d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test33");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.237386142813108d, (double) (-1443333376), (double) 110L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test34");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.2676506002282296E31d, (java.lang.Number) 2.718281828459045d, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test35");
        double double2 = org.apache.commons.math.util.FastMath.atan2(97.0d, 1.1457558948760198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5589849596451486d + "'", double2 == 1.5589849596451486d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test36");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 56);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test37");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray9 = noBracketingException8.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException8.addSuppressed((java.lang.Throwable) nullArgumentException10);
        java.lang.Throwable[] throwableArray12 = noBracketingException8.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-0.6166950048277285d), (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test38");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 4.605170185988092d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test39");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test40");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-99), (double) 970);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test41");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { 0.0d, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection10, false);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection10, false, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray24 = new double[] { 0.0d, (byte) -1 };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection28, false);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection28, false, true);
        double[] doubleArray36 = new double[] { 0.0d, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection40, false);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray36);
        double double44 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray2, doubleArray20);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray48 = new double[] { 0.0d, (byte) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, (int) (byte) 1);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray48);
        java.lang.Class<?> wildcardClass53 = doubleArray2.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074789439) + "'", int7 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1074789439) + "'", int25 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1074789439) + "'", int37 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1074789439) + "'", int45 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1074789439) + "'", int49 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test42");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 2601.0f);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test43");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6483608274590871d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test44");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 33.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 45.0d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray13 = noBracketingException12.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (-6.0d), (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 45.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test45");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(2910, 1759510529);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test46");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray3);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test47");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-6L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.7683716E-7f + "'", float1 == 4.7683716E-7f);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test48");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1078558720, (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test49");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-2.0d));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test50");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray10 = noBracketingException9.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException11 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException9.addSuppressed((java.lang.Throwable) nullArgumentException11);
        java.lang.Throwable[] throwableArray13 = noBracketingException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats2, localizable3, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 34365.07995043807d, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test51");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray6 = noBracketingException5.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray20 = noBracketingException19.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray20);
        java.lang.String str24 = localizedFormats10.getSourceString();
        exceptionContext8.setValue("org.apache.commons.math.exception.NullArgumentException: input array", (java.lang.Object) str24);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getPrevious();
        int int32 = nonMonotonousSequenceException30.getIndex();
        int int33 = nonMonotonousSequenceException30.getIndex();
        boolean boolean34 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext35 = nonMonotonousSequenceException30.getContext();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException30.getDirection();
        exceptionContext8.setValue("org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})", (java.lang.Object) nonMonotonousSequenceException30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException42 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (int) (byte) 10, 6);
        exceptionContext8.setValue("hi!", (java.lang.Object) dimensionMismatchException42);
        java.lang.String str44 = dimensionMismatchException42.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "permutation size ({0}" + "'", str24.equals("permutation size ({0}"));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-1.0f) + "'", number31.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(exceptionContext35);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: no optimum computed yet" + "'", str44.equals("org.apache.commons.math.exception.DimensionMismatchException: no optimum computed yet"));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test52");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.680646564964492E9d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 4.680646564964492E9d + "'", number2.equals(4.680646564964492E9d));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test53");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test54");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(1024.7494513531653d, 1.2676506002282296E31d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.338253001141148E30d + "'", double2 == 6.338253001141148E30d);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test55");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test56");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = mathArithmeticException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet12 = exceptionContext11.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException15 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.0d);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) exceptionContext11, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0.8235088501775307d, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 3000, objArray16);
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test57");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.2676506002282296E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9911921517319514d) + "'", double1 == (-0.9911921517319514d));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test58");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 52L, (double) 1.4E-45f);
        double double4 = regulaFalsiSolver3.getMin();
        double double5 = regulaFalsiSolver3.getRelativeAccuracy();
        double double6 = regulaFalsiSolver3.getMax();
        int int7 = regulaFalsiSolver3.getMaxEvaluations();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) int7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test59");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 101, (long) (-2146959327));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test60");
        float float2 = org.apache.commons.math.util.FastMath.max(4.8631707E18f, (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.8631707E18f + "'", float2 == 4.8631707E18f);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test61");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 4.75368975085586E30d);
        java.lang.String str2 = maxCountExceededException1.toString();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (4,753,689,750,855,860,000,000,000,000,000) exceeded" + "'", str2.equals("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (4,753,689,750,855,860,000,000,000,000,000) exceeded"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 4.75368975085586E30d + "'", number3.equals(4.75368975085586E30d));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test62");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074789439), 1079738368);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,079,738,368, n = -1,074,789,439");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test63");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5707963267948966d, (double) (byte) -1, 100.0d);
        double double4 = regulaFalsiSolver3.getMin();
        double double5 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test64");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet7 = exceptionContext6.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException10 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.0d);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) exceptionContext6, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0.8235088501775307d, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 3000, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray24);
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray24);
        java.lang.Throwable[] throwableArray28 = mathIllegalArgumentException27.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 111L, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test65");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (-10L), (float) 980);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test66");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test67");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(4, (int) (short) 100);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test68");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 7.62939453125E-6d);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test69");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test70");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number5 = nonMonotonousSequenceException4.getPrevious();
        int int6 = nonMonotonousSequenceException4.getIndex();
        int int7 = nonMonotonousSequenceException4.getIndex();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = nonMonotonousSequenceException4.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.6881171418161356E43d };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray12);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray23);
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray23);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray23);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException28 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray23);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test71");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(4, 2910);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2906) + "'", int2 == (-2906));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test72");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 6.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test73");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int[] intArray6 = new int[] {};
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray5);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, 10);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, 33);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray4);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray16);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray19);
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray18);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray18);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray18);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test74");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection6, false);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray12 = new double[] { 0.0d, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray16 = new double[] { 0.0d, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection20, false);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection20, false, true);
        double[] doubleArray28 = new double[] { 0.0d, (byte) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection32, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray28);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray12);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.7763568394002505E-15d);
        double[] doubleArray44 = new double[] { 0.0d, (byte) -1 };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray44, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection48, false);
        double[] doubleArray53 = new double[] { 0.0d, (byte) -1 };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection57, false);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray63 = new double[] { 0.0d, (byte) -1 };
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection67, false);
        double[][] doubleArray70 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray53, orderDirection67, doubleArray70);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection67, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4917798526449118d, (java.lang.Number) 32.57837388740756d, 10, orderDirection67, true);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection67, false, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1074789439) + "'", int13 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1074789439) + "'", int17 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1074789439) + "'", int29 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1074789439) + "'", int45 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1074789439) + "'", int54 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1074789439) + "'", int64 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test75");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0000001f, (java.lang.Number) (-1.0f), 3000);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test76");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-99.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test77");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray14 = new double[] { 0.0d, (byte) -1 };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection24, false);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection24, false, false);
        double[] doubleArray32 = new double[] { 0.0d, (byte) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray36 = new double[] { 0.0d, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection40, false);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection40, false, true);
        double[] doubleArray48 = new double[] { 0.0d, (byte) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48, orderDirection52, false);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray48);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray32);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 970, (java.lang.Number) 2.6881171418161356E43d, 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = nonMonotonousSequenceException60.getDirection();
        boolean boolean64 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection61, true, true);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection61, true, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1074789439) + "'", int15 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1074789439) + "'", int33 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1074789439) + "'", int37 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1074789439) + "'", int49 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test78");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506E31f, (java.lang.Number) 51L, (int) (byte) 10, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test79");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test80");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection6, false);
        double[] doubleArray11 = new double[] { 0.0d, (byte) -1 };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection15, false);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray21 = new double[] { 0.0d, (byte) -1 };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection25, false);
        double[][] doubleArray28 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection25, doubleArray28);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection25, false, false);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 52L);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 111L);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 1.5430806348152437d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1074789439) + "'", int12 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1074789439) + "'", int22 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
    }
}

