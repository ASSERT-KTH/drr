import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        java.lang.Throwable[] throwableArray6 = noBracketingException4.getSuppressed();
        double double7 = noBracketingException4.getLo();
        double double8 = noBracketingException4.getLo();
        double double9 = noBracketingException4.getHi();
        double double10 = noBracketingException4.getFHi();
        double double11 = noBracketingException4.getFLo();
        double double12 = noBracketingException4.getFHi();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        float[] floatArray5 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray11 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray18 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray24 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray24);
        float[] floatArray31 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray37 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray37);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray24);
        float[] floatArray46 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray52 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(floatArray46, floatArray52);
        float[] floatArray59 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray65 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(floatArray52, floatArray65);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray52);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 0, 5);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1077936128, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07793613E9f + "'", float2 == 1.07793613E9f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (double) (-10));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.9E-324d, 0.0d, (double) (byte) 0);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((-1074789439), univariateRealFunction6, 0.0d, 2.993222846126381d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1074789439L), (-0.9999902065507035d), Double.POSITIVE_INFINITY, 1.1624473515096265d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1073741824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.073741824E9d + "'", double1 == 1.073741824E9d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double[] doubleArray5 = new double[] { 51.99815368652344d, 99.99999999999999d, 1.0E-15d, 1.1774215933195176d, 1.6681005372000588d };
        try {
            double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 4.605170185988092d, objArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 810528423927919297L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        long long1 = org.apache.commons.math.util.FastMath.round((-2.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 74.20321057778875d, (java.lang.Number) (byte) 100, true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 30);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (short) 10, (float) 1078558720);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.9999902065507035d), (double) 2146959359L, 0.5063656411097588d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray17 = noBracketingException16.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) (short) 0, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 32L, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats7, localizable8, (java.lang.Object[]) throwableArray17);
        java.lang.Object[] objArray22 = new java.lang.Object[] { throwableArray17, 2.225073858507202E-308d };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 32, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray26);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 2.0d, objArray26);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException30 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray26);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException(localizable0, (double) 45L, 110.0d, 0.3796077390275217d, 1.0734796795E9d, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1.4E-45f, 10.0d, 916455424);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int2 = org.apache.commons.math.util.FastMath.max(10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.log10(110.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.041392685158225d + "'", double1 == 2.041392685158225d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (-6), (double) 1077936128);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.0d) + "'", double2 == (-6.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-0.99999994f), (-100.0d));
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 970, 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.3322366E12f + "'", float2 == 8.3322366E12f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) (-10), (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.floor(9.5367431640625E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 3.8834864931005E-310d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 6, (long) 2910);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2910L + "'", long2 == 2910L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 29.999998f, (double) 1180958720);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.999998092651367d + "'", double2 == 29.999998092651367d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1.5777218E-29f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1175191552) + "'", int1 == (-1175191552));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(74.20994852478785d, (double) 97.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray13 = new double[] { 0.0d, (byte) -1 };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (byte) 1);
        double[] doubleArray21 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        double[] doubleArray26 = new double[] { 0.0d, (byte) -1 };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, (int) (byte) 1);
        double[] doubleArray32 = new double[] { 0.0d, (byte) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { 0.0d, (byte) -1 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, (int) (byte) 1);
        double[] doubleArray43 = new double[] { 0.0d, (byte) -1 };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray43);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray16);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1074789439) + "'", int14 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1074789439) + "'", int27 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1074789439) + "'", int33 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1074789439) + "'", int38 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1074789439) + "'", int44 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.993222846126381d, (double) 2920);
        double double3 = regulaFalsiSolver2.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver2.solve(0, univariateRealFunction5, (double) 1.4E-45f, 15.104412573075516d, (double) (short) 0, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException2.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray11 = noBracketingException10.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (short) 0, (java.lang.Object[]) throwableArray11);
        java.lang.Number number13 = notFiniteNumberException12.getArgument();
        mathArithmeticException2.addSuppressed((java.lang.Throwable) notFiniteNumberException12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException2.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException(throwable18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NoBracketingException noBracketingException36 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray37 = noBracketingException36.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException36.addSuppressed((java.lang.Throwable) nullArgumentException38);
        java.lang.Throwable[] throwableArray40 = noBracketingException36.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, (java.lang.Object[]) throwableArray40);
        org.apache.commons.math.exception.NoBracketingException noBracketingException42 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, 74.20994852478785d, 0.8235088501775307d, 0.991708735023292d, (double) (byte) -1, (java.lang.Object[]) throwableArray40);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Object[]) throwableArray40);
        java.lang.Object obj45 = exceptionContext15.getValue("org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})");
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 0 + "'", number13.equals((short) 0));
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNull(obj45);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = nonMonotonousSequenceException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.6881171418161356E43d };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException16 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, 0, (int) (byte) 1);
        int int17 = dimensionMismatchException16.getDimension();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 10);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, 51.99815368652344d, 1.18095872E9d, (double) 5, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 1.07610125E9f, 1.2676506002282294E31d, (double) 520L, 1.7763568394002505E-15d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2676506002282294E31d + "'", double5 == 1.2676506002282294E31d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.7763568394002505E-15d + "'", double6 == 1.7763568394002505E-15d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(4.294967296E11d, (double) 2, 1.0E-14d, (double) (-10), 1.5845632502852868E29d, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.589934592E11d + "'", double6 == 8.589934592E11d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        java.lang.Object obj1 = new java.lang.Object();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.lang.Object[] objArray4 = new java.lang.Object[] { obj1, localizedFormats2, localizedFormats3 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.4210854715202004E-14d, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) 980, (int) (byte) -1, 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 980.0d + "'", double3 == 980.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray6 = noBracketingException5.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        exceptionContext8.setValue("permutation size ({0}", (java.lang.Object) localizedFormats10);
        org.apache.commons.math.exception.NotPositiveException notPositiveException13 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) '#');
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray16 = new double[] { 0.0d, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection24, false);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection24, false, true);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, (int) (byte) 1);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1074789439) + "'", int17 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 32, (float) 916455424);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.993222846126381d, 21.329171167414387d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 980.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17598659903657765d) + "'", double1 == (-0.17598659903657765d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 100.00001f, 8.589934592E11d, 0.0d, (double) 3000, (-1.875861447621275E7d), 2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.58992963248866E13d + "'", double6 == 8.58992963248866E13d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.9E-324d, 0.0d, (double) (byte) 0);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.log10(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 74.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 1.2676506E31f, 30.162848702026007d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.338253001141147E30d + "'", double2 == 6.338253001141147E30d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(0.0d, 2.993222846126381d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 4.440892098500626E-16d, 110.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        float float1 = org.apache.commons.math.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2910);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        java.lang.Throwable[] throwableArray6 = noBracketingException4.getSuppressed();
        double double7 = noBracketingException4.getFLo();
        double double8 = noBracketingException4.getFLo();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 110.0d, (java.lang.Number) 1073741824, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        java.lang.String str11 = mathIllegalArgumentException10.toString();
        org.apache.commons.math.exception.MathInternalError mathInternalError12 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathIllegalArgumentException10);
        java.lang.String str13 = mathIllegalArgumentException10.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})" + "'", str11.equals("org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})" + "'", str13.equals("org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2920);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2920L + "'", long1 == 2920L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 520L, 2.6881171418161356E43d, 1.8115262724608532d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1074789439));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 52L, (double) 1.4E-45f);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve(2910, univariateRealFunction5, 0.0d, (-1.0d), 8.881784197001252E-16d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074789439), 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 100, n = -1,074,789,439");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection6, false);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 1, 0.0f, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.729577951308233E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.729577951308233E-14d + "'", double1 == 5.729577951308233E-14d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.993222846126381d, (double) 2920);
        double double3 = regulaFalsiSolver2.getMax();
        int int4 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver2.solve(35, univariateRealFunction6, 3.963429442519106d, (double) 11, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 11, (double) 1180958720, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        exceptionContext1.addMessage(localizable2, objArray10);
        java.lang.Object obj16 = exceptionContext1.getValue("identical abscissas x[{0}] == x[{1}] == {2} cause division by zero");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray27 = noBracketingException26.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException37 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray38 = noBracketingException37.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray38);
        exceptionContext1.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.NoBracketingException noBracketingException46 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double47 = noBracketingException46.getFHi();
        java.lang.Throwable[] throwableArray48 = noBracketingException46.getSuppressed();
        exceptionContext1.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException50 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 2.7453460413932063d, (java.lang.Object[]) throwableArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray48);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.atanh(103.70899308565303d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.0d), 1.4711276648614138d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2L), 2.2250738585072014E-308d, (double) 2920L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 52L, (double) 1.4E-45f);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1074789439), objArray2);
        java.lang.String str4 = maxCountExceededException3.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MaxCountExceededException: illegal state: trust region step has failed to reduce Q" + "'", str4.equals("org.apache.commons.math.exception.MaxCountExceededException: illegal state: trust region step has failed to reduce Q"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 20304.80024943191d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double2 = org.apache.commons.math.util.FastMath.scalb(32.01562118716424d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.100048367679961E12d + "'", double2 == 1.100048367679961E12d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1076101120, 11L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5L, (java.lang.Number) 2910, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2910 + "'", number4.equals(2910));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.16284870202600743d, (double) (byte) 100, 1.3440585709080678E43d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.MathUtils.log(74.20321057778875d, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-23.9803919395796d) + "'", double2 == (-23.9803919395796d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(32, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(4, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.0333147966386297E40d, (double) 2146959360);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, 0.0d, 9.5367431640625E-6d, 20.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-127), (-876644351));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-10), 1079574528);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-127), 105L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-10), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1073741824, 1.3586848144178008d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.073741824E9d + "'", double2 == 1.073741824E9d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', (long) 2920);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2920L + "'", long2 == 2920L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.4711276648614138d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 51.99815368652344d, 1.073741824E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        float float2 = org.apache.commons.math.util.FastMath.copySign(Float.POSITIVE_INFINITY, (float) 1077936128);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 51L);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray9 = noBracketingException8.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException8.addSuppressed((java.lang.Throwable) nullArgumentException10);
        java.lang.Throwable[] throwableArray12 = noBracketingException8.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException(number0, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = notFiniteNumberException14.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(exceptionContext15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { 0.0d, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection10, false);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection10, false, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray24 = new double[] { 0.0d, (byte) -1 };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection28, false);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection28, false, true);
        double[] doubleArray36 = new double[] { 0.0d, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection40, false);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray36);
        double double44 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray2, doubleArray20);
        double[] doubleArray47 = new double[] { 0.0d, (byte) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47, (int) (byte) 1);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray54 = new double[] { 0.0d, (byte) -1 };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray58 = new double[] { 0.0d, (byte) -1 };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection62, false);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection62, false, true);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray54, (int) (byte) 1);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074789439) + "'", int7 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1074789439) + "'", int25 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1074789439) + "'", int37 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1074789439) + "'", int48 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1074789439) + "'", int55 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1074789439) + "'", int59 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction> univariateRealFunctionBracketedUnivariateRealSolver2 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double7 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (byte) 100, univariateRealFunction1, univariateRealFunctionBracketedUnivariateRealSolver2, 180.0d, 5.729577951308233E-14d, (double) 1.4E-45f, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.729577951308233E-14d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1443336336) + "'", int1 == (-1443336336));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-100.0d), (java.lang.Number) 0L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 30, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2146959359L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.146959359E9d + "'", double1 == 2.146959359E9d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(5, (-99));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 51.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7084297692661896d + "'", double1 == 3.7084297692661896d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9d, (java.lang.Number) 52.000004f, (-6));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1077936128);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796325867198d + "'", double1 == 1.570796325867198d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4965075614664802d + "'", double1 == 3.4965075614664802d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0559515664122574d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.100048367679961E12d, 1.9867717342662448d, 1.6681005372000588d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7506006346749412d + "'", double3 == 1.7506006346749412d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1073741824, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741824) + "'", int2 == (-1073741824));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(101.00495037373169d, (double) 105L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 107.28813568091127d + "'", double2 == 107.28813568091127d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-99), (-876644351));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-876,644,351)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.7467135528742547E19d, (double) 105L, 32.57837388740756d, 2.993222846126381d, (double) 17.5f, (double) 45L, (double) 111L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.8340492305179675E21d + "'", double8 == 1.8340492305179675E21d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-100.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(30L, (long) 1073741824);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1073741794L) + "'", long2 == (-1073741794L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-126.99999999999999d) + "'", double1 == (-126.99999999999999d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray10 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        double[] doubleArray15 = new double[] { 0.0d, (byte) -1 };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection19, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection19, true);
        double[] doubleArray26 = new double[] { 0.0d, (byte) -1 };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, (int) (byte) 1);
        double[] doubleArray32 = new double[] { 0.0d, (byte) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { 0.0d, (byte) -1 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, (int) (byte) 1);
        double[] doubleArray45 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray45);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray40);
        double[] doubleArray50 = new double[] { 0.0d, (byte) -1 };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, (int) (byte) 1);
        double[] doubleArray56 = new double[] { 0.0d, (byte) -1 };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray61 = new double[] { 0.0d, (byte) -1 };
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray61, (int) (byte) 1);
        double[] doubleArray67 = new double[] { 0.0d, (byte) -1 };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray67);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray67);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray40);
        try {
            double double73 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074789439) + "'", int16 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1074789439) + "'", int27 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1074789439) + "'", int33 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1074789439) + "'", int38 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1074789439) + "'", int51 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1074789439) + "'", int57 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1074789439) + "'", int62 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1074789439) + "'", int68 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0559515664122574d, 1.7506006346749412d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.542764623170829d + "'", double2 == 0.542764623170829d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = nonMonotonousSequenceException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        java.lang.Object[] objArray10 = null;
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(11, 1077936128);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1443336336));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-0.99999994f), (-100.0d));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double11 = regulaFalsiSolver2.solve(0, univariateRealFunction6, 0.8813735870195429d, 1.5704526841967397d, 1.0333147966386297E40d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray8);
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) ' ', 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 1.18095872E9d, 55576.90612768985d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int1 = org.apache.commons.math.util.MathUtils.sign(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32803.98024630548d + "'", double1 == 32803.98024630548d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 30L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 7.62939453125E-6d, 1.0333147966386297E40d, 2.013555484658411E15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1443336336));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,443,336,336)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09238692595529725d) + "'", double1 == (-0.09238692595529725d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1074789439));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0011616774309411641d + "'", double1 == 0.0011616774309411641d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.570796325867198d, (double) 17.5f, 1.9867717342662448d, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 100, 33, 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.00001f + "'", float3 == 100.00001f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(103.70899308565303d, (double) (-1.0f), 0.017453292519943295d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.09238692595529725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09265113173402188d) + "'", double1 == (-0.09265113173402188d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.04323229440977d) + "'", double1 == (-1.04323229440977d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 2910, (float) 6, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(810528423927919297L, (long) (-6));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4863170543567515782L + "'", long2 == 4863170543567515782L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-99), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-49.5d) + "'", double2 == (-49.5d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.993222846126381d, (double) 2920);
        double double3 = regulaFalsiSolver2.getMax();
        double double4 = regulaFalsiSolver2.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver2.solve(0, univariateRealFunction6, 6.811187835675313E8d, 8.881784197001252E-16d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.09238692595529725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08824769934363007d) + "'", double1 == (-0.08824769934363007d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 30.0f, 1.1774215933195176d, 1940.424037772842d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 1.07793613E9f, 0.36787944117144233d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,077,936,128, 0.368]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray9 = noBracketingException8.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection6, false);
        double[] doubleArray11 = new double[] { 0.0d, (byte) -1 };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection15, false);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray21 = new double[] { 0.0d, (byte) -1 };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection25, false);
        double[][] doubleArray28 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection25, doubleArray28);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection25, false, false);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 52L);
        double[] doubleArray38 = new double[] { 0.0d, (byte) -1 };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray38, (int) (byte) 1);
        double[] doubleArray46 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray46);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1074789439) + "'", int12 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1074789439) + "'", int22 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1074789439) + "'", int39 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(105L, (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.09265113173402188d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295E-16d + "'", double1 == 1.7453292519943295E-16d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = org.apache.commons.math.util.FastMath.min(1078558720, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 10L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        java.lang.Object[] objArray4 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray2);
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathArithmeticException5);
        java.lang.String str7 = mathArithmeticException5.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: initial capacity ({0}) is not positive" + "'", str7.equals("org.apache.commons.math.exception.MathArithmeticException: initial capacity ({0}) is not positive"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 1.1774215933195176d);
        double double3 = regulaFalsiSolver2.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(5, univariateRealFunction5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 120L + "'", long1 == 120L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(97, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 2146959360);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(100.0f, 5, 916455424);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 916,455,424, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.atan(74.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5572836357815685d + "'", double1 == 1.5572836357815685d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.0000001f, 1076101120);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 0.0d, (byte) -1 };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray11 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray16 = new double[] { 0.0d, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection20, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection20, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1074789439) + "'", int4 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1074789439) + "'", int17 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5707963267948966d, (double) (byte) -1, 100.0d);
        double double4 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double11 = regulaFalsiSolver3.solve((-1175191552), univariateRealFunction6, 0.0d, 3.9481480091341E13d, (double) (-1074789439), allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-8.771253179097727d), 1.07610112E9d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1079574528, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1624473515096265d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.7467135528742547E19d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1076101120, 0.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1, 0.0d, (-1.074789439E9d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray7 = noBracketingException6.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, (java.lang.Object[]) throwableArray7);
        java.lang.Number number9 = notFiniteNumberException8.getArgument();
        java.lang.Number number10 = notFiniteNumberException8.getArgument();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = notFiniteNumberException8.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 0 + "'", number9.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 0 + "'", number10.equals((short) 0));
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (short) -1, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3762336167272099d + "'", double1 == 0.3762336167272099d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11L, (java.lang.Number) 1078558720, (int) (short) -1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1078558720 + "'", number4.equals(1078558720));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.993222846126381d, (double) 2920);
        double double3 = regulaFalsiSolver2.getMax();
        double double4 = regulaFalsiSolver2.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double11 = regulaFalsiSolver2.solve(2146959360, univariateRealFunction6, (double) 1077936128, 4.534006706025518E9d, (double) (-1073741794L), allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(10.000001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3169578969248166d + "'", double1 == 1.3169578969248166d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 3000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1084715008 + "'", int1 == 1084715008);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        float[] floatArray5 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray11 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray18 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray24 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray24);
        float[] floatArray32 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray38 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray32);
        float[] floatArray46 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray52 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(floatArray46, floatArray52);
        float[] floatArray59 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray65 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(floatArray52, floatArray65);
        float[] floatArray73 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray79 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(floatArray73, floatArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(floatArray65, floatArray73);
        float[] floatArray87 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray93 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(floatArray87, floatArray93);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(floatArray73, floatArray87);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray73);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(floatArray87);
        org.junit.Assert.assertNotNull(floatArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2920, 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9223372036854775808L) + "'", long2 == (-9223372036854775808L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1.1920929E-7f, 1.570796325867198d, 4.534006706025518E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8, (int) (byte) 1);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 0.0d, (byte) -1 };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray19 = new double[] { 0.0d, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection23, false);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection23, false, true);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray8);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 15.104412573075516d);
        double[] doubleArray37 = new double[] { 0.0d, (byte) -1 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection41, false);
        double[] doubleArray46 = new double[] { 0.0d, (byte) -1 };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray46, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection50, false);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray56 = new double[] { 0.0d, (byte) -1 };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray56, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection60, false);
        double[][] doubleArray63 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray46, orderDirection60, doubleArray63);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection60, false, false);
        try {
            boolean boolean70 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection60, false, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (-0 < 15.104)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074789439) + "'", int16 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074789439) + "'", int20 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1074789439) + "'", int38 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1074789439) + "'", int47 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1074789439) + "'", int57 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-10), (long) (-99));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 89L + "'", long2 == 89L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double double1 = org.apache.commons.math.util.FastMath.floor(55576.90612768985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55576.0d + "'", double1 == 55576.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1443336336));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.783370351219997d) + "'", double1 == (-21.783370351219997d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double2 = org.apache.commons.math.util.FastMath.pow(97.0d, 1.570796325867198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1320.729080665132d + "'", double2 == 1320.729080665132d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) Float.POSITIVE_INFINITY, 1.6681005372000588d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int2 = org.apache.commons.math.util.FastMath.min(6, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-6));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-6L) + "'", long1 == (-6L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        float float1 = org.apache.commons.math.util.FastMath.signum(7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 3000, 4.75368975085586E30d, (-0.6016748025328988d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3000.601674802533d + "'", double3 == 3000.601674802533d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (short) 0, 9.320655887504984E28d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray10 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 4863170543567515782L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 62 + "'", int1 == 62);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (byte) -1, 0.0d, 0.1624473515096065d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.5872139151569291d), (double) 120L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5872139151569291d) + "'", double2 == (-0.5872139151569291d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(916455424, (-876644351));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        exceptionContext0.addMessage(localizable1, objArray9);
        java.util.Set<java.lang.String> strSet14 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet15 = exceptionContext0.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 2910L, (double) (-6));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2910.0061855604363d + "'", double2 == 2910.0061855604363d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.2250738585072014E-308d, (double) (byte) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1443336336));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5244542151902893d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1228702984092456d + "'", double1 == 2.1228702984092456d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1443336336), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1, n = -1,443,336,336");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.288234863767985E12d, (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.182619575871484E76d + "'", double2 == 6.182619575871484E76d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.2676506002282296E31d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7576.061319933956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number5 = nonMonotonousSequenceException4.getPrevious();
        int int6 = nonMonotonousSequenceException4.getIndex();
        int int7 = nonMonotonousSequenceException4.getIndex();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = nonMonotonousSequenceException4.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.6881171418161356E43d };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray12);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray12);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = localizedFormats0.getLocalizedString(locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2.0d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.9867717342662448d, 0.991708735023292d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9867717342662445d + "'", double2 == 1.9867717342662445d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.993222846126381d, (double) 2920);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double9 = regulaFalsiSolver2.solve((-127), univariateRealFunction4, 6.283185307179586d, 1.8340492305179675E21d, 1.3169578969248166d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (double) (-127));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray6 = noBracketingException5.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray20 = noBracketingException19.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray20);
        java.lang.String str24 = localizedFormats10.getSourceString();
        exceptionContext8.setValue("org.apache.commons.math.exception.NullArgumentException: input array", (java.lang.Object) str24);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getPrevious();
        int int32 = nonMonotonousSequenceException30.getIndex();
        int int33 = nonMonotonousSequenceException30.getIndex();
        boolean boolean34 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext35 = nonMonotonousSequenceException30.getContext();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException30.getDirection();
        exceptionContext8.setValue("org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})", (java.lang.Object) nonMonotonousSequenceException30);
        java.lang.Number number38 = nonMonotonousSequenceException30.getPrevious();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "permutation size ({0}" + "'", str24.equals("permutation size ({0}"));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-1.0f) + "'", number31.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(exceptionContext35);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (-1.0f) + "'", number38.equals((-1.0f)));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.875861447621275E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        incrementor0.resetCount();
        int int4 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5395564933646284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 35, 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96549157373046875L + "'", long2 == 96549157373046875L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray4 = null;
        try {
            double double5 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) '#');
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray16 = new double[] { 0.0d, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, (int) (byte) 1);
        double[] doubleArray22 = new double[] { 0.0d, (byte) -1 };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        try {
            double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1074789439) + "'", int17 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1074789439) + "'", int23 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 32L, 1.7506006346749412d, 4.158638853279167d, (-0.5244542151902893d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 53.83820463354175d + "'", double4 == 53.83820463354175d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 52L, (double) 1.4E-45f);
        double double6 = regulaFalsiSolver5.getAbsoluteAccuracy();
        int int7 = regulaFalsiSolver5.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution11 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double12 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, (-100.0d), (double) 89L, (double) 4863170543567515782L, allowedSolution11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution11 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution11.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int[] intArray0 = null;
        try {
            int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        incrementor0.resetCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(980, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = nonMonotonousSequenceException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.6881171418161356E43d };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        java.lang.Object obj15 = null;
        exceptionContext7.setValue("hi!", obj15);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, 96549157373046875L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3, 2910L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1663522375) + "'", int2 == (-1663522375));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.7467135528742547E19d, (java.lang.Number) 18300.000009536743d, false);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooLargeException6.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 18300.000009536743d + "'", number8.equals(18300.000009536743d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((-1.074789439E9d), (-1.6676087455616045E9d), (-23.9803919395796d), (double) 980, (double) 810528423927919297L, 1.5704526841967397d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.065224807088981E18d + "'", double6 == 3.065224807088981E18d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.setMaximalCount(980);
        int int5 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.225073858507202E-308d + "'", double1 == 2.225073858507202E-308d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { 0.0d, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection10, false);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection10, false, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray27 = new double[] { 0.0d, (byte) -1 };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray37 = new double[] { 0.0d, (byte) -1 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray41 = new double[] { 0.0d, (byte) -1 };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection45, false);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection45, false, true);
        double[] doubleArray53 = new double[] { 0.0d, (byte) -1 };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection57, false);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray53);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray37);
        double[] doubleArray64 = new double[] { 0.0d, (byte) -1 };
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection68, false);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray74 = new double[] { 0.0d, (byte) -1 };
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray74, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray74, orderDirection78, false);
        double[][] doubleArray81 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, orderDirection78, doubleArray81);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, doubleArray81);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, orderDirection24, doubleArray81);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection24, true, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074789439) + "'", int7 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1074789439) + "'", int28 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1074789439) + "'", int38 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1074789439) + "'", int42 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1074789439) + "'", int54 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1074789439) + "'", int65 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1074789439) + "'", int75 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.7467135528742547E19d, (double) 1084715008, 74.0d, 0.0d, 1.9867717342662448d, 0.9d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8946864054797056E28d + "'", double6 == 1.8946864054797056E28d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1074789439), objArray2);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.07610112E9d, (double) 11L, (double) 8.3322366E12f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getHi();
        double double8 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        int int3 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 51L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 980, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 507.5d + "'", double2 == 507.5d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 17.5f, 3000.601674802533d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1509.0508374012666d + "'", double2 == 1509.0508374012666d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray13 = new double[] { 0.0d, (byte) -1 };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (byte) 1);
        double[] doubleArray21 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        double[] doubleArray26 = new double[] { 0.0d, (byte) -1 };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, (int) (byte) 1);
        double[] doubleArray32 = new double[] { 0.0d, (byte) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray37 = new double[] { 0.0d, (byte) -1 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, (int) (byte) 1);
        double[] doubleArray43 = new double[] { 0.0d, (byte) -1 };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray43);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray16);
        double[] doubleArray51 = new double[] { 0.0d, (byte) -1 };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray55 = new double[] { 0.0d, (byte) -1 };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection59, false);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection59, false, true);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, (int) (byte) 1);
        double[] doubleArray69 = new double[] { 0.0d, (byte) -1 };
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray69, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection73, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection73, false);
        double[] doubleArray80 = new double[] { 0.0d, (byte) -1 };
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray80, (int) (byte) 1);
        double[] doubleArray88 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1074789439) + "'", int14 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1074789439) + "'", int27 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1074789439) + "'", int33 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1074789439) + "'", int38 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1074789439) + "'", int44 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1074789439) + "'", int52 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1074789439) + "'", int56 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1074789439) + "'", int70 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1074789439) + "'", int81 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.0d + "'", double89 == 1.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 101.00495037373169d + "'", double90 == 101.00495037373169d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.0d + "'", double91 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.0333147966386297E40d, 53.83820463354175d, 62);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1024.7494513531653d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.625350842618347d + "'", double1 == 7.625350842618347d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet7 = exceptionContext6.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException10 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.0d);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) exceptionContext6, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0.8235088501775307d, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 3000, objArray11);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 29.999998f, objArray11);
        java.lang.Number number18 = notFiniteNumberException17.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 29.999998f + "'", number18.equals(29.999998f));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        java.lang.Object[] objArray4 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double13 = noBracketingException12.getFHi();
        java.lang.Throwable[] throwableArray14 = noBracketingException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException5.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, 3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (-1.875861447621275E7d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.875861447621275E7d) + "'", number4.equals((-1.875861447621275E7d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.875861447621275E7d) + "'", number5.equals((-1.875861447621275E7d)));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(0.0d, 1.4711276743037347d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023560237179d + "'", double1 == 0.5403023560237179d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(1.8115262724608532d, (double) (-6), 29.999998092651367d, 8.58992963248866E13d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 916455424);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 2146959360);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, (int) (short) 10);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.9E-324d, 0.0d, (double) (byte) 0);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getMax();
        double double7 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        try {
            double double13 = regulaFalsiSolver3.solve((-1), univariateRealFunction9, 0.0d, 1.4711276648614138d, (double) 52L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-6L), (float) 4, 10.000001f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(720.0d, (double) 980L, (-0.9999999403953552d), 18312.065066792115d, 2.4758800785707605E27d, (-0.5244542151902893d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.2984857435121E27d) + "'", double6 == (-1.2984857435121E27d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        float float2 = org.apache.commons.math.util.FastMath.min(7.6293945E-6f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.6293945E-6f + "'", float2 == 7.6293945E-6f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.5335664749145508d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1457558948760198d + "'", double1 == 1.1457558948760198d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int[] intArray1 = new int[] { 97 };
        int[] intArray2 = new int[] {};
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray3);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, 10);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, 33);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        try {
            int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.08824769934363007d), 55.44068679350977d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1180958720);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34365.07995043806d + "'", double1 == 34365.07995043806d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.0f, (double) (-99));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.setMaximalCount(0);
        int int5 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (byte) -1, 0, 1084715008);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(2910L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.972630067242408d) + "'", double1 == (-0.972630067242408d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.570796325948127d, (double) 17.5f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(105L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.4711276648614138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.354142387049761d + "'", double1 == 4.354142387049761d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int1 = org.apache.commons.math.util.MathUtils.sign(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 30.162848702026007d, 180.0d, (-0.09265113173402188d), 31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-100.0d), (-1024.3329204058489d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5403023560237179d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int1 = org.apache.commons.math.util.MathUtils.hash(18300.000009536743d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1090117376 + "'", int1 == 1090117376);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray6);
        double double9 = noBracketingException8.getFHi();
        double double10 = noBracketingException8.getLo();
        double double11 = noBracketingException8.getHi();
        org.apache.commons.math.exception.MathInternalError mathInternalError12 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.294967296E11d + "'", double10 == 4.294967296E11d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 30.0d + "'", double11 == 30.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.0d + "'", double1 == 45.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9589242746631385d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6166950048277285d) + "'", double1 == (-0.6166950048277285d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (-10), 6.288234863767985E12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int5 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.07610112E9d, (double) 'a', 1084715008);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.4758800785707605E27d, (int) (byte) 0, (-2146959360));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(32.01562118716424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (-1.5777218E-29f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray6 = noBracketingException5.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray20 = noBracketingException19.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray20);
        java.lang.String str24 = localizedFormats10.getSourceString();
        exceptionContext8.setValue("org.apache.commons.math.exception.NullArgumentException: input array", (java.lang.Object) str24);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getPrevious();
        int int32 = nonMonotonousSequenceException30.getIndex();
        int int33 = nonMonotonousSequenceException30.getIndex();
        boolean boolean34 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext35 = nonMonotonousSequenceException30.getContext();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException30.getDirection();
        exceptionContext8.setValue("org.apache.commons.math.exception.MathIllegalArgumentException: cannot discard a negative number of elements ({0})", (java.lang.Object) nonMonotonousSequenceException30);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 20304.80024943191d);
        exceptionContext8.setValue("maximal number of iterations ({0}) exceeded", (java.lang.Object) notStrictlyPositiveException40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        exceptionContext8.setValue("", (java.lang.Object) localizedFormats43);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "permutation size ({0}" + "'", str24.equals("permutation size ({0}"));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-1.0f) + "'", number31.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(exceptionContext35);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.3796077390275217d, 1.7453292519943295E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3796077390275217d + "'", double2 == 0.3796077390275217d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 52L, (double) 1.4E-45f);
        double double4 = regulaFalsiSolver3.getMin();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getRelativeAccuracy();
        double double7 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.401298464324817E-45d + "'", double7 == 1.401298464324817E-45d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(127L, 810528423927919297L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 810528423927919424L + "'", long2 == 810528423927919424L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 96549157373046875L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) (short) 100, 1073741824);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = nonMonotonousSequenceException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.6881171418161356E43d };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray11);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) (-1), (java.lang.Number) (-1L), true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        exceptionContext0.addMessage(localizable1, objArray9);
        java.lang.Object obj15 = exceptionContext0.getValue("identical abscissas x[{0}] == x[{1}] == {2} cause division by zero");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray26 = noBracketingException25.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException36 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray37 = noBracketingException36.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException38 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray37);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.NoBracketingException noBracketingException45 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double46 = noBracketingException45.getFHi();
        java.lang.Throwable[] throwableArray47 = noBracketingException45.getSuppressed();
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats40, (java.lang.Object[]) throwableArray47);
        java.util.Set<java.lang.String> strSet49 = exceptionContext0.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(strSet49);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.570796325948127d, (double) (-876644351), (double) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-99), 2920L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2920L + "'", long2 == 2920L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        try {
            int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (-1663522375));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.5244542151902893d), 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray6 = noBracketingException5.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray17);
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        java.lang.Object[] objArray22 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray21);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray13 = new double[] { 0.0d, (byte) -1 };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (byte) 1);
        double[] doubleArray19 = new double[] { 0.0d, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray19);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1074789439) + "'", int14 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074789439) + "'", int20 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.7506006346749412d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-1175191552));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1090117376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        java.lang.Throwable[] throwableArray6 = noBracketingException4.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = noBracketingException4.getContext();
        double double8 = noBracketingException4.getFHi();
        double double9 = noBracketingException4.getFHi();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 17.5f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.183300132670378d + "'", double1 == 4.183300132670378d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        java.lang.Throwable[] throwableArray6 = noBracketingException4.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = noBracketingException4.getContext();
        double double8 = noBracketingException4.getFHi();
        double double9 = noBracketingException4.getLo();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) (-0.0f), false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(33, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-23.9803919395796d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 980L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5704526841967397d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027409570086015828d + "'", double1 == 0.027409570086015828d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        float float2 = org.apache.commons.math.util.FastMath.scalb(0.0f, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(1.4711276648614138d, 0.0d, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 105L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.347130205683185d + "'", double1 == 5.347130205683185d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1 + "'", number2.equals(1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray5 = noBracketingException4.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException4.addSuppressed((java.lang.Throwable) nullArgumentException6);
        double double8 = noBracketingException4.getFHi();
        double double9 = noBracketingException4.getLo();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 110.0d, (double) 1090117376, 1.4711276743037347d, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray4);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 10);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray9);
        int[] intArray11 = new int[] {};
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray12);
        int[] intArray17 = new int[] { (-1) };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray17);
        try {
            int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        float[] floatArray5 = new float[] { 0.0f, 11L, 100, (-99L), 127L };
        float[] floatArray11 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray17 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray11);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((-21.783370351219997d), 32.01562118716424d, 1.073741824E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 96549157373046875L, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 31);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1, objArray4);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 20304.80024943191d, objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 0.0d, (byte) -1 };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = new double[] { 0.0d, (byte) -1 };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection11, false);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection11, false, true);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100.0d), (java.lang.Number) (-1.0f), 0);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        boolean boolean27 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection24, true, false);
        try {
            boolean boolean30 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection24, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1074789439) + "'", int4 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1074789439) + "'", int8 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0f) + "'", number23.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(51L, (long) 2920);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 148920L + "'", long2 == 148920L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-6), (float) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray4 = new double[] { 0.0d, (byte) -1 };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray4, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection8, false);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray14 = new double[] { 0.0d, (byte) -1 };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection18, false);
        double[][] doubleArray21 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray4, orderDirection18, doubleArray21);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection1.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1074789439) + "'", int5 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1074789439) + "'", int15 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        long long1 = org.apache.commons.math.util.MathUtils.sign(127L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 97, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078097E-7d + "'", double1 == 1.1920928955078097E-7d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1084715008);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.084715008E9d + "'", double1 == 1.084715008E9d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 4.440892098500626E-16d, (double) 3000, 1.7453292519943295E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-1.6676087455616045E9d), 120.0d, (-0.9999902065507035d), (double) 89L, (double) (byte) 0, (double) (byte) -1, 0.0d, 81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.0011304955639166E11d) + "'", double8 == (-2.0011304955639166E11d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 62, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.0E-14d, 3000.601674802533d, (double) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        java.lang.Throwable[] throwableArray6 = noBracketingException4.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = noBracketingException4.getContext();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(number8, (java.lang.Number) (-1.875861447621275E7d), false);
        java.lang.Number number12 = numberIsTooSmallException11.getMin();
        noBracketingException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.String str14 = numberIsTooSmallException11.toString();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.875861447621275E7d) + "'", number12.equals((-1.875861447621275E7d)));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-18,758,614.476)" + "'", str14.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-18,758,614.476)"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-1.6676087455616045E9d), 1.3169578969248166d, 30.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.299894094467163d + "'", double3 == 1.299894094467163d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 20.0d, 32.57837388740756d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 100, 31);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-0.99999994f), (-100.0d));
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((-1), univariateRealFunction5, 2.146959359E9d, 1.7467135528742547E19d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((-23.9803919395796d), (double) ' ', 2.2163925864078933d, (double) 1079574528);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.FastMath.log(55576.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.925506732372718d + "'", double1 == 10.925506732372718d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1073741824);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,073,741,824, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(11.000000953674316d, 0.0d, 101.00495037373169d, 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray8 = new double[] { 0.0d, (byte) -1 };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8, (int) (byte) 1);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray15 = new double[] { 0.0d, (byte) -1 };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray19 = new double[] { 0.0d, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection23, false);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection23, false, true);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray8);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 15.104412573075516d);
        double[] doubleArray37 = new double[] { 0.0d, (byte) -1 };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray41 = new double[] { 0.0d, (byte) -1 };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection45, false);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection45, false, true);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, (int) (byte) 1);
        double[] doubleArray55 = new double[] { 0.0d, (byte) -1 };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection59, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection59, false);
        double[] doubleArray66 = new double[] { 0.0d, (byte) -1 };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66, (int) (byte) 1);
        double[] doubleArray74 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray74);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray69);
        double[] doubleArray79 = new double[] { 0.0d, (byte) -1 };
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray79, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray79, orderDirection83, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection83, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection83, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection83, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-0 <= 15.104)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1074789439) + "'", int9 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1074789439) + "'", int16 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074789439) + "'", int20 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1074789439) + "'", int38 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1074789439) + "'", int42 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1074789439) + "'", int56 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1074789439) + "'", int67 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1074789439) + "'", int80 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1077936128, (float) 127L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet7 = exceptionContext6.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException10 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.0d);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) exceptionContext6, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException24 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray25 = noBracketingException24.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException26 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray25);
        java.lang.Object[] objArray30 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-0.9251475365964139d), 8.589934592E11d, (double) 127L, (double) Float.NaN, objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        long long2 = org.apache.commons.math.util.MathUtils.pow(51L, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2601L + "'", long2 == 2601L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1663522375));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,663,522,375");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.math.util.FastMath.copySign(32803.98024630548d, 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32803.98024630548d + "'", double2 == 32803.98024630548d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7576.061319933956d, (double) 33.0f, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 89L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 89.0f + "'", float1 == 89.0f);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { 0.0d, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection10, false);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection10, false, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray24 = new double[] { 0.0d, (byte) -1 };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection28, false);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection28, false, true);
        double[] doubleArray36 = new double[] { 0.0d, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection40, false);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray36);
        double double44 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray2, doubleArray20);
        double[] doubleArray47 = new double[] { 0.0d, (byte) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47, (int) (byte) 1);
        double[] doubleArray53 = new double[] { 0.0d, (byte) -1 };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection57, false);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection57, false, false);
        double[] doubleArray65 = new double[] { 0.0d, (byte) -1 };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double[] doubleArray69 = new double[] { 0.0d, (byte) -1 };
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray69, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection73, false);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection73, false, true);
        double[] doubleArray81 = new double[] { 0.0d, (byte) -1 };
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray81, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81, orderDirection85, false);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray81);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray65);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074789439) + "'", int7 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1074789439) + "'", int25 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1074789439) + "'", int37 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1074789439) + "'", int48 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1074789439) + "'", int54 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1074789439) + "'", int66 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1074789439) + "'", int70 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1074789439) + "'", int82 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.875861447621275E7d), 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.875861447621275E7d) + "'", double2 == (-1.875861447621275E7d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1073741824, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 1.1774215933195176d);
        double double3 = regulaFalsiSolver2.getStartValue();
        double double4 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1774215933195176d + "'", double4 == 1.1774215933195176d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        incrementor0.resetCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        incrementor0.setMaximalCount(5);
        incrementor0.incrementCount((-99));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray9 = new double[] { 0.0d, (byte) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray19 = new double[] { 0.0d, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray23 = new double[] { 0.0d, (byte) -1 };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection27, false);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection27, false, true);
        double[] doubleArray35 = new double[] { 0.0d, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray35, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection39, false);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray35);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray19);
        double[] doubleArray46 = new double[] { 0.0d, (byte) -1 };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray46, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection50, false);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray56 = new double[] { 0.0d, (byte) -1 };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray56, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection60, false);
        double[][] doubleArray63 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray46, orderDirection60, doubleArray63);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, doubleArray63);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray63);
        double[] doubleArray67 = null;
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1074789439) + "'", int10 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1074789439) + "'", int20 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1074789439) + "'", int24 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1074789439) + "'", int36 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1074789439) + "'", int47 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1074789439) + "'", int57 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double2 = org.apache.commons.math.util.FastMath.copySign(7.625350842618347d, 4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.625350842618347d + "'", double2 == 7.625350842618347d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { 0.0d, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection10, false);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection10, false, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection24, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection24, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[][] doubleArray30 = null;
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray29, doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074789439) + "'", int7 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3000, (-10), 1077936128);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,077,936,128, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 127L, (float) 33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-99L) + "'", long2 == (-99L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 52, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-99));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-99.0d) + "'", double1 == (-99.0d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(120L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.09265113173402188d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09265113173402188d + "'", double1 == 0.09265113173402188d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.6681005372000588d, (double) 2601L, 74.20994852478785d, 4.440892098500626E-16d, (double) 105L, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4338.729497257353d + "'", double6 == 4338.729497257353d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.999999f, (float) 30L, (float) (-1443336336));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(120.0d, 0.0d, 1.3169578969248166d, 0.0d, (-0.8390715290764524d), 1.0E-15d, (double) 2910L, 1.299894094467163d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3782.6918148994446d + "'", double8 == 3782.6918148994446d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5624631863547607d + "'", double1 == 1.5624631863547607d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray4);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray3);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray11);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int[] intArray17 = new int[] {};
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray16);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray20);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, 10);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, 33);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        try {
            int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 52L, (java.lang.Number) 100L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray7 = noBracketingException6.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = maxCountExceededException8.getContext();
        java.lang.Object obj11 = exceptionContext9.getValue("identical abscissas x[{0}] == x[{1}] == {2} cause division by zero");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.sinh(32.01562118716424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.010307002767892E13d + "'", double1 == 4.010307002767892E13d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 6, (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-6), 1073741824);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1078558720, (int) (short) 0);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 52L, (java.lang.Number) 100L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathInternalError7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray19);
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray19);
        exceptionContext10.addMessage(localizable11, objArray19);
        java.lang.Object obj25 = exceptionContext10.getValue("identical abscissas x[{0}] == x[{1}] == {2} cause division by zero");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray36 = noBracketingException35.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats27, (org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.NoBracketingException noBracketingException46 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray47 = noBracketingException46.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException48 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, (java.lang.Number) 1.1920929E-7f, (java.lang.Object[]) throwableArray47);
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.NoBracketingException noBracketingException55 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double56 = noBracketingException55.getFHi();
        java.lang.Throwable[] throwableArray57 = noBracketingException55.getSuppressed();
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats50, (java.lang.Object[]) throwableArray57);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray57);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray57);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1077936128, (-6L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        double double9 = noBracketingException8.getFHi();
        java.lang.Throwable[] throwableArray10 = noBracketingException8.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0747894415675313E9d), (java.lang.Object[]) throwableArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2910L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.78908123303499d + "'", double1 == 50.78908123303499d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2910.0061855604363d, 0.0d, 1.9867717342662445d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 30.0f, (-1.0d), (double) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(6.283185307179586d, (-0.6166950048277285d), 1320.729080665132d, 1940.424037772842d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2562770.5806992557d + "'", double4 == 2562770.5806992557d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        float float1 = org.apache.commons.math.util.FastMath.signum((-0.99999994f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 3000);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.4758800785707605E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 9.5367431640625E-6d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '4', (-99));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2910L, 111L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3021L + "'", long2 == 3021L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2920L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2920.0f + "'", float1 == 2920.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 810528423927919424L, (double) 970L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1180958720, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.1920928955078097E-7d, (double) (-1443336336), (double) 31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.7168146928204138d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-126.99999999999999d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (byte) 0, 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1663522375), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1663522375 + "'", int2 == 1663522375);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        long long2 = org.apache.commons.math.util.FastMath.max(2920L, 127L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2920L + "'", long2 == 2920L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 4.294967296E11d, (double) 30, 3.948148009134034E13d, (double) 'a', objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.exception.NotPositiveException notPositiveException12 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 74.20994852478785d);
        java.lang.Number number13 = notPositiveException12.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.0E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0E-14d + "'", double1 == 2.0E-14d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double2 = org.apache.commons.math.util.FastMath.atan2(62.26061319933956d, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0586703859635653d + "'", double2 == 1.0586703859635653d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 103.70899308565303d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.4210854715202004E-14d, 74.20321057778875d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4210854715202004E-14d + "'", double2 == 1.4210854715202004E-14d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 9.999999f, (-0.9957231823717526d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04276722260815746d + "'", double2 == 0.04276722260815746d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        float float2 = org.apache.commons.math.util.FastMath.max(17.5f, (float) (-6L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.5f + "'", float2 == 17.5f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6483608274590871d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 970, (java.lang.Number) 2.6881171418161356E43d, 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        int int5 = nonMonotonousSequenceException3.getIndex();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 33);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double[] doubleArray2 = new double[] { 0.0d, (byte) -1 };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 1);
        double[] doubleArray10 = new double[] { 1.0d, 100, 4.9E-324d, 1.2676506E31f };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray10);
        double[] doubleArray14 = new double[] { 0.0d, (byte) -1 };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, (int) (byte) 1);
        double[] doubleArray20 = new double[] { 0.0d, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray14);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1074789439) + "'", int3 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1074789439) + "'", int15 == (-1074789439));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1074789439) + "'", int21 == (-1074789439));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.00000038146972d + "'", double1 == 10.00000038146972d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-0.99999994f), (-100.0d));
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((int) (byte) 0, univariateRealFunction5, 20.0d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray5 = noBracketingException4.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException4.addSuppressed((java.lang.Throwable) nullArgumentException6);
        java.lang.Throwable[] throwableArray8 = noBracketingException4.getSuppressed();
        double double9 = noBracketingException4.getHi();
        double double10 = noBracketingException4.getHi();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 29.999998f);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 29.999998f + "'", number2.equals(29.999998f));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074789439), 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 431061953 + "'", int2 == 431061953);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0734796795E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), 10.0d, (double) 1, Double.NaN);
        java.lang.Throwable[] throwableArray5 = noBracketingException4.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException();
        noBracketingException4.addSuppressed((java.lang.Throwable) nullArgumentException6);
        java.lang.Throwable[] throwableArray8 = noBracketingException4.getSuppressed();
        double double9 = noBracketingException4.getFHi();
        double double10 = noBracketingException4.getLo();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 32L, (double) 0, (double) 1.07610125E9f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(1.2649867700545243E20d, 1940.424037772842d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.324933850272621E19d + "'", double2 == 6.324933850272621E19d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.6681005372000588d);
        java.lang.Number number2 = notPositiveException1.getMin();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 6L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        float[] floatArray5 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray11 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray18 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray24 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray24);
        float[] floatArray32 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray38 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray32);
        float[] floatArray46 = new float[] { 32, 5, ' ', 5, 520L };
        float[] floatArray52 = new float[] { ' ', (short) -1, 1, (-1.0f), (short) -1 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(floatArray46, floatArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray52);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }
}

