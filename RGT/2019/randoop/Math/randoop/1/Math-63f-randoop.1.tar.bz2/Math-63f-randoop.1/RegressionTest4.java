import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 3.41642467E8d, 38);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(116397953);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1242702720, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(302370689, 418768642);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2018720640L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4749192053464507d, (java.lang.Number) 13300L, 1074790410);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1074790410 + "'", int4 == 1074790410);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        java.lang.Class<?> wildcardClass21 = bigInteger19.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 74);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 341642467);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-341642467) + "'", int2 == (-341642467));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.16397952E8f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-116397952) + "'", int1 == (-116397952));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 133L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.532562594670797d + "'", double1 == 11.532562594670797d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 141.77799547179387d + "'", double55 == 141.77799547179387d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1024.3332248852191d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17314283987466264d) + "'", double1 == (-0.17314283987466264d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 38);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4948722204034305d, (java.lang.Number) bigInteger3, (-1064011892), orderDirection9, true);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 45L);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1074790267));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.074790267E9d) + "'", double1 == (-1.074790267E9d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (-0.857293145724863d));
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (5.473 >= 0.547)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1074790410L, 1072693280, 1242703820);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 295572686, 1820469732);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1162858593, (-1720744188));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7839146842102701d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1838.8549405050114d, 0, 640);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.178640283428287d + "'", double1 == 1.178640283428287d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-1242702872), (-341642467));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(7.120168601884164E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 266836.4405751989d + "'", double1 == 266836.4405751989d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        double double1 = org.apache.commons.math.util.FastMath.floor(7.5979151462512712E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.5979151462512712E18d + "'", double1 == 7.5979151462512712E18d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double2 = org.apache.commons.math.util.MathUtils.log(506.7491536931128d, 57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6500026477323836d + "'", double2 == 0.6500026477323836d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8687300863290184d, (-4.568868562981395E12d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8687300863290184d + "'", double2 == 0.8687300863290184d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.17192359791113349d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7435783372043163d + "'", double1 == 1.7435783372043163d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 7L, (float) 152);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int int1 = org.apache.commons.math.util.MathUtils.sign(51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 11.548739357257748d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray25);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray60 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray65 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double[] doubleArray72 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray72);
        double[] doubleArray80 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray85 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray85);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        double[] doubleArray92 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray92);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray92);
        java.lang.Class<?> wildcardClass95 = doubleArray92.getClass();
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 173.49639765712718d + "'", double13 == 173.49639765712718d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 116397953 + "'", int40 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 116397953 + "'", int51 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 141.77799547179387d + "'", double53 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 116397953 + "'", int67 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 116397953 + "'", int87 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(wildcardClass95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-11013.232874703393d), (-1.074790267E9d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97L, (float) 66L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 66.0f + "'", float2 == 66.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, (float) (-341642467));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.41642464E8f) + "'", float2 == (-3.41642464E8f));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-0.7853087663494563d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(35, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.031814983519345d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3656472477812869d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 710262581, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.102625809999999E8d + "'", double2 == 7.102625809999999E8d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1632.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.398174092970465d + "'", double1 == 7.398174092970465d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0000000000000002d, (java.lang.Number) 1072693248, (int) 'a', orderDirection7, true);
        java.lang.Number number11 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number11, (int) (byte) 0, orderDirection13, false);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.6931471805599455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(710262581L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 33.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.487270706090812E226d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.487270706090812E226d + "'", double1 == 1.487270706090812E226d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-7.787770769709087E-11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.78777076940584E-11d) + "'", double1 == (-7.78777076940584E-11d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double2 = org.apache.commons.math.util.FastMath.min((-2.0d), (double) 1078591488);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 453387264, 21213L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 453387264L + "'", long2 == 453387264L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double1 = org.apache.commons.math.util.FastMath.sin(167.6365115361209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.905306560614352d) + "'", double1 == (-0.905306560614352d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(74, (-3));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1820469732, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (-607999154));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-2147483648), (long) 2094612153);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52871495L) + "'", long2 == (-52871495L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        float float2 = org.apache.commons.math.util.FastMath.max(2.95572672E8f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2031527.5224316113d, 1074790267);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8656633798112165E-34d + "'", double2 == 1.8656633798112165E-34d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        int[] intArray3 = new int[] { (-22), 47, 1 };
        int[] intArray4 = null;
        try {
            int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.020244052626882576d, 94.52666381172618d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02024405262688258d + "'", double2 == 0.02024405262688258d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1074790410, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(66L, (long) 302370689);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-302370623L) + "'", long2 == (-302370623L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray19 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray39);
        double[] doubleArray48 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray53 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray53);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray60 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray60);
        double[] doubleArray68 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray73 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray73);
        double[] doubleArray81 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray86 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray81, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray81);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray81);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray53);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 116397953 + "'", int14 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 116397953 + "'", int55 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.0d + "'", double89 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 35, (long) (-2018720640));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2018720605L) + "'", long2 == (-2018720605L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9899924966004455d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9899924966004455d + "'", double1 == 0.9899924966004455d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-97), (java.lang.Number) 1.1639795300000001E8d, (int) (short) 1);
        java.lang.Number number5 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number5, (int) (byte) 0, orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        int int12 = nonMonotonousSequenceException9.getIndex();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-302370623L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 341642467L, (-7.1026259E8f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.1026259E8f) + "'", float2 == (-7.1026259E8f));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-100) + "'", number5.equals((-100)));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(20L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException8.getSuppressed();
        int int11 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1162858593, (java.lang.Number) 1072693248, 0, orderDirection12, true);
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException14.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 11.548739357257748d);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1820469732);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-97));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5604874136486533d) + "'", double1 == (-1.5604874136486533d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-10.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 900);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7805679417235972d), (java.lang.Number) 17689, (int) ' ');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 17689 + "'", number4.equals(17689));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 7L, 1.23145302310912E15d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.974179951488727E10d), (java.lang.Number) 17689, 710262581);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 295572686);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0747904E9d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747903999999998E9d) + "'", double2 == (-1.0747903999999998E9d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 453387264, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, (float) 7597915146251272194L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int int1 = org.apache.commons.math.util.MathUtils.sign(341642467);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double2 = org.apache.commons.math.util.MathUtils.round(32.000000000000014d, 900);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.000000000000014d + "'", double2 == 32.000000000000014d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        long long2 = org.apache.commons.math.util.MathUtils.pow(8027335024410855827L, 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1819345943120105235L + "'", long2 == 1819345943120105235L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-607999154), (float) 1164380801L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.0799917E8f) + "'", float2 == (-6.0799917E8f));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.755939655505084d, 35.09616477787495d, 110.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.3555855338155708E-4d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 608290459 + "'", int1 == 608290459);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', (float) (-710262581));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.1026259E8f) + "'", float2 == (-7.1026259E8f));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.64190874E9f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1074790400, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790398 + "'", int2 == 1074790398);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1.72074419E9f), 1.2278539698898954d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1072693248, 1242703820);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 33.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0732178989295803E14d + "'", double1 == 1.0732178989295803E14d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.6648555768512805d, (double) 38, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double1 = org.apache.commons.math.util.FastMath.asin(7.5979151462512712E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(409.5484705342973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.426230690260639d + "'", double1 == 7.426230690260639d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number13, (int) (byte) 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number23 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number23, (int) (byte) 0, orderDirection25, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        java.lang.Number number30 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number30, (int) (byte) 0, orderDirection32, false);
        java.lang.Number number35 = nonMonotonousSequenceException34.getPrevious();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException34.getSuppressed();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        java.lang.Number number39 = nonMonotonousSequenceException34.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNull(number39);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 20L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.999999999999996d + "'", double2 == 19.999999999999996d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 243L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1064011892));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963258550575d) + "'", double1 == (-1.5707963258550575d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.877921717308338d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1069449216), 418L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20319535104L + "'", long2 == 20319535104L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1578235263));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2018720639), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-22.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.792456423065796E9d) + "'", double1 == (-1.792456423065796E9d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException12.getDirection();
        java.lang.Number number17 = nonMonotonousSequenceException12.getArgument();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-0.15917453895486158d) + "'", number17.equals((-0.15917453895486158d)));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        long long2 = org.apache.commons.math.util.FastMath.min(6L, 900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 100, 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 145 + "'", int2 == 145);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1242702720));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0f, (java.lang.Number) 900L, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass5 = orderDirection4.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 2.078043828059135d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1578235263), 900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1578235263L) + "'", long2 == (-1578235263L));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 116397953 + "'", int28 == 116397953);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 141.77799547179387d + "'", double30 == 141.77799547179387d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        double double1 = org.apache.commons.math.util.FastMath.cos(5597.405020796463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6113049182617487d + "'", double1 == 0.6113049182617487d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.41642367E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9901695715836932d) + "'", double1 == (-0.9901695715836932d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 0, (float) 51);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-116397952), (-1064011892));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2533141373155001d, (java.lang.Number) 92.13617560368711d, 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5604874136486533d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(15369779672L, (-13300L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51104517409400L + "'", long2 == 51104517409400L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 110L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.4711276743037347d, 0.5265890341390445d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6613634479879071d) + "'", double2 == (-1.6613634479879071d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(302370689, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(6.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 297.6480476109054d + "'", double1 == 297.6480476109054d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 21213L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21213.000000000004d + "'", double1 == 21213.000000000004d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-2.66162738E18f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 36L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        double double1 = org.apache.commons.math.util.FastMath.abs(18907.607239317167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18907.607239317167d + "'", double1 == 18907.607239317167d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(101.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6535299896840334E43d + "'", double1 == 3.6535299896840334E43d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int int1 = org.apache.commons.math.util.MathUtils.sign(453387309);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 302370689);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.356194490192345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2108077399032076d + "'", double1 == 1.2108077399032076d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 0.0f, (double) 48L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.26548245743669d + "'", double2 == 50.26548245743669d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 8241.117982517473d);
        double[] doubleArray43 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray48 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray57 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray62 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray69 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray69);
        double[] doubleArray77 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray82 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray82);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        double[] doubleArray89 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray82);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray62);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray62);
        try {
            double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 116397953 + "'", int50 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 116397953 + "'", int64 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 116397953 + "'", int84 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1L, 2.109441930129002d, 1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.FastMath.ulp(6.283185307179585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.9999999999999998d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9999999999999996d) + "'", double1 == (-1.9999999999999996d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, (-1485));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        java.lang.Number number36 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number36, (int) (byte) 0, orderDirection38, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException40.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection41, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 10, (long) (-1069449216));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1069449206L) + "'", long2 == (-1069449206L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.8452701486440284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray32 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray37 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray32);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 11.548739357257748d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 682801173 + "'", int43 == 682801173);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(900, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800 + "'", int2 == 800);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2908163984051896177L, 66L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 25, (long) 900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.086736875163732d, 0.0d, 51);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 341642467);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.9604644775390625E-8d + "'", double1 == 5.9604644775390625E-8d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-13300L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 51);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 1164380801);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (short) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 38);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 116397953);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (short) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 38);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) (short) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 38);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 51);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger42);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger43);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) (short) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 38);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 116397953);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (int) (short) 0);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1435802341, 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5980471570853250659L) + "'", long2 == (-5980471570853250659L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.2194330274671845E142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 327.1654692242942d + "'", double1 == 327.1654692242942d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.4033482475752073d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 21213L, (float) (-45));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-45.0f) + "'", float2 == (-45.0f));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0000000000000002d, (java.lang.Number) 1072693248, (int) 'a', orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-52871495L), 7.398174092970465d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.398174092970465d + "'", double2 == 7.398174092970465d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.2427038200439E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1075.1173681246125d + "'", double1 == 1075.1173681246125d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.7306508020759848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.91074756146761d + "'", double1 == 2.91074756146761d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray44 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray39);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        java.lang.Class<?> wildcardClass49 = doubleArray11.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.726092576980591d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 112.853732430691d + "'", double1 == 112.853732430691d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1043341504));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1043341504) + "'", int2 == (-1043341504));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 11.548739357257748d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray25);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        java.lang.Class<?> wildcardClass55 = doubleArray25.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 173.49639765712718d + "'", double13 == 173.49639765712718d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 116397953 + "'", int40 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 116397953 + "'", int51 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 141.77799547179387d + "'", double53 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 141.77799547179387d + "'", double54 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 33L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 33L + "'", long1 == 33L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-6.1047587092169766E-217d), 0.587817631806982d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3917569530000002E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.422185261053766d + "'", double1 == 1.422185261053766d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(45, (-1578235263));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 608290459, 2.993222846126381d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.079985864662049E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000041223072d + "'", double1 == 1.0000000041223072d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-302370623L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.20031662859868687d, 75.69015788066504d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2003166285986869d + "'", double2 == 0.2003166285986869d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.2194330274671845E142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1042794154864902E71d + "'", double1 == 1.1042794154864902E71d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-116397952), (-1578235263));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double[] doubleArray6 = new double[] { 101.0d, 6.283185307179586d, 1.1639795299999999E8d, 341642467L, 6.708203932499369d, 0.4948722204034305d };
        double[] doubleArray13 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray18 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray32);
        double[] doubleArray69 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray74 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray81 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray81);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 116397953 + "'", int20 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 116397953 + "'", int76 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1391756953) + "'", int85 == (-1391756953));
        org.junit.Assert.assertNotNull(doubleArray87);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.851910962E9d), (double) (-1851910911));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8519109117345176E9d) + "'", double2 == (-1.8519109117345176E9d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(682801173);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10, (double) (-3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-35), 1.0732178989295803E14d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.4540791532345779d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.471338398704413d) + "'", double1 == (-0.471338398704413d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-909337683));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 11.548739357257748d);
        try {
            double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 141.77799547179387d + "'", double35 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1074790267));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.074790268E9d) + "'", double1 == (-1.074790268E9d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(22631.853901740316d, 665.4996243425998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 665.8380678404828d + "'", double2 == 665.8380678404828d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4677992676220697d + "'", double1 == 1.4677992676220697d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Number number9 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number9, (int) (byte) 0, orderDirection11, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number15 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-0.15917453895486158d) + "'", number15.equals((-0.15917453895486158d)));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0174532925199433d + "'", double1 == 0.0174532925199433d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (short) 0, (double) 427L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1242702872), (-3245L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        double double1 = org.apache.commons.math.util.FastMath.cos(1075.1170220543652d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7697579016774339d + "'", double1 == 0.7697579016774339d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1242703820, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2147483648), 341642367);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5403405080349111d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        double double2 = org.apache.commons.math.util.MathUtils.log((-3.0149892708730254E-39d), 22631.853901740316d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 40.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.117214930923896d) + "'", double1 == (-1.117214930923896d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 1242703854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242703854 + "'", int2 == 1242703854);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.164380801E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.87545528223847d + "'", double1 == 20.87545528223847d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.1d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.021856742157335d + "'", double1 == 4.021856742157335d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.8731185927656904E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number13, (int) (byte) 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number23 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number23, (int) (byte) 0, orderDirection25, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        java.lang.Number number30 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number30, (int) (byte) 0, orderDirection32, false);
        java.lang.Number number35 = nonMonotonousSequenceException34.getPrevious();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException34.getSuppressed();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        java.lang.Class<?> wildcardClass39 = nonMonotonousSequenceException34.getClass();
        java.lang.String str40 = nonMonotonousSequenceException34.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str40.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 51);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.99822295029797d) + "'", double1 == (-2.99822295029797d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.6401443394691997d, 682801173, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1.72074419E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1463113874);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1463113874 + "'", int2 == 1463113874);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1125L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2021600L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double[] doubleArray46 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray51 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray58 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray38);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 4.6897636623981E13d);
        double[] doubleArray71 = new double[] { 1.3383347192042695E42d, 0.6483608274590866d, 2, 1.7467135528742547E19d, 1330L, 0.8813735870195429d };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 116397953 + "'", int53 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.77799547179387d + "'", double61 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.3383347192042695E42d + "'", double72 == 1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1242702720, (-710262581));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(900, (-2018720640));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60 + "'", int2 == 60);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        java.lang.Number number60 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException64 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number60, (int) (byte) 0, orderDirection62, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = nonMonotonousSequenceException64.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException67 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 123, (java.lang.Number) 1884372829, (-1391756953), orderDirection65, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection65, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection65 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection65.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7805679417235972d), (java.lang.Number) 0.9999468636254574d, (int) (byte) 0);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-13300L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 11.548739357257748d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray25);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 1330.0000000000002d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (430.421 >= 430.421)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 173.49639765712718d + "'", double13 == 173.49639765712718d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 116397953 + "'", int40 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 116397953 + "'", int51 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2018720577 + "'", int53 == 2018720577);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0732178989295803E14d + "'", double1 == 1.0732178989295803E14d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-909337683), 123);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-3));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3L) + "'", long1 == (-3L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number24 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number25 = nonMonotonousSequenceException19.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-45) + "'", number23.equals((-45)));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-45) + "'", number24.equals((-45)));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-45) + "'", number25.equals((-45)));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-2021600L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 101, 0.16721748028765693d, 32.000000000000014d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        int int2 = org.apache.commons.math.util.FastMath.min((-2147483648), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2018720640), 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2018720792) + "'", int2 == (-2018720792));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        double double1 = org.apache.commons.math.util.FastMath.sinh(17689.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        float float2 = org.apache.commons.math.util.FastMath.min((-36.0f), (float) (-909337683));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.0933766E8f) + "'", float2 == (-9.0933766E8f));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number13, (int) (byte) 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number22 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-100) + "'", number22.equals((-100)));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1851910911), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1819345943120105235L, (long) 682801173);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1819345943802906408L + "'", long2 == 1819345943802906408L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1074790398, 17L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4898718957697105920L) + "'", long2 == (-4898718957697105920L));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.57079632386786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0232274761312345d + "'", double1 == 1.0232274761312345d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int2 = org.apache.commons.math.util.FastMath.min(47, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1074790398);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1578235263), 21213L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5954861350322859903L) + "'", long2 == (-5954861350322859903L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-341642467));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray84 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray89 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray89);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray89);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 2.154434690031884d);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray95);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1391756953) + "'", int77 == (-1391756953));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 116397953 + "'", int91 == 116397953);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 2.154434690031884d + "'", double96 == 2.154434690031884d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(17689.0d, (double) 44L, 393600);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.16721748028765693d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16568455626439255d + "'", double2 == 0.16568455626439255d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-2018720792));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.118877057031384d) + "'", double1 == (-22.118877057031384d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-97));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-7.974179951488725E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 116397953L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10788.788300824148d + "'", double1 == 10788.788300824148d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-341642467));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9574671461537502E10d) + "'", double1 == (-1.9574671461537502E10d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8746265733841028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9904809706005997d + "'", double1 == 0.9904809706005997d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9904809706005997d, 0.0d, (double) (-26268165L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.0E10f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray13 = new int[] { 341642467 };
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int[] intArray30 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray36 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray36);
        java.lang.Class<?> wildcardClass41 = intArray36.getClass();
        int[] intArray46 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray52 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray52);
        int[] intArray58 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray64 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray64);
        int[] intArray71 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray77 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray71);
        try {
            int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 93.58952932887311d + "'", double37 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 133 + "'", int38 == 133);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.41642457E8d + "'", double39 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 93.58952932887311d + "'", double53 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 93.58952932887311d + "'", double65 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 133 + "'", int66 == 133);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 93.58952932887311d + "'", double78 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        double double2 = org.apache.commons.math.util.FastMath.min(0.3514963719953463d, 22631.853901740316d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3514963719953463d + "'", double2 == 0.3514963719953463d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 97.0d);
        double[] doubleArray36 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray41 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray48 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double[] doubleArray56 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray61 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray68 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray68);
        try {
            double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2018720577 + "'", int27 == 2018720577);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 116397953 + "'", int43 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116397953 + "'", int63 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.012025108203109165d, (double) 36L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.012025108203109166d + "'", double2 == 0.012025108203109166d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray20);
        double[] doubleArray34 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray39 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray39);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray59);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray39);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 40.0f);
        try {
            double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 141.77799547179387d + "'", double62 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        int int2 = org.apache.commons.math.util.FastMath.min(33, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 145, (-1.5707963267948966d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        int int2 = org.apache.commons.math.util.FastMath.min((-1851910962), (-116397954));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1851910962) + "'", int2 == (-1851910962));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(45, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 581202753, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1978765218L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        double double2 = org.apache.commons.math.util.FastMath.min(1.7467135528742547E19d, (double) 1164380801L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.164380801E9d + "'", double2 == 1.164380801E9d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 33.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0732178989295803E14d + "'", double1 == 1.0732178989295803E14d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.970291913552122d, (double) 1074790420L, 2.8080699495801755d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.3917569530000002E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(11.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1639795299999999E8d, (-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1639795299999997E8d + "'", double2 == 1.1639795299999997E8d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.4650066648966585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3818597918761964d + "'", double1 == 0.3818597918761964d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray13 = new int[] { 341642467 };
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int[] intArray30 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray36 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray36);
        int[] intArray42 = new int[] { 341642467 };
        int[] intArray47 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray53 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray53);
        int[] intArray59 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray65 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray65);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray65);
        int[] intArray70 = null;
        try {
            int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 93.58952932887311d + "'", double37 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 133 + "'", int38 == 133);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.41642457E8d + "'", double39 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 93.58952932887311d + "'", double54 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 93.58952932887311d + "'", double66 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 133 + "'", int67 == 133);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.41642457E8d + "'", double68 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        int int1 = org.apache.commons.math.util.FastMath.abs(581202753);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 581202753 + "'", int1 == 581202753);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(25, (-710262581));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-710262556) + "'", int2 == (-710262556));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-3L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 418.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number7, (int) (byte) 0, orderDirection9, false);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException11.getSuppressed();
        int int14 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1162858593, (java.lang.Number) 1072693248, 0, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 173.49639765712718d, (java.lang.Number) 1.4677992676220697d, 2094612153, orderDirection15, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        long long1 = org.apache.commons.math.util.FastMath.round(1432.3944878270581d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1432L + "'", long1 == 1432L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-5954861350322859903L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1074790400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-100L), (float) (-1069449206L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.06944922E9f) + "'", float2 == (-1.06944922E9f));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5440211108893698d + "'", double1 == 0.5440211108893698d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 38);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 47);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1632);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 2908163984051896177L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-710262556));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963253869666d) + "'", double1 == (-1.5707963253869666d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray42 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray47 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray56 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray61 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray68 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        double[] doubleArray76 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray81 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double[] doubleArray88 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray81, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray81);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray61);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray47);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 141.77799547179387d + "'", double35 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 116397953 + "'", int49 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116397953 + "'", int63 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 116397953 + "'", int83 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        long long1 = org.apache.commons.math.util.FastMath.round(0.33333333333333337d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.09677892484801823d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09647790358866054d) + "'", double1 == (-0.09647790358866054d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray32 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray37 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray32);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2018720577 + "'", int40 == 2018720577);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 167.6365115361209d + "'", double41 == 167.6365115361209d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.021856742157335d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11234892507244527d + "'", double2 == 0.11234892507244527d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.4195903379527587d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 11, (long) 145);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1595L + "'", long2 == 1595L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 295572686);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5158716.549663348d + "'", double1 == 5158716.549663348d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1064011892));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 302370689);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.26211304955879544d), (-34));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(409.5484705342973d, (double) (-4860L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.lang.Class<?> wildcardClass7 = bigInteger2.getClass();
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 38);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 116397953);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 38);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger17);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 38);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 51);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger27);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger27);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.8731185927656904E12d, (java.lang.Number) 0L, (-1391756953));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 5.149099138580496E65d, (-1578235263), orderDirection40, false);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        float float2 = org.apache.commons.math.util.FastMath.min(32.0f, (float) 48L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1242703820L, 4.6897636623981E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.689763662397892E13d + "'", double2 == 4.689763662397892E13d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 402.4287934927351d + "'", double1 == 402.4287934927351d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-7443739007964037119L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.4437388E18f + "'", float1 == 7.4437388E18f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.8080699495801755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.049010066246485226d + "'", double1 == 0.049010066246485226d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2018720792), (-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1242703820, (long) 1884372864);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2341717356397140480L + "'", long2 == 2341717356397140480L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        long long1 = org.apache.commons.math.util.FastMath.round(1.6081863851484017d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-100), (long) 682801173);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-68280117300L) + "'", long2 == (-68280117300L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 924.9995206073057d, (java.lang.Number) 1.1639795300000001E8d, 17689, orderDirection9, false);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 924.9995206073057d + "'", number12.equals(924.9995206073057d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(48L, (long) 453387264);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 453387264L + "'", long2 == 453387264L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2018720640));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2018720640 + "'", int1 == 2018720640);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.950000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 141.174963921477d + "'", double1 == 141.174963921477d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1242702720));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1242702720 + "'", int1 == 1242702720);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 682801173, (long) (-1064011892));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1064011892L) + "'", long2 == (-1064011892L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        double[] doubleArray6 = new double[] { 101.0d, 6.283185307179586d, 1.1639795299999999E8d, 341642467L, 6.708203932499369d, 0.4948722204034305d };
        double[] doubleArray13 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray18 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray32);
        double[] doubleArray69 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray74 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray81 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray81);
        java.lang.Number number89 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number89, (int) (byte) 0, orderDirection91, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection94 = nonMonotonousSequenceException93.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException96 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 924.9995206073057d, (java.lang.Number) 1.1639795300000001E8d, 17689, orderDirection94, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection94, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (101 >= 6.283)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 116397953 + "'", int20 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 116397953 + "'", int76 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection94 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection94.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7663241025761744d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0556403733611195d + "'", double1 == 1.0556403733611195d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.159898775761099d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7515641543894818d + "'", double1 == 1.7515641543894818d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 97, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray45);
        double[] doubleArray61 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray66 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        double[] doubleArray74 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray79 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray74);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 97.0d);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2018720577 + "'", int82 == 2018720577);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 127.0875471693886d + "'", double85 == 127.0875471693886d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-607999154), 38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-10), 1075.1170220543652d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.0d) + "'", double2 == (-10.0d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-17L), (long) 900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7166263576043864511L) + "'", long2 == (-7166263576043864511L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        double double1 = org.apache.commons.math.util.FastMath.exp(21213.000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double double1 = org.apache.commons.math.util.FastMath.atanh(114.59155902616465d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        long long2 = org.apache.commons.math.util.MathUtils.pow(44L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.02024405262688258d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02024405262688258d + "'", double1 == 0.02024405262688258d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1064011892));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1064011892 + "'", int1 == 1064011892);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int2 = org.apache.commons.math.util.FastMath.min(152, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        long long2 = org.apache.commons.math.util.FastMath.min(116397952L, (long) 1884372864);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 116397952L + "'", long2 == 116397952L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 7597915146251272192L, (-5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number5 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number5, (int) (byte) 0, orderDirection7, false);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Class<?> wildcardClass14 = throwableArray13.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        double double1 = org.apache.commons.math.util.FastMath.tanh(35.09616477787495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        java.lang.Class<?> wildcardClass21 = bigInteger19.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 133, 33L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4389L + "'", long2 == 4389L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        double double1 = org.apache.commons.math.util.FastMath.rint(1432.3944878270581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1432.0d + "'", double1 == 1432.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 1242703820);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.24270387E9f + "'", float2 == 1.24270387E9f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.668093098623077E43d, 0.9999999958776928d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int[] intArray28 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray34 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray34);
        int[] intArray38 = new int[] { 341642467 };
        int[] intArray43 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray49 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int[] intArray55 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray61 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray61);
        java.lang.Class<?> wildcardClass65 = intArray61.getClass();
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray61);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray61);
        int[] intArray72 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray78 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray78);
        int[] intArray84 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray90 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray84, intArray90);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray72, intArray90);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray90);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 93.58952932887311d + "'", double35 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 133 + "'", int36 == 133);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 93.58952932887311d + "'", double50 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 93.58952932887311d + "'", double62 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 133 + "'", int63 == 133);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.41642457E8d + "'", double64 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 93.58952932887311d + "'", double79 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 93.58952932887311d + "'", double91 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 133 + "'", int92 == 133);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }
}

