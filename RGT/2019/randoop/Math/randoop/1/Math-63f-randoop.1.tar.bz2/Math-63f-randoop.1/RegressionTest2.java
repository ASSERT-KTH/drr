import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray44 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray49 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray49);
        double[] doubleArray57 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray62 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray57);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray57);
        double[] doubleArray67 = null;
        try {
            double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 116397953 + "'", int37 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2018720577 + "'", int65 == 2018720577);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1074790267), (-116397954));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, 104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 1435802341);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray11 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray11);
        int[] intArray14 = new int[] { 341642467 };
        int[] intArray19 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray25 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
        int[] intArray31 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray37 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray37);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray11);
        int[] intArray47 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray53 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray53);
        int[] intArray59 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray65 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray65);
        int[] intArray71 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray77 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray59, intArray77);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray59);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray47);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 93.58952932887311d + "'", double12 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 93.58952932887311d + "'", double26 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 93.58952932887311d + "'", double38 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 133 + "'", int39 == 133);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.41642457E8d + "'", double40 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 93.58952932887311d + "'", double54 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 93.58952932887311d + "'", double66 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 93.58952932887311d + "'", double78 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 133 + "'", int79 == 133);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        float float2 = org.apache.commons.math.util.FastMath.min(Float.NaN, 0.0f);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.8731185927656904E12d, (java.lang.Number) 0L, (-1391756953));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException40.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 141.77799547179387d + "'", double35 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-13300L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 34164246700L, (-1.5707963258644826d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.41642467E10d + "'", double2 == 3.41642467E10d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(10.197844452515683d, (double) 1125L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1122.3216438233026d + "'", double2 == 1122.3216438233026d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.6634392799796833d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8452701486440284d + "'", double1 == 1.8452701486440284d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(22631.853901740316d, (double) 0L, (double) 104);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1851910962), 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.3440585709080678E43d), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3440585709080678E43d) + "'", double2 == (-1.3440585709080678E43d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35, 1023.6665581008151d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 38);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-2018720577L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 295572686 + "'", int1 == 295572686);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-100.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 11L, 0.5265890341390445d, (-0.15917453895486158d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6931471805599454d, (java.lang.Number) 52, 38);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', (-22));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5430806348152437d, (double) (-45), 410.32277652693745d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 110, 0, (-1485));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6648555768512805d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7839146842102701d + "'", double1 == 0.7839146842102701d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 135L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double[] doubleArray6 = new double[] { 101.0d, 6.283185307179586d, 1.1639795299999999E8d, 341642467L, 6.708203932499369d, 0.4948722204034305d };
        double[] doubleArray13 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray18 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray32);
        double[] doubleArray69 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray74 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray81 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray81);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (101 >= 6.283)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 116397953 + "'", int20 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 116397953 + "'", int76 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1641908722 + "'", int85 == 1641908722);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        float float1 = org.apache.commons.math.util.MathUtils.sign(10.1f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.419937735994375E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.714246622624574E38d + "'", double1 == 7.714246622624574E38d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2427038200439E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(100, (long) (-2));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double[] doubleArray82 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray87 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray94 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray67);
        double[] doubleArray99 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (-7.974179951488727E10d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 116397953 + "'", int89 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 48L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6401443394691997d) + "'", double1 == (-0.6401443394691997d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1641908722);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.64190874E9f + "'", float1 == 1.64190874E9f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 17689);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 17689.0f + "'", float1 == 17689.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-97));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8066624897703196d + "'", double1 == 3.8066624897703196d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1330L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-3245L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.26211304955879544d) + "'", double1 == (-0.26211304955879544d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.3514963719953463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4540791532345779d) + "'", double1 == (-0.4540791532345779d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-1720744188));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 123);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2018720577L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2018720640) + "'", int1 == (-2018720640));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int1 = org.apache.commons.math.util.MathUtils.sign(116397953);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 45L, (double) (-2018720640));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17453292519943295d) + "'", double1 == (-0.17453292519943295d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1074790400);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0747904E9d + "'", double1 == 1.0747904E9d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8020054536586982d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44842875866404064d + "'", double1 == 0.44842875866404064d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1632);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1074790410, (long) (-10));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790400L + "'", long2 == 1074790400L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.4948722204034305d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.8452701486440284d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9226350743220142d + "'", double2 == 0.9226350743220142d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.math.util.FastMath.min(341642467, 1435802341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341642467 + "'", int2 == 341642467);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 10, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1242703720L, 58.003605222980525d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 58.003605222980525d + "'", double2 == 58.003605222980525d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-45), (-1074790267));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-22));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) ' ', (-0.6401443394691997d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int2 = org.apache.commons.math.util.FastMath.max(295572686, 3200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 295572686 + "'", int2 == 295572686);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 11L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1641908722);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray29 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray35 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray29);
        int[] intArray38 = null;
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 93.58952932887311d + "'", double36 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 17689.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 133.0d + "'", double1 == 133.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.signum(173.49639765712718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.538918511081545d, 1.755939655505084d, 0.6d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        long long1 = org.apache.commons.math.util.FastMath.abs(133L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 133L + "'", long1 == 133L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.7306508020759848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999546000702375d) + "'", double1 == (-0.9999546000702375d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.FastMath.min(10445.438196338302d, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-100.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 295572686);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.95572672E8f + "'", float1 == 2.95572672E8f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.6634392799796833d, 25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6634392799796833d + "'", double2 == 2.6634392799796833d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-7.974179951488727E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.974179951488725E10d) + "'", double1 == (-7.974179951488725E10d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6931471805599454d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01209770050168668d + "'", double1 == 0.01209770050168668d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1074790400L, (int) (short) 1, 1641908722);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 133L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 133.0d + "'", double1 == 133.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.14893343620557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3989675083974022d + "'", double1 == 1.3989675083974022d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9442097121712444d, (double) 110);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-2018720477L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.018720477E9d) + "'", double1 == (-2.018720477E9d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) 116397953);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.6321205588285577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-35L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1069449216) + "'", int1 == (-1069449216));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(341642367, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341642367 + "'", int2 == 341642367);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1064011892), (-1851910962));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.17452218322646063d), 93.58952932887311d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.acos(8.973782826130416E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5472863151975287d, 1.0937901169005635d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(51.00000000000001d, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3440585709080678E43d + "'", double2 == 1.3440585709080678E43d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(45, 1162858593);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.293235581474069E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.293235581474069E-9d + "'", double1 == 9.293235581474069E-9d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 74);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.602325267042627d + "'", double1 == 8.602325267042627d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { 341642467 };
        int[] intArray7 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray13 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray13);
        int[] intArray19 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray25 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray25);
        java.lang.Class<?> wildcardClass29 = intArray25.getClass();
        try {
            int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 93.58952932887311d + "'", double14 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 93.58952932887311d + "'", double26 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 133 + "'", int27 == 133);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.41642457E8d + "'", double28 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.asin(7.896296018268067E13d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.2250738585072014E-308d, (double) (short) 10, 1100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 7597915146251272192L, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.5979151462512712E18d + "'", double2 == 7.5979151462512712E18d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5729.0d, 0.16721748028765693d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2650001477823025d) + "'", double2 == (-1.2650001477823025d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 900, (-2), (-45));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.5265890341390445d, 1330);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5265890341390445d + "'", double2 == 0.5265890341390445d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(17689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1242703820L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.791759469228055d + "'", double1 == 1.791759469228055d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 341642367);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2018720640), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2018720640) + "'", int2 == (-2018720640));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(38, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4033482475752073d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099615d + "'", double1 == 5.916079783099615d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1884372829, 48L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1884372877L + "'", long2 == 1884372877L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6648555768512805d, (-710262581));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.547053763040636E60d + "'", double2 == 8.547053763040636E60d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-16.255619765854984d) + "'", double1 == (-16.255619765854984d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1074790400, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8417931547546046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3205243074936246d + "'", double1 == 1.3205243074936246d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1884372877L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1884372864 + "'", int1 == 1884372864);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.391756953E9d, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5314137165142955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009274919043434221d + "'", double1 == 0.009274919043434221d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1884372877L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998401122480931d + "'", double1 == 0.9998401122480931d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.41642467E8d, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707962975245309d + "'", double2 == 1.5707962975245309d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2661627379775963136L) + "'", long2 == (-2661627379775963136L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        float float1 = org.apache.commons.math.util.FastMath.abs(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 133, 1.487270706090812E226d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.487270706090812E226d + "'", double2 == 1.487270706090812E226d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1242703854);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.24270387E9f + "'", float1 == 1.24270387E9f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4719211491775512d + "'", double1 == 2.4719211491775512d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 33, (-1720744188));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray84 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray89 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray89);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray89);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray89);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1391756953) + "'", int77 == (-1391756953));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 116397953 + "'", int91 == 116397953);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double2 = org.apache.commons.math.util.MathUtils.log(9.332621544395286E157d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4129651365067377d + "'", double1 == 1.4129651365067377d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 133, (-1851910962), 341642467);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int2 = org.apache.commons.math.util.MathUtils.pow(38, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 453387264 + "'", int2 == 453387264);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.20031662859868687d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.477297384994364d + "'", double1 == 11.477297384994364d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1632.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2127201544178425d + "'", double1 == 3.2127201544178425d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int1 = org.apache.commons.math.util.FastMath.abs(1242703854);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1242703854 + "'", int1 == 1242703854);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        long long2 = org.apache.commons.math.util.FastMath.min((-35L), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1391756953), (float) (-33L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-33.0f) + "'", float2 == (-33.0f));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.tanh(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(506.7491536931128d, 410.323d, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52, (float) 10000000000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0E10f + "'", float2 == 1.0E10f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(135L, (long) 1164380801);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1164380936L + "'", long2 == 1164380936L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.math.util.FastMath.max(295572686, (-1069449216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 295572686 + "'", int2 == 295572686);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10000000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.cos(155327.58075060102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5761614954794603d + "'", double1 == 0.5761614954794603d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.419937735994375E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.100000381469727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7805679417235972d) + "'", double1 == (-0.7805679417235972d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1851910962L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.851910962E9d) + "'", double1 == (-1.851910962E9d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1164380936L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 38);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1435802341);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 330L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-100L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1884372829);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5604874136486533d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5604874136486533d + "'", double2 == 1.5604874136486533d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1100 + "'", int1 == 1100);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection34, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (133 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.17453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1727820635163638d) + "'", double1 == (-0.1727820635163638d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1330.0000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.193685818395112d + "'", double1 == 7.193685818395112d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.acos(22631.853901740316d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.1733711779497936d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7450479860810146d + "'", double1 == 1.7450479860810146d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(3200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(173.49639765712718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 173.4963976571272d + "'", double1 == 173.4963976571272d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.20031662859868687d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2003166285986869d + "'", double1 == 0.2003166285986869d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5314137165142955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.587817631806982d + "'", double1 == 0.587817631806982d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.159898775761099d + "'", double1 == 1.159898775761099d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 295572686, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15369779672L + "'", long2 == 15369779672L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 110);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(48L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (short) 0, 35, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-116397954));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 341642467, (-45));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Number number11 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5440211108893698d), (java.lang.Number) 0.0d, 3, orderDirection12, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-0.15917453895486158d) + "'", number11.equals((-0.15917453895486158d)));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double2 = org.apache.commons.math.util.FastMath.pow(22631.853901740316d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3.141592653589793d, (-1851910962), 1632);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { 341642467 };
        int[] intArray7 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray13 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray13);
        int[] intArray19 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray25 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray25);
        try {
            int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 93.58952932887311d + "'", double14 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 93.58952932887311d + "'", double26 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 133 + "'", int27 == 133);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.41642457E8d + "'", double28 == 3.41642457E8d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1072693248, 116397953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(7597915146251272192L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7597915146251272192L + "'", long2 == 7597915146251272192L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1641908722, (double) 341642367);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3656472477812869d + "'", double2 == 1.3656472477812869d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.1727820635163638d), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.787637788602359d) + "'", double2 == (-5.787637788602359d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-10.0d), (java.lang.Number) 1330, (int) (byte) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1,330 >= -10)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1,330 >= -10)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1720744188));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.193685818395112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8569514662435544d + "'", double1 == 0.8569514662435544d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(6607.792551685291d, (-7.787770769709087E-11d), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.15917453895486158d) + "'", number7.equals((-0.15917453895486158d)));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.6195157923977364d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-607999154) + "'", int1 == (-607999154));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.41642467E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        long long1 = org.apache.commons.math.util.MathUtils.sign(10000000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int1 = org.apache.commons.math.util.FastMath.abs(45);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 45 + "'", int1 == 45);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 1074790400);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790400L + "'", long2 == 1074790400L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double1 = org.apache.commons.math.util.FastMath.tan((-2.426324808873483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8687300863290184d + "'", double1 == 0.8687300863290184d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1884372864, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1391756953), 1242703820, (-2018720640));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray13 = new int[] { 341642467 };
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int[] intArray30 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray36 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray36);
        int[] intArray45 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray51 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray51);
        int[] intArray57 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray63 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray63);
        int[] intArray69 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray75 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray57);
        try {
            int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 93.58952932887311d + "'", double37 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 133 + "'", int38 == 133);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.41642457E8d + "'", double39 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 93.58952932887311d + "'", double52 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 93.58952932887311d + "'", double64 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 93.58952932887311d + "'", double76 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 133 + "'", int77 == 133);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.8080699495801755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray26 = new int[] { 341642467 };
        int[] intArray31 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray37 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int[] intArray43 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray49 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray49);
        int[] intArray57 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray63 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray63);
        int[] intArray69 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray75 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray75);
        int[] intArray81 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray87 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray87);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray69);
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray69);
        try {
            int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 93.58952932887311d + "'", double38 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 93.58952932887311d + "'", double50 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 133 + "'", int51 == 133);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.41642457E8d + "'", double52 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 93.58952932887311d + "'", double64 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 93.58952932887311d + "'", double76 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 93.58952932887311d + "'", double88 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 133 + "'", int89 == 133);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 3.41642367E8d + "'", double91 == 3.41642367E8d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100L, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5786501469438234d + "'", double2 == 1.5786501469438234d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double2 = org.apache.commons.math.util.FastMath.min(4.9E-324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray54 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray59 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray66 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray66);
        double[] doubleArray74 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray79 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray86 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray79);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray59);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass92 = orderDirection91.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection91, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 116397953 + "'", int61 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 116397953 + "'", int81 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass92);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 38, (long) (-22));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 418L + "'", long2 == 418L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.atanh(22025.465794806718d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (byte) -1, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5d) + "'", double2 == (-0.5d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double2 = org.apache.commons.math.util.FastMath.max(5.050000000000001d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.050000000000001d + "'", double2 == 5.050000000000001d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, 116397953);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-97), (java.lang.Number) 1.1639795300000001E8d, (int) (short) 1);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.098879754253295E-232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.098879754253295E-232d + "'", double1 == 4.098879754253295E-232d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-45));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-45.0d) + "'", double1 == (-45.0d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.950000000000001d + "'", double1 == 4.950000000000001d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, 1884372877L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1884372877L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 1242703854);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 110, 8027335024410855827L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.tanh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, (long) 1242703820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        long long1 = org.apache.commons.math.util.MathUtils.sign(15369779672L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 15369779672L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 110L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 110 + "'", int1 == 110);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.683317618811995E36d, (java.lang.Number) 9.332621544395287E157d, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double2 = org.apache.commons.math.util.FastMath.max(2578.3100780887044d, (double) 1125L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2578.3100780887044d + "'", double2 == 2578.3100780887044d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.9855683087099187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1074790410);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0937901169005635d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.5472863151975287d, 74, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.5472863151975287d + "'", double3 == 1.5472863151975287d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 0, (double) (-35L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int2 = org.apache.commons.math.util.FastMath.max((-1485), (-116397954));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1485) + "'", int2 == (-1485));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.6195157923977364d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        int int23 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(453387264, 38);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 654.4575736498787d + "'", double2 == 654.4575736498787d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.41642467E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.57079632386786d + "'", double1 == 1.57079632386786d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        long long2 = org.apache.commons.math.util.MathUtils.pow(48L, 2018720577);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        double[] doubleArray53 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray58 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray53);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 11.548739357257748d);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray40);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (133 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.15917453895486158d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.15850993369010735d) + "'", double1 == (-0.15850993369010735d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1820L + "'", long2 == 1820L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        int int2 = org.apache.commons.math.util.FastMath.min(116397953, 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, (long) 1242703820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 123, (double) 66L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.584941794290999E137d + "'", double2 == 8.584941794290999E137d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.5129738426669538d), 116397953);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0149892708730254E-39d) + "'", double2 == (-3.0149892708730254E-39d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double2 = org.apache.commons.math.util.FastMath.atan2(52.0d, (double) 1632.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03185196894184327d + "'", double2 == 0.03185196894184327d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1024.3332248852191d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 33);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.4195903379527587d), (-0.5d), 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-33L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.2075343299958265d) + "'", double1 == (-3.2075343299958265d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 17689, (long) 1074790410);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790410L + "'", long2 == 1074790410L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5729.0d, (-0.7853981633974483d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.26211304955879544d), 1.0299016745147208E166d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-17.89400457879299d) + "'", double1 == (-17.89400457879299d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1164380801);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1164380801L + "'", long1 == 1164380801L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1, 7.120168407330043E10d, (-5.487233297348662d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(38, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 51);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 35);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1639795300000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-5.787637788602359d), 1330);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.197246318314786E-216d) + "'", double2 == (-4.197246318314786E-216d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double[] doubleArray4 = new double[] { 1242703820, 10445.4381963383d, 45, (-0.5129738426669538d) };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        java.lang.Number number10 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number10, (int) (byte) 0, orderDirection12, false);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1470638038216647d, (java.lang.Number) 1074790410, 1632, orderDirection16, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection16, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1,242,703,820 >= 10,445.438)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2427038200439E9d + "'", double5 == 1.2427038200439E9d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1632, 17689);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-7.974179951488725E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.568868562981395E12d) + "'", double1 == (-4.568868562981395E12d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray20);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray20);
        double[] doubleArray35 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray40 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray47 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 116397953 + "'", int42 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2018720577, (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 581202753 + "'", int2 == 581202753);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(66L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double[] doubleArray82 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray87 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray94 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray67);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 116397953 + "'", int89 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-35L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-34.99999999999999d) + "'", double1 == (-34.99999999999999d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray54 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray59 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray66 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray66);
        double[] doubleArray74 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray79 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray86 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray79);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray59);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray45);
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 116397953 + "'", int61 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 116397953 + "'", int81 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 141.77799547179387d + "'", double91 == 141.77799547179387d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        long long2 = org.apache.commons.math.util.FastMath.min(66L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', (long) 74);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0000000000000004d + "'", double1 == 3.0000000000000004d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.acos(6607.792551685291d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double2 = org.apache.commons.math.util.MathUtils.round(5.69887449709238E-13d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        long long2 = org.apache.commons.math.util.FastMath.max(900L, (-2661627379775963136L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-116397954), 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1978765218 + "'", int2 == 1978765218);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 133L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-710262581), (-2));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.1026259E8f) + "'", float2 == (-7.1026259E8f));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.FastMath.signum(11.548739357257748d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray19 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray32);
        try {
            double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 116397953 + "'", int14 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5511210043331066E25d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1242703720L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.asinh(173.4963976571272d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.849312322216629d + "'", double1 == 5.849312322216629d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.5129738426669538d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4907704892567988d) + "'", double1 == (-0.4907704892567988d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int2 = org.apache.commons.math.util.FastMath.min((-36), 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-36) + "'", int2 == (-36));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10.0f, (double) 1391756953L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 100, 15369779672L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1536977967200L + "'", long2 == 1536977967200L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2533141373155001d, (java.lang.Number) 92.13617560368711d, 0);
        java.lang.Number number5 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number5, (int) (byte) 0, orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        int int12 = nonMonotonousSequenceException9.getIndex();
        boolean boolean13 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number15 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-0.15917453895486158d) + "'", number15.equals((-0.15917453895486158d)));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9899924966004455d) + "'", double1 == (-0.9899924966004455d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-13300L), (long) 152);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2021600L) + "'", long2 == (-2021600L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 341642467L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.6401443394691997d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6401443394691997d + "'", double1 == 0.6401443394691997d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5569432209472811d + "'", double1 == 0.5569432209472811d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int2 = org.apache.commons.math.util.MathUtils.pow(38, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 23L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 23L + "'", long1 == 23L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        long long1 = org.apache.commons.math.util.FastMath.abs(15369779672L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 15369779672L + "'", long1 == 15369779672L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-710262581), (float) 45L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.1026259E8f) + "'", float2 == (-7.1026259E8f));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.acos((-7.974179951488725E10d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double[] doubleArray4 = new double[] { 1242703820, 10445.4381963383d, 45, (-0.5129738426669538d) };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2427038200439E9d + "'", double5 == 1.2427038200439E9d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2427038200439E9d + "'", double6 == 1.2427038200439E9d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.5129738426669538d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.535769213919338d) + "'", double1 == (-0.535769213919338d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-10), 1164380801, 116397953);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 17689, 418L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2908163984051896177L + "'", long2 == 2908163984051896177L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray44 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray39);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5440211108893698d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray13 = new int[] { 341642467 };
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int[] intArray30 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray36 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray36);
        int[] intArray45 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray51 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray51);
        int[] intArray57 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray63 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray63);
        int[] intArray69 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray75 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray57);
        try {
            double double79 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 93.58952932887311d + "'", double37 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 133 + "'", int38 == 133);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.41642457E8d + "'", double39 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 93.58952932887311d + "'", double52 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 93.58952932887311d + "'", double64 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 93.58952932887311d + "'", double76 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 133 + "'", int77 == 133);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 100, 8027335024410855827L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8027335024410855727L) + "'", long2 == (-8027335024410855727L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(22026.465794806718d, 4.419937735994375E40d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1100, 1242703820);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1242702720) + "'", int2 == (-1242702720));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        try {
            java.lang.Class<?> wildcardClass9 = number8.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100L), (java.lang.Number) 52.0d, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.109441930129002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.182472559217436d + "'", double1 == 4.182472559217436d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1072693248L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.849312322216629d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-100L), 45, (-1720744188));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.7649716428696172d, 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.0732178989295803E14d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0732178989295803E14d + "'", double2 == 1.0732178989295803E14d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-7.1026259E8f), 0, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1242703820);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.24270382E9d + "'", double1 == 1.24270382E9d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int int1 = org.apache.commons.math.util.FastMath.abs((-710262581));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 710262581 + "'", int1 == 710262581);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1435802341, (-1242702720));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1632, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21216 + "'", int2 == 21216);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(48L, (long) (-45));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 33, 8027335024410855827L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5943824120834121313L + "'", long2 == 5943824120834121313L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int[] intArray1 = new int[] { 341642467 };
        int[] intArray6 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray12 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray12);
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray24);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray24);
        int[] intArray32 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray38 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray38);
        int[] intArray44 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray50 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray50);
        int[] intArray56 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray62 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray44);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray44);
        int[] intArray67 = null;
        try {
            int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 93.58952932887311d + "'", double13 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 133 + "'", int26 == 133);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.41642457E8d + "'", double27 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 93.58952932887311d + "'", double39 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 93.58952932887311d + "'", double51 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 93.58952932887311d + "'", double63 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 133 + "'", int64 == 133);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 3.41642367E8d + "'", double66 == 3.41642367E8d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-8027335024410855727L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.849312322216629d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.924148256317348d + "'", double1 == 1.924148256317348d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1330L, (-2018720477L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2018719147L) + "'", long2 == (-2018719147L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.5707963258644826d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1242702720));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1720744188), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.72074419E9f) + "'", float2 == (-1.72074419E9f));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.2427038200000002E9d, 6.38905609893065d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.726092576980591d + "'", double2 == 4.726092576980591d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.302585092994046d + "'", double2 == 2.302585092994046d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 341642467L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3) + "'", int2 == (-3));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.5314137165142955d, 17689);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.148539621088837E-224d) + "'", double2 == (-1.148539621088837E-224d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 33, (long) 133);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4131591025766d + "'", double1 == 148.4131591025766d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double3 = org.apache.commons.math.util.MathUtils.round(7.8962960182681E13d, (-34), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1884372864);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.05000808490679d + "'", double1 == 22.05000808490679d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(7597915146251272192L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7597915146251272194L + "'", long2 == 7597915146251272194L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(2, 74);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.109441930129002d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1463113874 + "'", int1 == 1463113874);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3200, (-2018720640), (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1632, (long) 51);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1242702720), (-1242702720));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242702720 + "'", int2 == 1242702720);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-36), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 45L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1391756953L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1463113874);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int int2 = org.apache.commons.math.util.FastMath.max((-2018720640), (-2018720640));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2018720640) + "'", int2 == (-2018720640));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-2018719147L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.018719147E9d) + "'", double1 == (-2.018719147E9d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        long long1 = org.apache.commons.math.util.FastMath.abs(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-100), (-1242702720));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242702620 + "'", int2 == 1242702620);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-45.0d), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-45.0d) + "'", double2 == (-45.0d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1820L, (-2018720577L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3674071450140L) + "'", long2 == (-3674071450140L));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.391756953E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3917569530000002E9d + "'", double1 == 1.3917569530000002E9d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 152);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 152.0d + "'", double1 == 152.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', 1125L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1752582786134912493L) + "'", long2 == (-1752582786134912493L));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9226350743220142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03497003954460952d) + "'", double1 == (-0.03497003954460952d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 1, (-1242702720));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5511210043331066E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.19064567883508d + "'", double1 == 25.19064567883508d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray41 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray46 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray60 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double[] doubleArray67 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray67);
        double[] doubleArray75 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray80 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray80);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray87 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray80);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray60);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray60);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 116397953 + "'", int48 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 116397953 + "'", int62 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 116397953 + "'", int82 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1884372829, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(710262581, 1162858593);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0747904E9f + "'", float1 == 1.0747904E9f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5.849312322216629d, 1.159898775761099d, (double) (-1074790400));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2018719147L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0187191E9f + "'", float1 == 2.0187191E9f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(25, (-22));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1330, (-710262581));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-3674071450140L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int2 = org.apache.commons.math.util.FastMath.min((-1069449216), 21216);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1069449216) + "'", int2 == (-1069449216));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(123, 3200);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 1.0732178989295803E14d, 52, orderDirection9, false);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.0f + "'", number12.equals(1.0f));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double1 = org.apache.commons.math.util.FastMath.expm1(22.05000808490679d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.768745727000001E9d + "'", double1 == 3.768745727000001E9d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(453387264, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 453387264 + "'", int2 == 453387264);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.148539621088837E-224d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2908163984051896177L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1122.3216438233026d, 581202753, 341642367);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1391756953), (double) (-36), 11.548739357257748d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1330);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(6607.792551685291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.32773631566592d + "'", double1 == 115.32773631566592d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-3.2075343299958265d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05598203492917749d) + "'", double1 == (-0.05598203492917749d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1632, 1242703720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2028092471040L + "'", long2 == 2028092471040L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 51);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.math.BigInteger bigInteger21 = null;
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 3, (-1720744188));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5707963267948966d, 8.602325267042627d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.602325267042627d + "'", double2 == 8.602325267042627d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.4711276743037347d), 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4711276743037347d) + "'", double2 == (-1.4711276743037347d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-10.0d), (java.lang.Number) 1330, (int) (byte) 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1330 + "'", number5.equals(1330));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1069449216), 2018720577, 1463113874);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double1 = org.apache.commons.math.util.FastMath.sin(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.857293145724863d) + "'", double1 == (-0.857293145724863d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1485));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        float float3 = org.apache.commons.math.util.MathUtils.round((-100.0f), (-1074790267), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.NEGATIVE_INFINITY + "'", float3 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9092974268256817d) + "'", double1 == (-0.9092974268256817d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2028092471040L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(51, (-1851910962));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1851910911) + "'", int2 == (-1851910911));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int1 = org.apache.commons.math.util.MathUtils.sign(38);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int int2 = org.apache.commons.math.util.FastMath.max(295572686, 2018720577);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2018720577 + "'", int2 == 2018720577);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1074790410, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5529564587671496d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5569432209472811d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5907008138154553d + "'", double1 == 0.5907008138154553d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.8066624897703196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52, (-2147483648));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1480170323 + "'", int1 == 1480170323);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long1 = org.apache.commons.math.util.FastMath.round(7.193685818395112d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7L + "'", long1 == 7L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.57079632386786d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1820469732 + "'", int1 == 1820469732);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1242703820, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2925382975464931328L + "'", long2 == 2925382975464931328L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.14893343620557d, (java.lang.Number) 1884372829, (-710262581), orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.109441930129002d, (java.lang.Number) (-1.148539621088837E-224d), (-2018720640), orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-36), 135L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4860L) + "'", long2 == (-4860L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1069449216), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.8020054536586982d), Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8020054536586981d) + "'", double2 == (-0.8020054536586981d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9226350743220142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9605389499244755d + "'", double1 == 0.9605389499244755d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double1 = org.apache.commons.math.util.FastMath.log(5.849312322216629d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7663241025761744d + "'", double1 == 1.7663241025761744d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.2533141373155001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 116397954L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.622659904607587d) + "'", double1 == (-6.622659904607587d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int2 = org.apache.commons.math.util.FastMath.min(152, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3200L, (float) 1074790410);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3200.0f + "'", float2 == 3200.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.154434690031884d, (double) (-3), (double) 2018720577);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1485), (long) 17689);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-26268165L) + "'", long2 == (-26268165L));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(97, (-97));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int[] intArray1 = new int[] { 341642467 };
        int[] intArray6 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray12 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray12);
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray24);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray24);
        int[] intArray32 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray38 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray38);
        int[] intArray44 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray50 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray50);
        int[] intArray57 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray63 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray57);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray32);
        int[] intArray71 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray77 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray77);
        int[] intArray83 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray89 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray83, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray89);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray71);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 93.58952932887311d + "'", double13 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 133 + "'", int26 == 133);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.41642457E8d + "'", double27 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 93.58952932887311d + "'", double39 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 93.58952932887311d + "'", double51 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 133 + "'", int52 == 133);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 93.58952932887311d + "'", double64 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 341642367 + "'", int66 == 341642367);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 93.58952932887311d + "'", double78 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 93.58952932887311d + "'", double90 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 133 + "'", int91 == 133);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-116397954), (-2147483648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.924148256317348d, (double) 1100, 7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double[] doubleArray46 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray51 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray58 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray38);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 116397953 + "'", int53 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.77799547179387d + "'", double61 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 173.49639765712718d + "'", double63 == 173.49639765712718d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(341642367);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1242702720);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.668093098623077E43d + "'", double1 == 7.668093098623077E43d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1242703820);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 116397953);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 38);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 116397953);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 341642467, (int) '4', orderDirection14, true);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3200, 3.4934271057485095E19d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int2 = org.apache.commons.math.util.MathUtils.pow(341642467, 1632);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 302370689 + "'", int2 == 302370689);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 133, (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 243L + "'", long2 == 243L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.09677892484801823d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

