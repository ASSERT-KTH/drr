import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8655103306675352d + "'", double1 == 0.8655103306675352d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100L, (long) 341642467);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34164246700L + "'", long2 == 34164246700L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-34));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10445.4381963383d, (double) 34164246700L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10445.438196338302d + "'", double2 == 10445.438196338302d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.MathUtils.sign(7.896296018268069E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1242703820, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-34));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-34) + "'", int1 == (-34));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int[] intArray28 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray34 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray16);
        int[] intArray39 = new int[] { 341642467 };
        int[] intArray44 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray50 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray50);
        int[] intArray56 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray62 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray62);
        try {
            double double66 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 93.58952932887311d + "'", double35 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 133 + "'", int36 == 133);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 93.58952932887311d + "'", double51 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 93.58952932887311d + "'", double63 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 133 + "'", int64 == 133);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.41642457E8d + "'", double65 == 3.41642457E8d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-100), 330L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-36));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(123);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1125L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1125L + "'", long1 == 1125L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(133, 133);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17689 + "'", int2 == 17689);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52, (-1074790400));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        double[] doubleArray37 = null;
        try {
            double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1752011936438014d, 0.0d, 1.0E-34d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-45));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-45.0d) + "'", double1 == (-45.0d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6607.792551685291d + "'", double1 == 6607.792551685291d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) -1, 1632);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 110, (long) 116397953);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long2 = org.apache.commons.math.util.FastMath.min(3L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1632);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1125L, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1125.0d + "'", double2 == 1125.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.3978952727983707d, (double) 17689);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3555855379673048E-4d + "'", double2 == 1.3555855379673048E-4d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.283185307179586d, (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179585d + "'", double2 == 6.283185307179585d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math.util.FastMath.atan2(11.548739357257748d, (double) 1242703820L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.293235581474069E-9d + "'", double2 == 9.293235581474069E-9d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1242703820, (-34));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242703854 + "'", int2 == 1242703854);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(116397953, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116397953 + "'", int2 == 116397953);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6931471805599453d, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6931471805599454d + "'", double2 == 0.6931471805599454d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 52, 45L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5314137165142955d, 0.0d, 17689);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.3440585709080678E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 44L, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1391756953) + "'", int36 == (-1391756953));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.15917453895486158d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1884372829 + "'", int1 == 1884372829);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        long long2 = org.apache.commons.math.util.FastMath.max(52L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException12.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.4948722204034305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.354089627384433d + "'", double1 == 28.354089627384433d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 34164246700L, 52);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1074790410, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1736481776669303d) + "'", double1 == (-0.1736481776669303d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5129738426669538d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.109441930129002d + "'", double1 == 2.109441930129002d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 58.003605222980525d, (java.lang.Number) 22025.465794806718d, 52);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double[] doubleArray82 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray87 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray94 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray67);
        double double98 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 116397953 + "'", int89 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 141.77799547179387d + "'", double98 == 141.77799547179387d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 135L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.356194490192345d + "'", double1 == 2.356194490192345d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.1736481776669303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17192359791113349d) + "'", double1 == (-0.17192359791113349d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number13, (int) (byte) 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int22 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray6 = new double[] { 101.0d, 6.283185307179586d, 1.1639795299999999E8d, 341642467L, 6.708203932499369d, 0.4948722204034305d };
        double[] doubleArray13 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray18 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray32);
        double[] doubleArray69 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray74 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray81 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray81);
        double[] doubleArray85 = null;
        try {
            double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 116397953 + "'", int20 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 116397953 + "'", int76 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1391756953));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.974179951488727E10d) + "'", double1 == (-7.974179951488727E10d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-34));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(97.69314718055995d, 1.5604874136486533d, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '4', 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104 + "'", int2 == 104);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-97), (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1023.6665581008151d + "'", double1 == 1023.6665581008151d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (long) 116397953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1162858593 + "'", int2 == 1162858593);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1162858593, (long) 3200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3200L + "'", long2 == 3200L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.3288408966594203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963258644826d) + "'", double1 == (-1.5707963258644826d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100L, 1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1072693248, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776928d + "'", double1 == 0.9999999958776928d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(22025.465794806718d, 0.8417931547546046d, 1125.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 10, (int) ' ', 900);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        java.lang.Number number21 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number21, (int) (byte) 0, orderDirection23, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection23, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (133 > 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7467135528742547E19d + "'", double1 == 1.7467135528742547E19d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-34), (float) (-36));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-36.0f) + "'", float2 == (-36.0f));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 3.6535299896840334E43d, 1.0732178989295803E14d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(Double.NaN, 2.154434690031884d, 2.14893343620557d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1242703854, (-100));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.755939655505084d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8080699495801755d + "'", double1 == 2.8080699495801755d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int16 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.8080699495801755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-45), 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.708203932499369d, 4.419937735994375E40d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        double[] doubleArray37 = null;
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray37);
        java.lang.Number number43 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number43, (int) (byte) 0, orderDirection45, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = nonMonotonousSequenceException47.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 1.0732178989295803E14d, 52, orderDirection48, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection48, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.109441930129002d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3200L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3200 + "'", int1 == 3200);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1L), 1.16397953E8d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.1736481776669303d), (double) Float.NaN, 11.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 133L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 133L + "'", long2 == 133L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(17689, 17689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17689 + "'", int2 == 17689);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-45), 3200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3245L) + "'", long2 == (-3245L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(35, 341642467);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 45L, 7.896296018268069E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.69887449709238E-13d + "'", double2 == 5.69887449709238E-13d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1330, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1330L + "'", long2 == 1330L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(110);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 410.32277652693745d + "'", double1 == 410.32277652693745d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.17192359791113349d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1727820104094196d) + "'", double1 == (-0.1727820104094196d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1162858593);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math.util.MathUtils.round(410.32277652693745d, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 410.323d + "'", double2 == 410.323d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1242703820);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 0, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-45));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 3200);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 17L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 0, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790400 + "'", int2 == 1074790400);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-36), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.833336070820506d + "'", double1 == 11.833336070820506d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.33333333333333337d, (java.lang.Number) 410.32277652693745d, (int) (byte) -1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 17689);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 40.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-36));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        double[] doubleArray43 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray48 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray48);
        double[] doubleArray56 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray61 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray68 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116397953 + "'", int63 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 94.52666381172618d + "'", double71 == 94.52666381172618d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int1 = org.apache.commons.math.util.FastMath.abs(33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.math.util.FastMath.max((-36), 1242703854);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242703854 + "'", int2 == 1242703854);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(35.0d, 45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.23145302310912E15d + "'", double2 == 1.23145302310912E15d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.9E-324d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 0, (long) 900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1162858593);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6634392799796833d + "'", double1 == 2.6634392799796833d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-100));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(10445.438196338302d, (double) 1074790400);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0747904031127295E9d + "'", double2 == 1.0747904031127295E9d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray44 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray39);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException52.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection53, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 100, 0.9999999958776928d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1), 1884372829);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3288408966594203d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray29 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray35 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray29);
        int[] intArray39 = new int[] { 341642467 };
        int[] intArray44 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray50 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray50);
        int[] intArray56 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray62 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray62);
        try {
            double double66 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 93.58952932887311d + "'", double36 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 93.58952932887311d + "'", double51 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 93.58952932887311d + "'", double63 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 133 + "'", int64 == 133);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.41642457E8d + "'", double65 == 3.41642457E8d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11013.232874703393d) + "'", double1 == (-11013.232874703393d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 341642467);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray38 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray31);
        double[] doubleArray41 = null;
        try {
            double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 116397953 + "'", int33 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(97.0d, (-45));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7569058147491887E-12d + "'", double2 == 2.7569058147491887E-12d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 3200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray26 = new int[] { 341642467 };
        int[] intArray31 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray37 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int[] intArray43 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray49 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray49);
        try {
            double double53 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 93.58952932887311d + "'", double38 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 93.58952932887311d + "'", double50 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 133 + "'", int51 == 133);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.41642457E8d + "'", double52 == 3.41642457E8d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.FastMath.max(900, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 900 + "'", int2 == 900);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.154434690031884d, (double) (short) 0, 0.6931471805599454d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = org.apache.commons.math.util.FastMath.abs(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.16397953E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7649716428696172d, 0.9442097121712444d, 2.7569058147491887E-12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1074790400, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 924.9995206073057d + "'", double2 == 924.9995206073057d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1432.3944878270581d + "'", double1 == 1432.3944878270581d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.asin(6607.792551685291d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1639795300000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 135L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.130333768495006d + "'", double1 == 2.130333768495006d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 401.07045659157626d + "'", double1 == 401.07045659157626d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.419937735994375E40d, 410.323d, 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray19 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray40);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray40);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 116397953 + "'", int14 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 101.0d + "'", double48 == 101.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 116397953 + "'", int49 == 116397953);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 135L, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.2533141373155001d, (-22), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int[] intArray28 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray34 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray16);
        int[] intArray42 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray48 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray48);
        int[] intArray54 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray60 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray60);
        int[] intArray66 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray72 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray72);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray54);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray42);
        int[] intArray77 = null;
        try {
            int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 93.58952932887311d + "'", double35 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 133 + "'", int36 == 133);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 93.58952932887311d + "'", double49 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 93.58952932887311d + "'", double61 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 93.58952932887311d + "'", double73 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 133 + "'", int74 == 133);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.tan(11.548739357257748d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6195157923977364d) + "'", double1 == (-1.6195157923977364d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) -1, (long) (-1391756953));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1391756953L + "'", long2 == 1391756953L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double[] doubleArray82 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray87 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray94 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray67);
        int int98 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 116397953 + "'", int89 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 116397953 + "'", int98 == 116397953);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-34), 17L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7597915146251272192L + "'", long2 == 7597915146251272192L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 97, 0.0d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int2 = org.apache.commons.math.util.MathUtils.pow(116397953, 123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1164380801 + "'", int2 == 1164380801);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(97.69314718055995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5597.405020796463d + "'", double1 == 5597.405020796463d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 1.0732178989295803E14d, 52, orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 6L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(9.286355438117551d, (double) 1164380801);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.15917453895486158d) + "'", number8.equals((-0.15917453895486158d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9442097121712444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6648555768512805d + "'", double1 == 0.6648555768512805d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1391756953L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.391756953E9d + "'", double1 == 1.391756953E9d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.floor(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.0d + "'", double1 == 5729.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5403023058681398d, (double) 45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681398d + "'", double2 == 0.5403023058681398d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(25, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.6195157923977364d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.426324808873483d) + "'", double1 == (-2.426324808873483d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, (-97));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0732178989295803E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8731185927656904E12d + "'", double1 == 1.8731185927656904E12d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.8417931547546046d, 1330);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.1047587092169766E-217d) + "'", double2 == (-6.1047587092169766E-217d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-2.426324808873483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6195157923977364d) + "'", double1 == (-1.6195157923977364d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5265890341390445d + "'", double1 == 0.5265890341390445d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 341642467);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double2 = org.apache.commons.math.util.FastMath.atan2(10445.438196338302d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1102230246251565E-16d, (double) 17689, 17689);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 141.77799547179387d + "'", double77 == 141.77799547179387d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray25 = null;
        try {
            int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1162858593);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3514963719953463d + "'", double1 == 0.3514963719953463d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.9855683087099187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0937901169005635d + "'", double1 == 1.0937901169005635d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.tanh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.8962960182681E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.000000000000014d + "'", double1 == 32.000000000000014d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1242703854);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.120168601884164E10d + "'", double1 == 7.120168601884164E10d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22631.853901740316d + "'", double1 == 22631.853901740316d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.1736481776669303d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-10), (double) 45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.0d) + "'", double2 == (-10.0d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        float float1 = org.apache.commons.math.util.MathUtils.sign(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(36L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63025.35746439055d + "'", double1 == 63025.35746439055d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1074790400, (-22));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray44 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray39);
        double[] doubleArray54 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray59 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray59);
        double[] doubleArray67 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray72 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        double[] doubleArray79 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray79);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray59);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 116397953 + "'", int74 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 116397953 + "'", int83 == 116397953);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 116397953 + "'", int84 == 116397953);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1074790410, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        double[] doubleArray37 = null;
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection39, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str16 = nonMonotonousSequenceException12.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1242703820, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242703820 + "'", int2 == 1242703820);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395287E157d + "'", double1 == 9.332621544395287E157d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100, (long) 104);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-710262581));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(17689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int2 = org.apache.commons.math.util.FastMath.max(1074790410, 17689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790410 + "'", int2 == 1074790410);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1330L, 1.2064329653550159d, (double) 1.24270387E9f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.6195157923977364d), (double) 1.24270387E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3032193983521574E-9d) + "'", double2 == (-1.3032193983521574E-9d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1164380801);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.tan(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6893620967346508d) + "'", double1 == (-0.6893620967346508d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 2018720577);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1851910962) + "'", int1 == (-1851910962));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.6634392799796833d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int1 = org.apache.commons.math.util.FastMath.abs(38);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 38 + "'", int1 == 38);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int int2 = org.apache.commons.math.util.FastMath.max(25, 1164380801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1164380801 + "'", int2 == 1164380801);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { 341642467 };
        int[] intArray7 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray13 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray13);
        int[] intArray19 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray25 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray25);
        int[] intArray33 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray39 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray39);
        int[] intArray45 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray51 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray51);
        int[] intArray57 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray63 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray63);
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray63);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray45);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray45);
        try {
            int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 93.58952932887311d + "'", double14 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 93.58952932887311d + "'", double26 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 133 + "'", int27 == 133);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.41642457E8d + "'", double28 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 93.58952932887311d + "'", double40 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 93.58952932887311d + "'", double52 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 93.58952932887311d + "'", double64 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 133 + "'", int65 == 133);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 3.41642367E8d + "'", double67 == 3.41642367E8d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.4749192053464507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        float float2 = org.apache.commons.math.util.MathUtils.round(32.0f, 110);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        boolean boolean23 = nonMonotonousSequenceException19.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1330);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 11.548739357257748d);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray36 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray41 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray41);
        double[] doubleArray49 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray54 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray61 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 11.548739357257748d);
        double[] doubleArray67 = null;
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray67);
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 173.49639765712718d + "'", double29 == 173.49639765712718d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 116397953 + "'", int56 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 141.77799547179387d + "'", double64 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.2427038200439E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.120168407330043E10d + "'", double1 == 7.120168407330043E10d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-100));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5729.5779513082325d) + "'", double1 == (-5729.5779513082325d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1), (-0.09677892484801823d), (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.5055564237435929d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.16721748028765693d, (double) 1330);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2572742812523796E-4d + "'", double2 == 1.2572742812523796E-4d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection36, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not decreasing (10 < 44,199,377,359,943,750,000,000,000,000,000,000,000,000)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(3200, 17689);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 44L, (java.lang.Number) (-0.5440211108893698d), 0, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 40.0f, 2.7569058147491887E-12d, (double) (-3245L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-7.974179951488727E10d), (int) 'a', 341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.031814983519345d) + "'", double1 == (-1.031814983519345d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-33L), (-97));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int1 = org.apache.commons.math.util.FastMath.abs(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-100.0f), (double) 116397954L, 1.7467135528742547E19d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.9855683087099187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3085853819747226d + "'", double1 == 1.3085853819747226d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.1733711779497936d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray15 = new int[] { (-45), (short) 100, 1632 };
        try {
            int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.floor(5.69887449709238E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-34), (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int[] intArray28 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray34 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray34);
        try {
            int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 93.58952932887311d + "'", double35 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 133 + "'", int36 == 133);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.896296018268069E13d, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.896296018268067E13d + "'", double2 == 7.896296018268067E13d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0299016745147208E166d + "'", double1 == 1.0299016745147208E166d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int2 = org.apache.commons.math.util.FastMath.min(341642467, (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-36) + "'", int2 == (-36));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 45.0f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.0d + "'", double2 == 45.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1242703820, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1242703720L + "'", long2 == 1242703720L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 116397954L, (double) 100.0f, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1072693248, 330L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66L + "'", long2 == 66L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-100L), 10.197844452515683d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 13300L, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 0.0f, 1.1639795300000001E8d, (double) 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math.util.MathUtils.round((-5729.5779513082325d), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5729.5779513082325d) + "'", double2 == (-5729.5779513082325d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.683317618811995E36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 85.05446701758153d + "'", double1 == 85.05446701758153d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-22));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 100, (long) 2018720577);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2018720477L) + "'", long2 == (-2018720477L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0.0f, 7.120168601884164E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.120168601884164E10d + "'", double2 == 7.120168601884164E10d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3200L, (java.lang.Number) (byte) -1, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.4749192053464507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 116397953);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5975900424043384d + "'", double1 == 0.5975900424043384d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1072693248);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1072693248L + "'", long1 == 1072693248L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.007199254740992E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.007199254740992E15d + "'", double1 == 9.007199254740992E15d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.tanh(85.05446701758153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.538918511081545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9999999958776928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.079985864662049E-5d + "'", double1 == 9.079985864662049E-5d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1L, 7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.4948722204034305d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 506.7491536931128d + "'", double2 == 506.7491536931128d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(35L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 116397953);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 116397953L + "'", long1 == 116397953L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1074790400, 1884372829, 2018720577);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.5511210043331066E25d, (int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.5511210043331066E25d + "'", double3 == 1.5511210043331066E25d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.69887449709238E-13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1064011892) + "'", int1 == (-1064011892));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 133, (java.lang.Number) (byte) -1, (int) 'a');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4653893333223524d + "'", double1 == 2.4653893333223524d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.log(51.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9318256327243257d + "'", double1 == 3.9318256327243257d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0264848819015071E-4d + "'", double1 == 1.0264848819015071E-4d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7649716428696173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8746265733841028d + "'", double1 == 0.8746265733841028d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.acos(10.197844452515685d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 51);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4093490824269389E22d + "'", double1 == 1.4093490824269389E22d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1884372829, 104);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1838.8549405050114d + "'", double2 == 1838.8549405050114d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0299016745147208E166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-97), (java.lang.Number) 1.1639795300000001E8d, (int) (short) 1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(133, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790267) + "'", int2 == (-1074790267));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.6893620967346508d), 1.3862943611198906d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2018720477L), (double) 123, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 38);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.9855683087099187d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.atanh(22026.465794806718d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(3200, 1242703820);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1632, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 341642467, 900);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray38 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray38);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 116397953 + "'", int33 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.math.util.FastMath.max((-1851910962), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(33, (-45));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1485) + "'", int2 == (-1485));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 152);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int[] intArray6 = new int[] { (-1851910962), 1632, (-1391756953), 1242703854, 17689, 52 };
        int[] intArray7 = null;
        try {
            int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.6535299896840334E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.487233297348662d) + "'", double1 == (-5.487233297348662d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.8731185927656904E12d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1435802341 + "'", int1 == 1435802341);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-22));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008851309290403876d + "'", double1 == 0.008851309290403876d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 45);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 341642467, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 133, (double) (-100.0f), 506.7491536931128d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0264848819015071E-4d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1.0f), 1.4711276743037347d, (double) (-97));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 45.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4934271057485095E19d + "'", double1 == 3.4934271057485095E19d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 133L, 2.6634392799796833d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20031662859868687d + "'", double2 == 0.20031662859868687d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1162858593);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(8241.117982517473d, (-1074790267));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.973782826130416E43d + "'", double2 == 8.973782826130416E43d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 52, (-3245L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.031814983519345d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double2 = org.apache.commons.math.util.FastMath.atan2(97.0d, 1.7306508020759848d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5529564587671496d + "'", double2 == 1.5529564587671496d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 110L, 97, (int) (short) 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1632, 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1632.0f + "'", float2 == 1632.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass7 = throwableArray6.getClass();
        java.lang.Class<?> wildcardClass8 = throwableArray6.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-100), 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1164380801, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, 85.05446701758153d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.6535299896840334E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.0d + "'", double1 == 101.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2), 1072693248L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray13 = new int[] { 341642467 };
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int[] intArray30 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray36 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray36);
        java.lang.Class<?> wildcardClass41 = intArray36.getClass();
        int[] intArray46 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray52 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray52);
        int[] intArray55 = new int[] { 341642467 };
        int[] intArray60 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray66 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray66);
        int[] intArray72 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray78 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray78);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray78);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray78);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray52);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 93.58952932887311d + "'", double37 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 133 + "'", int38 == 133);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.41642457E8d + "'", double39 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 93.58952932887311d + "'", double53 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 93.58952932887311d + "'", double67 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 93.58952932887311d + "'", double79 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 133 + "'", int80 == 133);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 3.41642457E8d + "'", double81 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double[] doubleArray82 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray87 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray94 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray67);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 116397953 + "'", int89 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1162858593, (-45));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(17689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155327.58075060102d + "'", double1 == 155327.58075060102d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double2 = org.apache.commons.math.util.FastMath.atan2(85.05446701758153d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5472863151975287d + "'", double2 == 1.5472863151975287d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 116397953);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.1727820104094196d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17452218322646063d) + "'", double1 == (-0.17452218322646063d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int[] intArray28 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray34 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray16);
        int[] intArray42 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray48 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray48);
        int[] intArray54 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray60 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray42);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 93.58952932887311d + "'", double35 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 133 + "'", int36 == 133);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 93.58952932887311d + "'", double49 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 93.58952932887311d + "'", double61 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 133 + "'", int62 == 133);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 45);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2578.3100780887044d + "'", double1 == 2578.3100780887044d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-33L), 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-33.0d) + "'", double2 == (-33.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-710262581), (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 123, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray84 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray89 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray89);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray89);
        java.lang.Class<?> wildcardClass94 = doubleArray74.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1391756953) + "'", int77 == (-1391756953));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 116397953 + "'", int91 == 116397953);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(wildcardClass94);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(155327.58075060102d, (-1.4711276743037347d), 5.69887449709238E-13d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 2018720577);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1851910962));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 152);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.math.util.MathUtils.pow(38, 2018720577);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1330, (long) 3200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray44 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray39);
        double[] doubleArray54 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray59 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray59);
        double[] doubleArray67 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray72 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        double[] doubleArray79 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray79);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray59);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 116397953 + "'", int74 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(341642467, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1074790400), 1435802341);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int2 = org.apache.commons.math.util.FastMath.max(1884372829, 2018720577);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2018720577 + "'", int2 == 2018720577);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray63 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray68 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray68);
        double[] doubleArray76 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray81 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray76);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray76);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 116397953 + "'", int56 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2018720577 + "'", int84 == 2018720577);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 167.6365115361209d + "'", double85 == 167.6365115361209d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 116397953 + "'", int86 == 116397953);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 0);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1242703820);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(45, (-34));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4033482475752073d + "'", double1 == 1.4033482475752073d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.3514963719953463d, (double) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-307.6526555685888d) + "'", double1 == (-307.6526555685888d));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray41 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray46 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray60 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double[] doubleArray67 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray67);
        double[] doubleArray75 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray80 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray80);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray87 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray80);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray60);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray60);
        double[] doubleArray92 = null;
        try {
            double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 116397953 + "'", int48 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 116397953 + "'", int62 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 116397953 + "'", int82 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 10.1f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.100000381469727d + "'", double2 == 10.100000381469727d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4195903379527587d) + "'", double1 == (-0.4195903379527587d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1435802341, 34164246700L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double[] doubleArray53 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray58 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray65 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray58);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray38);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray76 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray81 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray81);
        double[] doubleArray89 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray94 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray89, doubleArray94);
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray89);
        int int97 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray89);
        boolean boolean99 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 116397953 + "'", int40 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 116397953 + "'", int60 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 2018720577 + "'", int97 == 2018720577);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 167.6365115361209d + "'", double98 == 167.6365115361209d);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        long long1 = org.apache.commons.math.util.FastMath.abs(1330L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1330L + "'", long1 == 1330L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.6195157923977364d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8020054536586982d) + "'", double1 == (-0.8020054536586982d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 116397954L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.7853087663494565d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853087663494563d) + "'", double1 == (-0.7853087663494563d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) -1, 1330);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 34164246700L, (float) 1884372829);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.88437286E9f + "'", float2 == 1.88437286E9f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9999999958776928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int2 = org.apache.commons.math.util.FastMath.min(17689, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1391756953L, (float) 1242703820);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.24270387E9f + "'", float2 == 1.24270387E9f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-45) + "'", number4.equals((-45)));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0299016745147208E166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0299016745147208E166d + "'", double1 == 1.0299016745147208E166d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1162858593);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.8080699495801755d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 116397953L, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.09616477787495d + "'", double2 == 35.09616477787495d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 116397953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 3L, 1435802341);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-22), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.120168601884164E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.120168601884164E10d + "'", double1 == 7.120168601884164E10d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int2 = org.apache.commons.math.util.FastMath.min(33, 900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.0d, 0.5403023058681398d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 45.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6532125137753437d + "'", double1 == 1.6532125137753437d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double2 = org.apache.commons.math.util.FastMath.min(63025.35746439055d, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195429d + "'", double2 == 0.8813735870195429d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int2 = org.apache.commons.math.util.FastMath.min(33, (-1064011892));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1064011892) + "'", int2 == (-1064011892));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.exp(5729.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.atan((-307.6526555685888d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.56754591936242d) + "'", double1 == (-1.56754591936242d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray18 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double[] doubleArray26 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray31 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray38 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray38);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        double[] doubleArray67 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray72 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray72);
        double[] doubleArray80 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray85 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray80);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray80);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray52);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection94 = nonMonotonousSequenceException93.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection95 = nonMonotonousSequenceException93.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection95, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 116397953 + "'", int33 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 101.0d + "'", double88 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + orderDirection94 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection94.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection95 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection95.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 10, (long) 38);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        int int1 = org.apache.commons.math.util.MathUtils.hash(93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1720744188) + "'", int1 == (-1720744188));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1470638038216647d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1851910962));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1851910962L) + "'", long1 == (-1851910962L));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.1639795299999999E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.197844452515683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0129108974696095d + "'", double1 == 3.0129108974696095d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.7067655527413216E89d, 97.69314718055995d, 100.00000000000001d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1884372829, (double) 1242703820L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long2 = org.apache.commons.math.util.MathUtils.pow(35L, 133);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8027335024410855827L + "'", long2 == 8027335024410855827L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1330, 1884372829);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.41642367E8d, 341642467);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.098879754253295E-232d + "'", double2 == 4.098879754253295E-232d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int2 = org.apache.commons.math.util.FastMath.min((-1074790400), 2018720577);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-100L), 133L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-13300L) + "'", long2 == (-13300L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6648555768512805d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8153867651926173d + "'", double1 == 0.8153867651926173d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

