import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 10, 1074790410L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790420L + "'", long2 == 1074790420L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.5707963258644826d), (double) (-2147483648), 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        long long2 = org.apache.commons.math.util.FastMath.max(900L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-34d, (java.lang.Number) 11.0f, (-1064011892));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.acos(924.9995206073057d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.109441930129002d, (double) 35L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999999999999998d + "'", double1 == 9.999999999999998d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1820469732, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(45, 453387264);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 453387309 + "'", int2 == 453387309);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.01209770050168668d, (double) (-2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5604874136486533d, 0.2003166285986869d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-2018720640));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2018720640L + "'", long1 == 2018720640L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1632, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 116397953);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2031527.5224316113d + "'", double1 == 2031527.5224316113d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(302370689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.2650001477823025d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9018665140088857d) + "'", double1 == (-0.9018665140088857d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 116397953 + "'", int14 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-2018720577L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963262995333d) + "'", double1 == (-1.5707963262995333d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.141592653589793d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (-100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1074790410, (long) 1641908722);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1764707748500956020L + "'", long2 == 1764707748500956020L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-45), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 1, (long) 1641908722);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1641908723L + "'", long2 == 1641908723L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (133 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-36));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0d, (-0.03497003954460952d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03497003954460952d) + "'", double2 == (-0.03497003954460952d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1884372864, 74);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1332.8347913921116d + "'", double2 == 1332.8347913921116d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.032908758547247E67d + "'", double1 == 4.032908758547247E67d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1125L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1125L + "'", long2 == 1125L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        float float1 = org.apache.commons.math.util.FastMath.abs(17689.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 17689.0f + "'", float1 == 17689.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.5d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-3245L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2716092771680511d + "'", double1 == 0.2716092771680511d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2533141373155001d, (java.lang.Number) 92.13617560368711d, 0);
        java.lang.Number number5 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number5, (int) (byte) 0, orderDirection7, false);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        int int12 = nonMonotonousSequenceException9.getIndex();
        boolean boolean13 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean15 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.654893846056297d + "'", double1 == 9.654893846056297d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1463113874, (float) 295572686);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.95572672E8f + "'", float2 == 2.95572672E8f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.487270706090812E226d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1074790400), (-1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747904E9d) + "'", double2 == (-1.0747904E9d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1330.0000000000002d, 1432.3944878270581d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1072693248, 1536977967200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1535905273952L) + "'", long2 == (-1535905273952L));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.FastMath.signum(155327.58075060102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray25);
        double[] doubleArray36 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray41 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double[] doubleArray50 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray55 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray55);
        double[] doubleArray63 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray68 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray68);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray75 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray75);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, 11.548739357257748d);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray55);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 116397953 + "'", int28 == 116397953);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 173.49639765712718d + "'", double43 == 173.49639765712718d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 116397953 + "'", int70 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 141.77799547179387d + "'", double78 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 116397953 + "'", int81 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 141.77799547179387d + "'", double83 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1074790410);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.120168601884164E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.98878233513793d + "'", double1 == 24.98878233513793d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.FastMath.asinh(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.741450291257945d + "'", double1 == 4.741450291257945d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-1720744188), (-710262581));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-10.0d), (java.lang.Number) 1125L, 581202753);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 302370689, 1480170323, 1242703820);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 116397953, (long) 3200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7443739007964037119L) + "'", long2 == (-7443739007964037119L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(341642367, (-2018720640));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(116397953, (-116397954));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0732178989295803E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015625d + "'", double1 == 0.015625d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3205243074936246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9688450872122514d + "'", double1 == 0.9688450872122514d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-36), 1242702620);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5729.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 75.69015788066504d + "'", double1 == 75.69015788066504d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.5055564237435929d, 1242703854);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52, (float) 6L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1125L, (long) 710262581);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 710263706L + "'", long2 == 710263706L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.538918511081545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.706730115886607d + "'", double1 == 5.706730115886607d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(453387264);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.4711276743037347d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray13 = new int[] { 341642467 };
        int[] intArray18 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray24 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray24);
        int[] intArray30 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray36 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray36);
        int[] intArray42 = new int[] { 341642467 };
        int[] intArray47 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray53 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray53);
        int[] intArray59 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray65 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray65);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray65);
        int[] intArray74 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray80 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray80);
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray80);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 93.58952932887311d + "'", double25 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 93.58952932887311d + "'", double37 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 133 + "'", int38 == 133);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.41642457E8d + "'", double39 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 93.58952932887311d + "'", double54 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 93.58952932887311d + "'", double66 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 133 + "'", int67 == 133);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.41642457E8d + "'", double68 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 93.58952932887311d + "'", double81 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.18516357615334d + "'", double1 == 181.18516357615334d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 900, (long) 341642467);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-341641567L) + "'", long2 == (-341641567L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        long long1 = org.apache.commons.math.util.FastMath.abs((-33L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 33L + "'", long1 == 33L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 11.548739357257748d);
        double[] doubleArray38 = null;
        double[] doubleArray45 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray50 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray50);
        double[] doubleArray58 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray63 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray58);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray58);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray38);
        try {
            double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 141.77799547179387d + "'", double35 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1641908723L, number1, (int) (byte) 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.8731185927656904E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0732178989295803E14d + "'", double1 == 1.0732178989295803E14d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (-710262581));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1.0f, (double) (-607999154));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3656472477812869d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.086736875163732d + "'", double1 == 2.086736875163732d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 3200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3200L + "'", long2 == 3200L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1851910911));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(21216, 1884372829);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        double[] doubleArray77 = null;
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 243L, 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.7853087663494565d), 32.000000000000014d, (-0.03497003954460952d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(74);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(21216);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 330L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18907.607239317167d + "'", double1 == 18907.607239317167d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        long long1 = org.apache.commons.math.util.FastMath.abs(1764707748500956020L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1764707748500956020L + "'", long1 == 1764707748500956020L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int1 = org.apache.commons.math.util.FastMath.abs(302370689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 302370689 + "'", int1 == 302370689);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1330);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double[] doubleArray4 = new double[] { 1242703820, 10445.4381963383d, 45, (-0.5129738426669538d) };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray17 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray17);
        double[] doubleArray25 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray30 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray37 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray37);
        double[] doubleArray46 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray51 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray60 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray65 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double[] doubleArray72 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray72);
        double[] doubleArray80 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray85 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray85);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        double[] doubleArray92 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray85);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray65);
        double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray65);
        double[] doubleArray98 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 0.8655103306675352d);
        double double99 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2427038200439E9d + "'", double5 == 1.2427038200439E9d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 116397953 + "'", int32 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 116397953 + "'", int53 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 116397953 + "'", int67 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 116397953 + "'", int87 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray98);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 1.2427037200438163E9d + "'", double99 == 1.2427037200438163E9d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 38);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long1 = org.apache.commons.math.util.FastMath.round(1838.8549405050114d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1839L + "'", long1 == 1839L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.FastMath.signum((-5.787637788602359d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2018720640), 74);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1162858593);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1851910911), 116397953L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1968308864L) + "'", long2 == (-1968308864L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 110L, (float) (-34));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-34.0f) + "'", float2 == (-34.0f));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6401443394691997d, 1.0536712127723509E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6401443394691996d + "'", double2 == 0.6401443394691996d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1435802341, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2094612153 + "'", int2 == 2094612153);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 17689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-710262581));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 710262581L + "'", long1 == 710262581L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1072693248L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.030475546991784d + "'", double1 == 9.030475546991784d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8221188003905089d + "'", double1 == 1.8221188003905089d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int int2 = org.apache.commons.math.util.FastMath.max(45, 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-4860L), (double) 1125L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4860.0d) + "'", double2 == (-4860.0d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-114.59155902616465d) + "'", double1 == (-114.59155902616465d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double double1 = org.apache.commons.math.util.FastMath.acosh(11.833336070820506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 581202753, (long) (-2018720640));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(22.05000808490679d, 410.32277652693745d, 0.7839146842102701d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 51 + "'", int1 == 51);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 302370689, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.726092576980591d, (double) 133L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 341642467);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 295572686, (double) (-3245L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3241.998905777931d) + "'", double2 == (-3241.998905777931d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-1720744188));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.lang.Class<?> wildcardClass7 = bigInteger2.getClass();
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 38);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 116397953);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 38);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger17);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 38);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 51);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger27);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger27);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        try {
            java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (-710262581));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        long long1 = org.apache.commons.math.util.FastMath.round(7.120168407330043E10d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 71201684073L + "'", long1 == 71201684073L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 11L, (float) 104);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 104.0f + "'", float2 == 104.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.signum(8241.117982517473d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5907008138154553d, (double) 10.1f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05841868007282064d + "'", double2 == 0.05841868007282064d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 0, 17L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-17L) + "'", long2 == (-17L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1535905273952L), 1242703854);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double1 = org.apache.commons.math.util.FastMath.acos((-17.89400457879299d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        double[] doubleArray53 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray58 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray53);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 11.548739357257748d);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray40);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 2578.3100780887044d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-13300L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.8066624897703196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0121831249543365d + "'", double1 == 2.0121831249543365d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double1 = org.apache.commons.math.util.FastMath.log(4.950000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5993875765805992d + "'", double1 == 1.5993875765805992d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.sin(9.654893846056297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.22809035561368166d) + "'", double1 == (-0.22809035561368166d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-116397954));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-116397952) + "'", int1 == (-116397952));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 5.6843418860808015E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 51L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-116397952));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 11.548739357257748d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray25);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 173.49639765712718d + "'", double13 == 173.49639765712718d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 116397953 + "'", int40 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.77799547179387d + "'", double48 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 116397953 + "'", int51 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1884372864, (-22));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-3674071450140L), (long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(8.547053763040636E60d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4917422951003033E59d + "'", double1 == 1.4917422951003033E59d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1125L, (long) (-710262581));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.FastMath.abs((-114.59155902616465d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.4653893333223524d, (-0.6401443394691997d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        double[] doubleArray42 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray47 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray56 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray61 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray68 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        double[] doubleArray76 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray81 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double[] doubleArray88 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray81, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray81);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray61);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray61);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 5.706730115886607d);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 10.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 116397953 + "'", int49 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116397953 + "'", int63 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 116397953 + "'", int83 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1884372864, (float) 10000000000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0E10f + "'", float2 == 1.0E10f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 33, (-2));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2018720640), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2018720639) + "'", int2 == (-2018720639));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013276747223059479d) + "'", double1 == (-0.013276747223059479d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        long long2 = org.apache.commons.math.util.FastMath.max(34164246700L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34164246700L + "'", long2 == 34164246700L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.0747904E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.rint((-7.974179951488727E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.9741799515E10d) + "'", double1 == (-7.9741799515E10d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (5.473 >= 0.547)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(92.13617560368711d, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22026.73608296762d + "'", double2 == 22026.73608296762d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        double[] doubleArray53 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray58 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray53);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 11.548739357257748d);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray40);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (-0.1736481776669303d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(9.286355438117551d, 3.970291913552122d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0031701309379653d + "'", double2 == 3.0031701309379653d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) -1, (double) 581202753);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-116397954), 3200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-2018719147L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0747904E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 900, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-10), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9L) + "'", long2 == (-9L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7853981633974483d), (double) 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 110.0d + "'", double2 == 110.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7853981633974483d), 1.1470638038216645d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray29 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray35 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray29);
        int[] intArray38 = new int[] {};
        int[] intArray43 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray49 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int[] intArray52 = new int[] { 341642467 };
        int[] intArray57 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray63 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray63);
        int[] intArray69 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray75 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray75);
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray75);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray49);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray49);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 93.58952932887311d + "'", double36 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 93.58952932887311d + "'", double50 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 93.58952932887311d + "'", double64 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 93.58952932887311d + "'", double76 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 133 + "'", int77 == 133);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 3.41642457E8d + "'", double78 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 93.58952932887311d + "'", double81 == 93.58952932887311d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray84 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray89 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray89);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray89);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, (double) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1391756953) + "'", int77 == (-1391756953));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 116397953 + "'", int91 == 116397953);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1764707748500956020L, 38, 581202753);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.05598203492917749d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.056040590681765284d) + "'", double1 == (-0.056040590681765284d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) (-1.0f), (int) (byte) 10, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (-1 < 97)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (-1 < 97)"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6648555768512805d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9442097121712443d + "'", double1 == 1.9442097121712443d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 0, 1480170323, (-1242702720));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray11 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray11);
        int[] intArray14 = new int[] { 341642467 };
        int[] intArray19 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray25 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
        int[] intArray31 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray37 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray37);
        try {
            double double42 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 93.58952932887311d + "'", double12 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 93.58952932887311d + "'", double26 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 93.58952932887311d + "'", double38 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 133 + "'", int39 == 133);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.41642457E8d + "'", double40 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.560487413648653d, 1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 418L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 418.0f + "'", float1 == 418.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        float float2 = org.apache.commons.math.util.MathUtils.round(418.0f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 418.0f + "'", float2 == 418.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1242703820L, (-116397952));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(295572686, 152);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1069449216));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1043341504) + "'", int1 == (-1043341504));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double1 = org.apache.commons.math.util.FastMath.log(9.332621544395287E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.086736875163732d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1d + "'", double2 == 2.1d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(7.193685818395112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 665.4996243425998d + "'", double1 == 665.4996243425998d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 93L, 1330);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 665.4996243425998d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 302370689, 2.95572672E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.95572672E8f + "'", float2 == 2.95572672E8f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1074790400, 0, 47);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1074790410);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07479041E9d + "'", double1 == 1.07479041E9d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1074790410L, 74);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.07479041E9d + "'", double2 == 1.07479041E9d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray21 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray26 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray33 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double[] doubleArray41 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray46 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray53 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray46);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray26);
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 116397953 + "'", int14 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 116397953 + "'", int28 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 116397953 + "'", int48 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-10), (-2018719147L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2018719147L) + "'", long2 == (-2018719147L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.1d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3222192947339193d + "'", double1 == 0.3222192947339193d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.abs(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(47, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray84 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray89 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray89);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray89);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        double[] doubleArray95 = null;
        try {
            double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray89, doubleArray95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1391756953) + "'", int77 == (-1391756953));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 116397953 + "'", int91 == 116397953);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 116397953 + "'", int94 == 116397953);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int1 = org.apache.commons.math.util.MathUtils.sign(302370689);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        int int23 = nonMonotonousSequenceException19.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-34) + "'", int23 == (-34));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double double1 = org.apache.commons.math.util.FastMath.cosh(133.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8849354310165015E57d + "'", double1 == 2.8849354310165015E57d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 45, (-0.17452218322646063d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 330L, (double) (-1851910962));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.15917453895486158d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14715250913184438d) + "'", double1 == (-0.14715250913184438d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.9E-324d, (double) (byte) -1, (double) (-1074790267));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 243L, 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number4, (int) (byte) 0, orderDirection6, false);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException8.getSuppressed();
        int int11 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1162858593, (java.lang.Number) 1072693248, 0, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-10), (long) (-116397952));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 116397942L + "'", long2 == 116397942L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1890.7607239317165d + "'", double1 == 1890.7607239317165d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double[] doubleArray46 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray51 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray58 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray38);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 116397953 + "'", int53 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.77799547179387d + "'", double61 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2018720577 + "'", int63 == 2018720577);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.2533141373155001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8937432374471157d + "'", double1 == 1.8937432374471157d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.6634392799796833d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4917422951003033E59d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 136.25246524904807d + "'", double1 == 136.25246524904807d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.22809035561368166d), 4.726092576980591d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.055094951565905d + "'", double2 == 6.055094951565905d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 101.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 418L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.714207693407102E181d + "'", double1 == 1.714207693407102E181d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) (-116397952));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 116397952L + "'", long2 == 116397952L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (-2.426324808873483d));
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 4.419937735994375E40d + "'", double79 == 4.419937735994375E40d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1164380801);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-45) + "'", number5.equals((-45)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-45) + "'", number6.equals((-45)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 44L, 1125.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.148539621088837E-224d), (-1391756953), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-4.197246318314786E-216d), (-1720744188));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.7997002675545735E-292d) + "'", double2 == (-5.7997002675545735E-292d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.01209770050168668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012025108203109165d + "'", double1 == 0.012025108203109165d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray54 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray59 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray66 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray66);
        double[] doubleArray74 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray79 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray86 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray79);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray59);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection91, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 116397953 + "'", int61 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 116397953 + "'", int81 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.0937901169005635d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-45));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1820469732);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.rint(18907.607239317167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18908.0d + "'", double1 == 18908.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-2.426324808873483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.702786807958734d + "'", double1 == 5.702786807958734d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(94.52666381172618d, (double) (-710262581), 7.120168407330043E10d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1978765218, (-26268165L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.math.util.FastMath.max(2018720577, (-116397952));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2018720577 + "'", int2 == 2018720577);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray74 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray78 = null;
        try {
            double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray74, doubleArray78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 116397953 + "'", int69 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1391756953) + "'", int77 == (-1391756953));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double2 = org.apache.commons.math.util.FastMath.max(35.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double1 = org.apache.commons.math.util.FastMath.sinh(6.708203932499369d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 409.5484705342973d + "'", double1 == 409.5484705342973d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 25, (-1.2650001477823025d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.999999999999996d + "'", double2 == 24.999999999999996d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 900, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(74, (-1851910962));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1851910888) + "'", int2 == (-1851910888));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.9318256327243257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.078043828059135d + "'", double1 == 2.078043828059135d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) -1, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-36) + "'", int2 == (-36));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1242702720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1242702720 + "'", int2 == 1242702720);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3, 2094612153);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-45), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.44842875866404064d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4650066648966585d + "'", double1 == 0.4650066648966585d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.056040590681765284d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.159898775761099d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020244052626882576d + "'", double1 == 0.020244052626882576d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray19);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double[] doubleArray46 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray51 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray58 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray58);
        double[] doubleArray67 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray72 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray72);
        double[] doubleArray80 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray85 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray80);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 11.548739357257748d);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray67);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection92 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection92, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (133 > 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 116397953 + "'", int53 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + orderDirection92 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection92.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.391756953E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.391756953E9d + "'", double1 == 1.391756953E9d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-13300L), (-4.197246318314786E-216d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.503295299184174d + "'", double2 == 1.503295299184174d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(173.4963976571272d, Double.POSITIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(22026.73608296762d, 155327.58075060102d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1242703854, (-2021600L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2021600L) + "'", long2 == (-2021600L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        java.lang.Class<?> wildcardClass14 = doubleArray11.getClass();
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 116397953 + "'", int15 == 116397953);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(36L, (-100L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 136L + "'", long2 == 136L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 93L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4093490824269389E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.41549527535753E7d + "'", double1 == 2.41549527535753E7d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3860292320770566d + "'", double1 == 0.3860292320770566d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1391756953L, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3222192947339193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32807288427351594d + "'", double1 == 0.32807288427351594d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3555855379673048E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3555855338155708E-4d + "'", double1 == 1.3555855338155708E-4d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.5707963258644826d), (double) 133L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2132313131463998E26d) + "'", double2 == (-1.2132313131463998E26d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-17L), (long) 3200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1043341504), 1463113874);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1164380936L, 341642467L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 822738469L + "'", long2 == 822738469L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        java.lang.Class<?> wildcardClass14 = doubleArray11.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(123, 3200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 393600 + "'", int2 == 393600);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1391756953), (-1752582786134912493L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 38);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 116397953);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 38);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger10);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 38);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 51);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 1164380801);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 38);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 116397953);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 38);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger33);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) (short) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 38);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 51);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger43);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger44);
        java.lang.Number number48 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number48, (int) (byte) 0, orderDirection50, false);
        java.lang.Throwable[] throwableArray53 = nonMonotonousSequenceException52.getSuppressed();
        java.lang.Number number55 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number55, (int) (byte) 0, orderDirection57, false);
        java.lang.Throwable[] throwableArray60 = nonMonotonousSequenceException59.getSuppressed();
        java.lang.String str61 = nonMonotonousSequenceException59.toString();
        nonMonotonousSequenceException52.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = nonMonotonousSequenceException52.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.3860292320770566d, (java.lang.Number) bigInteger13, 1330, orderDirection63, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str61.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-116397952), 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 38);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 38);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 116397953);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 38);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger14);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger7, (java.lang.Number) 10.1f, 1242703854);
        java.lang.Number number26 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number26, (int) (byte) 0, orderDirection28, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 1.0732178989295803E14d, 52, orderDirection31, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException33.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642367, (java.lang.Number) 10.1f, (int) ' ', orderDirection34, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(45, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 5943824120834121313L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.9438241208341217E18d + "'", double1 == 5.9438241208341217E18d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.0d, (-1391756953));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.52281387416075E108d) + "'", double2 == (-3.52281387416075E108d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 341642467);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (short) 10, 1641908722);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1480170323, 1242703820);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1100, (-1720744188));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 74);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(330L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 427L + "'", long2 == 427L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4463520074491623d + "'", double1 == 2.4463520074491623d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(10.197844452515685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.3440585709080678E43d), 7.8962960182681E13d, 25);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1851910888));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-5.487233297348662d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0957702878637992d) + "'", double1 == (-0.0957702878637992d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1632.0f, 0.5569432209472811d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 900, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 47, 900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        long long1 = org.apache.commons.math.util.FastMath.abs(822738469L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 822738469L + "'", long1 == 822738469L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(136L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 5943824120834121313L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(302370689, 116397953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 418768642 + "'", int2 == 418768642);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.2650001477823025d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 341642467L, 0.0d, (-0.17453292519943295d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-100), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1884372829);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.756685051842792d + "'", double1 == 0.756685051842792d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        long long1 = org.apache.commons.math.util.FastMath.round((-45.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-45L) + "'", long1 == (-45L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 710263706L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 3.0f, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(45);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 129.12393363912722d + "'", double1 == 129.12393363912722d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.332621544395287E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.660549437995381E78d + "'", double1 == 9.660549437995381E78d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1884372864, (-5.487233297348662d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2018720577);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2.0187191E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8888126494588616d + "'", double1 == 0.8888126494588616d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double1 = org.apache.commons.math.util.FastMath.asinh(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.69310178011491d + "'", double1 == 10.69310178011491d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(152.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.149099138580496E65d + "'", double1 == 5.149099138580496E65d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.4749192053464507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38860321225521666d + "'", double1 == 0.38860321225521666d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-0.15917453895486158d) + "'", number8.equals((-0.15917453895486158d)));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 1435802341);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 133);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double1 = org.apache.commons.math.util.FastMath.log10(1125.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0511525224473814d + "'", double1 == 3.0511525224473814d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException19.getArgument();
        java.lang.Number number24 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException19.getDirection();
        java.lang.Class<?> wildcardClass26 = nonMonotonousSequenceException19.getClass();
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException19.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-45) + "'", number23.equals((-45)));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-45) + "'", number24.equals((-45)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(7.5979151462512712E18d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2632797070932267E28d + "'", double2 == 3.2632797070932267E28d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(581202753, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 581202753 + "'", int2 == 581202753);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1485));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.3860292320770566d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3860292320770566d + "'", double2 == 0.3860292320770566d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double2 = org.apache.commons.math.util.FastMath.max((-5.487233297348662d), (-5729.5779513082325d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.487233297348662d) + "'", double2 == (-5.487233297348662d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', (-34));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.148539621088837E-224d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.148539621088837E-224d) + "'", double1 == (-1.148539621088837E-224d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1242702620);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1075.1170220543652d + "'", double1 == 1075.1170220543652d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray45);
        double[] doubleArray61 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray66 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray66);
        java.lang.Number number70 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number70, (int) (byte) 0, orderDirection72, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = nonMonotonousSequenceException74.getDirection();
        java.lang.Number number77 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number77, (int) (byte) 0, orderDirection79, false);
        java.lang.Number number82 = nonMonotonousSequenceException81.getPrevious();
        java.lang.Throwable[] throwableArray83 = nonMonotonousSequenceException81.getSuppressed();
        nonMonotonousSequenceException74.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException81);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection89 = nonMonotonousSequenceException88.getDirection();
        java.lang.Number number90 = nonMonotonousSequenceException88.getArgument();
        nonMonotonousSequenceException74.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException88);
        java.lang.Number number92 = nonMonotonousSequenceException88.getArgument();
        java.lang.Number number93 = nonMonotonousSequenceException88.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection94 = nonMonotonousSequenceException88.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection94, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number82);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertTrue("'" + orderDirection89 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection89.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number90 + "' != '" + (-45) + "'", number90.equals((-45)));
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + (-45) + "'", number92.equals((-45)));
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + (-45) + "'", number93.equals((-45)));
        org.junit.Assert.assertTrue("'" + orderDirection94 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection94.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-10.0d), (java.lang.Number) 1330, (int) (byte) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1,330 >= -10)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1,330 >= -10)"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-10.0d) + "'", number6.equals((-10.0d)));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Number number9 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number9, (int) (byte) 0, orderDirection11, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(34164246700L, (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34164246700L + "'", long2 == 34164246700L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray12 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        double[] doubleArray33 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray38 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray33);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 11.548739357257748d);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray42);
        try {
            double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.332621544395287E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2194330274671845E142d + "'", double1 == 1.2194330274671845E142d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 45L, (-607999154), (-34));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray25 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray32 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray32);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray25);
        double[] doubleArray56 = null;
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 116397953 + "'", int13 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 116397953 + "'", int27 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int int2 = org.apache.commons.math.util.FastMath.max(302370689, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 302370689 + "'", int2 == 302370689);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.012025108203109165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012025398033545041d + "'", double1 == 0.012025398033545041d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1074790267));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9129311827723892d + "'", double1 == 1.9129311827723892d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray45);
        double[] doubleArray61 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray66 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection69, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1164380801L, 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.164380801E9d + "'", double2 == 1.164380801E9d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1072693248, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693280 + "'", int2 == 1072693280);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(900, (-1851910962));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 51);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 25);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) '4');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.086736875163732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.091333737841489d + "'", double1 == 4.091333737841489d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 900, (float) 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33.0f + "'", float2 == 33.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int int2 = org.apache.commons.math.util.FastMath.min((-1485), (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1485) + "'", int2 == (-1485));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, 1078591488);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1978765218, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1978765218L + "'", long2 == 1978765218L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-9L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 341642467L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 15369779672L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15369779672L + "'", long2 == 15369779672L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1242702720), 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1242702872) + "'", int2 == (-1242702872));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.007199254740992E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6062574002155612d + "'", double1 == 1.6062574002155612d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1485), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        double[] doubleArray42 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray47 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray54 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray54);
        double[] doubleArray62 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray67 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        double[] doubleArray75 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray80 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray75);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray47);
        double[] doubleArray86 = null;
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 116397953 + "'", int49 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 101.0d + "'", double83 == 101.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 141.77799547179387d + "'", double84 == 141.77799547179387d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.2278539698898954d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1480170323);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double1 = org.apache.commons.math.util.FastMath.log1p(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983702d + "'", double1 == 2.3978952727983702d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 2908163984051896177L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9950547536867305d) + "'", double1 == (-0.9950547536867305d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 8241.117982517473d);
        double[] doubleArray42 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray47 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray56 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray61 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray68 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        double[] doubleArray76 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray81 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double[] doubleArray88 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray81, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray81);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray61);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray61);
        int int93 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 116397953 + "'", int49 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116397953 + "'", int63 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 116397953 + "'", int83 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-909337683) + "'", int93 == (-909337683));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int int2 = org.apache.commons.math.util.FastMath.max(101, 1480170323);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1480170323 + "'", int2 == 1480170323);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double double2 = org.apache.commons.math.util.FastMath.max(665.4996243425998d, 0.5569432209472811d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 665.4996243425998d + "'", double2 == 665.4996243425998d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 100, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        java.lang.Class<?> wildcardClass25 = intArray22.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.2533141373155001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6081863851484017d + "'", double1 == 1.6081863851484017d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9688450872122514d, 101.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.0d + "'", double2 == 101.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.4653893333223524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 141.25640365594253d + "'", double1 == 141.25640365594253d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-34), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(141.25640365594253d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.207980886496978d + "'", double1 == 5.207980886496978d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(5.6843418860808015E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        double[] doubleArray6 = new double[] { 101.0d, 6.283185307179586d, 1.1639795299999999E8d, 341642467L, 6.708203932499369d, 0.4948722204034305d };
        double[] doubleArray13 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray18 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray27 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray32 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray39 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray47 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray52 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray59 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray32);
        double[] doubleArray69 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray74 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray81 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray81);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection86 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection86, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 116397953 + "'", int20 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 116397953 + "'", int34 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 116397953 + "'", int54 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 116397953 + "'", int76 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1641908722 + "'", int85 == 1641908722);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-3674071450140L), 0.2716092771680511d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948226d) + "'", double2 == (-1.5707963267948226d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 'a', 71201684073L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6223754616562534559L) + "'", long2 == (-6223754616562534559L));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1242702720);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2427027200000002E9d + "'", double1 == 1.2427027200000002E9d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1.24270387E9f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.242703872E9d + "'", double2 == 1.242703872E9d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.3032193983521574E-9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1074790410L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790410L + "'", long2 == 1074790410L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1074790267));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1978765218, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1978765218L + "'", long2 == 1978765218L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        float float2 = org.apache.commons.math.util.FastMath.max(45.0f, (float) (-22));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-22.0f) + "'", float2 == (-22.0f));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4749192053464507d, (java.lang.Number) 13300L, 1074790410);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.23145302310912E15d, (java.lang.Number) 0.5403023058681398d, (-1074790400), orderDirection12, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6931471805599454d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9442097121712444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1074790400), 104);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(92.13617560368711d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94347.4438181756d + "'", double2 == 94347.4438181756d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, 8.683317618811995E36d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 152);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 302370689, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1752582786134912493L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.75258278613491251E18d) + "'", double1 == (-1.75258278613491251E18d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.17453292519943295d), 85.05446701758153d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.2632797070932267E28d, (double) 1463113874);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray41 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray46 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray60 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double[] doubleArray67 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray67);
        double[] doubleArray75 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray80 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray80);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray87 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray80);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray60);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray60);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 116397953 + "'", int48 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 116397953 + "'", int62 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 116397953 + "'", int82 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 116397953 + "'", int92 == 116397953);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1851910911), 116397953);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2427037200438163E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-6.622659904607587d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.877921717308338d) + "'", double1 == (-1.877921717308338d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(5.706730115886607d, (-1.75258278613491251E18d), 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 17689, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17689.0d + "'", double2 == 17689.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.391756953E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.143563399651683d + "'", double1 == 9.143563399651683d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int1 = org.apache.commons.math.util.FastMath.abs((-97));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number13, (int) (byte) 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean22 = nonMonotonousSequenceException5.getStrict();
        int int23 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2028092471040L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int[] intArray4 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray10 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray10);
        int[] intArray16 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray22 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray22);
        int[] intArray26 = new int[] { 341642467 };
        int[] intArray31 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray37 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int[] intArray43 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray49 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray49);
        java.lang.Class<?> wildcardClass53 = intArray49.getClass();
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray49);
        int[] intArray55 = new int[] {};
        int[] intArray60 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray66 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray66);
        int[] intArray69 = new int[] { 341642467 };
        int[] intArray74 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray80 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray80);
        int[] intArray86 = new int[] { (short) 100, '#', (byte) 1, '#' };
        int[] intArray92 = new int[] { (byte) 10, '4', (short) 10, '4', ' ' };
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray86, intArray92);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray92);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray92);
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray92);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray66);
        double double98 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray66);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 93.58952932887311d + "'", double11 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 93.58952932887311d + "'", double23 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 133 + "'", int24 == 133);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 93.58952932887311d + "'", double38 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 93.58952932887311d + "'", double50 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 133 + "'", int51 == 133);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.41642457E8d + "'", double52 == 3.41642457E8d);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 93.58952932887311d + "'", double67 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 93.58952932887311d + "'", double81 == 93.58952932887311d);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 93.58952932887311d + "'", double93 == 93.58952932887311d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 133 + "'", int94 == 133);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 3.41642457E8d + "'", double95 == 3.41642457E8d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(Double.NEGATIVE_INFINITY, (-10));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-116397954));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number13, (int) (byte) 0, orderDirection15, false);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean22 = nonMonotonousSequenceException11.getStrict();
        java.lang.Number number24 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number24, (int) (byte) 0, orderDirection26, false);
        java.lang.Throwable[] throwableArray29 = nonMonotonousSequenceException28.getSuppressed();
        java.lang.Number number30 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException28.getSuppressed();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 116397953);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 38);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 10.1f, 1242703854);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-100), (java.lang.Number) 10L, (int) (short) 10);
        java.lang.Number number25 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number25, (int) (byte) 0, orderDirection27, false);
        java.lang.Number number30 = nonMonotonousSequenceException29.getPrevious();
        java.lang.String str31 = nonMonotonousSequenceException29.toString();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException29);
        boolean boolean33 = nonMonotonousSequenceException23.getStrict();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35, 114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.091333737841489d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-3), 1242702620);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 2028092471040L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.33811679777773d + "'", double1 == 28.33811679777773d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        int int1 = org.apache.commons.math.util.FastMath.abs(1463113874);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1463113874 + "'", int1 == 1463113874);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean16 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number17 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2018720639), 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1578235263) + "'", int2 == (-1578235263));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(25.19064567883508d, (-2018720640));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.768295750607753E-269d) + "'", double2 == (-4.768295750607753E-269d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        int int1 = org.apache.commons.math.util.MathUtils.hash(52.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-36));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-2661627379775963136L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.66162738E18f) + "'", float2 == (-2.66162738E18f));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.15850993369010735d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.729977650449503d + "'", double1 == 1.729977650449503d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 21216, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1242703854, 104);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray52 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray45);
        double[] doubleArray61 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray66 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray66);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 11.548739357257748d);
        double[] doubleArray43 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray48 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray48);
        double[] doubleArray56 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray61 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray68 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 11.548739357257748d);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray48);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.77799547179387d + "'", double34 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 116397953 + "'", int63 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 141.77799547179387d + "'", double71 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 116397953 + "'", int74 == 116397953);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 94.52666381172618d + "'", double75 == 94.52666381172618d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 141.77799547179387d + "'", double76 == 141.77799547179387d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6931471805599454d, 1.3085853819747226d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6931471805599455d + "'", double2 == 0.6931471805599455d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 133, (java.lang.Number) (byte) -1, (int) 'a');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass5 = orderDirection4.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1074790410, (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number8, (int) (byte) 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass24 = throwableArray23.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-45) + "'", number21.equals((-45)));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.6062574002155612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2522950870122742d + "'", double1 == 1.2522950870122742d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 21216, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21213L + "'", long2 == 21213L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-2.0d), 3.41642467E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9999999999999998d) + "'", double2 == (-1.9999999999999998d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double1 = org.apache.commons.math.util.FastMath.floor(24.999999999999996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.0d + "'", double1 == 24.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9688450872122514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 51);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 25);
        java.lang.Class<?> wildcardClass23 = bigInteger19.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 38);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 38);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 51);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 1164380801);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (short) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 38);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 116397953);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (short) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 38);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) (short) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 38);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 116397953);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger38);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger29);
        try {
            java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) (-1851910962));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1125.0d, 2.078043828059135d, 0.8888126494588616d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 17689, (float) (-116397954));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.16397952E8f) + "'", float2 == (-1.16397952E8f));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (null > -0.159)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.15917453895486158d), number1, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number11 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-0.15917453895486158d) + "'", number9.equals((-0.15917453895486158d)));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-0.15917453895486158d) + "'", number11.equals((-0.15917453895486158d)));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3200, (-2018720640));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 640 + "'", int2 == 640);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8655103306675352d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015106004980173341d + "'", double1 == 0.015106004980173341d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int2 = org.apache.commons.math.util.FastMath.max(51, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1851910911), (-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.9999546000702375d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403405080349111d + "'", double1 == 0.5403405080349111d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-36.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 640, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        double double1 = org.apache.commons.math.util.FastMath.floor(10445.4381963383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10445.0d + "'", double1 == 10445.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1851910962));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-45), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.545454545454547d + "'", double1 == 5.545454545454547d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0f, (java.lang.Number) 900L, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2427038200439E9d, (java.lang.Number) 35.0d, (int) (byte) 100, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 38);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 116397953);
        java.lang.Class<?> wildcardClass7 = bigInteger2.getClass();
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 38);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 116397953);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 38);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger17);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger14);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (short) 0);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 38);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 116397953);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 38);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger34);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 38);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 51);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 1164380801);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long long1 = org.apache.commons.math.util.FastMath.round(0.01209770050168668d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4411627128891868d + "'", double1 == 1.4411627128891868d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(10.69310178011491d, 1.4917422951003033E59d, 3.8066624897703196d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.086736875163732d, (java.lang.Number) 1.7067655527413216E89d, 341642467);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 341642467 + "'", int4 == 341642467);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 5.849312322216629d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1069449216), (-2147483648));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double[] doubleArray6 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray11 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        double[] doubleArray19 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray24 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray31 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray31);
        double[] doubleArray40 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray45 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray54 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray59 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray66 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray66);
        double[] doubleArray74 = new double[] { 100.0f, 100.0f, (-1), (short) 100, (short) 0, 10L };
        double[] doubleArray79 = new double[] { 100.0f, 10, 100.0f, 1.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray86 = new double[] { 133, '#', 10.0f, 4.419937735994375E40d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray79);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray59);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray45);
        double[] doubleArray91 = null;
        try {
            double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 116397953 + "'", int26 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 116397953 + "'", int47 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 116397953 + "'", int61 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 116397953 + "'", int81 == 116397953);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.4907704892567988d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1228644703164126d + "'", double1 == 1.1228644703164126d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45), (java.lang.Number) 1330, (-34));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-45) + "'", number5.equals((-45)));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-45) + "'", number7.equals((-45)));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.6532125137753437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.653212513775344d + "'", double1 == 1.653212513775344d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.008851309290403876d, (-4.768295750607753E-269d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1074790267), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790267 + "'", int2 == 1074790267);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        long long2 = org.apache.commons.math.util.FastMath.max((long) ' ', 15369779672L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15369779672L + "'", long2 == 15369779672L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double3 = org.apache.commons.math.util.MathUtils.round((-3.2075343299958265d), 97, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-3.2075343299958265d) + "'", double3 == (-3.2075343299958265d));
    }
}

