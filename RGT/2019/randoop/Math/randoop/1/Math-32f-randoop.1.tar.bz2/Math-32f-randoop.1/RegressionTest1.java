import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        double double5 = vector3D4.getZ();
        double double6 = vector3D4.getY();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (-1272213960), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.27221396E9d) + "'", double2 == (-1.27221396E9d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree0);
        try {
            boolean boolean2 = polygonsSet1.isEmpty();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList1 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList1);
        boolean boolean3 = intervalsSet2.isEmpty();
        double double4 = intervalsSet2.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform5 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet2.applyTransform(euclidean1DTransform5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet2.buildNew(euclidean1DBSPTree7);
        double double9 = intervalsSet2.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet2);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane11 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList12);
        boolean boolean14 = intervalsSet13.isEmpty();
        double double15 = intervalsSet13.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet13.applyTransform(euclidean1DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = intervalsSet13.buildNew(euclidean1DBSPTree18);
        double double20 = intervalsSet13.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint21 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet13);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane22 = subOrientedPoint10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint21);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane23 = subOrientedPoint10.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean27 = vector1D25.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double29 = vector1D25.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        double double30 = vector1D25.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean34 = vector1D32.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean39 = vector1D37.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double41 = vector1D37.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean45 = vector1D43.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        double double48 = vector1D43.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D40, (double) (-1), vector1D43, 0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double57 = vector1D53.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean61 = vector1D59.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double63 = vector1D59.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        double double64 = vector1D59.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D56, (double) (-1), vector1D59, 0.0d, vector1D66);
        double double68 = vector1D50.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean72 = vector1D70.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double74 = vector1D70.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        double double75 = vector1D70.getX();
        double double76 = vector1D70.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D25, (double) 0.0f, vector1D32, (double) 0, vector1D50, (double) (-1.0f), vector1D70);
        double double78 = vector1D77.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint80 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D77, true);
        boolean boolean81 = orientedPoint80.isDirect();
        try {
            org.apache.commons.math3.geometry.partitioning.Side side82 = subOrientedPoint10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertNotNull(intervalsSet19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane23);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 0, (float) (byte) -1, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D4, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D2, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D15, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine21 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D13, vector2D15);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane22 = subLine10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine21);
        java.util.List<org.apache.commons.math3.geometry.euclidean.twod.Segment> segmentList23 = subLine10.getSegments();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane24 = subLine10.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion25 = euclidean2DAbstractSubHyperplane24.getRemainingRegion();
        boolean boolean26 = euclidean2DAbstractSubHyperplane24.isEmpty();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(segmentList23);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane24);
        org.junit.Assert.assertNotNull(euclidean1DRegion25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D8.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D8.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D5, (double) (-1), vector1D8, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D8.scalarMultiply((double) (byte) 10);
        double double19 = vector1D8.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean24 = vector1D22.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double26 = vector1D22.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean30 = vector1D28.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double32 = vector1D28.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        double double33 = vector1D28.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D25, (double) (-1), vector1D28, 0.0d, vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = vector1D28.scalarMultiply((double) (byte) 10);
        double double39 = vector1D28.getNorm1();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean44 = vector1D42.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double46 = vector1D42.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D45);
        double double47 = vector1D42.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean51 = vector1D49.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean56 = vector1D54.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double58 = vector1D54.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D57);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean62 = vector1D60.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double64 = vector1D60.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D63);
        double double65 = vector1D60.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D57, (double) (-1), vector1D60, 0.0d, vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean72 = vector1D70.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double74 = vector1D70.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean78 = vector1D76.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double80 = vector1D76.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D79);
        double double81 = vector1D76.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D73, (double) (-1), vector1D76, 0.0d, vector1D83);
        double double85 = vector1D67.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean89 = vector1D87.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double91 = vector1D87.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D90);
        double double92 = vector1D87.getX();
        double double93 = vector1D87.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D94 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D42, (double) 0.0f, vector1D49, (double) 0, vector1D67, (double) (-1.0f), vector1D87);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D95 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 3.8146973E-6f, vector1D8, (double) 3.0517578E-5f, vector1D28, 1.8378770664093453d, vector1D49);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        boolean boolean9 = vector3D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        boolean boolean15 = vector3D12.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D0.add(3.141592653589793d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        boolean boolean22 = vector3D20.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = plane23.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D25.negate();
        boolean boolean27 = vector3D25.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D25.getZero();
        double double29 = plane23.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 1, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D16.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D31.orthogonal();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D7.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double22 = vector2D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D14, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D25.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D16.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D27.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment32 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D7, vector2D30, line31);
        java.text.NumberFormat numberFormat33 = null;
        java.lang.String str34 = vector2D30.toString(numberFormat33);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line36 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D38.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = vector2D41.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        double double44 = vector2D38.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = vector2D42.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = vector2D48.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D54.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        double double57 = vector2D51.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D49, vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D60.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D51.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D62.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line66 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment67 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D42, vector2D65, line66);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) Float.NaN, vector2D65);
        java.lang.String str69 = vector2D68.toString();
        line35.reset(vector2D68, (double) 1.4E-45f);
        double[] doubleArray72 = vector2D68.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{(NaN); (NaN)}" + "'", str34.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "{(NaN); (NaN)}" + "'", str69.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        double double7 = vector1D2.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean11 = vector1D9.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean16 = vector1D14.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double18 = vector1D14.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean22 = vector1D20.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double24 = vector1D20.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        double double25 = vector1D20.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D17, (double) (-1), vector1D20, 0.0d, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean32 = vector1D30.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double34 = vector1D30.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean38 = vector1D36.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double40 = vector1D36.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        double double41 = vector1D36.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D33, (double) (-1), vector1D36, 0.0d, vector1D43);
        double double45 = vector1D27.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean49 = vector1D47.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D47.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        double double52 = vector1D47.getX();
        double double53 = vector1D47.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D2, (double) 0.0f, vector1D9, (double) 0, vector1D27, (double) (-1.0f), vector1D47);
        double double55 = vector1D54.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D54);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector57 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = vector1D54.subtract(euclidean1DVector57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree5 = polygonsSet3.getTree(false);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane6 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane7 = polygonsSet3.intersection(euclidean2DSubHyperplane6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(polygonsSet3);
        org.junit.Assert.assertNull(euclidean2DBSPTree5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.018934535433830814d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018934535433830814d + "'", double1 == 0.018934535433830814d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double12 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray8);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) (byte) 100);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray16, (double) (short) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection21, false, false);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection21, true, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1023L), (java.lang.Number) 1.0848689673994147d, (int) (byte) 10, orderDirection21, false);
        boolean boolean30 = nonMonotonicSequenceException29.getStrict();
        boolean boolean31 = nonMonotonicSequenceException29.getStrict();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        java.lang.String str3 = vector2D2.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double10 = vector2D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D8.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D2.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double22 = vector2D14.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D23.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D29.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D27, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D25, vector2D27);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D15, vector2D25);
        double double35 = vector2D15.getNorm1();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(NaN); (NaN)}" + "'", str3.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane1 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList2);
        boolean boolean4 = intervalsSet3.isEmpty();
        double double5 = intervalsSet3.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform6 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion7 = intervalsSet3.applyTransform(euclidean1DTransform6);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree8 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = intervalsSet3.buildNew(euclidean1DBSPTree8);
        double double10 = intervalsSet3.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint11 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane1, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane12 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList13 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet14 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList13);
        boolean boolean15 = intervalsSet14.isEmpty();
        double double16 = intervalsSet14.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform17 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion18 = intervalsSet14.applyTransform(euclidean1DTransform17);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet20 = intervalsSet14.buildNew(euclidean1DBSPTree19);
        double double21 = intervalsSet14.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint22 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane12, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet14);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane23 = subOrientedPoint11.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint22);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane24 = intervalsSet0.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion7);
        org.junit.Assert.assertNotNull(intervalsSet9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.NEGATIVE_INFINITY + "'", double16 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion18);
        org.junit.Assert.assertNotNull(intervalsSet20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane23);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane24);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.negate();
        boolean boolean4 = vector3D2.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = plane5.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.normalize();
        org.apache.commons.math3.geometry.Space space10 = vector3D7.getSpace();
        boolean boolean11 = plane5.contains(vector3D7);
        plane5.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane13 = plane5.wholeHyperplane();
        double double14 = subPlane13.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane15 = subPlane13.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion16 = subPlane13.getRemainingRegion();
        try {
            boolean boolean17 = polygonsSet1.contains(euclidean2DRegion16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(space10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(subPlane13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane15);
        org.junit.Assert.assertNotNull(euclidean2DRegion16);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection11, false, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[][] doubleArray17 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray16, doubleArray17);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, orderDirection11, doubleArray17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (byte) 100);
        double double24 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray23);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = plane3.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree7 = polyhedronsSet5.getTree(true);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(polyhedronsSet5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D8.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D8.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D5, (double) (-1), vector1D8, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        double double24 = vector1D19.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean28 = vector1D26.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean33 = vector1D31.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double35 = vector1D31.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean39 = vector1D37.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double41 = vector1D37.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        double double42 = vector1D37.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D34, (double) (-1), vector1D37, 0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean49 = vector1D47.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D47.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double57 = vector1D53.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        double double58 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D50, (double) (-1), vector1D53, 0.0d, vector1D60);
        double double62 = vector1D44.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean66 = vector1D64.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double68 = vector1D64.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        double double69 = vector1D64.getX();
        double double70 = vector1D64.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D19, (double) 0.0f, vector1D26, (double) 0, vector1D44, (double) (-1.0f), vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = vector1D15.add(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D72);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D72);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D8.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D8.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D5, (double) (-1), vector1D8, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean20 = vector1D18.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean26 = vector1D24.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double28 = vector1D24.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        double double29 = vector1D24.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D21, (double) (-1), vector1D24, 0.0d, vector1D31);
        double double33 = vector1D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean39 = vector1D37.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double41 = vector1D37.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean45 = vector1D43.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        double double48 = vector1D43.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D40, (double) (-1), vector1D43, 0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double57 = vector1D53.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean61 = vector1D59.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double63 = vector1D59.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        double double64 = vector1D59.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D56, (double) (-1), vector1D59, 0.0d, vector1D66);
        double double68 = vector1D50.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean73 = vector1D71.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double75 = vector1D71.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean79 = vector1D77.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double81 = vector1D77.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D80);
        double double82 = vector1D77.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D74, (double) (-1), vector1D77, 0.0d, vector1D84);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2.3978952727983707d, vector1D56, 100.0d, vector1D85);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(6.691673596021348E41d, vector1D21, (double) 0.0f, vector1D85, (double) 0.0f, vector1D88, 0.6483608274590866d, vector1D90);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = vector1D21.getZero();
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertNotNull(vector1D92);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        boolean boolean2 = intervalsSet1.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane3 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList4 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList4);
        boolean boolean6 = intervalsSet5.isEmpty();
        double double7 = intervalsSet5.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform8 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion9 = intervalsSet5.applyTransform(euclidean1DTransform8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = intervalsSet5.buildNew(euclidean1DBSPTree10);
        double double12 = intervalsSet5.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        boolean boolean14 = intervalsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        double double15 = intervalsSet5.getSize();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion9);
        org.junit.Assert.assertNotNull(intervalsSet11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 3, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) (-1359791915), Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass7 = vector3D6.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        boolean boolean10 = vector3D8.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = plane11.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D13.normalize();
        org.apache.commons.math3.geometry.Space space16 = vector3D13.getSpace();
        boolean boolean17 = plane11.contains(vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D13);
        boolean boolean19 = plane5.isSimilarTo(plane18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        java.lang.String str23 = vector2D22.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        double double30 = vector2D24.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D28.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = vector2D22.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D35.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D38.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        double double41 = vector2D35.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D39.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D33.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) vector2D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = plane18.getPointAt(vector2D33, (-1024.0d));
        java.lang.String str49 = vector2D33.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D54.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        double double57 = vector2D51.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = vector2D55.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D62.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        java.lang.String str65 = vector2D64.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D66.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = vector2D69.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        double double72 = vector2D66.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = vector2D70.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = vector2D64.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = vector2D77.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D78);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = vector2D80.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double83 = vector2D77.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double84 = vector2D75.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        org.apache.commons.math3.geometry.Space space85 = vector2D81.getSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D89 = vector2D87.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D88);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (byte) 1, vector2D59, 4.9E-324d, vector2D81, (double) (-1.0f), vector2D88);
        double double91 = vector2D33.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D88);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(space16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{(NaN); (NaN)}" + "'", str23.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{(NaN); (NaN)}" + "'", str49.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "{(NaN); (NaN)}" + "'", str65.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertEquals((double) double83, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double84, Double.NaN, 0);
        org.junit.Assert.assertNotNull(space85);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertNotNull(vector2D89);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) (byte) 100);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray4, (double) (short) 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        double[][] doubleArray11 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray10, doubleArray11);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray4, doubleArray11);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, number2, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray11);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        boolean boolean4 = vector3D1.isInfinite();
        double double5 = vector3D1.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane6 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double16 = vector2D10.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D10.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane6.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-57.29577951308232d), vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D24.getZero();
        double[] doubleArray26 = vector2D25.toArray();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane7 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane5, euclidean2DRegion6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        boolean boolean10 = vector3D8.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = plane11.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D17.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D22.scalarMultiply(2.3978952727983707d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane26 = subPlane7.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane11);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(subPlane12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane26);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        boolean boolean9 = vector3D7.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane10.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        boolean boolean15 = vector3D12.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D0.add(3.141592653589793d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D0.getZero();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass1 = vector3D0.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.negate();
        boolean boolean4 = vector3D2.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = plane5.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.normalize();
        org.apache.commons.math3.geometry.Space space10 = vector3D7.getSpace();
        boolean boolean11 = plane5.contains(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = plane12.copySelf();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(space10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plane13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        double double5 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane6 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList2);
        boolean boolean4 = polyhedronsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D9);
        double double11 = vector3D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = plane15.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.normalize();
        org.apache.commons.math3.geometry.Space space20 = vector3D17.getSpace();
        boolean boolean21 = plane15.contains(vector3D17);
        plane15.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane23 = plane15.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D24.negate();
        boolean boolean26 = vector3D24.isInfinite();
        boolean boolean27 = vector3D24.isInfinite();
        double double28 = vector3D24.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24);
        org.apache.commons.math3.geometry.partitioning.Side side30 = subPlane23.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = plane29.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D32.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        double double35 = plane29.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        double double36 = vector3D9.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.partitioning.Region.Location location37 = polyhedronsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        double[] doubleArray38 = vector3D9.toArray();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(space20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(subPlane23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + side30 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side30.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + location37 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location37.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = spaceBSPTree0.split(spaceSubHyperplane1);
        org.junit.Assert.assertNotNull(spaceBSPTree2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 3.0517578E-5f, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5258789061315762E-5d + "'", double2 == 1.5258789061315762E-5d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (byte) 10, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math3.util.FastMath.log10(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        double double2 = vector3D0.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double4 = vector3D0.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        java.lang.String str5 = vector3D0.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        boolean boolean8 = vector3D6.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D6.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane13.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.normalize();
        org.apache.commons.math3.geometry.Space space18 = vector3D15.getSpace();
        boolean boolean19 = plane13.contains(vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D21.negate();
        boolean boolean23 = vector3D21.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane24.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.normalize();
        org.apache.commons.math3.geometry.Space space29 = vector3D26.getSpace();
        boolean boolean30 = plane24.contains(vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane24);
        boolean boolean32 = plane20.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, (double) ' ', (double) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D37.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D39.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D38.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D43.negate();
        boolean boolean45 = vector3D43.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D43.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D47.negate();
        boolean boolean49 = vector3D47.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = plane50.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D52.negate();
        boolean boolean54 = vector3D52.isInfinite();
        boolean boolean55 = vector3D52.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D57.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane59 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D56, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D39.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        plane31.reset(vector3D36, vector3D39);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D9, vector3D39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{-1; 0; 0}" + "'", str5.equals("{-1; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(space18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(space29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        plane3.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane3.wholeHyperplane();
        double double12 = subPlane11.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane13 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane14 = subPlane11.split(euclidean3DHyperplane13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean4 = vector1D2.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D8.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D8.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D5, (double) (-1), vector1D8, 0.0d, vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean20 = vector1D18.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean26 = vector1D24.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double28 = vector1D24.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        double double29 = vector1D24.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D21, (double) (-1), vector1D24, 0.0d, vector1D31);
        double double33 = vector1D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean39 = vector1D37.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double41 = vector1D37.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean45 = vector1D43.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        double double48 = vector1D43.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D40, (double) (-1), vector1D43, 0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double57 = vector1D53.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean61 = vector1D59.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double63 = vector1D59.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        double double64 = vector1D59.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D56, (double) (-1), vector1D59, 0.0d, vector1D66);
        double double68 = vector1D50.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean73 = vector1D71.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double75 = vector1D71.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean79 = vector1D77.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double81 = vector1D77.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D80);
        double double82 = vector1D77.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D74, (double) (-1), vector1D77, 0.0d, vector1D84);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2.3978952727983707d, vector1D56, 100.0d, vector1D85);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ONE;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D91 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(6.691673596021348E41d, vector1D21, (double) 0.0f, vector1D85, (double) 0.0f, vector1D88, 0.6483608274590866d, vector1D90);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D92 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        double double93 = vector1D88.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D92);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertNotNull(vector1D90);
        org.junit.Assert.assertNotNull(vector1D92);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 'a', 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean5 = vector1D3.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double7 = vector1D3.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean11 = vector1D9.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D9.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        double double14 = vector1D9.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D6, (double) (-1), vector1D9, 0.0d, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean27 = vector1D25.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double29 = vector1D25.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        double double30 = vector1D25.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D22, (double) (-1), vector1D25, 0.0d, vector1D32);
        double double34 = vector1D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean39 = vector1D37.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double41 = vector1D37.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean45 = vector1D43.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        double double48 = vector1D43.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D40, (double) (-1), vector1D43, 0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2.3978952727983707d, vector1D22, 100.0d, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 0, vector1D52);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D11.negate();
        boolean boolean13 = vector3D11.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = plane14.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.normalize();
        org.apache.commons.math3.geometry.Space space19 = vector3D16.getSpace();
        boolean boolean20 = plane14.contains(vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane14);
        boolean boolean22 = plane10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, (double) ' ', (double) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D27.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D29.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D28.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D33.negate();
        boolean boolean35 = vector3D33.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D33.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D37.negate();
        boolean boolean39 = vector3D37.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = plane40.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D42.negate();
        boolean boolean44 = vector3D42.isInfinite();
        boolean boolean45 = vector3D42.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D41.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D47.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D46, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D29.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D46);
        plane21.reset(vector3D26, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D52.negate();
        boolean boolean54 = vector3D52.isInfinite();
        boolean boolean55 = vector3D52.isInfinite();
        double double56 = vector3D52.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane57 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D59.negate();
        boolean boolean61 = vector3D59.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane62 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = plane62.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D64.negate();
        boolean boolean66 = vector3D64.isInfinite();
        boolean boolean67 = vector3D64.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D63.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D64);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D52.add(3.141592653589793d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        double double70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D29, vector3D69);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(space19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 19.739208802178716d + "'", double70 == 19.739208802178716d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 32L, (-1.359791915E9d), 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        double double3 = vector2D0.getNormInf();
        boolean boolean4 = vector2D0.isInfinite();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D7.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double22 = vector2D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D14, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D25.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D16.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D27.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment32 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D7, vector2D30, line31);
        java.text.NumberFormat numberFormat33 = null;
        java.lang.String str34 = vector2D30.toString(numberFormat33);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D36.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        double double42 = vector2D36.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = vector2D43.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D44, vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D50.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = vector2D53.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = vector2D56.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double59 = vector2D53.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D57.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D63.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D66.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = vector2D69.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        double double72 = vector2D66.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        double double73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D64, vector2D66);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = vector2D75.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D66.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = vector2D77.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line81 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment82 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D57, vector2D80, line81);
        java.text.NumberFormat numberFormat83 = null;
        java.lang.String str84 = vector2D80.toString(numberFormat83);
        org.apache.commons.math3.geometry.euclidean.twod.Line line85 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D50, vector2D80);
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment86 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D36, vector2D48, line85);
        boolean boolean87 = line35.isParallelTo(line85);
        org.apache.commons.math3.geometry.euclidean.twod.Line line88 = line35.copySelf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{(NaN); (NaN)}" + "'", str34.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "{(NaN); (NaN)}" + "'", str84.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(line88);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.negate();
        boolean boolean4 = vector3D1.isInfinite();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        double double6 = vector1D1.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean15 = vector1D13.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D13.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        double double24 = vector1D19.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D16, (double) (-1), vector1D19, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean31 = vector1D29.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double33 = vector1D29.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D32, (double) (-1), vector1D35, 0.0d, vector1D42);
        double double44 = vector1D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean48 = vector1D46.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double50 = vector1D46.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        double double51 = vector1D46.getX();
        double double52 = vector1D46.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D1, (double) 0.0f, vector1D8, (double) 0, vector1D26, (double) (-1.0f), vector1D46);
        double double54 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D53, true);
        boolean boolean57 = orientedPoint56.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet58 = orientedPoint56.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint59 = orientedPoint56.wholeHyperplane();
        double double60 = subOrientedPoint59.getSize();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(intervalsSet58);
        org.junit.Assert.assertNotNull(subOrientedPoint59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        double double6 = vector1D1.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean15 = vector1D13.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D13.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        double double24 = vector1D19.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D16, (double) (-1), vector1D19, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean31 = vector1D29.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double33 = vector1D29.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D32, (double) (-1), vector1D35, 0.0d, vector1D42);
        double double44 = vector1D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean48 = vector1D46.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double50 = vector1D46.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        double double51 = vector1D46.getX();
        double double52 = vector1D46.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D1, (double) 0.0f, vector1D8, (double) 0, vector1D26, (double) (-1.0f), vector1D46);
        double double54 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D53, true);
        boolean boolean57 = orientedPoint56.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean61 = vector1D59.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double63 = vector1D59.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean67 = vector1D65.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double69 = vector1D65.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        double double70 = vector1D65.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D62, (double) (-1), vector1D65, 0.0d, vector1D72);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean77 = vector1D75.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double79 = vector1D75.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D78);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D81 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean83 = vector1D81.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double85 = vector1D81.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D84);
        double double86 = vector1D81.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D89 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D78, (double) (-1), vector1D81, 0.0d, vector1D88);
        double double90 = vector1D72.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D78);
        java.lang.String str91 = vector1D72.toString();
        double double92 = orientedPoint56.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D72);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{0}" + "'", str91.equals("{0}"));
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass1 = vector3D0.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.negate();
        boolean boolean4 = vector3D2.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = plane5.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.normalize();
        org.apache.commons.math3.geometry.Space space10 = vector3D7.getSpace();
        boolean boolean11 = plane5.contains(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D7);
        double[] doubleArray13 = vector3D7.toArray();
        double[] doubleArray14 = vector3D7.toArray();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(space10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D2.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.Space space6 = vector3D3.getSpace();
        double double7 = vector3D3.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D9.negate();
        boolean boolean11 = vector3D9.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = plane12.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D14.negate();
        boolean boolean16 = vector3D14.isInfinite();
        boolean boolean17 = vector3D14.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D19.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray22 = vector3D21.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D20.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.Space space24 = vector3D21.getSpace();
        double double25 = vector3D21.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.negate();
        double double28 = vector3D26.getNormSq();
        double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D21, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        double double31 = vector3D30.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D34.negate();
        boolean boolean36 = vector3D34.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D34.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D39.negate();
        boolean boolean41 = vector3D39.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D39.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D43.negate();
        boolean boolean45 = vector3D43.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = plane46.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D48.negate();
        boolean boolean50 = vector3D48.isInfinite();
        boolean boolean51 = vector3D48.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D47.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D53.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D42, vector3D52, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = plane55.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line57 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D34, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.773121177104694d, vector3D3, (double) 1.4E-45f, vector3D30, 0.0d, vector3D34);
        double double59 = vector3D58.getAlpha();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(space6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(space24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-3.141592653589793d) + "'", double59 == (-3.141592653589793d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math3.util.FastMath.abs((-1.5309649148733797d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5309649148733797d + "'", double1 == 1.5309649148733797d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList2);
        boolean boolean4 = intervalsSet3.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        boolean boolean8 = intervalsSet7.isEmpty();
        double double9 = intervalsSet7.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform10 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion11 = intervalsSet7.applyTransform(euclidean1DTransform10);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = intervalsSet7.buildNew(euclidean1DBSPTree12);
        double double14 = intervalsSet7.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        boolean boolean16 = intervalsSet3.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = intervalsSet7.getTree(false);
        boolean boolean19 = intervalsSet1.isEmpty(euclidean1DBSPTree18);
        try {
            java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList20 = intervalsSet1.asList();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion11);
        org.junit.Assert.assertNotNull(intervalsSet13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) ' ', (long) (-1359791915));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1359791915), (float) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        boolean boolean2 = intervalsSet1.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(6.0d);
        org.apache.commons.math3.geometry.partitioning.Region.Location location5 = intervalsSet1.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        double double6 = vector1D4.getNorm();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + location5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location5.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.0d + "'", double6 == 6.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        double double3 = vector3D0.getY();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D0.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.negate();
        boolean boolean6 = vector3D4.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane7 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = plane7.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D9.negate();
        boolean boolean11 = vector3D9.isInfinite();
        boolean boolean12 = vector3D9.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D14.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D13, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = plane16.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D18.negate();
        boolean boolean20 = vector3D18.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = plane21.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D23.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.normalize();
        org.apache.commons.math3.geometry.Space space26 = vector3D23.getSpace();
        boolean boolean27 = plane21.contains(vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        boolean boolean30 = plane21.contains(vector3D29);
        boolean boolean31 = plane16.isSimilarTo(plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = plane16.getV();
        double double33 = vector3D32.getAlpha();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(space26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.141592653589793d + "'", double33 == 3.141592653589793d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList2);
        boolean boolean4 = intervalsSet3.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        boolean boolean8 = intervalsSet7.isEmpty();
        double double9 = intervalsSet7.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform10 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion11 = intervalsSet7.applyTransform(euclidean1DTransform10);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = intervalsSet7.buildNew(euclidean1DBSPTree12);
        double double14 = intervalsSet7.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        boolean boolean16 = intervalsSet3.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = intervalsSet7.getTree(false);
        boolean boolean19 = intervalsSet1.isEmpty(euclidean1DBSPTree18);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList20 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet21 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList20);
        boolean boolean22 = intervalsSet21.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane23 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList24 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet25 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList24);
        boolean boolean26 = intervalsSet25.isEmpty();
        double double27 = intervalsSet25.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform28 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion29 = intervalsSet25.applyTransform(euclidean1DTransform28);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet25.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet25.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint33 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane23, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        boolean boolean34 = intervalsSet21.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree36 = intervalsSet21.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet37 = intervalsSet1.buildNew(euclidean1DBSPTree36);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion11);
        org.junit.Assert.assertNotNull(intervalsSet13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion29);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree36);
        org.junit.Assert.assertNotNull(intervalsSet37);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        plane3.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane3.wholeHyperplane();
        double double12 = subPlane11.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane13 = subPlane11.copySelf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform14 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane15 = euclidean3DAbstractSubHyperplane13.applyTransform(euclidean3DTransform14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        plane3.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane3.wholeHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet13 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList12);
        double double14 = polyhedronsSet13.getBoundarySize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = plane18.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D20.normalize();
        org.apache.commons.math3.geometry.Space space23 = vector3D20.getSpace();
        boolean boolean24 = plane18.contains(vector3D20);
        plane18.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane26 = plane18.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane27 = polyhedronsSet13.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane26);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane28 = subPlane26.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane29 = subPlane26.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion30 = euclidean3DAbstractSubHyperplane29.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane3, euclidean2DRegion30);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(space23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(subPlane26);
        org.junit.Assert.assertNotNull(euclidean3DSubHyperplane27);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane28);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane29);
        org.junit.Assert.assertNotNull(euclidean2DRegion30);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        java.lang.String str3 = vector2D2.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.negate();
        boolean boolean6 = vector3D4.isInfinite();
        boolean boolean7 = vector3D4.isInfinite();
        double double8 = vector3D4.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass11 = vector3D10.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = plane15.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.normalize();
        org.apache.commons.math3.geometry.Space space20 = vector3D17.getSpace();
        boolean boolean21 = plane15.contains(vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10, vector3D17);
        boolean boolean23 = plane9.isSimilarTo(plane22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        java.lang.String str27 = vector2D26.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D28.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D31.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double34 = vector2D28.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D32.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D26.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D42.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D43.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D37.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = plane22.getPointAt(vector2D37, (-1024.0d));
        double double53 = vector2D2.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        double double54 = vector2D2.getNorm1();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(NaN); (NaN)}" + "'", str3.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(space20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{(NaN); (NaN)}" + "'", str27.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 1074266112, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        double double2 = vector3D0.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double4 = vector3D0.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList5 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet6 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList5);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList7 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList7);
        boolean boolean9 = polyhedronsSet6.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        boolean boolean13 = vector3D10.isInfinite();
        double double14 = vector3D10.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation15 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet16 = polyhedronsSet6.rotate(vector3D10, rotation15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        double double20 = vector3D10.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double21 = vector3D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass7 = vector3D6.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        boolean boolean10 = vector3D8.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = plane11.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D13.normalize();
        org.apache.commons.math3.geometry.Space space16 = vector3D13.getSpace();
        boolean boolean17 = plane11.contains(vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D13);
        boolean boolean19 = plane5.isSimilarTo(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        boolean boolean22 = vector3D20.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D20.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D24.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree27 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector3D24);
        plane18.reset(vector3D20, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.negate();
        boolean boolean31 = vector3D29.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane32.getV();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = plane32.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D36.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D42.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D43.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D49.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = vector2D52.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = vector2D52.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D50, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D61.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D52.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = vector2D63.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line67 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment68 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D43, vector2D66, line67);
        java.text.NumberFormat numberFormat69 = null;
        java.lang.String str70 = vector2D66.toString(numberFormat69);
        org.apache.commons.math3.geometry.euclidean.twod.Line line71 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D36, vector2D66);
        boolean boolean72 = vector2D66.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = plane35.getPointAt(vector2D66, (double) 1.0f);
        plane18.reset(plane35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D76.negate();
        boolean boolean78 = vector3D76.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane79 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D76);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = plane79.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = vector3D81.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D81.normalize();
        org.apache.commons.math3.geometry.Space space84 = vector3D81.getSpace();
        boolean boolean85 = plane79.contains(vector3D81);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane86 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane79);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = plane79.getOrigin();
        boolean boolean88 = plane18.isSimilarTo(plane79);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(space16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(polyhedronsSet34);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{(NaN); (NaN)}" + "'", str70.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(space84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList0);
        double double2 = polyhedronsSet1.getBoundarySize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.negate();
        boolean boolean5 = vector3D3.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane6 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = plane6.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D8.normalize();
        org.apache.commons.math3.geometry.Space space11 = vector3D8.getSpace();
        boolean boolean12 = plane6.contains(vector3D8);
        plane6.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane14 = plane6.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane15 = polyhedronsSet1.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane14);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion17 = polyhedronsSet1.applyTransform(euclidean3DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree19 = euclidean3DAbstractRegion17.getTree(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(space11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(subPlane14);
        org.junit.Assert.assertNotNull(euclidean3DSubHyperplane15);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double11 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        double double12 = vector1D7.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D4, (double) (-1), vector1D7, 0.0d, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double21 = vector1D17.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean25 = vector1D23.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        double double28 = vector1D23.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D20, (double) (-1), vector1D23, 0.0d, vector1D30);
        double double32 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean44 = vector1D42.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean49 = vector1D47.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D47.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double57 = vector1D53.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        double double58 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D50, (double) (-1), vector1D53, 0.0d, vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean65 = vector1D63.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double67 = vector1D63.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean71 = vector1D69.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double73 = vector1D69.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D72);
        double double74 = vector1D69.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D66, (double) (-1), vector1D69, 0.0d, vector1D76);
        double double78 = vector1D60.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean82 = vector1D80.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double84 = vector1D80.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D83);
        double double85 = vector1D80.getX();
        double double86 = vector1D80.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D35, (double) 0.0f, vector1D42, (double) 0, vector1D60, (double) (-1.0f), vector1D80);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = vector1D14.subtract((double) (-1), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D90 = vector1D35.scalarMultiply((double) 10.000001f);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertNotNull(vector1D90);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.594700892207039d + "'", double1 == 4.594700892207039d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int[] intArray6 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6, 0);
        int[] intArray15 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15, 0);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray15);
        int[] intArray19 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15);
        int[] intArray21 = org.apache.commons.math3.util.MathArrays.copyOf(intArray19, 0);
        int[] intArray28 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray30 = org.apache.commons.math3.util.MathArrays.copyOf(intArray28, 0);
        int[] intArray37 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray39 = org.apache.commons.math3.util.MathArrays.copyOf(intArray37, 0);
        double double40 = org.apache.commons.math3.util.MathArrays.distance(intArray30, intArray37);
        int int41 = org.apache.commons.math3.util.MathArrays.distance1(intArray19, intArray37);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D4, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D2, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double20 = vector2D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D18.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double33 = vector2D27.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D36.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D27.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D38.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment43 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D18, vector2D41, line42);
        java.text.NumberFormat numberFormat44 = null;
        java.lang.String str45 = vector2D41.toString(numberFormat44);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line46);
        org.apache.commons.math3.geometry.partitioning.Side side48 = subLine10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D49.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = vector2D52.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = vector2D52.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = vector2D56.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D62.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D65.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D66);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = vector2D68.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D69);
        double double71 = vector2D65.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D69);
        double double72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D63, vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = vector2D74.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = vector2D65.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = vector2D76.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line80 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment81 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D56, vector2D79, line80);
        java.text.NumberFormat numberFormat82 = null;
        java.lang.String str83 = vector2D79.toString(numberFormat82);
        org.apache.commons.math3.geometry.euclidean.twod.Line line84 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D49, vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Line line85 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line84);
        boolean boolean86 = line46.isParallelTo(line85);
        org.apache.commons.math3.geometry.euclidean.twod.Line line87 = null;
        try {
            double double88 = line46.getOffset(line87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{(NaN); (NaN)}" + "'", str45.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + side48 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side48.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "{(NaN); (NaN)}" + "'", str83.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double6 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D4.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double19 = vector2D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D11, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D22.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D13.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D24.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line28 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment29 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D4, vector2D27, line28);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine30 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(segment29);
        org.apache.commons.math3.geometry.euclidean.twod.Line line31 = segment29.getLine();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNull(line31);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.normalize();
        double double9 = plane5.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = plane5.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane5.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion12 = subPlane11.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertNotNull(euclidean2DRegion12);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass1 = vector3D0.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.negate();
        boolean boolean4 = vector3D2.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = plane5.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.normalize();
        org.apache.commons.math3.geometry.Space space10 = vector3D7.getSpace();
        boolean boolean11 = plane5.contains(vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D7);
        double[] doubleArray13 = vector3D7.toArray();
        boolean boolean14 = vector3D7.isInfinite();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(space10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList0);
        double double2 = polyhedronsSet1.getBoundarySize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree4 = polyhedronsSet1.getTree(true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        boolean boolean7 = vector3D5.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = plane8.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        boolean boolean13 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D9.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray18 = vector3D17.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.Space space20 = vector3D17.getSpace();
        double double21 = vector3D17.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D22.negate();
        double double24 = vector3D22.getNormSq();
        double double25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D17, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet27 = polyhedronsSet1.translate(vector3D26);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList28 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet29 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList28);
        double double30 = polyhedronsSet29.getBoundarySize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree32 = polyhedronsSet29.getTree(true);
        boolean boolean33 = polyhedronsSet27.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(space20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(polyhedronsSet27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1018167296 + "'", int1 == 1018167296);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 0, 30.41592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.41592653589793d + "'", double2 == 30.41592653589793d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D1.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        double double4 = vector2D3.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 100.0f, vector2D3, (double) (-2081393569), vector2D7, 1.5309649148733797d, vector2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection11, false, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[][] doubleArray17 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray16, doubleArray17);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, orderDirection11, doubleArray17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (byte) 100);
        double double24 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 5729.5779513082325d);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (byte) 1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray30 = vector3D29.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray32 = vector3D31.toArray();
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray36 = vector3D35.toArray();
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray34, doubleArray36);
        double double38 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray30, doubleArray34);
        double double39 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray26, doubleArray30);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (5,729.578 >= -0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-5729.5779513082325d) + "'", double39 == (-5729.5779513082325d));
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) -1, (int) '#');
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (-1272213960));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.27221389E9f) + "'", float1 == (-1.27221389E9f));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        try {
            double double4 = polygonsSet3.getSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(polygonsSet3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        double double6 = vector1D1.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean15 = vector1D13.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D13.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        double double24 = vector1D19.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D16, (double) (-1), vector1D19, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean31 = vector1D29.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double33 = vector1D29.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D32, (double) (-1), vector1D35, 0.0d, vector1D42);
        double double44 = vector1D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean48 = vector1D46.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double50 = vector1D46.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        double double51 = vector1D46.getX();
        double double52 = vector1D46.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D1, (double) 0.0f, vector1D8, (double) 0, vector1D26, (double) (-1.0f), vector1D46);
        double double54 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D53, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = vector1D53.negate();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D57);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        boolean boolean8 = vector3D6.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D6.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane13.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        boolean boolean18 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D19, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine25 = line24.wholeLine();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList26 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet27 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList26);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList28 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet29 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList28);
        boolean boolean30 = polyhedronsSet27.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D31.negate();
        boolean boolean33 = vector3D31.isInfinite();
        boolean boolean34 = vector3D31.isInfinite();
        double double35 = vector3D31.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation36 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet37 = polyhedronsSet27.rotate(vector3D31, rotation36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        double double41 = vector3D31.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = line24.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Line line43 = line24.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = null;
        try {
            double double45 = line43.getAbscissa(vector3D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subLine25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(line43);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) (short) 0);
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double6 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D4.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        double double16 = vector2D10.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D14.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D9, vector2D19);
        double double21 = vector2D9.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = null;
        try {
            double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D9, vector2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        boolean boolean7 = vector3D5.isInfinite();
        boolean boolean8 = vector3D5.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        double double10 = vector3D4.getX();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D3.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D14.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        java.lang.String str22 = vector2D21.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D23.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double29 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D27.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D21.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D34.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D37.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double40 = vector2D34.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double41 = vector2D32.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D14.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.Space space43 = vector2D38.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{(NaN); (NaN)}" + "'", str22.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(space43);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D4, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D2, vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double20 = vector2D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D18.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double33 = vector2D27.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D36.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D27.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D38.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line42 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment43 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D18, vector2D41, line42);
        java.text.NumberFormat numberFormat44 = null;
        java.lang.String str45 = vector2D41.toString(numberFormat44);
        org.apache.commons.math3.geometry.euclidean.twod.Line line46 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line46);
        org.apache.commons.math3.geometry.partitioning.Side side48 = subLine10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = vector2D49.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = vector2D52.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = vector2D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D53, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine59 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D51, vector2D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = vector2D60.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = vector2D63.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = vector2D66.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double69 = vector2D63.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = vector2D67.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = vector2D73.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = vector2D76.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = vector2D79.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D80);
        double double82 = vector2D76.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D80);
        double double83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D74, vector2D76);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D86 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = vector2D85.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D86);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = vector2D76.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = vector2D87.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line91 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment92 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D67, vector2D90, line91);
        java.text.NumberFormat numberFormat93 = null;
        java.lang.String str94 = vector2D90.toString(numberFormat93);
        org.apache.commons.math3.geometry.euclidean.twod.Line line95 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D60, vector2D90);
        org.apache.commons.math3.geometry.euclidean.twod.Line line96 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line95);
        org.apache.commons.math3.geometry.partitioning.Side side97 = subLine59.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line95);
        double double98 = line46.getOffset(line95);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{(NaN); (NaN)}" + "'", str45.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + side48 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side48.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double83, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertNotNull(vector2D86);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertNotNull(vector2D90);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "{(NaN); (NaN)}" + "'", str94.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertTrue("'" + side97 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side97.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
        org.junit.Assert.assertEquals((double) double98, Double.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double6 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D0.negate();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector8 = null;
        try {
            double double9 = vector2D7.dotProduct(euclidean2DVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        java.text.NumberFormat numberFormat1 = null;
        try {
            java.lang.String str2 = vector3D0.toString(numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (byte) 1, (-1272213960), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        plane3.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane3.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        boolean boolean15 = vector3D12.isInfinite();
        double double16 = vector3D12.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.partitioning.Side side18 = subPlane11.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D19.negate();
        boolean boolean21 = vector3D19.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getV();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet24 = plane22.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane25 = subPlane11.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane22);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList26 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet27 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList26);
        double double28 = polyhedronsSet27.getBoundarySize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.negate();
        boolean boolean31 = vector3D29.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane32.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D34.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.normalize();
        org.apache.commons.math3.geometry.Space space37 = vector3D34.getSpace();
        boolean boolean38 = plane32.contains(vector3D34);
        plane32.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane40 = plane32.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane41 = polyhedronsSet27.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane40);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane42 = subPlane40.copySelf();
        boolean boolean43 = euclidean3DAbstractSubHyperplane42.isEmpty();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane44 = subPlane11.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane42);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + side18 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side18.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(polyhedronsSet24);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(space37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(subPlane40);
        org.junit.Assert.assertNotNull(euclidean3DSubHyperplane41);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane44);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection4, false, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray9 = vector3D8.toArray();
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray9, orderDirection12, false, true);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection12, true, false);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray23 = vector3D22.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray25 = vector3D24.toArray();
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray29 = vector3D28.toArray();
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray27, doubleArray29);
        double double31 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray23, doubleArray27);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray35 = vector3D34.toArray();
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35, (int) (byte) 100);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray35, (double) (short) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection40 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray35, orderDirection40, false, false);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray23, orderDirection40, true, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException48 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1023L), (java.lang.Number) 1.0848689673994147d, (int) (byte) 10, orderDirection40, false);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection40, false, true);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D2.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D2);
        java.text.NumberFormat numberFormat6 = null;
        try {
            java.lang.String str7 = vector3D1.toString(numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D4, vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine10 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D2, vector2D4);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane11 = subLine10.getHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D16, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D14, vector2D16);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane23 = subLine22.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane24 = subLine10.split(euclidean2DHyperplane23);
        boolean boolean25 = subLine10.isEmpty();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DHyperplane11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean2DHyperplane23);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 9.765625E-4f, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) (short) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection6, false, false);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) (short) 10);
        double[] doubleArray17 = new double[] { 52.0d, 4.594700892207039d, (-10), (-3.2188144992860074E19d), 3.111507638930571E-61d };
        double double18 = org.apache.commons.math3.util.MathArrays.distance(doubleArray11, doubleArray17);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 43.417868168403295d + "'", double18 == 43.417868168403295d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass7 = vector3D6.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        boolean boolean10 = vector3D8.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = plane11.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D13.normalize();
        org.apache.commons.math3.geometry.Space space16 = vector3D13.getSpace();
        boolean boolean17 = plane11.contains(vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D13);
        boolean boolean19 = plane5.isSimilarTo(plane18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        java.lang.String str23 = vector2D22.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        double double30 = vector2D24.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D28.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = vector2D22.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D35.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = vector2D38.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        double double41 = vector2D35.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D39.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D33.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) vector2D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = plane18.getPointAt(vector2D33, (-1024.0d));
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane18);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(space16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{(NaN); (NaN)}" + "'", str23.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D48);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        boolean boolean2 = intervalsSet1.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane3 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList4 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList4);
        boolean boolean6 = intervalsSet5.isEmpty();
        double double7 = intervalsSet5.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform8 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion9 = intervalsSet5.applyTransform(euclidean1DTransform8);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = intervalsSet5.buildNew(euclidean1DBSPTree10);
        double double12 = intervalsSet5.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        boolean boolean14 = intervalsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        double double15 = intervalsSet1.getSize();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) double15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion9);
        org.junit.Assert.assertNotNull(intervalsSet11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math3.util.FastMath.min(2.0d, (double) (-1023L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1023.0d) + "'", double2 == (-1023.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList2);
        boolean boolean4 = polyhedronsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        boolean boolean7 = vector3D5.isInfinite();
        boolean boolean8 = vector3D5.isInfinite();
        double double9 = vector3D5.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation10 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet11 = polyhedronsSet1.rotate(vector3D5, rotation10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D12.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        double double15 = vector3D5.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) ' ', vector3D20);
        double double22 = vector3D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D23.negate();
        boolean boolean25 = vector3D23.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane26.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D28.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.normalize();
        org.apache.commons.math3.geometry.Space space31 = vector3D28.getSpace();
        boolean boolean32 = plane26.contains(vector3D28);
        plane26.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane34 = plane26.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D35.negate();
        boolean boolean37 = vector3D35.isInfinite();
        boolean boolean38 = vector3D35.isInfinite();
        double double39 = vector3D35.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35);
        org.apache.commons.math3.geometry.partitioning.Side side41 = subPlane34.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = plane40.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D43.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        double double46 = plane40.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        double double47 = vector3D20.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        double double48 = vector3D44.getNorm1();
        double double49 = vector3D12.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(space31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(subPlane34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + side41 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side41.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathInternalError1.getContext();
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (byte) 100);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) (short) 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray14 = vector3D13.toArray();
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray14, doubleArray15);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, doubleArray15);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 2.0d, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError1, localizable3, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray15);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double6 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double23 = vector2D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D21.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D33.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D30.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D30.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment46 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D21, vector2D44, line45);
        java.text.NumberFormat numberFormat47 = null;
        java.lang.String str48 = vector2D44.toString(numberFormat47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line49 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment50 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D12, line49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = segment50.getStart();
        double[] doubleArray52 = vector2D51.toArray();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{(NaN); (NaN)}" + "'", str48.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-1.0d), 0.018934535433830814d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D0.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.negate();
        boolean boolean6 = vector3D4.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane7 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = plane7.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D9.negate();
        boolean boolean11 = vector3D9.isInfinite();
        boolean boolean12 = vector3D9.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D14.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D13, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = plane16.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D18.negate();
        boolean boolean20 = vector3D18.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = plane21.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D23.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D23.normalize();
        org.apache.commons.math3.geometry.Space space26 = vector3D23.getSpace();
        boolean boolean27 = plane21.contains(vector3D23);
        plane21.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane29 = plane21.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D30.negate();
        boolean boolean32 = vector3D30.isInfinite();
        boolean boolean33 = vector3D30.isInfinite();
        double double34 = vector3D30.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane35 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30);
        org.apache.commons.math3.geometry.partitioning.Side side36 = subPlane29.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = plane35.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        double double41 = plane35.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D42.negate();
        boolean boolean44 = vector3D42.isInfinite();
        boolean boolean45 = vector3D42.isInfinite();
        double double46 = vector3D42.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane47 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = plane35.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        plane16.reset(plane35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D50.negate();
        boolean boolean52 = vector3D50.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = plane53.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D55.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D55.normalize();
        org.apache.commons.math3.geometry.Space space58 = vector3D55.getSpace();
        boolean boolean59 = plane53.contains(vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = vector3D61.negate();
        boolean boolean63 = vector3D61.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane64 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = plane64.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D66.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D66.normalize();
        org.apache.commons.math3.geometry.Space space69 = vector3D66.getSpace();
        boolean boolean70 = plane64.contains(vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane71 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane64);
        boolean boolean72 = plane60.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane71);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = vector2D73.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D74);
        java.lang.String str76 = vector2D75.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D77 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = vector2D77.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D78);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = vector2D80.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double83 = vector2D77.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D86 = vector2D81.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = vector2D75.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = plane60.getPointAt(vector2D86, (double) 10.0f);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D91 = plane16.getPointAt(vector2D86, (double) 9.765625E-4f);
        plane16.revertSelf();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(space26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(subPlane29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + side36 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side36.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(space58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(space69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "{(NaN); (NaN)}" + "'", str76.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertNotNull(vector2D82);
        org.junit.Assert.assertEquals((double) double83, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertNotNull(vector2D86);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector3D89);
        org.junit.Assert.assertNotNull(vector3D91);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(30.41592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.515063602162529d + "'", double1 == 5.515063602162529d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        java.lang.String str3 = vector2D2.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double10 = vector2D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D8.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D2.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = vector2D15.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double22 = vector2D13.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D19.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double27 = vector2D26.getNorm1();
        double double28 = vector2D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(NaN); (NaN)}" + "'", str3.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        java.lang.String str3 = vector2D2.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.negate();
        boolean boolean6 = vector3D4.isInfinite();
        boolean boolean7 = vector3D4.isInfinite();
        double double8 = vector3D4.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        java.lang.Class<?> wildcardClass11 = vector3D10.getClass();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = plane15.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.normalize();
        org.apache.commons.math3.geometry.Space space20 = vector3D17.getSpace();
        boolean boolean21 = plane15.contains(vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10, vector3D17);
        boolean boolean23 = plane9.isSimilarTo(plane22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        java.lang.String str27 = vector2D26.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D28.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D31.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double34 = vector2D28.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = vector2D32.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D26.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D42.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double45 = vector2D39.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = vector2D43.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        double double49 = vector2D37.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D47);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) vector2D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = plane22.getPointAt(vector2D37, (-1024.0d));
        double double53 = vector2D2.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DVector54 = null;
        try {
            double double55 = vector2D37.distance1(euclidean2DVector54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{(NaN); (NaN)}" + "'", str3.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(space20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{(NaN); (NaN)}" + "'", str27.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double12 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray8);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) (byte) 100);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray16, (double) (short) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection21, false, false);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection21, true, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1023L), (java.lang.Number) 1.0848689673994147d, (int) (byte) 10, orderDirection21, false);
        int int30 = nonMonotonicSequenceException29.getIndex();
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException34 = new org.apache.commons.math3.exception.NullArgumentException(localizable32, objArray33);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonicSequenceException29, localizable31, objArray33);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean9 = vector1D7.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double11 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        double double12 = vector1D7.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D4, (double) (-1), vector1D7, 0.0d, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean19 = vector1D17.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double21 = vector1D17.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean25 = vector1D23.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        double double28 = vector1D23.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D20, (double) (-1), vector1D23, 0.0d, vector1D30);
        double double32 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean44 = vector1D42.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean49 = vector1D47.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D47.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean55 = vector1D53.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double57 = vector1D53.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        double double58 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D50, (double) (-1), vector1D53, 0.0d, vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean65 = vector1D63.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double67 = vector1D63.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean71 = vector1D69.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double73 = vector1D69.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D72);
        double double74 = vector1D69.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D66, (double) (-1), vector1D69, 0.0d, vector1D76);
        double double78 = vector1D60.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean82 = vector1D80.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double84 = vector1D80.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D83);
        double double85 = vector1D80.getX();
        double double86 = vector1D80.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D87 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D35, (double) 0.0f, vector1D42, (double) 0, vector1D60, (double) (-1.0f), vector1D80);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D88 = vector1D14.subtract((double) (-1), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        double double89 = vector1D14.getNormInf();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(vector1D83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math3.util.FastMath.signum(60440.54486402465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) '#', (double) (-10), (double) (byte) 1, 1.0000000000000002d, (double) 97.0f, (double) (byte) 0, (double) '#', 2.422048691767486d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-264.228295788138d) + "'", double8 == (-264.228295788138d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        double double6 = vector1D1.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean15 = vector1D13.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D13.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        double double24 = vector1D19.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D16, (double) (-1), vector1D19, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean31 = vector1D29.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double33 = vector1D29.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D32, (double) (-1), vector1D35, 0.0d, vector1D42);
        double double44 = vector1D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean48 = vector1D46.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double50 = vector1D46.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        double double51 = vector1D46.getX();
        double double52 = vector1D46.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D1, (double) 0.0f, vector1D8, (double) 0, vector1D26, (double) (-1.0f), vector1D46);
        double double54 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D53, true);
        boolean boolean57 = orientedPoint56.isDirect();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList58 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet59 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList58);
        boolean boolean60 = intervalsSet59.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane61 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList62 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet63 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList62);
        boolean boolean64 = intervalsSet63.isEmpty();
        double double65 = intervalsSet63.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform66 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion67 = intervalsSet63.applyTransform(euclidean1DTransform66);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree68 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet69 = intervalsSet63.buildNew(euclidean1DBSPTree68);
        double double70 = intervalsSet63.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint71 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane61, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet63);
        boolean boolean72 = intervalsSet59.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet63);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint73 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint56, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet63);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.NEGATIVE_INFINITY + "'", double65 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion67);
        org.junit.Assert.assertNotNull(intervalsSet69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        plane3.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane3.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        boolean boolean15 = vector3D12.isInfinite();
        double double16 = vector3D12.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.partitioning.Side side18 = subPlane11.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D19.negate();
        boolean boolean21 = vector3D19.isInfinite();
        boolean boolean22 = vector3D19.isInfinite();
        double double23 = vector3D19.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.negate();
        boolean boolean28 = vector3D26.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane29.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D31.negate();
        boolean boolean33 = vector3D31.isInfinite();
        boolean boolean34 = vector3D31.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D19.add(3.141592653589793d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D39.negate();
        boolean boolean41 = vector3D39.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = plane42.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D44.negate();
        boolean boolean46 = vector3D44.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D44.getZero();
        double double48 = plane42.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 1, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D35.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D51.negate();
        boolean boolean53 = vector3D51.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane54 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = plane54.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D56.negate();
        boolean boolean58 = vector3D56.isInfinite();
        boolean boolean59 = vector3D56.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D55.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        plane17.reset(vector3D44, vector3D55);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + side18 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side18.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(vector3D60);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.negate();
        boolean boolean5 = vector3D3.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D3.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        boolean boolean10 = vector3D8.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D8.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.negate();
        boolean boolean14 = vector3D12.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = plane15.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.negate();
        boolean boolean19 = vector3D17.isInfinite();
        boolean boolean20 = vector3D17.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D22.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11, vector3D21, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane24.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D3, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine27 = line26.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.negate();
        boolean boolean31 = vector3D29.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D29.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D34.negate();
        boolean boolean36 = vector3D34.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D34.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D38.negate();
        boolean boolean40 = vector3D38.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = plane41.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D43.negate();
        boolean boolean45 = vector3D43.isInfinite();
        boolean boolean46 = vector3D43.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D42.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D48.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37, vector3D47, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = plane50.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line52 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D29, vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D53.negate();
        double double55 = vector3D53.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = line52.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = line26.intersection(line52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D0.subtract((double) 10.000001f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(subLine27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 0, (int) (byte) 100);
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray5 = polygonsSet4.getVertices();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException2, localizable3, (java.lang.Object[]) vector2DArray5);
        int int7 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertNotNull(vector2DArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.8135279227115655d), (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8135279227115654d) + "'", double2 == (-0.8135279227115654d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math3.util.FastMath.log10((-0.9251475365964139d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        boolean boolean2 = intervalsSet1.isEmpty();
        double double3 = intervalsSet1.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform4 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet1.applyTransform(euclidean1DTransform4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet1.buildNew(euclidean1DBSPTree6);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion8 = intervalsSet1.copySelf();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane4 = plane3.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane5 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane6 = subPlane4.reunite(euclidean3DSubHyperplane5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(subPlane4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(99.00000000000004d, (-57.29577951308232d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList1 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList1);
        boolean boolean3 = intervalsSet2.isEmpty();
        double double4 = intervalsSet2.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform5 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet2.applyTransform(euclidean1DTransform5);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree7 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = intervalsSet2.buildNew(euclidean1DBSPTree7);
        double double9 = intervalsSet2.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet2);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane11 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList12);
        boolean boolean14 = intervalsSet13.isEmpty();
        double double15 = intervalsSet13.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet13.applyTransform(euclidean1DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = intervalsSet13.buildNew(euclidean1DBSPTree18);
        double double20 = intervalsSet13.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint21 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet13);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane22 = subOrientedPoint10.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint21);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane23 = subOrientedPoint10.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion24 = euclidean1DAbstractSubHyperplane23.getRemainingRegion();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion6);
        org.junit.Assert.assertNotNull(intervalsSet8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertNotNull(intervalsSet19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane23);
        org.junit.Assert.assertNotNull(euclidean1DRegion24);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D1);
        double double6 = vector3D5.getNorm1();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D2);
        org.apache.commons.math3.geometry.Space space5 = vector3D2.getSpace();
        double double6 = vector3D2.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.negate();
        double double9 = vector3D7.getNormSq();
        double double10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D2, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D11.negate();
        boolean boolean13 = vector3D11.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = plane14.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.negate();
        boolean boolean18 = vector3D16.isInfinite();
        boolean boolean19 = vector3D16.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D21.negate();
        boolean boolean23 = vector3D21.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane24.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.negate();
        boolean boolean28 = vector3D26.isInfinite();
        boolean boolean29 = vector3D26.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D25.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        double double31 = vector3D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane32.getNormal();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(space5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D33);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        boolean boolean8 = vector3D6.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D6.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane13.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        boolean boolean18 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D19, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D1.normalize();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D3.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D3.getZero();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2227587494850775E-162d + "'", double1 == 2.2227587494850775E-162d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.773121177104694d, (java.lang.Number) 10.0f, (-1272213960));
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1272213960) + "'", int4 == (-1272213960));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int[] intArray6 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray8 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6, 0);
        int[] intArray15 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15, 0);
        double double18 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray15);
        int[] intArray19 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15);
        int[] intArray20 = org.apache.commons.math3.util.MathArrays.copyOf(intArray19);
        int[] intArray27 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray29 = org.apache.commons.math3.util.MathArrays.copyOf(intArray27, 0);
        int[] intArray36 = new int[] { 3, (byte) 1, 3, 10, (short) 0, (byte) 10 };
        int[] intArray38 = org.apache.commons.math3.util.MathArrays.copyOf(intArray36, 0);
        double double39 = org.apache.commons.math3.util.MathArrays.distance(intArray29, intArray36);
        int[] intArray40 = org.apache.commons.math3.util.MathArrays.copyOf(intArray36);
        int[] intArray41 = org.apache.commons.math3.util.MathArrays.copyOf(intArray40);
        int int42 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray20, intArray40);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray2 = vector3D1.toArray();
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, (int) (byte) 100);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray2, (double) (short) 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double[][] doubleArray9 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, doubleArray9);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray2, doubleArray9);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        double double11 = plane3.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        double double18 = vector2D12.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D16.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D21.scalarMultiply(2.3978952727983707d);
        double double24 = vector2D21.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane3.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D25);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = vector2D1.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        double double7 = vector2D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D5.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D11.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double17 = vector2D11.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D15.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D10, vector2D20);
        double double22 = vector2D10.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray27 = vector3D26.toArray();
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (byte) 100);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple30 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D31.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D34.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D37.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D35, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D33, vector2D35);
        boolean boolean42 = orderedTuple30.equals((java.lang.Object) vector2D33);
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(4.9E-324d, vector2D10, (double) 1L, vector2D24, 11.009431976351623d, vector2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.negate();
        boolean boolean5 = vector3D3.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane6 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D8.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray11 = vector3D10.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D9.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.Space space13 = vector3D10.getSpace();
        double double14 = vector3D10.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        double double17 = vector3D15.getNormSq();
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D10, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D19.negate();
        boolean boolean21 = vector3D19.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D24.negate();
        boolean boolean26 = vector3D24.isInfinite();
        boolean boolean27 = vector3D24.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D23.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.negate();
        boolean boolean31 = vector3D29.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = plane32.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D34.negate();
        boolean boolean36 = vector3D34.isInfinite();
        boolean boolean37 = vector3D34.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D33.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        double double39 = vector3D28.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D42.negate();
        boolean boolean44 = vector3D42.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = plane45.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D47.negate();
        boolean boolean49 = vector3D47.isInfinite();
        boolean boolean50 = vector3D47.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D52.negate();
        boolean boolean54 = vector3D52.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane55 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = plane55.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D57.negate();
        boolean boolean59 = vector3D57.isInfinite();
        boolean boolean60 = vector3D57.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = vector3D56.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        double double62 = vector3D51.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D51, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1.0000000000000002d, vector3D3, (double) (-1359791915), vector3D10, (double) 1L, vector3D51);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Line line66 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(space13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.5707963267948966d + "'", double64 == 1.5707963267948966d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double6 = vector2D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D10.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D17.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = vector2D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double23 = vector2D17.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D21.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = vector2D27.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D33.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double36 = vector2D30.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D30.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D41.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment46 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D21, vector2D44, line45);
        java.text.NumberFormat numberFormat47 = null;
        java.lang.String str48 = vector2D44.toString(numberFormat47);
        org.apache.commons.math3.geometry.euclidean.twod.Line line49 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, vector2D44);
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment50 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D0, vector2D12, line49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = segment50.getStart();
        org.apache.commons.math3.geometry.euclidean.twod.Line line52 = segment50.getLine();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{(NaN); (NaN)}" + "'", str48.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(line52);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        boolean boolean8 = vector3D6.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D6.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane13.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        boolean boolean18 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D19, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D1.scalarMultiply((double) 100.0f);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D27.negate();
        double double29 = vector3D26.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.0d + "'", double29 == 99.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean3 = vector1D1.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D1.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        double double6 = vector1D1.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean10 = vector1D8.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean15 = vector1D13.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D13.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean21 = vector1D19.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        double double24 = vector1D19.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D16, (double) (-1), vector1D19, 0.0d, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean31 = vector1D29.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double33 = vector1D29.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean37 = vector1D35.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D35.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        double double40 = vector1D35.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1, vector1D32, (double) (-1), vector1D35, 0.0d, vector1D42);
        double double44 = vector1D26.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean48 = vector1D46.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double50 = vector1D46.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        double double51 = vector1D46.getX();
        double double52 = vector1D46.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(555.0d, vector1D1, (double) 0.0f, vector1D8, (double) 0, vector1D26, (double) (-1.0f), vector1D46);
        double double54 = vector1D53.getX();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D53, true);
        boolean boolean57 = orientedPoint56.isDirect();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint58 = orientedPoint56.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint59 = orientedPoint58.copySelf();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(orientedPoint58);
        org.junit.Assert.assertNotNull(orientedPoint59);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray3 = vector3D2.toArray();
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3, orderDirection6, false, true);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math3.exception.NullArgumentException(localizable12, objArray13);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-1L), objArray13);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) boolean9, localizable10, objArray13);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException17 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray13);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (byte) -1, objArray13);
        java.lang.Throwable[] throwableArray19 = notFiniteNumberException18.getSuppressed();
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        boolean boolean7 = vector3D5.isInfinite();
        boolean boolean8 = vector3D5.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector10 = null;
        try {
            double double11 = vector3D5.distanceSq(euclidean3DVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        boolean boolean8 = vector3D6.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D6.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane13.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        boolean boolean18 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D19, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine25 = line24.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D27.negate();
        boolean boolean29 = vector3D27.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D27.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D32.negate();
        boolean boolean34 = vector3D32.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D32.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = vector3D36.negate();
        boolean boolean38 = vector3D36.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = plane39.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D41.negate();
        boolean boolean43 = vector3D41.isInfinite();
        boolean boolean44 = vector3D41.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D40.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D46.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane48 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D45, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = plane48.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line50 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D27, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D51.negate();
        double double53 = vector3D51.getNormSq();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = line50.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = line24.intersection(line50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = line24.pointAt((double) 1.1920929E-7f);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D57.getZero();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subLine25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D2.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = vector2D5.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = vector2D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double11 = vector2D5.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        double double12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D3, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D5.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = vector2D16.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D21.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        java.lang.String str24 = vector2D23.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = vector2D25.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D28.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        double double31 = vector2D25.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = vector2D29.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D23.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = vector2D36.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D39.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        double double42 = vector2D36.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        double double43 = vector2D34.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D16.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.359791915E9d), vector2D16);
        java.text.NumberFormat numberFormat46 = null;
        java.lang.String str47 = vector2D16.toString(numberFormat46);
        org.apache.commons.math3.exception.util.Localizable localizable48 = null;
        org.apache.commons.math3.exception.util.Localizable localizable49 = null;
        org.apache.commons.math3.exception.util.Localizable localizable51 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D54.negate();
        boolean boolean56 = vector3D54.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D54.getZero();
        double double58 = vector3D54.getNormSq();
        java.lang.Object[] objArray60 = new java.lang.Object[] { "hi!", 6.283185307179586d, vector3D54, (short) -1 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable51, objArray60);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException62 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable49, (java.lang.Number) 100, objArray60);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) str47, localizable48, objArray60);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException64 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray60);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{(NaN); (NaN)}" + "'", str24.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{(NaN); (NaN)}" + "'", str47.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        double double3 = vector3D1.getAlpha();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        boolean boolean3 = vector3D0.isInfinite();
        double double4 = vector3D0.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D9.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double15 = vector2D9.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D7, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = vector2D18.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D9.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = plane5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double23 = vector2D21.getNorm1();
        double[] doubleArray24 = vector2D21.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = vector2D21.scalarMultiply((double) (byte) 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D27.negate();
        boolean boolean29 = vector3D27.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = plane30.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D32.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D32.normalize();
        org.apache.commons.math3.geometry.Space space35 = vector3D32.getSpace();
        boolean boolean36 = plane30.contains(vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D38.negate();
        boolean boolean40 = vector3D38.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = plane41.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D43.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D43.normalize();
        org.apache.commons.math3.geometry.Space space46 = vector3D43.getSpace();
        boolean boolean47 = plane41.contains(vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane48 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane41);
        boolean boolean49 = plane37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = vector2D50.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        java.lang.String str53 = vector2D52.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = vector2D54.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = vector2D57.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        double double60 = vector2D54.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = vector2D58.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = vector2D52.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = plane37.getPointAt(vector2D63, (double) 10.0f);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(space35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(space46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{(NaN); (NaN)}" + "'", str53.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector2D67);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(32L, (-32L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet0 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = polygonsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree5 = polygonsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet6 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList1 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList1);
        boolean boolean3 = intervalsSet2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet2);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane5 = subOrientedPoint4.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion6 = euclidean1DAbstractSubHyperplane5.getRemainingRegion();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane5);
        org.junit.Assert.assertNotNull(euclidean1DRegion6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = plane4.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.normalize();
        org.apache.commons.math3.geometry.Space space9 = vector3D6.getSpace();
        boolean boolean10 = plane4.contains(vector3D6);
        plane4.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane12 = plane4.wholeHyperplane();
        double double13 = subPlane12.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane14 = subPlane12.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion15 = euclidean3DAbstractSubHyperplane14.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane16 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane(euclidean3DHyperplane0, euclidean2DRegion15);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(space9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(subPlane12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane14);
        org.junit.Assert.assertNotNull(euclidean2DRegion15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = vector2D0.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = vector2D3.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double9 = vector2D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = vector2D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D3.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = vector2D14.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        java.lang.String str22 = vector2D21.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D23.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double29 = vector2D23.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = vector2D27.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D21.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D34.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D35);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = vector2D37.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double40 = vector2D34.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double41 = vector2D32.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = vector2D14.subtract((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D42.scalarMultiply(0.0d);
        double double45 = vector2D44.getX();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{(NaN); (NaN)}" + "'", str22.equals("{(NaN); (NaN)}"));
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray4 = vector3D3.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray6 = vector3D5.toArray();
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray10 = vector3D9.toArray();
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double12 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray8);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) (byte) 100);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray16, (double) (short) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray16, orderDirection21, false, false);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection21, true, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-1023L), (java.lang.Number) 1.0848689673994147d, (int) (byte) 10, orderDirection21, false);
        int int30 = nonMonotonicSequenceException29.getIndex();
        java.lang.Number number31 = nonMonotonicSequenceException29.getPrevious();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.0848689673994147d + "'", number31.equals(1.0848689673994147d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection11, false, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[][] doubleArray17 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray16, doubleArray17);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, orderDirection11, doubleArray17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (byte) 100);
        double double24 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 5729.5779513082325d);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection29 = null;
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray28, orderDirection29, false, false);
        double double33 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray28);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 5729.5779513082325d + "'", double33 == 5729.5779513082325d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        float float2 = org.apache.commons.math3.util.Precision.round(Float.NaN, 0);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray5 = vector3D4.toArray();
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray8 = vector3D7.toArray();
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection11, false, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray16 = vector3D15.toArray();
        double[][] doubleArray17 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray16, doubleArray17);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, orderDirection11, doubleArray17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray21 = vector3D20.toArray();
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (byte) 100);
        double double24 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray5, 5729.5779513082325d);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (byte) 1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection29 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray28, orderDirection29, false);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray33 = vector3D32.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray35 = vector3D34.toArray();
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35, (int) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray39 = vector3D38.toArray();
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray39);
        double double41 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray43 = vector3D42.toArray();
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43, (int) (byte) 100);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray43, (double) (short) 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray49 = vector3D48.toArray();
        double[][] doubleArray50 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray49, doubleArray50);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray43, doubleArray50);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray37, doubleArray50);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray37);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math3.util.FastMath.min(1.5309649148733797d, 1.5309649148733797d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5309649148733797d + "'", double2 == 1.5309649148733797d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean5 = vector1D3.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D6.normalize();
        double double9 = vector3D8.getNormSq();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) -1, vector1D3, vector3D8 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray10);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0, objArray10);
        java.lang.Number number13 = notFiniteNumberException12.getArgument();
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.negate();
        boolean boolean2 = vector3D0.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = plane3.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.normalize();
        org.apache.commons.math3.geometry.Space space8 = vector3D5.getSpace();
        boolean boolean9 = plane3.contains(vector3D5);
        plane3.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane11 = plane3.wholeHyperplane();
        double double12 = subPlane11.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane13 = subPlane11.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion14 = euclidean3DAbstractSubHyperplane13.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DHyperplane15 = euclidean3DAbstractSubHyperplane13.getHyperplane();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(space8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(subPlane11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.POSITIVE_INFINITY + "'", double12 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane13);
        org.junit.Assert.assertNotNull(euclidean2DRegion14);
        org.junit.Assert.assertNotNull(euclidean3DHyperplane15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval((double) 100.0f, (double) 3.8146973E-6f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, 3.7621956910836314d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (-1272213960), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList1 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList1);
        boolean boolean3 = intervalsSet2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet2);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        boolean boolean8 = intervalsSet7.isEmpty();
        double double9 = intervalsSet7.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform10 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion11 = intervalsSet7.applyTransform(euclidean1DTransform10);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree12 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = intervalsSet7.buildNew(euclidean1DBSPTree12);
        double double14 = intervalsSet7.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane16 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList17 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList17);
        boolean boolean19 = intervalsSet18.isEmpty();
        double double20 = intervalsSet18.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform21 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion22 = intervalsSet18.applyTransform(euclidean1DTransform21);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree23 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet24 = intervalsSet18.buildNew(euclidean1DBSPTree23);
        double double25 = intervalsSet18.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint26 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane16, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane27 = subOrientedPoint15.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint26);
        double double28 = subOrientedPoint15.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane29 = subOrientedPoint4.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint15);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform30 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane31 = euclidean1DAbstractSubHyperplane29.applyTransform(euclidean1DTransform30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion11);
        org.junit.Assert.assertNotNull(intervalsSet13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion22);
        org.junit.Assert.assertNotNull(intervalsSet24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane29);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(10.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        boolean boolean2 = intervalsSet1.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform3 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion4 = intervalsSet1.applyTransform(euclidean1DTransform3);
        boolean boolean5 = intervalsSet1.isEmpty();
        double double6 = intervalsSet1.getInf();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double[] doubleArray1 = vector3D0.toArray();
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) (short) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection6, false, false);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray1, (double) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray11, (double) 10.000001f);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(1.5309649148733797d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.negate();
        boolean boolean3 = vector3D1.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.negate();
        boolean boolean8 = vector3D6.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D6.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D10.negate();
        boolean boolean12 = vector3D10.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = plane13.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        boolean boolean18 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane22 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D19, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane22.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine25 = line24.wholeLine();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList26 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet27 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList26);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList28 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet29 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList28);
        boolean boolean30 = polyhedronsSet27.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D31.negate();
        boolean boolean33 = vector3D31.isInfinite();
        boolean boolean34 = vector3D31.isInfinite();
        double double35 = vector3D31.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation36 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet37 = polyhedronsSet27.rotate(vector3D31, rotation36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D38.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        double double41 = vector3D31.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = line24.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Line line43 = line24.revert();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D45.negate();
        boolean boolean47 = vector3D45.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = vector3D45.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-10), vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = vector3D50.negate();
        boolean boolean52 = vector3D50.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D50.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D54.negate();
        boolean boolean56 = vector3D54.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane57 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = plane57.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = vector3D59.negate();
        boolean boolean61 = vector3D59.isInfinite();
        boolean boolean62 = vector3D59.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D58.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D64.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane66 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D53, vector3D63, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = plane66.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line68 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D45, vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine69 = line68.wholeLine();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = line68.pointAt(51.999996185302734d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = line24.intersection(line68);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subLine25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(polyhedronsSet37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(line43);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertNotNull(subLine69);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet1 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet3 = polygonsSet1.buildNew(euclidean2DBSPTree2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D4.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double10 = vector2D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D8.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D13.scalarMultiply(2.3978952727983707d);
        double double16 = vector2D13.getY();
        try {
            org.apache.commons.math3.geometry.partitioning.Region.Location location17 = polygonsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(polygonsSet3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((-264.228295788138d), 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-270569.7748870533d) + "'", double2 == (-270569.7748870533d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet0 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray1 = polygonsSet0.getVertices();
        double double2 = polygonsSet0.getBoundarySize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree4 = polygonsSet0.getTree(true);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = vector2D9.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        double double12 = vector2D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = vector2D10.subtract(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = vector2D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = vector2D22.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        double double25 = vector2D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        double double26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = vector2D28.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D19.add((double) (short) -1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = vector2D30.scalarMultiply((double) (-1));
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Segment segment35 = new org.apache.commons.math3.geometry.euclidean.twod.Segment(vector2D10, vector2D33, line34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) Float.NaN, vector2D33);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D33, 1.0d);
        org.apache.commons.math3.geometry.partitioning.Side side39 = polygonsSet0.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line38);
        org.junit.Assert.assertNotNull(vector2DArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree4);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertTrue("'" + side39 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side39.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 1L, (double) 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        boolean boolean2 = intervalsSet1.isEmpty();
        double double3 = intervalsSet1.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform4 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet1.applyTransform(euclidean1DTransform4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree6 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = intervalsSet1.buildNew(euclidean1DBSPTree6);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList8 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList8);
        boolean boolean10 = intervalsSet9.isEmpty();
        double double11 = intervalsSet9.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform12 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion13 = intervalsSet9.applyTransform(euclidean1DTransform12);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree14 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet15 = intervalsSet9.buildNew(euclidean1DBSPTree14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet17 = intervalsSet9.buildNew(euclidean1DBSPTree16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree18);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList20 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet21 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList20);
        boolean boolean22 = intervalsSet21.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane23 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList24 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet25 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList24);
        boolean boolean26 = intervalsSet25.isEmpty();
        double double27 = intervalsSet25.getInf();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform28 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion29 = intervalsSet25.applyTransform(euclidean1DTransform28);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree30 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = intervalsSet25.buildNew(euclidean1DBSPTree30);
        double double32 = intervalsSet25.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint33 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane23, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        boolean boolean34 = intervalsSet21.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree36 = intervalsSet25.getTree(false);
        boolean boolean37 = intervalsSet19.isEmpty(euclidean1DBSPTree36);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet38 = intervalsSet17.buildNew(euclidean1DBSPTree36);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet39 = intervalsSet1.buildNew(euclidean1DBSPTree36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion13);
        org.junit.Assert.assertNotNull(intervalsSet15);
        org.junit.Assert.assertNotNull(intervalsSet17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion29);
        org.junit.Assert.assertNotNull(intervalsSet31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(intervalsSet38);
        org.junit.Assert.assertNotNull(intervalsSet39);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_J;
        boolean boolean1 = vector3D0.isInfinite();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -10 + "'", short2 == (short) -10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList0);
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList2 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList2);
        double double4 = polyhedronsSet3.getBoundarySize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D5.negate();
        boolean boolean7 = vector3D5.isInfinite();
        boolean boolean8 = vector3D5.isInfinite();
        double double9 = vector3D5.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5);
        org.apache.commons.math3.geometry.partitioning.Region.Location location11 = polyhedronsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        boolean boolean12 = polyhedronsSet1.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet3);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = polyhedronsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.negate();
        boolean boolean17 = vector3D15.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = plane18.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D20.negate();
        boolean boolean22 = vector3D20.isInfinite();
        boolean boolean23 = vector3D20.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D19.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D25.negate();
        boolean boolean27 = vector3D25.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = plane28.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D30.negate();
        boolean boolean32 = vector3D30.isInfinite();
        boolean boolean33 = vector3D30.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D29.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double double35 = vector3D24.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double double36 = vector3D30.getAlpha();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D37.negate();
        boolean boolean39 = vector3D37.isInfinite();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane40 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = plane40.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D42.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D42.normalize();
        org.apache.commons.math3.geometry.Space space45 = vector3D42.getSpace();
        boolean boolean46 = plane40.contains(vector3D42);
        plane40.revertSelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane48 = plane40.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D49.negate();
        boolean boolean51 = vector3D49.isInfinite();
        boolean boolean52 = vector3D49.isInfinite();
        double double53 = vector3D49.getNorm1();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane54 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D49);
        org.apache.commons.math3.geometry.partitioning.Side side55 = subPlane48.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = plane54.getNormal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = vector3D57.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        double double60 = plane54.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        double double61 = vector3D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D62.negate();
        double double64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D58, vector3D63);
        org.apache.commons.math3.geometry.partitioning.Region.Location location65 = polyhedronsSet3.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D63);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + location11 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location11.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.141592653589793d + "'", double36 == 3.141592653589793d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(space45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(subPlane48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + side55 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side55.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + location65 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location65.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
    }
}

