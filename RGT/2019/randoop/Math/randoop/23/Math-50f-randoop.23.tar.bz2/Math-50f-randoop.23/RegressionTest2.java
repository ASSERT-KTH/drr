import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, 0.0f, (-53));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.009950000012498683d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.351548590286222d + "'", double2 == 0.351548590286222d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-5.9042362923625349E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getLo();
        double double10 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.FastMath.atan2(50.0d, 1.079574529000002E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.631454212458534E-8d + "'", double2 == 4.631454212458534E-8d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(6, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 10, 28.716814692820414d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException7 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10.0d);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) tooManyEvaluationsException7);
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-3300), (java.lang.Number) 1.07957453E9f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.8272501129310708d, 9.332621544395286E157d, (double) 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000, 6]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.831008000716577E22d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve((int) (byte) -1, univariateRealFunction3, 1.5440680443502757d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3147, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 314700 + "'", int2 == 314700);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-5904236292362534911L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-5,904,236,292,362,534,911)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-29L), (float) (-1), (float) (-3300L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1025.8508197214162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0854373658767d + "'", double1 == 10.0854373658767d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.401298464324817E-45d, 2.7182818284590455d, 1.8189894035458565E-12d, 0.0d, (double) (byte) 100, (double) (-5.9042362E18f));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-5.904236153912951E20d) + "'", double6 == (-5.904236153912951E20d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.21942525837900473d, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1, (float) 107957452800L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8159496001766002d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 300, (-0.0f), (float) 1079574528);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int10 = regulaFalsiSolver9.getEvaluations();
        exceptionContext4.setValue("out of range", (java.lang.Object) regulaFalsiSolver9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray16 = notStrictlyPositiveException15.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = notStrictlyPositiveException15.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray20);
        java.lang.Throwable[] throwableArray22 = nullArgumentException21.getSuppressed();
        exceptionContext17.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray22);
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray22);
        java.lang.Object obj26 = null;
        exceptionContext4.setValue("invalid iteration limits: min={0}, max={1}", obj26);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-3300), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 6, n = -3,300");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 32.0d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 32.0d + "'", number2.equals(32.0d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 1.5515679276951895d, (double) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getFHi();
        double double10 = noBracketingException6.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.07957453E9f), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07957453E9f) + "'", float2 == (-1.07957453E9f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.230405886098971d) + "'", double1 == (-1.230405886098971d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 10.0f, 100.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 3.743392130574644E-23d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 1, (double) 1079574528);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079574528E9d + "'", double2 == 1.079574528E9d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) '4', (-42));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0E-15d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000008E-150d + "'", double2 == 1.0000000000000008E-150d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathArithmeticException10.getContext();
        java.lang.String str12 = mathArithmeticException10.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = mathArithmeticException10.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: index ({0})" + "'", str12.equals("org.apache.commons.math.exception.MathArithmeticException: index ({0})"));
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException7 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10.0d);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) tooManyEvaluationsException7);
        java.lang.String str9 = tooManyEvaluationsException7.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations" + "'", str9.equals("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 22025.465794806718d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1608.495438637974d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5701746278785413d) + "'", double1 == (-1.5701746278785413d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double2 = org.apache.commons.math.util.FastMath.min(1.8189894035458565E-12d, 2.2041199826559246d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8189894035458565E-12d + "'", double2 == 1.8189894035458565E-12d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(363.7393755555636d, (-3.91886975727153E-15d), (double) (-42), 0.0d, (double) 52, (double) 58.0f, (-1.401298464324817E-45d), 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3015.9999999999986d + "'", double8 == 3015.9999999999986d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 300);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        double[] doubleArray23 = new double[] { 10L, 1.0f };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) ' ');
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 52);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray32 = null;
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray31);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray53);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray53);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 52);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) 'a');
        double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray53, doubleArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection74, false);
        java.lang.Number number77 = nonMonotonousSequenceException76.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException76.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException76.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection79, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (10 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-868592058) + "'", int29 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-868592058) + "'", int66 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 26.710743801652892d + "'", double69 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.136250564655356d + "'", double70 == 9.136250564655356d);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 2 + "'", number77.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1072693248, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NaN, (double) 10.0f, (double) 'a');
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver3.solve(52, univariateRealFunction5, 6.933277615277467d, 6.867258771281655d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2, (long) (-1111295802));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,111,295,802)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.079574529000002E9d, 1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079574529000002E9d + "'", double2 == 1.079574529000002E9d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-3300L), (-1.4E-45f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.4E-45f) + "'", float2 == (-1.4E-45f));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 1.1752011936438014d, (double) (-5904236292362534911L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver0.solve((int) 'a', univariateRealFunction4, 0.21942525837900473d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = nullArgumentException2.getContext();
        java.lang.Object obj5 = exceptionContext3.getValue("standard deviation must be positive ({0})");
        java.util.Set<java.lang.String> strSet6 = exceptionContext3.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395465E155d + "'", double1 == 9.332621544395465E155d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 300, (-5.9042362923625339E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException5.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (short) 1, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-18) + "'", int1 == (-18));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3015.9999999999986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.Object obj0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray5);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 99, (double) (short) -1, 0.0d, (double) 100L, objArray17);
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: lower bound ({0}) must be strictly less than upper bound ({1})");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 5L, (double) (-18));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [5, -18]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int2 = regulaFalsiSolver1.getEvaluations();
        int int3 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver1.solve(0, univariateRealFunction5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-2));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-2)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(854.7438016528926d, 0.009900662135208755d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2305998764687729d + "'", double2 == 0.2305998764687729d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getCount();
        int int3 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((-1111295802));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NaN, (double) 10.0f, (double) 'a');
        double double4 = regulaFalsiSolver3.getMax();
        double double5 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double10 = regulaFalsiSolver3.solve(99, univariateRealFunction7, 1.60978210179491616E17d, (double) 1.09951163E12f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (-42), (double) 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) 1072693248L, (double) (byte) -1, 0.17453292519943295d, 1.7423491986308186E12d, (double) 2L, 35.0d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.484698397226463E12d + "'", double8 == 3.484698397226463E12d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-1L), (float) (short) 10, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.rint(360.99999994039536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 361.0d + "'", double1 == 361.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1111295802));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,111,295,802");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1079574528L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray12);
        float[] floatArray21 = new float[] { 0.0f, 3.8146973E-6f, 100.0f, (short) -1, (byte) 10, 100L };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray21);
        float[] floatArray23 = null;
        float[] floatArray28 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray29 = null;
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray29);
        float[] floatArray35 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray35, floatArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray28);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray28);
        float[] floatArray45 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray46 = null;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray45, floatArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray46);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.07957453E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07957453E9f + "'", float1 == 1.07957453E9f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        long long2 = org.apache.commons.math.util.FastMath.max((long) ' ', 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(1.0f, 1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double4 = regulaFalsiSolver3.getMax();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getRelativeAccuracy();
        int int7 = regulaFalsiSolver3.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution11 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double12 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-18), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, 22025.465794806718d, 2.2041199826559246d, 9.0d, allowedSolution11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution11 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution11.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray11 = new int[] { 1079574528, (byte) 1 };
        int[] intArray16 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray16);
        int[] intArray23 = new int[] { (-1), 52, 0, 10, 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray23);
        int[] intArray28 = new int[] { 1079574528, (byte) 1 };
        int[] intArray33 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray33);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, 0);
        int[] intArray40 = new int[] { 1079574528, (byte) 1 };
        int[] intArray45 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray45);
        int[] intArray52 = new int[] { (-1), 52, 0, 10, 100 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray52);
        int[] intArray56 = new int[] { 1079574528, (byte) 1 };
        int[] intArray61 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray61);
        int[] intArray65 = new int[] { 1079574528, (byte) 1 };
        int[] intArray70 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray70);
        int[] intArray77 = new int[] { (-1), 52, 0, 10, 100 };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray77);
        int[] intArray81 = org.apache.commons.math.util.MathUtils.copyOf(intArray61, (int) '4');
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray81);
        try {
            double double84 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1079574580 + "'", int24 == 1079574580);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.079574529000002E9d + "'", double25 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1079574580 + "'", int53 == 1079574580);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1079574580 + "'", int78 == 1079574580);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.079574529000002E9d + "'", double79 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 3, (long) 3200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1072693248L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693280L + "'", long2 == 1072693280L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 32.752533349056684d, 1.8189894035458565E-12d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.17453292519943295d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.17453292519943295d + "'", double2 == 0.17453292519943295d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException(number0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.7453292519943295d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1079574580L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07957458E9d + "'", double1 == 1.07957458E9d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.acos(10.04987562112089d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathArithmeticException10.getContext();
        java.util.Set<java.lang.String> strSet12 = exceptionContext11.getKeys();
        exceptionContext11.setValue("", (java.lang.Object) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertNotNull(strSet12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.220446049250313E-16d, 21.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.08446764274574539d) + "'", double2 == (-0.08446764274574539d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.9171523356672744d, (-868592058));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 260 + "'", int2 == 260);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-23.734272574603658d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0153917149507097E10d + "'", double1 == 1.0153917149507097E10d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double2 = org.apache.commons.math.util.FastMath.pow(Double.NaN, 5.298342365610589d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9589242746631385d), 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1079574528L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079574528E9d + "'", double1 == 1.079574528E9d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 1072696548L, 1.1962108355622936d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5263085229064353d + "'", double2 == 0.5263085229064353d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int1 = org.apache.commons.math.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1079574580);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-18), (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-16L) + "'", long2 == (-16L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1078525952, (double) 52L, (double) '4');
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver3.solve(0, univariateRealFunction5, (-2.6991118430775174d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 314700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.933277615277467d, 1.60978210179491616E17d, 1.0795745782851064E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-5.9042356E18f), 100.0f, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] { 10L, 1.0f };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray16 = new double[] { 10L, 1.0f };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        double[] doubleArray29 = new double[] { 10L, 1.0f };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) ' ');
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, 52);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 1.0f);
        double[] doubleArray38 = null;
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.141592653589793d);
        double double44 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray37);
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, 52);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 2);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-868592058) + "'", int35 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 26.710743801652892d + "'", double44 == 26.710743801652892d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 29.236001806897132d + "'", double53 == 29.236001806897132d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.8272501129310708d + "'", double56 == 1.8272501129310708d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 0, (float) 1079574529, 1079574529);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(6, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.60978210179491616E17d, 1.07957458E9d, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray11 = notStrictlyPositiveException10.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1L, objArray13);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.6843909265968924d, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (short) 100);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        try {
            double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 29.236001806897132d + "'", double35 == 29.236001806897132d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 3, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        float float1 = org.apache.commons.math.util.FastMath.ulp((-1.07957453E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(99, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1111295802));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,111,295,802)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double2 = org.apache.commons.math.util.FastMath.max(385468.450545982d, 1.0153917149507097E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0153917149507097E10d + "'", double2 == 1.0153917149507097E10d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double7 = regulaFalsiSolver1.solve(100, univariateRealFunction3, (-0.9589242746631385d), (double) (short) 100, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "overflow in subtraction: {0} - {1}" + "'", str1.equals("overflow in subtraction: {0} - {1}"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        double[] doubleArray10 = new double[] { 10L, 1.0f };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) ' ');
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 52);
        double[] doubleArray18 = new double[] { 10L, 1.0f };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) ' ');
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21, 52);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray26);
        double[] doubleArray32 = new double[] { 10L, 1.0f };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) ' ');
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray35, 52);
        double[] doubleArray40 = new double[] { 10L, 1.0f };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) ' ');
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray43, 52);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 1.0f);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray48);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray26);
        double[] doubleArray56 = new double[] { 10L, 1.0f };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) ' ');
        double[] doubleArray62 = new double[] { 10L, 1.0f };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 0);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-868592058) + "'", int24 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-868592058) + "'", int46 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 28.322376750431598d + "'", double53 == 28.322376750431598d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-29L), (java.lang.Number) (short) 1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-16L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-16.0d) + "'", double1 == (-16.0d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2 + "'", number6.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-0.8390715290764524d) + "'", number9.equals((-0.8390715290764524d)));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.abs(74.65823634883017d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.65823634883017d + "'", double1 == 74.65823634883017d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.009900662135208755d, 6.283185307179586d, (double) (-5.9042362E18f), 19.09090909090909d, 0.0d, (-1608.495438637974d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.1271723566561087E20d) + "'", double6 == (-1.1271723566561087E20d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.484698397226463E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.57254979383581d + "'", double1 == 29.57254979383581d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray5);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray5);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.401298464324817E-45d, objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.4E-45f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0, 2);
        int int4 = dimensionMismatchException3.getDimension();
        int int5 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(2.718281828459045d, (double) 9223372036854775807L, 3628800.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [9,223,372,036,854,776,000, 3,628,800]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-96) + "'", int2 == (-96));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3147);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.49789674291322d + "'", double1 == 3.49789674291322d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.620404523E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1072693280L, (-42));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3956124250860895d, 3.080808751038084d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(30, (-18));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 84.73931296875567d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (-53));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.exp(19.186126185776242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1499518398606595E8d + "'", double1 == 2.1499518398606595E8d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.9711353880321711E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9711353880321711E12d + "'", double1 == 1.9711353880321711E12d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        double[] doubleArray17 = new double[] { 10L, 1.0f };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray19);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray21);
        double[] doubleArray25 = new double[] { 10L, 1.0f };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, 52);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray34 = new double[] { 10L, 1.0f };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 21.0d + "'", double20 == 21.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-868592058) + "'", int31 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5588463977399145d + "'", double1 == 0.5588463977399145d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1.07957453E9f, 2.5091784786580567d, (-18));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 2.1499518398606595E8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(6);
        int int4 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 58, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 58L + "'", long2 == 58L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.util.FastMath.min(1.7423491986308186E12d, 1.0000000794728534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000794728534d + "'", double2 == 1.0000000794728534d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 300);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        double[] doubleArray23 = new double[] { 10L, 1.0f };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) ' ');
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 52);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray32 = null;
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray31);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray53);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray53);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 52);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) 'a');
        double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray53, doubleArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray53);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 84.73931296875568d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection76, false);
        java.lang.Number number79 = nonMonotonousSequenceException78.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = nonMonotonousSequenceException78.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = nonMonotonousSequenceException78.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72, orderDirection81, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (77.036 >= 7.704)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-868592058) + "'", int29 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-868592058) + "'", int66 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 26.710743801652892d + "'", double69 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.136250564655356d + "'", double70 == 9.136250564655356d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 2 + "'", number79.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection81 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection81.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 152L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1818435879447726d + "'", double1 == 2.1818435879447726d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = nullArgumentException2.getContext();
        java.lang.String str4 = nullArgumentException2.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NullArgumentException: out of range" + "'", str4.equals("org.apache.commons.math.exception.NullArgumentException: out of range"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        float[] floatArray18 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray19);
        float[] floatArray23 = null;
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray23);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0000000794728534d, (double) (-5.9042362E18f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray5);
        java.lang.Throwable[] throwableArray7 = nullArgumentException6.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.5943665446595849d, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.4E-45f), (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3170812395271425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9679866101303016d + "'", double1 == 0.9679866101303016d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.log10(29.614185789921695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4714997966830203d + "'", double1 == 1.4714997966830203d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 4.440892098500626E-16d);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) (byte) 0, 6.283185307179586d, (double) (byte) 10, 0.0d, (double) (-29L), 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 3, (int) (short) 1);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException11 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray17);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException(localizable8, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray17);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number6, objArray17);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(19.186126185776242d, 2.7194528101212354E12d, 28.716814692820414d, 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.217576477130726E13d + "'", double4 == 5.217576477130726E13d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.FastMath.copySign(9.332621544395465E155d, 0.9957788084963161d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.332621544395465E155d + "'", double2 == 9.332621544395465E155d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.0f), (java.lang.Number) (-16.0d), false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.log(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) ' ', 300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9600 + "'", int2 == 9600);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.log1p(854.7438016528926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.751971034208944d + "'", double1 == 6.751971034208944d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(6);
        int int4 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 6, (java.lang.Number) 6.283185307179586d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 152L, (float) 9600);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 152.0f + "'", float2 == 152.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-8.664339742098155d), 6.751971034208944d, 5.298342365610589d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [6.752, 5.298]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 1079574528, (byte) 1 };
        int[] intArray8 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 0);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        try {
            int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 35867348190L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35867348190L + "'", long2 == 35867348190L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-868592058));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.acosh(25.4050030308942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.927705731488613d + "'", double1 == 3.927705731488613d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7724538509055159d + "'", double1 == 1.7724538509055159d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double double1 = org.apache.commons.math.util.FastMath.floor(361.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 361.0d + "'", double1 == 361.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray15 = new int[] { 1079574528, (byte) 1 };
        int[] intArray20 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 0);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray25);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) 'a');
        int[] intArray31 = new int[] { 1079574528, (byte) 1 };
        int[] intArray36 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray38, 0);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray40);
        int[] intArray44 = new int[] { 1079574528, (byte) 1 };
        int[] intArray49 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray51 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray51, 0);
        int[] intArray54 = org.apache.commons.math.util.MathUtils.copyOf(intArray53);
        int[] intArray57 = new int[] { 1079574528, (byte) 1 };
        int[] intArray62 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray62);
        int[] intArray64 = org.apache.commons.math.util.MathUtils.copyOf(intArray62);
        int[] intArray66 = org.apache.commons.math.util.MathUtils.copyOf(intArray64, 0);
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray67);
        int[] intArray70 = org.apache.commons.math.util.MathUtils.copyOf(intArray67, (int) 'a');
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray70);
        int[] intArray74 = new int[] { 1079574528, (byte) 1 };
        int[] intArray79 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray79);
        int[] intArray86 = new int[] { (-1), 52, 0, 10, 100 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray74);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1079574580 + "'", int87 == 1079574580);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection13, false);
        double[] doubleArray18 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[] doubleArray21 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[][] doubleArray22 = new double[][] { doubleArray18, doubleArray21 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection13, doubleArray22);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-868592058) + "'", int9 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 314700, 32, 1079574529);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,079,574,529, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4');
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.484698397226463E12d, 361.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(35, 618402555);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-618402520) + "'", int2 == (-618402520));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1.4E-45f), (double) 0, 26.710743801652892d, (double) 9223372036854775807L, objArray5);
        double double7 = noBracketingException6.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.223372036854776E18d + "'", double7 == 9.223372036854776E18d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(35867348190L, (long) 3210);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35867344980L + "'", long2 == 35867344980L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 10L, 1.0f };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double[] doubleArray7 = new double[] { 10L, 1.0f };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 10L, 1.0f };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) ' ');
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, 52);
        double[] doubleArray20 = new double[] { 10L, 1.0f };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) ' ');
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, 52);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 1.0f);
        double[] doubleArray29 = null;
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray28);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray28);
        double[] doubleArray35 = new double[] { 10L, 1.0f };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) ' ');
        double double39 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray28, doubleArray38);
        double[] doubleArray42 = new double[] { 10L, 1.0f };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) ' ');
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45, 52);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray45);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray45);
        try {
            double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-868592058) + "'", int26 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 9.090909090909092d + "'", double32 == 9.090909090909092d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 26.710743801652892d + "'", double39 == 26.710743801652892d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-868592058) + "'", int48 == (-868592058));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 28.322376750431598d + "'", double50 == 28.322376750431598d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 30, 97.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-9L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 300);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        double[] doubleArray23 = new double[] { 10L, 1.0f };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) ' ');
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 52);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray32 = null;
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray31);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray53);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray53);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 52);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) 'a');
        double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray53, doubleArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray53);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 84.73931296875568d);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-868592058) + "'", int29 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-868592058) + "'", int66 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 26.710743801652892d + "'", double69 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.136250564655356d + "'", double70 == 9.136250564655356d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.04987562112089d + "'", double73 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double2 = org.apache.commons.math.util.FastMath.atan2(97.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5811052399411398d + "'", double2 == 1.5811052399411398d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 1.09951163E12f, (double) 160L, 32.0d, (double) (short) 1, (double) (-3300L), 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.75921860411192E14d + "'", double6 == 1.75921860411192E14d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.math.util.FastMath.max(260, 1078525952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078525952 + "'", int2 == 1078525952);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 100, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-3200), (float) 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 58L, 0.2305998764687729d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 57.999996f + "'", float2 == 57.999996f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 300, (long) 3210);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 963000L + "'", long2 == 963000L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-3300), 5.217576477130726E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.217576477130892E13d + "'", double2 == 5.217576477130892E13d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 58.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 160L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.079574528E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41036740004704136d) + "'", double1 == (-0.41036740004704136d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.4E-45f));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.4E-45f) + "'", number3.equals((-1.4E-45f)));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.009949835840666133d);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.009949835840666133d + "'", number2.equals(0.009949835840666133d));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.009949835840666133d + "'", number3.equals(0.009949835840666133d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.6313083693369503E35d, 3147, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2.4414062E-4f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000298023226d + "'", double1 == 1.0000000298023226d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 160L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getLo();
        double double10 = noBracketingException6.getFLo();
        double double11 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.718281828459045d + "'", double10 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.0f), (float) 1079574580L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 1.0f);
        double[] doubleArray48 = new double[] { 10L, 1.0f };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) ' ');
        double[] doubleArray54 = new double[] { 10L, 1.0f };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray48);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        try {
            double double59 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray34, doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 52 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-868592058) + "'", int43 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException3 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-8.664339742098155d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2896.3094188984737d + "'", double1 == 2896.3094188984737d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 1079574580L, 0.0d, (-35.35050620855721d), 0.21942525837900473d, (-8.664339742098155d), (double) 10L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-94.40019137962283d) + "'", double6 == (-94.40019137962283d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException(localizable4, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext19 = notFiniteNumberException18.getContext();
        java.util.Set<java.lang.String> strSet20 = exceptionContext19.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertNotNull(strSet20);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = org.apache.commons.math.util.FastMath.max(1072693248, 314700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693248 + "'", int2 == 1072693248);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(10, (-868592058));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.009949835840666133d);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = maxCountExceededException1.getContext();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.009949835840666133d + "'", number2.equals(0.009949835840666133d));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray1);
        java.lang.Number number3 = notFiniteNumberException2.getArgument();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount();
        int int4 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.resetCount();
        incrementor0.incrementCount((-3200));
        int int5 = incrementor0.getCount();
        try {
            incrementor0.incrementCount(1078525952);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 9223372036854775807L, 1.0343390004198511E30d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0343390004198511E30d + "'", double2 == 1.0343390004198511E30d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.log(29.236001806897132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3754008884219857d + "'", double1 == 3.3754008884219857d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.04987562112089d + "'", double11 == 10.04987562112089d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-3200));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException7.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = notStrictlyPositiveException7.getContext();
        java.lang.Object obj11 = exceptionContext9.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray14);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray14);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-868592058), 1.079574529000002E9d, 100.0d, Double.NaN, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1079574580, (java.lang.Number) 2.3841858E-7f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0153917149507097E10d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(35, (int) (byte) 0);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6657737500283538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.873190273214229d + "'", double1 == 0.873190273214229d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double2 = org.apache.commons.math.util.FastMath.max((-16.0d), 1.0000000794728534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000794728534d + "'", double2 == 1.0000000794728534d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 9600, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9600.0d + "'", double2 == 9600.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for binomial coefficient (n, k), got n = -1");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray12);
        float[] floatArray19 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray19, floatArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray19);
        float[] floatArray27 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray28);
        float[] floatArray34 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray34, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray35);
        float[] floatArray42 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray42, floatArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray35, floatArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray19, floatArray35);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-18), 1.0000000794728534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5152978171476064d) + "'", double2 == (-1.5152978171476064d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((-0.08446764274574539d), 84.73931296875568d, 3.3754008884219857d, (double) 2.4414062E-4f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.15690594188224d) + "'", double4 == (-7.15690594188224d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.3170812395271425d, 1.0706198036401884d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.697330184572498d + "'", double2 == 1.697330184572498d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray7 = new double[] { 10L, 1.0f };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) ' ');
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, 52);
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double[] doubleArray16 = new double[] { 10L, 1.0f };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) ' ');
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, 52);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection27, false);
        double[] doubleArray32 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[] doubleArray35 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[][] doubleArray36 = new double[][] { doubleArray32, doubleArray35 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, orderDirection27, doubleArray36);
        try {
            double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 21.0d + "'", double13 == 21.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-868592058) + "'", int22 == (-868592058));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-868592058) + "'", int23 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 5, (java.lang.Number) 1.791759469228055d, true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1079574529);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.0d, (java.lang.Number) (-0.99999994f), 52);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = nonMonotonousSequenceException3.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.99999994f) + "'", number4.equals((-0.99999994f)));
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(5, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.015269573507533d + "'", double1 == 1.015269573507533d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-3300L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(152L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 142L + "'", long2 == 142L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 0, (double) 52, 1.5707963267948966d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1072693248, 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0726932480000001E9d + "'", double2 == 1.0726932480000001E9d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.3495709937154414d, (double) 5L, 19.09090909090909d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver1.solve(0, univariateRealFunction6, (double) 107957452800L, (double) 5L, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) -1, (long) 58);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-58L) + "'", long2 == (-58L));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 314700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.00001f + "'", float1 == 97.00001f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2, (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 57.999996f, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection22, false);
        double[] doubleArray27 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[] doubleArray30 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[][] doubleArray31 = new double[][] { doubleArray27, doubleArray30 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray14, orderDirection22, doubleArray31);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray2, doubleArray31);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-868592058) + "'", int17 == (-868592058));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-868592058) + "'", int18 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-30145599) + "'", int34 == (-30145599));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1079574580);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 10L, 1.0f };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double[] doubleArray7 = new double[] { 10L, 1.0f };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray17 = new double[] { 10L, 1.0f };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        double[] doubleArray22 = new double[] { 10L, 1.0f };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) ' ');
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25, 52);
        double[] doubleArray30 = new double[] { 10L, 1.0f };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) ' ');
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33, 52);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray38);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray38);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 3.141592653589793d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection48, false);
        java.lang.Number number51 = nonMonotonousSequenceException50.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException50.getDirection();
        boolean boolean56 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection53, true, false);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection53, true, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats63, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray66 = notStrictlyPositiveException65.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException67 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats61, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException68 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats60, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext69 = mathArithmeticException68.getContext();
        java.util.Set<java.lang.String> strSet70 = exceptionContext69.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats71 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        double[] doubleArray74 = new double[] { 10L, 1.0f };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) ' ');
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray77, 52);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException87 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection85, false);
        double[] doubleArray90 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[] doubleArray93 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[][] doubleArray94 = new double[][] { doubleArray90, doubleArray93 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray77, orderDirection85, doubleArray94);
        exceptionContext69.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats71, (java.lang.Object[]) doubleArray94);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection53, doubleArray94);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.04987562112089d + "'", double10 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-868592058) + "'", int36 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 2 + "'", number51.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(exceptionContext69);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + localizedFormats71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats71.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-868592058) + "'", int80 == (-868592058));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-868592058) + "'", int81 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.440892098500626E-16d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.setMaximalCount(1620404523);
        int int5 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1620404523 + "'", int5 == 1620404523);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double2 = org.apache.commons.math.util.FastMath.max(1025.8508197214162d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1025.8508197214162d + "'", double2 == 1025.8508197214162d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        float float2 = org.apache.commons.math.util.FastMath.min(1.1920929E-7f, 34.999996f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1920929E-7f + "'", float2 == 1.1920929E-7f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        float[] floatArray4 = new float[] { 3210, (short) 1, 35L, (-18) };
        float[] floatArray9 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray10 = null;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray9, floatArray10);
        float[] floatArray16 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray16, floatArray17);
        float[] floatArray23 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray24 = null;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray16, floatArray24);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(floatArray9, floatArray24);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray24);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray11 = new int[] { 1079574528, (byte) 1 };
        int[] intArray16 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray16);
        int[] intArray23 = new int[] { (-1), 52, 0, 10, 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray23);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) '4');
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, 35);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1079574580 + "'", int24 == 1079574580);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.079574529000002E9d + "'", double25 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) -1, 0.0d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1.07957453E9f, (-14.52444713108708d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double[] doubleArray2 = new double[] { 1620404523, 1.0f };
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1,620,404,523 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.3754008884219857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9309150279939942d + "'", double1 == 1.9309150279939942d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, number9, objArray10);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, number17, objArray18);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray18);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 5.916079783099616d, objArray18);
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (-618402520), 1.0000000000000008E-150d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.971980194454883E-151d + "'", double2 == 4.971980194454883E-151d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-618402520));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.084066969169249d + "'", double1 == 1.084066969169249d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray11 = new int[] { 1079574528, (byte) 1 };
        int[] intArray16 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray16);
        int[] intArray23 = new int[] { (-1), 52, 0, 10, 100 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray23);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) '4');
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1079574580 + "'", int24 == 1079574580);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.079574529000002E9d + "'", double25 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 2.7194528101212354E12d, (double) 12L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -1");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.4714997966830203d, (double) (-96));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 618402555);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 851.9689327757983d + "'", double1 == 851.9689327757983d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 107957452800L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07957453E11f + "'", float2 == 1.07957453E11f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.933277615277467d, (java.lang.Number) 854.7438016528926d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) ' ', (-3300));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getLo();
        double double10 = noBracketingException6.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-16.0d), (double) (-5904236293441060863L), 0.9171523356672744d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 314700, (-29L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-29)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-1.0d));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double8 = regulaFalsiSolver1.solve(58, univariateRealFunction4, 5.217576477130892E13d, 26.710743801652892d, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-3300));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '#', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        float[] floatArray0 = null;
        float[] floatArray5 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray6);
        float[] floatArray12 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray5);
        float[] floatArray21 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray22);
        float[] floatArray28 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray29 = null;
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray29);
        float[] floatArray38 = new float[] { 0.0f, 3.8146973E-6f, 100.0f, (short) -1, (byte) 10, 100L };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray29, floatArray38);
        float[] floatArray44 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray44, floatArray45);
        float[] floatArray51 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray44, floatArray52);
        float[] floatArray59 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray60 = null;
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray59, floatArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(floatArray52, floatArray59);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(floatArray38, floatArray52);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray52);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(11, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 100, n = 11");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 35867344980L, (float) 3210, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1079574528, (float) 35867348190L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07957453E9f + "'", float2 == 1.07957453E9f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-9L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(3.927705731488613d, (double) 1072693248L, 3.927705731488613d, 0.6843909265968924d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.213223420986822E9d + "'", double4 == 4.213223420986822E9d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3170812395271425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 75.46319630076432d + "'", double1 == 75.46319630076432d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(20.799832845832398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3630255670242375d + "'", double1 == 0.3630255670242375d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 3.49789674291322d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.080808751038084d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.755223276691055d + "'", double1 == 1.755223276691055d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5440680443502757d, (double) 1620404523);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.0d, 21.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double2 = org.apache.commons.math.util.FastMath.scalb(25.4050030308942d, 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int[] intArray1 = new int[] { 52 };
        try {
            int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray1, (-3300));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100L, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 11013.232920103324d, true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.99999994f), true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.99999994f) + "'", number5.equals((-0.99999994f)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.99999994f) + "'", number6.equals((-0.99999994f)));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-9L), (double) (-5904236292362534911L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-30145599), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-30145599L) + "'", long2 == (-30145599L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NaN, (double) 10.0f, (double) 'a');
        double double4 = regulaFalsiSolver3.getMax();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getStartValue();
        double double7 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        try {
            double double13 = regulaFalsiSolver3.solve(260, univariateRealFunction9, 0.3630255670242375d, 385468.450545982d, (double) 35867348190L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-1.7763568394002505E-15d), (double) 142L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 142.0d + "'", double3 == 142.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1072696548L, (float) 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269658E9f + "'", float2 == 1.07269658E9f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 35867344980L, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.5867345E10f + "'", float2 == 3.5867345E10f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1.1920929E-7f, 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1920928955078125E-7d + "'", double2 == 1.1920928955078125E-7d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 10, (double) '4', (-0.5440211108893698d), (double) (byte) 100);
        double double5 = noBracketingException4.getFLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        java.lang.Throwable[] throwableArray9 = nullArgumentException8.getSuppressed();
        noBracketingException4.addSuppressed((java.lang.Throwable) nullArgumentException8);
        double double11 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5440211108893698d) + "'", double5 == (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.5440211108893698d) + "'", double11 == (-0.5440211108893698d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1962108355622936d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1962108355622936d + "'", double2 == 1.1962108355622936d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.07269658E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.resetCount();
        incrementor0.incrementCount((-3200));
        int int5 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 97.00001f, 74.65823634883017d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 71.86726640067619d + "'", double2 == 71.86726640067619d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(6);
        incrementor0.setMaximalCount((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 1620404523, (-2));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        long long2 = org.apache.commons.math.util.FastMath.min(1072696548L, 142L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 142L + "'", long2 == 142L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1079574564, Double.NEGATIVE_INFINITY, 1079574529);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 10.04987562112089d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(2.384185791015625E-7d, 26.710743801652892d, (-16.0d), (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-559.9999936316624d) + "'", double4 == (-559.9999936316624d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1620404523, 260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1620404783 + "'", int2 == 1620404783);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.60978210179491616E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8095997915995805E15d + "'", double1 == 2.8095997915995805E15d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1.1920929E-7f, number2, false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.String str2 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "standard deviation must be positive ({0})" + "'", str1.equals("standard deviation must be positive ({0})"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "standard deviation must be positive ({0})" + "'", str2.equals("standard deviation must be positive ({0})"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.579251212010101d + "'", double1 == 6.579251212010101d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.17093156852589028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1709315685258903d + "'", double1 == 0.1709315685258903d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray9 = notStrictlyPositiveException8.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = notStrictlyPositiveException8.getContext();
        java.lang.Object obj12 = exceptionContext10.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray15);
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (-868592058), 1.079574529000002E9d, 100.0d, Double.NaN, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.apache.commons.math.exception.NotPositiveException notPositiveException21 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 35.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1111295802));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,111,295,802");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.20787957635076193d, (double) ' ');
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = regulaFalsiSolver2.solve(0, univariateRealFunction5, (double) 314700, (double) (short) -1, 4.213223420986822E9d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.20787957635076193d + "'", double3 == 0.20787957635076193d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-16L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 36, (float) 152L, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 3, (long) 1078525952);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3235577856L + "'", long2 == 3235577856L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-53), (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59L) + "'", long2 == (-59L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.380197048738361d, (-1608.495438637974d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(152L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 5.9484893E18f, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2182506082114927E22d + "'", double2 == 1.2182506082114927E22d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.8159496001766002d, (java.lang.Number) 0.351548590286222d, true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) ' ');
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, 52);
        double[] doubleArray14 = new double[] { 10L, 1.0f };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) ' ');
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17, 52);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 1.0f);
        double[] doubleArray23 = null;
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray22);
        double[] doubleArray28 = new double[] { 10L, 1.0f };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) ' ');
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray31, 52);
        double[] doubleArray36 = new double[] { 10L, 1.0f };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) ' ');
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, 52);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray44);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray2, doubleArray44);
        double[] doubleArray52 = new double[] { 10L, 1.0f };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) ' ');
        double[] doubleArray58 = new double[] { 10L, 1.0f };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-868592058) + "'", int20 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-868592058) + "'", int42 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 9.181818181818182d + "'", double49 == 9.181818181818182d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 2.16440893E10f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 21644089344L + "'", long1 == 21644089344L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1L, 2896.3094188984737d, (double) 142L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 0, (double) 52, 1.5707963267948966d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver3.solve(68, univariateRealFunction6, (double) 10.0f, 3.141592653589793d, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) Double.NaN);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = notPositiveException1.getContext();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-18), 9600);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 9,600, n = -18");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int1 = org.apache.commons.math.util.FastMath.abs(3200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3200 + "'", int1 == 3200);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 152.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [152, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 1078525952, (double) 35867344980L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.588355687698014E10d + "'", double2 == 3.588355687698014E10d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        float float2 = org.apache.commons.math.util.MathUtils.round(34.999996f, 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        int int3 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve(0, univariateRealFunction5, 1.0000000000000008E-150d, 35.0d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 12L, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 5L, 0.17093156852589028d, (double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.079574529000002E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1072693280L, 32, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1079574528, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.079574527779588E11d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 7, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, 0);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray19 = new double[] { 10L, 1.0f };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray19);
        double[] doubleArray24 = new double[] { 10L, 1.0f };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) ' ');
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, 52);
        double[] doubleArray32 = new double[] { 10L, 1.0f };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) ' ');
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray35, 52);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double[] doubleArray41 = null;
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray40);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray40);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 3.141592653589793d);
        double[] doubleArray49 = new double[] { 10L, 1.0f };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) ' ');
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52, 52);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 1.0f);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray66 = new double[] { 10L, 1.0f };
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray60);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray60);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray60);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-868592058) + "'", int38 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-868592058) + "'", int55 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.0d + "'", double69 == 10.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 9.090909090909092d + "'", double71 == 9.090909090909092d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.17093156852589028d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 2, 2.1818435879447726d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 26.710743801652892d, (java.lang.Number) (-16L), false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray14 = new int[] { 1079574528, (byte) 1 };
        int[] intArray19 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int[] intArray26 = new int[] { (-1), 52, 0, 10, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray26);
        int[] intArray30 = new int[] { 1079574528, (byte) 1 };
        int[] intArray35 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray39 = new int[] { 1079574528, (byte) 1 };
        int[] intArray44 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray44);
        int[] intArray51 = new int[] { (-1), 52, 0, 10, 100 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray51);
        int[] intArray55 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) '4');
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1079574580 + "'", int27 == 1079574580);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1079574580 + "'", int52 == 1079574580);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.079574529000002E9d + "'", double53 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 5, 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException5.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray14);
        java.lang.Throwable[] throwableArray16 = nullArgumentException15.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 0.5943665446595849d, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-14.52444713108708d), (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) -1, (-30145599));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for binomial coefficient (n, k), got n = -1");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 618402555, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0920128E8f + "'", float2 == 3.0920128E8f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        int int5 = regulaFalsiSolver1.getMaxEvaluations();
        double double6 = regulaFalsiSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 1.07269658E9f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.0000000000000008E-150d, (double) 6L, (double) 68, 363.7393755555636d, 1.5515679276951895d, (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 24733.43345207068d + "'", double6 == 24733.43345207068d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, Double.POSITIVE_INFINITY, (double) ' ', 0.0d, (-0.9999999999997456d), objArray5);
        double double7 = noBracketingException6.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, objArray2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = maxCountExceededException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        exceptionContext4.setValue("", (java.lang.Object) localizedFormats6);
        java.util.Set<java.lang.String> strSet8 = exceptionContext4.getKeys();
        java.lang.Object obj10 = exceptionContext4.getValue("org.apache.commons.math.exception.MathIllegalStateException: denominator format");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray16);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray16);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray16);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException20 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray16);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) mathArithmeticException20);
        java.lang.String str22 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (2 > -0.839)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (2 > -0.839)"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 58, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 3200, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3200.0f + "'", float2 == 3200.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.9E-324d, (double) 35L, 0.0d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.9999999999997456d), (java.lang.Number) 0.0f, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) '#', (double) 97.00001f, (double) (short) 0, 1.0795745782851064E9d, 6.579251212010101d, (double) (-868592058), 4.9E-324d, (double) (-5904236292362534911L));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-5.714681955338581E9d) + "'", double8 == (-5.714681955338581E9d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        double[] doubleArray19 = new double[] { 10L, 1.0f };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) ' ');
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22, 52);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray27);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray27);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.141592653589793d);
        double[] doubleArray36 = new double[] { 10L, 1.0f };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) ' ');
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, 52);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray53 = new double[] { 10L, 1.0f };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray47);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray47);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray47);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.909 >= 0.091)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-868592058) + "'", int25 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-868592058) + "'", int42 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 10.0d + "'", double56 == 10.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 9.090909090909092d + "'", double58 == 9.090909090909092d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 29.236001806897132d, (java.lang.Number) 9.332621544395286E157d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(2.16440893E10f, (double) 1079574528L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.16440873E10f + "'", float2 == 2.16440873E10f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 19.09090909090909d, (java.lang.Number) 1.3495709937154414d, false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, 1025.8508197214162d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray14 = new int[] { 1079574528, (byte) 1 };
        int[] intArray19 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int[] intArray26 = new int[] { (-1), 52, 0, 10, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray26);
        int[] intArray30 = new int[] { 1079574528, (byte) 1 };
        int[] intArray35 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray39 = new int[] { 1079574528, (byte) 1 };
        int[] intArray44 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray44);
        int[] intArray51 = new int[] { (-1), 52, 0, 10, 100 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray51);
        int[] intArray55 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) '4');
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray55);
        int[] intArray60 = new int[] { 1079574528, (byte) 1 };
        int[] intArray65 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray60);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats68, (java.lang.Number) 29.236001806897132d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats71 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats76 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats81 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException83 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats81, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray84 = notStrictlyPositiveException83.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext85 = notStrictlyPositiveException83.getContext();
        java.lang.Object obj87 = exceptionContext85.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats88 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray90 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException91 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray90);
        exceptionContext85.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats88, objArray90);
        org.apache.commons.math.exception.NoBracketingException noBracketingException93 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats76, (double) (-868592058), 1.079574529000002E9d, 100.0d, Double.NaN, objArray90);
        org.apache.commons.math.exception.NoBracketingException noBracketingException94 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats71, (double) (short) 100, (double) (-2), (double) 3210, 1.7453292519943295d, objArray90);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) intArray60, (org.apache.commons.math.exception.util.Localizable) localizedFormats68, objArray90);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1079574580 + "'", int27 == 1079574580);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1079574580 + "'", int52 == 1079574580);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.079574529000002E9d + "'", double53 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats68.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats71.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats76.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats81.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray84);
        org.junit.Assert.assertNotNull(exceptionContext85);
        org.junit.Assert.assertNull(obj87);
        org.junit.Assert.assertTrue("'" + localizedFormats88 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats88.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray90);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03093515553795393d + "'", double1 == 0.03093515553795393d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.09524572920695733d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100, 1.60978210179491616E17d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] { 10L, 1.0f };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) ' ');
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, 52);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, (int) 'a');
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, 52);
        double[] doubleArray55 = new double[] { 10L, 1.0f };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) ' ');
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58, 52);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray52);
        double double68 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray18, doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection75, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.0f, (java.lang.Number) 618402555, (int) (short) 100, orderDirection75, true);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection75, false, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection83, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly decreasing (0 <= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-868592058) + "'", int42 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-868592058) + "'", int61 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 854.7438016528926d + "'", double68 == 854.7438016528926d);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.9711353880321711E12d, (-2), (-3300));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] { 10L, 1.0f };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray16 = new double[] { 10L, 1.0f };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        double[] doubleArray29 = new double[] { 10L, 1.0f };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) ' ');
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, 52);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 1.0f);
        double[] doubleArray38 = null;
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 3.141592653589793d);
        double double44 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray37);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-868592058) + "'", int35 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 26.710743801652892d + "'", double44 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 29.236001806897132d + "'", double45 == 29.236001806897132d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        float[] floatArray18 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray23 = null;
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray23);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.exp(9600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-2), (double) 1.1920929E-7f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 10L, 1.0f };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) ' ');
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, 52);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray19);
        try {
            double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-868592058) + "'", int17 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 2.7182818284590455d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1079574580, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574580 + "'", int2 == 1079574580);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.41036740004704136d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.38878459101458657d) + "'", double1 == (-0.38878459101458657d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double2 = org.apache.commons.math.util.FastMath.pow(11013.232920103324d, 1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1741772.8558443133d + "'", double2 == 1741772.8558443133d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.sinh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) ' ');
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11, 52);
        double[] doubleArray16 = new double[] { 10L, 1.0f };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) ' ');
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, 52);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double[] doubleArray25 = null;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray24);
        double[] doubleArray30 = new double[] { 10L, 1.0f };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray32);
        double[] doubleArray36 = new double[] { 10L, 1.0f };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) ' ');
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, 52);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, (int) 'a');
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, 52);
        double[] doubleArray55 = new double[] { 10L, 1.0f };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) ' ');
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58, 52);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray52);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray39);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-868592058) + "'", int22 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 9.090909090909092d + "'", double33 == 9.090909090909092d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-868592058) + "'", int42 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-868592058) + "'", int61 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 19.186126185776242d + "'", double69 == 19.186126185776242d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3210, (-1.5707963267948966d), 1079574564);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1.07957453E11f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.math.util.FastMath.max(3147, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3147 + "'", int2 == 3147);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.079574528E9d, 1079574528);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-559.9999936316624d), 3200, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray7 = new double[] { 10L, 1.0f };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) ' ');
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, 52);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) 'a');
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray15);
        double[] doubleArray19 = new double[] { 10L, 1.0f };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) ' ');
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22, 52);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-868592058) + "'", int13 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 19.09090909090909d + "'", double16 == 19.09090909090909d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.831008000716577E22d);
        double double2 = regulaFalsiSolver1.getMin();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver1.solve((-96), univariateRealFunction5, (double) 3.8146973E-6f, (double) 5948489912671272961L, (-0.9999999999997456d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getLo();
        double double8 = noBracketingException6.getFHi();
        double double9 = noBracketingException6.getLo();
        double double10 = noBracketingException6.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.718281828459045d + "'", double10 == 2.718281828459045d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 314700, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 314705L + "'", long2 == 314705L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1111295802), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1111295750) + "'", int2 == (-1111295750));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) (short) 0, (float) 21644089425L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(361.0d, (double) 7, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double4 = regulaFalsiSolver3.getMax();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getRelativeAccuracy();
        double double7 = regulaFalsiSolver3.getAbsoluteAccuracy();
        int int8 = regulaFalsiSolver3.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution12 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double13 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, 32.0d, 0.0d, 8.881784197001252E-16d, allowedSolution12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution12 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution12.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        double double5 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1079574528L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 963000L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, 1620404783);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.5811052399411398d, (double) 3200);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5811052399411398d + "'", double2 == 1.5811052399411398d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 3200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-16L));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, number1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double2 = org.apache.commons.math.util.FastMath.hypot(361.0d, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 361.00191287283445d + "'", double2 == 361.00191287283445d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-868592058));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException4.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5515679276951895d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int10 = regulaFalsiSolver9.getEvaluations();
        exceptionContext4.setValue("out of range", (java.lang.Object) regulaFalsiSolver9);
        int int12 = regulaFalsiSolver9.getEvaluations();
        double double13 = regulaFalsiSolver9.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.079574528E9d + "'", double13 == 1.079574528E9d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.743392130574644E-23d, (java.lang.Number) 0.6931471805599453d, (-3300));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) 1079574580, 363.7393755555636d, 2.2041199826559246d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 801.7252261408056d + "'", double4 == 801.7252261408056d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-29L), 7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 97, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.440892098500626E-16d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 3200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getFHi();
        double double10 = noBracketingException6.getLo();
        java.lang.Throwable[] throwableArray11 = noBracketingException6.getSuppressed();
        double double12 = noBracketingException6.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1079574528);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }
}

