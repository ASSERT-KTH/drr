import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount((-1));
        incrementor0.incrementCount();
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 1.1752011936438014d, 10.0854373658767d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        org.apache.commons.math.util.MathUtils.checkFinite(22025.465794806718d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 3235577856L, (float) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.799832844906106d + "'", double1 == 20.799832844906106d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(21.0d, (double) 58, (double) 5.9484893E18f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1079574529, 1.015269573507533d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.285715710302049E-4d + "'", double2 == 7.285715710302049E-4d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.2250738585072014E-308d, (double) 152.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(68);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4800355424368287E96d + "'", double1 == 2.4800355424368287E96d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(5.948489912671273E18d, 1025.8508197214162d, (-1.079574527779588E11d), 2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.102263253018401E21d + "'", double4 == 6.102263253018401E21d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, 107957452800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 1079574528L, 100.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1079574580L, (double) 7, 3147);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.755223276691055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.784739195201826d + "'", double1 == 5.784739195201826d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        java.lang.Class<?> wildcardClass11 = mathArithmeticException10.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.7763568394002505E-15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(3.079336099152003d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-18));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1031.3240312354817d) + "'", double1 == (-1031.3240312354817d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 'a', 1.09951163E12f, (float) (-29L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.831008000716577E22d);
        double double2 = regulaFalsiSolver1.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver1.solve((-3200), univariateRealFunction4, 0.009949835840666133d, 9.914443704113327E9d, (double) 57.999996f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1079574528, (long) 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574596L + "'", long2 == 1079574596L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray9);
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray9);
        java.util.Set<java.lang.String> strSet12 = exceptionContext4.getKeys();
        java.lang.Class<?> wildcardClass13 = strSet12.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.791759469228055d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-975795447) + "'", int1 == (-975795447));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-5.9042362923625349E18d), 32, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double2 = org.apache.commons.math.util.FastMath.copySign(5.784739195201826d, (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.784739195201826d + "'", double2 == 5.784739195201826d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4714997966830203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.063091050668521d + "'", double1 == 2.063091050668521d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, 1.9309150279939942d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.119145819711063d + "'", double2 == 9.119145819711063d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 58L, 1.0E-14d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int10 = regulaFalsiSolver9.getEvaluations();
        exceptionContext4.setValue("out of range", (java.lang.Object) regulaFalsiSolver9);
        double double12 = regulaFalsiSolver9.getStartValue();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        long long1 = org.apache.commons.math.util.MathUtils.sign(5948489912671272961L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(363.7393755555636d, 5.293955920339377E-23d, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7165256995489035d + "'", double1 == 1.7165256995489035d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(1.0000002f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000004f + "'", float1 == 1.0000004f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3628800.0d, (java.lang.Number) 1620404783, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray16 = new int[] { 1079574528, (byte) 1 };
        int[] intArray21 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray25 = new int[] { 1079574528, (byte) 1 };
        int[] intArray30 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray30);
        int[] intArray37 = new int[] { (-1), 52, 0, 10, 100 };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray37);
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray21, (int) '4');
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray42);
        try {
            int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray42, (-53));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1079574580 + "'", int38 == 1079574580);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.079574529000002E9d + "'", double39 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.873190273214229d, (java.lang.Number) 58L, (-42), orderDirection3, false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "numerator format" + "'", str1.equals("numerator format"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long2 = org.apache.commons.math.util.FastMath.max(6L, 35867344980L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35867344980L + "'", long2 == 35867344980L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 30, (float) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.7194528101212354E12d, (java.lang.Number) 142L, false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.1709315685258903d);
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-1.1271723566561087E20d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int int2 = org.apache.commons.math.util.FastMath.max(3, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1.0000002f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430809150050864d + "'", double1 == 1.5430809150050864d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        double[] doubleArray19 = new double[] { 10L, 1.0f };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) ' ');
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22, 52);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray27);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray27);
        double[] doubleArray34 = new double[] { 10L, 1.0f };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) ' ');
        double double38 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray37);
        double[] doubleArray41 = new double[] { 10L, 1.0f };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) ' ');
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray44, 52);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray44);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 0);
        double[] doubleArray54 = new double[] { 10L, 1.0f };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) ' ');
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray57, 52);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray57, (int) 'a');
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-868592058) + "'", int25 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 9.090909090909092d + "'", double31 == 9.090909090909092d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 26.710743801652892d + "'", double38 == 26.710743801652892d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-868592058) + "'", int47 == (-868592058));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 28.322376750431598d + "'", double49 == 28.322376750431598d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-868592058) + "'", int60 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 28.18181818181818d + "'", double63 == 28.18181818181818d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException7 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10.0d);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) tooManyEvaluationsException7);
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        int int11 = nonMonotonousSequenceException5.getIndex();
        boolean boolean12 = nonMonotonousSequenceException5.getStrict();
        int int13 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.incrementCount();
        incrementor0.resetCount();
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 36, (float) 21644089425L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.16440893E10f + "'", float2 == 2.16440893E10f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1620404783, (-3300L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-3,300)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(35.0f, (-5.9042356E18f), (float) 618402555);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray12);
        float[] floatArray21 = new float[] { 0.0f, 3.8146973E-6f, 100.0f, (short) -1, (byte) 10, 100L };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray21);
        float[] floatArray27 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray28);
        float[] floatArray34 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray34, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray35);
        float[] floatArray42 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray42, floatArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray35, floatArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray35);
        float[] floatArray51 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray52);
        float[] floatArray58 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray59 = null;
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray58, floatArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray59);
        float[] floatArray68 = new float[] { 0.0f, 3.8146973E-6f, 100.0f, (short) -1, (byte) 10, 100L };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray59, floatArray68);
        float[] floatArray70 = null;
        float[] floatArray75 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray76 = null;
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray75, floatArray76);
        float[] floatArray82 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray83 = null;
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray82, floatArray83);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray75, floatArray83);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray70, floatArray75);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(floatArray68, floatArray75);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray68);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(floatArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 21644089425L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, (long) (-3300));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-3,300)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getLo();
        double double8 = noBracketingException6.getFHi();
        double double9 = noBracketingException6.getLo();
        double double10 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35.0f, 3.831008000716577E22d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1608.495438637974d), 9.090909090909092d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 34.999996f, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.999996185302734d + "'", double2 == 34.999996185302734d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, number1, (java.lang.Number) 1.0000001f, false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        float float2 = org.apache.commons.math.util.FastMath.copySign(1.0f, 6.0000005f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException2 = new org.apache.commons.math.exception.TooManyEvaluationsException(number1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        java.lang.String str19 = mathIllegalStateException18.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.MathIllegalStateException: overflow in subtraction: {0} - {1}" + "'", str19.equals("org.apache.commons.math.exception.MathIllegalStateException: overflow in subtraction: {0} - {1}"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0726932480000001E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.793438378082765d + "'", double1 == 20.793438378082765d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        int int5 = regulaFalsiSolver1.getMaxEvaluations();
        int int6 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-42), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2896.3094188984737d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 2.302585092994046d, 0.009949835840666133d, 1.0E-14d, 84.73931296875567d, objArray5);
        java.lang.Class<?> wildcardClass7 = noBracketingException6.getClass();
        double double8 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.302585092994046d + "'", double8 == 2.302585092994046d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.831008000716577E22d);
        double double2 = regulaFalsiSolver1.getMin();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve((int) (byte) -1, univariateRealFunction5, (double) 5L, 6.867258771281655d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 57.999996f, 260);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 57.999996185302734d + "'", double2 == 57.999996185302734d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.math.util.FastMath.rint(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 58);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.079574529000002E9d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079574529000002E9d + "'", double2 == 1.079574529000002E9d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = null;
        try {
            double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.20787957635076193d, (double) ' ');
        int int5 = regulaFalsiSolver4.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 0.6657737500283538d, (double) 314705L, 0.0d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 963000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, objArray3);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 99, (double) (short) -1, 0.0d, (double) 100L, objArray15);
        double double18 = noBracketingException17.getHi();
        double double19 = noBracketingException17.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = null;
        try {
            double double35 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0000002f, (float) (-3300L), 3147);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.588355687698014E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.262862148299572E8d + "'", double1 == 6.262862148299572E8d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.1271723566561087E20d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1271723566561087E20d) + "'", double1 == (-1.1271723566561087E20d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.FastMath.exp(21.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3188157344832146E9d + "'", double1 == 1.3188157344832146E9d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(52, 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,079,574,528, n = 52");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-868592058), 618402555);
        java.lang.String str4 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "some rows have length {0} while others have length {1}" + "'", str4.equals("some rows have length {0} while others have length {1}"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.0000000000000008E-150d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1079574529, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.incrementCount();
        int int8 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-1.1752011936438014d), 20.799832845832398d, 3.484698397226463E12d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (-58L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException3.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = mathArithmeticException5.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException5.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray16 = notStrictlyPositiveException15.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = notStrictlyPositiveException15.getContext();
        java.lang.Object obj19 = exceptionContext17.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray22);
        exceptionContext17.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray22);
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) (-868592058), 1.079574529000002E9d, 100.0d, Double.NaN, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 1079574580, (java.lang.Number) 2.3841858E-7f, false);
        java.lang.Object[] objArray30 = null;
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.7763568394002505E-15d), (java.lang.Number) 10.04987562112089d, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(68, (-18));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-18)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 1079574528L, 5.298342365610589d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-1.0d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve(32, univariateRealFunction3, 84.73931296875568d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 97.0f, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.resetCount();
        try {
            incrementor0.incrementCount(300);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-42), 1.084066969169249d, 618402555);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 11, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double7 = regulaFalsiSolver1.solve(52, univariateRealFunction3, 0.9999999958776927d, 99.99999999999999d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 9.181818181818182d, 9.914443704113327E9d, (-1111295750));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 2.0d, (double) 1079574528, 1.1752011936438014d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 30, (-3.91886975727153E-15d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 29.999998f + "'", float2 == 29.999998f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-0.0d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.5152978171476064d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.055470024017319465d + "'", double1 == 0.055470024017319465d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.784739195201826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.544286559205797d) + "'", double1 == (-0.544286559205797d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 3, (int) (short) 1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException13 = new org.apache.commons.math.exception.TooManyEvaluationsException(number12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException27 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray24);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext29 = mathIllegalStateException28.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException34 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException41 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray40);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException42 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray40);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException43 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray40);
        exceptionContext29.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray40);
        org.apache.commons.math.exception.NoBracketingException noBracketingException45 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (double) 32, (double) 1078525952, (double) 100, 2.384185791015625E-7d, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.07957453E11f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4761.577708301236d + "'", double1 == 4761.577708301236d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-1.0d));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        int int3 = regulaFalsiSolver1.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve(0, univariateRealFunction5, 1.7724538509055159d, 0.21942525837900473d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-59L), 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-58.999996f) + "'", float2 == (-58.999996f));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-1.0d), (double) 35867344980L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int1 = org.apache.commons.math.util.MathUtils.hash(854.7438016528926d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 248339168 + "'", int1 == 248339168);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray8);
        double double10 = noBracketingException9.getFHi();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getLo();
        double double13 = noBracketingException9.getFLo();
        java.lang.Throwable[] throwableArray14 = noBracketingException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.718281828459045d + "'", double11 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.718281828459045d + "'", double13 == 2.718281828459045d);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException3.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = mathArithmeticException5.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException5.getContext();
        java.lang.Throwable[] throwableArray8 = mathArithmeticException5.getSuppressed();
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) -1, 10.0854373658767d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1620404783);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 36, 6.579251212010101d, 1.0E-14d, (double) 21644089344L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, (java.lang.Number) 1.60978210179491616E17d, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray15 = new int[] { 1079574528, (byte) 1 };
        int[] intArray20 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 0);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray25);
        int[] intArray29 = new int[] { 1079574528, (byte) 1 };
        int[] intArray34 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray36, 0);
        int[] intArray41 = new int[] { 1079574528, (byte) 1 };
        int[] intArray46 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int[] intArray53 = new int[] { (-1), 52, 0, 10, 100 };
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray53);
        int[] intArray57 = new int[] { 1079574528, (byte) 1 };
        int[] intArray62 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray62);
        int[] intArray66 = new int[] { 1079574528, (byte) 1 };
        int[] intArray71 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray71);
        int[] intArray78 = new int[] { (-1), 52, 0, 10, 100 };
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray78);
        int[] intArray82 = org.apache.commons.math.util.MathUtils.copyOf(intArray62, (int) '4');
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray82);
        int[] intArray87 = new int[] { 1079574528, (byte) 1 };
        int[] intArray92 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray87);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray87);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1079574580 + "'", int54 == 1079574580);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1079574580 + "'", int79 == 1079574580);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.079574529000002E9d + "'", double80 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1.4E-45f), 0.17453292519943295d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException17 = new org.apache.commons.math.exception.TooManyEvaluationsException(number16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray28);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException30 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray28);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException31 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray28);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray28);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = mathIllegalStateException32.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException45 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray44);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException46 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray44);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray44);
        exceptionContext33.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray44);
        org.apache.commons.math.exception.NoBracketingException noBracketingException49 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) 32, (double) 1078525952, (double) 100, 2.384185791015625E-7d, objArray44);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException50 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray44);
        java.lang.Class<?> wildcardClass51 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(wildcardClass51);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        long long2 = org.apache.commons.math.util.FastMath.min(160L, (long) 3147);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 160L + "'", long2 == 160L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int int2 = org.apache.commons.math.util.FastMath.min(1620404523, 300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300 + "'", int2 == 300);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, objArray3);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 99, (double) (short) -1, 0.0d, (double) 100L, objArray15);
        double double18 = noBracketingException17.getLo();
        double double19 = noBracketingException17.getFHi();
        double double20 = noBracketingException17.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 99.0d + "'", double18 == 99.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0000000794728534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.718282044488667d + "'", double1 == 1.718282044488667d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.FastMath.asin((-5.904236153912951E20d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(6.0000005f, (float) (-5904236292362534911L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3147, (-42));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-132174) + "'", int2 == (-132174));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.7182818284590453d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, objArray3);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 99, (double) (short) -1, 0.0d, (double) 100L, objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray24);
        java.lang.String str27 = localizedFormats18.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "cannot access {0} method in percentile implementation {1}" + "'", str27.equals("cannot access {0} method in percentile implementation {1}"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.9171523356672744d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection43, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.0f, (java.lang.Number) 618402555, (int) (short) 100, orderDirection43, true);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection43, true, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 3235577856L, (double) (byte) 0, 6.000000000000001d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [3,235,577,856, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.35252977886304d) + "'", double1 == (-15.35252977886304d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 142L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8090099069535975d) + "'", double1 == (-0.8090099069535975d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, number3, objArray4);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray16);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) 99, (double) (short) -1, 0.0d, (double) 100L, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.1499518398606595E8d, (-16.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.0d, (java.lang.Number) 1, 30);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.7194528101212354E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve((int) (byte) 1, univariateRealFunction5, 11.0d, (double) '#', allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 314700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.352522263609918d + "'", double1 == 13.352522263609918d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 35.0d);
        java.lang.Class<?> wildcardClass2 = tooManyEvaluationsException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-96), 1079574529);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,079,574,529, n = -96");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray12 = notStrictlyPositiveException11.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 3.732511156817248d, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, number3, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.16440893E10f, (java.lang.Object[]) throwableArray12);
        java.lang.Number number18 = maxCountExceededException17.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.16440893E10f + "'", number18.equals(2.16440893E10f));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, 152L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 10, (int) (byte) -1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (short) 0, (java.lang.Number) 1.60978210179491616E17d, false);
        boolean boolean8 = numberIsTooLargeException7.getBoundIsAllowed();
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) numberIsTooLargeException7);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (-42), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException2 = new org.apache.commons.math.exception.TooManyEvaluationsException(number1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext18 = mathIllegalStateException17.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray29);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException31 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray29);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException32 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray29);
        exceptionContext18.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException34 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.0726932480000001E9d, objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 152L, 1.0000001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 152.0f + "'", float2 == 152.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.079574529000002E9d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2214041920491114d + "'", double2 == 0.2214041920491114d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6574544541530771d + "'", double1 == 1.6574544541530771d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 35867348190L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 5948489912671272961L, (int) (byte) 100, 314700);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 314,700, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2 + "'", number6.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-618402520), (float) 32, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 851.9689327757983d, 0.5588463977399145d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 963000L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) 128.0f, 0.0d, (-0.38878459101458657d), 2.384185791015625E-7d, (double) (-1111295802), (double) 1L, 29.57254979383581d, 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.1112947669607573E9d) + "'", double8 == (-1.1112947669607573E9d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 300);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        double[] doubleArray23 = new double[] { 10L, 1.0f };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) ' ');
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 52);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray32 = null;
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray31);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray53);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray53);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 52);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) 'a');
        double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray53, doubleArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray53);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 84.73931296875568d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection76, false);
        java.lang.Number number79 = nonMonotonousSequenceException78.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = nonMonotonousSequenceException78.getDirection();
        boolean boolean83 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72, orderDirection80, true, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-868592058) + "'", int29 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-868592058) + "'", int66 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 26.710743801652892d + "'", double69 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.136250564655356d + "'", double70 == 9.136250564655356d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 2 + "'", number79.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray36 = null;
        try {
            double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1111295802) + "'", int35 == (-1111295802));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707055269350272d + "'", double1 == 1.5707055269350272d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException4 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException(localizable1, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.apache.commons.math.exception.MathInternalError mathInternalError15 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathIllegalStateException14);
        java.lang.Class<?> wildcardClass16 = mathIllegalStateException14.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 29.999998f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int int1 = org.apache.commons.math.util.MathUtils.hash(Double.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2146959360 + "'", int1 == 2146959360);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, objArray2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = maxCountExceededException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        exceptionContext4.setValue("", (java.lang.Object) localizedFormats6);
        java.util.Set<java.lang.String> strSet8 = exceptionContext4.getKeys();
        java.lang.Object obj10 = exceptionContext4.getValue("");
        java.util.Set<java.lang.String> strSet11 = exceptionContext4.getKeys();
        java.util.Set<java.lang.String> strSet12 = exceptionContext4.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", obj10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertNotNull(strSet12);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (double) (-58L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1023));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.009950000012498683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        double double3 = regulaFalsiSolver1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.9309150279939942d, 363.7393755555636d, 2146959360);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        double[] doubleArray17 = new double[] { 10L, 1.0f };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) ' ');
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, 52);
        double[] doubleArray25 = new double[] { 10L, 1.0f };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, 52);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray33);
        double[] doubleArray39 = new double[] { 10L, 1.0f };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray41);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, (int) 'a');
        double[] doubleArray56 = new double[] { 10L, 1.0f };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) ' ');
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59, 52);
        double[] doubleArray64 = new double[] { 10L, 1.0f };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) ' ');
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray67, 52);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 1.0f);
        double[] doubleArray73 = null;
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray72);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray61);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray48);
        double double78 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray33);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 107957452800L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-868592058) + "'", int31 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 9.090909090909092d + "'", double42 == 9.090909090909092d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-868592058) + "'", int70 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 26.710743801652892d + "'", double78 == 26.710743801652892d);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException7 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10.0d);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) tooManyEvaluationsException7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = tooManyEvaluationsException7.getContext();
        java.lang.Throwable[] throwableArray10 = tooManyEvaluationsException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int2 = org.apache.commons.math.util.FastMath.max(300, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300 + "'", int2 == 300);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray7 = new double[] { 10L, 1.0f };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) ' ');
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, 52);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) 'a');
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-868592058) + "'", int13 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 19.09090909090909d + "'", double16 == 19.09090909090909d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 72090561 + "'", int17 == 72090561);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-2), (double) 1.0000002f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.9999999f) + "'", float2 == (-1.9999999f));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int int1 = org.apache.commons.math.util.MathUtils.hash(360.99999994039536d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1081700353) + "'", int1 == (-1081700353));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(22025.465794806718d, (double) 58.0f, 0.17093156852589028d, (double) 5, 0.6843909265968924d, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1277477.8707566322d + "'", double6 == 1277477.8707566322d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 3, (int) (short) 1);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException11 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray17);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException(localizable8, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray17);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number6, objArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) (short) 1, 0, orderDirection29, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 30, (java.lang.Number) 10.000000000000002d, 0, orderDirection29, false);
        notFiniteNumberException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        java.lang.Number number35 = nonMonotonousSequenceException33.getPrevious();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 10.000000000000002d + "'", number35.equals(10.000000000000002d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (29.091 >= 2.909)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 99, (double) 21644089425L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.00001f + "'", float2 == 99.00001f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 300);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 0.0d);
        try {
            double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getFHi();
        double double10 = noBracketingException6.getLo();
        double double11 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.873190273214229d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8731902732142292d + "'", double1 == 0.8731902732142292d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5707963267948966d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray12);
        float[] floatArray21 = new float[] { 0.0f, 3.8146973E-6f, 100.0f, (short) -1, (byte) 10, 100L };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray21);
        float[] floatArray23 = null;
        float[] floatArray28 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray29 = null;
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray29);
        float[] floatArray35 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray35, floatArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray28);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray28);
        float[] floatArray45 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray46 = null;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray45, floatArray46);
        float[] floatArray52 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray53 = null;
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray52, floatArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray45, floatArray53);
        float[] floatArray62 = new float[] { 0.0f, 3.8146973E-6f, 100.0f, (short) -1, (byte) 10, 100L };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray53, floatArray62);
        float[] floatArray64 = null;
        float[] floatArray69 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray70 = null;
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray69, floatArray70);
        float[] floatArray76 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray77 = null;
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray76, floatArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray69, floatArray77);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray64, floatArray69);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(floatArray62, floatArray69);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray62);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1620404523, 50.0d, (-618402520));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NaN, (double) 10.0f, (double) 'a');
        double double4 = regulaFalsiSolver3.getMax();
        double double5 = regulaFalsiSolver3.getMax();
        double double6 = regulaFalsiSolver3.getStartValue();
        double double7 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution13 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double14 = regulaFalsiSolver3.solve(0, univariateRealFunction9, 0.9915754354503429d, 0.0d, 11013.232920103324d, allowedSolution13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution13 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution13.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.3614195558365d + "'", double1 == 44.3614195558365d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(29.57254979383581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5515679276951895d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 10L, 1.0f };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) ' ');
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, 52);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray19);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-868592058) + "'", int17 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double1 = org.apache.commons.math.util.FastMath.signum((-23.734272574603658d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException2 = new org.apache.commons.math.exception.TooManyEvaluationsException(number1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 963000L, (double) 29.999998f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 152L);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double6 = regulaFalsiSolver1.solve((-975795447), univariateRealFunction3, 3.080808751038084d, 0.6931471805599453d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(84.73931296875567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 3210, (long) (-42));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-42)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.0706198036401884d, 0.20940667843058006d, 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.732511156817248d, 0.0d, 1620404783);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(99.0d, 3.484698397226463E12d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1920928955078125E-7d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-5.9042356E18f), (double) (-29L), 52.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 34.999996185302734d, number1, false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        incrementor0.incrementCount(5);
        int int10 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (30) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 1620404783);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((-1608.495438637974d), 1.7106542054101733E38d, 363.7393755555636d, 0.009950000012498683d);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 363.7393755555636d + "'", double5 == 363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 363.7393755555636d + "'", double6 == 363.7393755555636d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0000000298023226d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.980232216565071E-8d + "'", double1 == 2.980232216565071E-8d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        float float1 = org.apache.commons.math.util.FastMath.ulp(97.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(3.079336099152003d, (double) (-975795447), 0.2214041920491114d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8579319071028917d + "'", double3 == 2.8579319071028917d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 360.99999994039536d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double2 = org.apache.commons.math.util.MathUtils.log((-5.904236153912951E20d), 9.223372036854776E18d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0000000298023226d, (double) 72090561, (double) 2.16440893E10f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 9600);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(3.49789674291322d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 1079574580L, (-1608.495438637974d), (double) (-5.9042356E18f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.setMaximalCount(1620404523);
        int int5 = incrementor0.getMaximalCount();
        incrementor0.incrementCount(6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1620404523 + "'", int5 == 1620404523);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray8);
        noBracketingException6.addSuppressed((java.lang.Throwable) nullArgumentException9);
        double double11 = noBracketingException6.getFLo();
        org.apache.commons.math.exception.MathInternalError mathInternalError12 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.718281828459045d + "'", double11 == 2.718281828459045d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5515679276951895d, (double) 1079574580L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5263085229064353d, (java.lang.Number) 3.49789674291322d, 35, orderDirection11, true);
        int int14 = nonMonotonousSequenceException13.getIndex();
        int int15 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 2 + "'", number9.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-5904236292362534911L), (long) (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,023)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        double[] doubleArray19 = new double[] { 10L, 1.0f };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) ' ');
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22, 52);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray27);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray27);
        double[] doubleArray34 = new double[] { 10L, 1.0f };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) ' ');
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, 52);
        double[] doubleArray42 = new double[] { 10L, 1.0f };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) ' ');
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45, 52);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        double[] doubleArray51 = null;
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray50);
        double[] doubleArray56 = new double[] { 10L, 1.0f };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) ' ');
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59, 52);
        double[] doubleArray64 = new double[] { 10L, 1.0f };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) ' ');
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray67, 52);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 1.0f);
        double[] doubleArray73 = null;
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray72);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray72);
        double[] doubleArray79 = new double[] { 10L, 1.0f };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray79);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) ' ');
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray82, 52);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray82, (int) 'a');
        double double88 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray72, doubleArray82);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray82);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-868592058) + "'", int25 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 9.090909090909092d + "'", double31 == 9.090909090909092d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-868592058) + "'", int48 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-868592058) + "'", int70 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-868592058) + "'", int85 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 26.710743801652892d + "'", double88 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 19.186126185776242d + "'", double89 == 19.186126185776242d);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException7.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = notStrictlyPositiveException7.getContext();
        java.lang.Object obj11 = exceptionContext9.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray14);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray14);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-868592058), 1.079574529000002E9d, 100.0d, Double.NaN, objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray25 = notStrictlyPositiveException24.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException28 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray7 = new double[] { 10L, 1.0f };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) ' ');
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, 52);
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double[] doubleArray16 = new double[] { 10L, 1.0f };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) ' ');
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, 52);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) 'a');
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray28 = new double[] { 10L, 1.0f };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28);
        double[] doubleArray32 = new double[] { 10L, 1.0f };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray32);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray53);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray53);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 3.141592653589793d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection63, false);
        java.lang.Number number66 = nonMonotonousSequenceException65.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = nonMonotonousSequenceException65.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException65.getDirection();
        boolean boolean71 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection68, true, false);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection68, true, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection68, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (29.091 > 2.909)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 21.0d + "'", double13 == 21.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-868592058) + "'", int22 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 2 + "'", number66.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(50.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.20787957635076193d, (double) ' ');
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver2.solve(0, univariateRealFunction5, 6.751971034208944d, 0.0d, (double) (-42));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(35.0f, (float) (-5904236292362534911L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray14 = new double[] { 10L, 1.0f };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14);
        double[] doubleArray18 = new double[] { 10L, 1.0f };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        double[] doubleArray23 = new double[] { 10L, 1.0f };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) ' ');
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 52);
        double[] doubleArray31 = new double[] { 10L, 1.0f };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) ' ');
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34, 52);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 1.0f);
        double[] doubleArray40 = null;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray39);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray39);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 3.141592653589793d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection49, false);
        java.lang.Number number52 = nonMonotonousSequenceException51.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException51.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException51.getDirection();
        boolean boolean57 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection54, true, false);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-868592058) + "'", int37 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 2 + "'", number52.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) '4', 1.1920928955078125E-7d, (double) (byte) 10, 0.0d, (double) (-53), 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.198883056640625E-6d + "'", double6 == 6.198883056640625E-6d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) noBracketingException6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1079574528, 1079574528L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574528L + "'", long2 == 1079574528L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        double double5 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) Double.NaN);
        java.lang.Number number2 = notPositiveException1.getArgument();
        java.lang.Number number3 = notPositiveException1.getMin();
        java.lang.Throwable[] throwableArray4 = notPositiveException1.getSuppressed();
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.0d, (java.lang.Number) 52.0d, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooSmallException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(72090561, 9600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72080961 + "'", int2 == 72080961);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-0.0f), (double) 5, 0.0d);
        double double4 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 360.0d + "'", double1 == 360.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 2, 2.16440873E10f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray36 = new double[] { 10L, 1.0f };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) ' ');
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, 52);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, (int) 'a');
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, 52);
        double[] doubleArray55 = new double[] { 10L, 1.0f };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) ' ');
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58, 52);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray52);
        double double68 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray18, doubleArray52);
        double[] doubleArray71 = new double[] { 10L, 1.0f };
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) ' ');
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray74, 52);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 1.0f);
        double[] doubleArray82 = new double[] { 10L, 1.0f };
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray82);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) ' ');
        double[] doubleArray88 = new double[] { 10L, 1.0f };
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray82);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-868592058) + "'", int42 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-868592058) + "'", int61 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 854.7438016528926d + "'", double68 == 854.7438016528926d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-868592058) + "'", int77 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 10.0d + "'", double91 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        float float1 = org.apache.commons.math.util.FastMath.signum(35.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (-1.5152978171476064d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 260, (long) (-975795447));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-253706816220L) + "'", long2 == (-253706816220L));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (byte) 0, (float) 160L, 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, 0);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(97.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2L, 2.8579319071028917d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        double[] doubleArray19 = new double[] { 10L, 1.0f };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) ' ');
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22, 52);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray27);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray27);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 3.141592653589793d);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, 72090561);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-868592058) + "'", int25 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double2 = org.apache.commons.math.util.MathUtils.log(9.332621544395286E157d, 84.73931296875567d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.012205386427753895d + "'", double2 == 0.012205386427753895d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.582023220382097d, 29.236001806897132d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(3.079336099152003d, 4.605170185988092d, (double) 99.00001f, (double) 6, (-7.15690594188224d), 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 608.1809125728189d + "'", double6 == 608.1809125728189d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, (-53));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-53)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999092042625951d + "'", double1 == 0.9999092042625951d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1.4E-45f), (double) 0, 26.710743801652892d, (double) 9223372036854775807L, objArray5);
        double double7 = noBracketingException6.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-5904236293441060863L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5904236293441060863L) + "'", long2 == (-5904236293441060863L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        float[] floatArray4 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray5);
        float[] floatArray11 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        float[] floatArray18 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray27 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray28);
        float[] floatArray34 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray34, floatArray35);
        float[] floatArray41 = new float[] { '#', (-1), 100.0f, (short) 10 };
        float[] floatArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray41, floatArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray34, floatArray42);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray28, floatArray34);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray28);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException4.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = notStrictlyPositiveException4.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("out of range");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int12 = regulaFalsiSolver11.getEvaluations();
        exceptionContext6.setValue("out of range", (java.lang.Object) regulaFalsiSolver11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray18 = notStrictlyPositiveException17.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext19 = notStrictlyPositiveException17.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray22);
        java.lang.Throwable[] throwableArray24 = nullArgumentException23.getSuppressed();
        exceptionContext19.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Object[]) throwableArray24);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1072696548L, (java.lang.Object[]) throwableArray24);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1079574596L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1072693248);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 10L, 1.0f };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) ' ');
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, 52);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) ' ');
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray14, 52);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray19);
        double[] doubleArray25 = new double[] { 10L, 1.0f };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, 52);
        double[] doubleArray33 = new double[] { 10L, 1.0f };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) ' ');
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, 52);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray41);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        double[] doubleArray48 = new double[] { 10L, 1.0f };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) ' ');
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, 52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, (int) 'a');
        double double57 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray41, doubleArray51);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        try {
            double double60 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray0, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-868592058) + "'", int17 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-868592058) + "'", int39 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-868592058) + "'", int54 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 26.710743801652892d + "'", double57 == 26.710743801652892d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 57.999996f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.060442944775775d + "'", double1 == 4.060442944775775d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 52, (double) 314705L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.079574529000002E9d, (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963212371516d + "'", double2 == 1.5707963212371516d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.0795745782851064E9d, 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0795745782851064E9d + "'", double2 == 1.0795745782851064E9d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        double double9 = noBracketingException6.getFHi();
        double double10 = noBracketingException6.getLo();
        org.apache.commons.math.exception.MathInternalError mathInternalError11 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.718281828459045d + "'", double8 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1.9999999f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.009900662135208755d, (double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009900662135208757d + "'", double2 == 0.009900662135208757d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray7 = notStrictlyPositiveException6.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1.4E-45f), (double) 0, 26.710743801652892d, (double) 9223372036854775807L, objArray5);
        java.lang.String str7 = noBracketingException6.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: elements cannot be retrieved from a negative array index -0" + "'", str7.equals("org.apache.commons.math.exception.NoBracketingException: elements cannot be retrieved from a negative array index -0"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-2), (-1081700353));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((-5.9042362923625349E18d), 0.8731902732142292d, (double) 300);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException4 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        java.lang.Throwable[] throwableArray5 = nullArgumentException4.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.5943665446595849d, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException(84.73931296875567d, 0.20787957635076193d, (-23.734272574603658d), (-1.401298464324817E-45d));
        notFiniteNumberException6.addSuppressed((java.lang.Throwable) noBracketingException11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-30145599), (java.lang.Number) 4.060442944775775d, 300);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        org.apache.commons.math.util.MathUtils.checkFinite((-1.5701746278785413d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 'a');
        double double2 = regulaFalsiSolver1.getMax();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        int int5 = regulaFalsiSolver1.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double11 = regulaFalsiSolver1.solve((-868592058), univariateRealFunction7, (double) 6L, 6.102263253018401E21d, (double) 300);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int10 = regulaFalsiSolver9.getEvaluations();
        exceptionContext4.setValue("out of range", (java.lang.Object) regulaFalsiSolver9);
        int int12 = regulaFalsiSolver9.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        double[] doubleArray10 = new double[] { 10L, 1.0f };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) ' ');
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 52);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray18);
        double[] doubleArray24 = new double[] { 10L, 1.0f };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray26);
        double[] doubleArray30 = new double[] { 10L, 1.0f };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) ' ');
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33, 52);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33, (int) 'a');
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double[] doubleArray42 = new double[] { 10L, 1.0f };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        double[] doubleArray46 = new double[] { 10L, 1.0f };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray46);
        double[] doubleArray51 = new double[] { 10L, 1.0f };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) ' ');
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray54, 52);
        double[] doubleArray59 = new double[] { 10L, 1.0f };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) ' ');
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray62, 52);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 1.0f);
        double[] doubleArray68 = null;
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray67);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray67);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 3.141592653589793d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection77, false);
        java.lang.Number number80 = nonMonotonousSequenceException79.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = nonMonotonousSequenceException79.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = nonMonotonousSequenceException79.getDirection();
        boolean boolean85 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection82, true, false);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray67);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-868592058) + "'", int16 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 9.090909090909092d + "'", double27 == 9.090909090909092d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-868592058) + "'", int36 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-868592058) + "'", int65 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 2 + "'", number80.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection81 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection81.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection82.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 31.0d + "'", double87 == 31.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 4.440892098500626E-16d, (java.lang.Number) 2.7182818284590455d, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.7182818284590455d + "'", number5.equals(2.7182818284590455d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int2 = org.apache.commons.math.util.FastMath.max(99, 1078525952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078525952 + "'", int2 == 1078525952);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(58.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9403184054350179d + "'", double1 == 0.9403184054350179d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.015269573507533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7007529698288765d + "'", double1 == 0.7007529698288765d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.07957453E11f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double1 = org.apache.commons.math.util.FastMath.signum(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.60978210179491616E17d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int int2 = org.apache.commons.math.util.FastMath.min(1079574580, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.2214041920491114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0246101944708708d + "'", double1 == 1.0246101944708708d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray15 = new int[] { 1079574528, (byte) 1 };
        int[] intArray20 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 0);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray25);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) 'a');
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray28, 3);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray28, 0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (-0.0f), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, (java.lang.Number) (-0.8163415799735064d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        int int1 = org.apache.commons.math.util.FastMath.abs((-96));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 96 + "'", int1 == 96);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-18), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8) + "'", int2 == (-8));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double double2 = org.apache.commons.math.util.MathUtils.log(10.0854373658767d, (double) 3147);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.485020510061639d + "'", double2 == 3.485020510061639d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(152.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 152.00002f + "'", float1 == 152.00002f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.20787957635076193d, (double) ' ');
        double double3 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("out of range");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int10 = regulaFalsiSolver9.getEvaluations();
        exceptionContext4.setValue("out of range", (java.lang.Object) regulaFalsiSolver9);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction13 = null;
        try {
            double double17 = regulaFalsiSolver9.solve((-1023), univariateRealFunction13, 5.948489912671273E18d, 2.7182818284590455d, 10.0854373658767d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.030475546991784d + "'", double1 == 9.030475546991784d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(29.614185789921695d, (-5.9042362923625349E18d), (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(128.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.97958971132712d + "'", double1 == 97.97958971132712d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-3300));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double2 = org.apache.commons.math.util.FastMath.min(3.080808751038084d, 1.60978210179491616E17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.080808751038084d + "'", double2 == 3.080808751038084d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 3015.9999999999986d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1072696548L, 1.0000002f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray15 = new int[] { 1079574528, (byte) 1 };
        int[] intArray20 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 0);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray25);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) 'a');
        int[] intArray31 = new int[] { 1079574528, (byte) 1 };
        int[] intArray36 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray38, 0);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray40);
        int[] intArray44 = new int[] { 1079574528, (byte) 1 };
        int[] intArray49 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray53 = new int[] { 1079574528, (byte) 1 };
        int[] intArray58 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray58);
        int[] intArray65 = new int[] { (-1), 52, 0, 10, 100 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray65);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray65);
        int[] intArray70 = org.apache.commons.math.util.MathUtils.copyOf(intArray65, 32);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1079574580 + "'", int66 == 1079574580);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.079574529000002E9d + "'", double67 == 1.079574529000002E9d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray70);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.8414709848078965d, 11, 1078525952);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 58L, (float) 5948489912671272961L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.1709315685258903d);
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "number of trials must be non-negative ({0})" + "'", str3.equals("number of trials must be non-negative ({0})"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(11.0d, 30, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double2 = org.apache.commons.math.util.FastMath.min((-5.714681955338581E9d), (-1608.495438637974d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.714681955338581E9d) + "'", double2 == (-5.714681955338581E9d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, 0);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) (short) 1, 0, orderDirection29, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 30, (java.lang.Number) 10.000000000000002d, 0, orderDirection29, false);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection29, false, false);
        try {
            boolean boolean39 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection29, false, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (10 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-868592058) + "'", int21 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.7763568394002505E-15d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1126170624) + "'", int1 == (-1126170624));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 12L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, Double.NaN, (-14.52444713108708d), (double) 1079574529);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 9600, (double) (-53), 20.799832845832398d, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = new double[] { 10L, 1.0f };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) ' ');
        double[] doubleArray18 = new double[] { 10L, 1.0f };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, 300);
        double[] doubleArray25 = new double[] { 10L, 1.0f };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, 52);
        double[] doubleArray33 = new double[] { 10L, 1.0f };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) ' ');
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, 52);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray41);
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, 52);
        double[] doubleArray55 = new double[] { 10L, 1.0f };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) ' ');
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58, 52);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray63);
        double[] doubleArray70 = new double[] { 10L, 1.0f };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) ' ');
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray73, 52);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray73, (int) 'a');
        double double79 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray63, doubleArray73);
        double double80 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray63);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        double[] doubleArray84 = new double[] { 10L, 1.0f };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray84);
        double[] doubleArray88 = new double[] { 10L, 1.0f };
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray84, doubleArray88);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.04987562112089d + "'", double9 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-868592058) + "'", int39 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-868592058) + "'", int61 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-868592058) + "'", int76 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 26.710743801652892d + "'", double79 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 9.136250564655356d + "'", double80 == 9.136250564655356d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.461729143006029E41d + "'", double1 == 2.461729143006029E41d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, (double) 2.16440893E10f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 314705L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray6 = new double[] { 10L, 1.0f };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = new double[] { 10L, 1.0f };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) ' ');
        double[] doubleArray18 = new double[] { 10L, 1.0f };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, 300);
        double[] doubleArray25 = new double[] { 10L, 1.0f };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray28, 52);
        double[] doubleArray33 = new double[] { 10L, 1.0f };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) ' ');
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, 52);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray41);
        double[] doubleArray47 = new double[] { 10L, 1.0f };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) ' ');
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, 52);
        double[] doubleArray55 = new double[] { 10L, 1.0f };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) ' ');
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58, 52);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray63);
        double[] doubleArray70 = new double[] { 10L, 1.0f };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) ' ');
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray73, 52);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray73, (int) 'a');
        double double79 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray63, doubleArray73);
        double double80 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray63);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        double[] doubleArray84 = new double[] { 10L, 1.0f };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray84);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) ' ');
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray87, 52);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, (double) 1.0f);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.04987562112089d + "'", double9 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-868592058) + "'", int39 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-868592058) + "'", int61 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-868592058) + "'", int76 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 26.710743801652892d + "'", double79 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 9.136250564655356d + "'", double80 == 9.136250564655356d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-868592058) + "'", int90 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 21.0d + "'", double93 == 21.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        java.lang.Object[] objArray3 = null;
        exceptionContext1.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 6.579251212010101d, (-0.544286559205797d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(152.00002f, (-1081700353), (-2));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -2, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1079574580);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 29.236001806897132d + "'", double8 == 29.236001806897132d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.831008000716577E22d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException4 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        java.lang.Throwable[] throwableArray5 = nullArgumentException4.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.5943665446595849d, (java.lang.Object[]) throwableArray5);
        java.lang.Object[] objArray7 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1608.495438637974d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (short) 100);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        java.lang.Number number4 = notPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException13 = new org.apache.commons.math.exception.TooManyEvaluationsException(number12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException27 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray24);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext29 = mathIllegalStateException28.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException34 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException41 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray40);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException42 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray40);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException43 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray40);
        exceptionContext29.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray40);
        org.apache.commons.math.exception.NoBracketingException noBracketingException45 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (double) 32, (double) 1078525952, (double) 100, 2.384185791015625E-7d, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray40);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException47 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException1, localizable5, objArray40);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray11 = notStrictlyPositiveException10.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = notStrictlyPositiveException10.getContext();
        java.lang.Object obj14 = exceptionContext12.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray17);
        exceptionContext12.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException20 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (-868592058), 1.079574529000002E9d, 100.0d, Double.NaN, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray17);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.009999500037496774d, objArray17);
        java.lang.Number number23 = maxCountExceededException22.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.009999500037496774d + "'", number23.equals(0.009999500037496774d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 10.0f, (double) 0L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        float float2 = org.apache.commons.math.util.FastMath.scalb(Float.POSITIVE_INFINITY, 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 1L, (double) 1072693248, (double) 3.5867345E10f, 0.5263085229064353d, 1.0000000000000008E-150d, (double) (-100));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.994998256078943E10d + "'", double6 == 1.994998256078943E10d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05235987755982989d + "'", double1 == 0.05235987755982989d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 32.0d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray10 = notStrictlyPositiveException9.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = mathArithmeticException12.getContext();
        java.util.Set<java.lang.String> strSet14 = exceptionContext13.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        double[] doubleArray18 = new double[] { 10L, 1.0f };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) ' ');
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21, 52);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection29, false);
        double[] doubleArray34 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[] doubleArray37 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[][] doubleArray38 = new double[][] { doubleArray34, doubleArray37 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray21, orderDirection29, doubleArray38);
        exceptionContext13.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray38);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-868592058) + "'", int24 == (-868592058));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-868592058) + "'", int25 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int2 = org.apache.commons.math.util.MathUtils.pow(314700, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-96), 1.07957453E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-96.0f) + "'", float2 == (-96.0f));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) (-3300));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.8095997915995805E15d);
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (29.091 >= 2.909)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        long long2 = org.apache.commons.math.util.MathUtils.pow(132L, 314705L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.0d + "'", double1 == 24.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        float float2 = org.apache.commons.math.util.MathUtils.round((-96.0f), 58);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection6, false);
        java.lang.Number number9 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5263085229064353d, (java.lang.Number) 3.49789674291322d, 35, orderDirection11, true);
        int int14 = nonMonotonousSequenceException13.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException13.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 2 + "'", number9.equals(2));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 5948489912671272961L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(48, (-868592058));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 868592106 + "'", int2 == 868592106);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        java.lang.String str3 = mathIllegalStateException2.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = mathIllegalStateException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.MathIllegalStateException: denominator format" + "'", str3.equals("org.apache.commons.math.exception.MathIllegalStateException: denominator format"));
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5943665446595849d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6843909265968923d + "'", double1 == 0.6843909265968923d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 142L, (double) 97.0f, 314700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray15 = new int[] { 1079574528, (byte) 1 };
        int[] intArray20 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 0);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray25);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) 'a');
        int[] intArray31 = new int[] { 1079574528, (byte) 1 };
        int[] intArray36 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray38, 0);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray40);
        int[] intArray44 = new int[] { 1079574528, (byte) 1 };
        int[] intArray49 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray53 = new int[] { 1079574528, (byte) 1 };
        int[] intArray58 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray58);
        int[] intArray65 = new int[] { (-1), 52, 0, 10, 100 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray65);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray65);
        int[] intArray71 = new int[] { 1079574528, (byte) 1 };
        int[] intArray76 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray71, intArray76);
        int[] intArray80 = new int[] { 1079574528, (byte) 1 };
        int[] intArray85 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray80, intArray85);
        int[] intArray87 = org.apache.commons.math.util.MathUtils.copyOf(intArray85);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray71);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1079574580 + "'", int66 == 1079574580);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.079574529000002E9d + "'", double67 == 1.079574529000002E9d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.0d + "'", double88 == 1.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 74.65823634883017d);
        double[] doubleArray16 = new double[] { 10L, 1.0f };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) ' ');
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, 52);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray19);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 58L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 29.236001806897132d + "'", double22 == 29.236001806897132d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 21644089344L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.814697265625E-6d + "'", double1 == 3.814697265625E-6d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1126170624), (double) (-1.4E-45f));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double1 = org.apache.commons.math.util.FastMath.log(0.009999500037496774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.605220183488268d) + "'", double1 == (-4.605220183488268d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.Number number2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, objArray3);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 99, (double) (short) -1, 0.0d, (double) 100L, objArray15);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = localizedFormats0.getLocalizedString(locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(1.0d, (double) 0.0f, (double) 1L, 32.0d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (-1L), 100.0d, 2.718281828459045d, (double) '#', objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray13);
        noBracketingException11.addSuppressed((java.lang.Throwable) nullArgumentException14);
        noBracketingException4.addSuppressed((java.lang.Throwable) nullArgumentException14);
        double double17 = noBracketingException4.getFHi();
        double double18 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 32.0d + "'", double17 == 32.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 248339168, (long) 248339168);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 248339168L + "'", long2 == 248339168L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 1078525952, (-1.7763568394002505E-15d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.078525952E9d + "'", double2 == 1.078525952E9d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 10, (long) (-3300));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-3,300)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-59L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-5.418539921951662d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(72080961, 96);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        long long1 = org.apache.commons.math.util.FastMath.round(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-0.0f), (double) 5, 0.0d);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.0d) + "'", double5 == (-0.0d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-618402520), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -618,402,520");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.084066969169249d, 2.461729143006029E41d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1079574580, 300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574280 + "'", int2 == 1079574280);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.4E-45f, (java.lang.Number) 0.6657737500283538d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) 9223372036854775807L, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1079574529, (-30145599L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-30,145,599)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(1.0d, (double) 0.0f, (double) 1L, 32.0d);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getLo();
        double double7 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1962108355622936d, 9.914443704113327E9d, 5.916079783099616d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver3.solve((-132174), univariateRealFunction6, 1.5515679276951895d, 0.2305998764687729d, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1962108355622936d + "'", double4 == 1.1962108355622936d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 44.3614195558365d, 1.9711353880321711E12d, 1079574564);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double double2 = org.apache.commons.math.util.FastMath.max(5.217576477130726E13d, (double) (-618402520));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.217576477130726E13d + "'", double2 == 5.217576477130726E13d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, (-96));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-96)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.FastMath.atanh(99.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1620404523, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) (-1L), 0.2214041920491114d, 2.718281828459045d, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 12L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 35.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        int int1 = org.apache.commons.math.util.FastMath.abs(1079574580);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574580 + "'", int1 == 1079574580);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 35867348190L, (float) 9600, (float) (-59L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray11 = new double[] { 10L, 1.0f };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        double[] doubleArray17 = new double[] { 10L, 1.0f };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray19);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray27 = new double[] { 10L, 1.0f };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27);
        double[] doubleArray31 = new double[] { 10L, 1.0f };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 21.0d + "'", double20 == 21.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 293.8181818181818d + "'", double34 == 293.8181818181818d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.5403023058681398d, 854.7438016528926d, 1.2341215074081695d);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2341215074081695d + "'", double4 == 1.2341215074081695d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-2.6991118430775174d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.399628413419635d) + "'", double1 == (-7.399628413419635d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.30756025842063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.074689670070945d + "'", double1 == 5.074689670070945d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 260, (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1.07269658E9f, (double) 1079574564, 3.743392130574644E-23d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-3300L));
        java.lang.String str3 = notPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotPositiveException: permutation size (-3,300" + "'", str3.equals("org.apache.commons.math.exception.NotPositiveException: permutation size (-3,300"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double2 = org.apache.commons.math.util.FastMath.max(3.484698397226463E12d, (double) 160L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.484698397226463E12d + "'", double2 == 3.484698397226463E12d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount();
        try {
            incrementor0.incrementCount(96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (30) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.07957458E9d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver1.solve(1079574564, univariateRealFunction3, (-0.9589242746631385d), (double) 21644089344L, (double) 2.4414062E-4f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-0.08446764274574539d), 3.927705731488613d, 3.814697265625E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.8432342740456016d + "'", double3 == 3.8432342740456016d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double double1 = org.apache.commons.math.util.FastMath.sinh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) Float.POSITIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 10, (int) (byte) -1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math.exception.NotPositiveException notPositiveException5 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) Double.NaN);
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) notPositiveException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray11 = notStrictlyPositiveException10.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = notStrictlyPositiveException10.getContext();
        java.lang.Object obj14 = exceptionContext12.getValue("out of range");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray17);
        exceptionContext12.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 2.1818435879447726d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int[] intArray14 = new int[] { 1079574528, (byte) 1 };
        int[] intArray19 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int[] intArray26 = new int[] { (-1), 52, 0, 10, 100 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray26);
        int[] intArray30 = new int[] { 1079574528, (byte) 1 };
        int[] intArray35 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray39 = new int[] { 1079574528, (byte) 1 };
        int[] intArray44 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray44);
        int[] intArray51 = new int[] { (-1), 52, 0, 10, 100 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray51);
        int[] intArray55 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) '4');
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray55);
        int[] intArray60 = new int[] { 1079574528, (byte) 1 };
        int[] intArray65 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray60);
        int[] intArray70 = new int[] { 1079574528, (byte) 1 };
        int[] intArray75 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray75);
        int[] intArray77 = org.apache.commons.math.util.MathUtils.copyOf(intArray75);
        int[] intArray79 = org.apache.commons.math.util.MathUtils.copyOf(intArray77, 0);
        int[] intArray80 = org.apache.commons.math.util.MathUtils.copyOf(intArray79);
        int[] intArray81 = org.apache.commons.math.util.MathUtils.copyOf(intArray80);
        int[] intArray84 = new int[] { 1079574528, (byte) 1 };
        int[] intArray89 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray89);
        int[] intArray91 = org.apache.commons.math.util.MathUtils.copyOf(intArray89);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray81, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray91);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1079574580 + "'", int27 == 1079574580);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1079574580 + "'", int52 == 1079574580);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.079574529000002E9d + "'", double53 == 1.079574529000002E9d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException3.getSuppressed();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.123233995736766E-17d + "'", double1 == 6.123233995736766E-17d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-8), (-96.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.0f) + "'", float2 == (-8.0f));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1111295750));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.0d);
        double[] doubleArray12 = new double[] { 10L, 1.0f };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) ' ');
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, 52);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection23, false);
        double[] doubleArray28 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[] doubleArray31 = new double[] { 80.5d, (-0.33045352012621665d) };
        double[][] doubleArray32 = new double[][] { doubleArray28, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray15, orderDirection23, doubleArray32);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-868592058) + "'", int18 == (-868592058));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-868592058) + "'", int19 == (-868592058));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int[] intArray2 = new int[] { 1079574528, (byte) 1 };
        int[] intArray7 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray12 = new int[] { 1079574528, (byte) 1 };
        int[] intArray17 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray17);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 0);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int[] intArray25 = new int[] { 1079574528, (byte) 1 };
        int[] intArray30 = new int[] { 1079574528, 0, 35, (byte) 1 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray30);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30);
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray32, 0);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray35);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) 'a');
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray38);
        try {
            int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray38, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1079574564 + "'", int39 == 1079574564);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5811052399411398d, (-5.418539921951662d), (-1126170624));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.814704541591866E-6d + "'", double1 == 3.814704541591866E-6d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve(0, univariateRealFunction4, 3.49789674291322d, (double) (byte) 10, 360.0d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.8163415799735064d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01424784839147029d) + "'", double1 == (-0.01424784839147029d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-8.0f));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(314700);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 3, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3218079744L + "'", long2 == 3218079744L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1111295750), 1079574280);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.009900662135208755d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int2 = org.apache.commons.math.util.MathUtils.pow(12, (long) 3147);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 2, 0.8414709848078965d, 0.0d, 0.9403184054350179d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.682941969615793d + "'", double4 == 1.682941969615793d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-1111295750), (float) 1079574596L, (float) 21644089344L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException7.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException(number0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) Float.NaN, 1.1920928955078125E-7d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-127)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 21644089425L, (java.lang.Number) 1.09951163E12f, (-2));
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException7.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.620404523E9d, objArray10);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(260, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 263 + "'", int2 == 263);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(3.0920128E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double double2 = org.apache.commons.math.util.FastMath.hypot(9.0d, 1.994998256078943E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.994998256078943E10d + "'", double2 == 1.994998256078943E10d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray8 = new double[] { 10L, 1.0f };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 300);
        double[] doubleArray15 = new double[] { 10L, 1.0f };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, 52);
        double[] doubleArray23 = new double[] { 10L, 1.0f };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) ' ');
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 52);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray32 = null;
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray31);
        double[] doubleArray37 = new double[] { 10L, 1.0f };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) ' ');
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 52);
        double[] doubleArray45 = new double[] { 10L, 1.0f };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) ' ');
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48, 52);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray53);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray53);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 52);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) 'a');
        double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray53, doubleArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray53);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 84.73931296875568d);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray74 = null;
        try {
            double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-868592058) + "'", int29 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-868592058) + "'", int51 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-868592058) + "'", int66 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 26.710743801652892d + "'", double69 == 26.710743801652892d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.136250564655356d + "'", double70 == 9.136250564655356d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.04987562112089d + "'", double73 == 10.04987562112089d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.080808751038084d, 0.6657737500283538d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 132L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 132.00000000000003d + "'", double1 == 132.00000000000003d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 32.0d);
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException7.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 1079574580, (java.lang.Object[]) throwableArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.620404523E9d, objArray10);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 6.102263253018401E21d, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) (-42), (double) 2146959360);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.073479659E9d + "'", double2 == 1.073479659E9d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, number1, true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-3200));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.4414062E-4f + "'", float1 == 2.4414062E-4f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        int int3 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 0, (double) 52, 1.5707963267948966d);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5707963267948966d + "'", double4 == 1.5707963267948966d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(100, (-42));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 142 + "'", int2 == 142);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { (short) -1, 28, 32, 2, 99 };
        try {
            int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, (java.lang.Number) 1.60978210179491616E17d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double[] doubleArray2 = new double[] { 10L, 1.0f };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, 52);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) 'a');
        double[] doubleArray13 = new double[] { 10L, 1.0f };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) ' ');
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, 52);
        double[] doubleArray21 = new double[] { 10L, 1.0f };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) ' ');
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 52);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean38 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection35, false, false);
        double[] doubleArray41 = new double[] { 10L, 1.0f };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) ' ');
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray44, 52);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray44, (int) 'a');
        double[] doubleArray52 = new double[] { 10L, 1.0f };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) ' ');
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55, 52);
        double[] doubleArray60 = new double[] { 10L, 1.0f };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) ' ');
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 52);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 1.0f);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray68);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray57);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean77 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73, orderDirection74, false, false);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection74, false, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-868592058) + "'", int8 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-868592058) + "'", int27 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-868592058) + "'", int47 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-868592058) + "'", int66 == (-868592058));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1079574564, (-8));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574572 + "'", int2 == 1079574572);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(30);
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        int int8 = incrementor0.getCount();
        incrementor0.setMaximalCount(0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, Double.POSITIVE_INFINITY, (double) (-1.07957453E9f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.resetCount();
        incrementor0.incrementCount((-3200));
        int int5 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (byte) 0);
        incrementor0.incrementCount((-3200));
        try {
            incrementor0.incrementCount((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(35, (int) (byte) 0);
        java.lang.Throwable[] throwableArray4 = dimensionMismatchException3.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException7 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10.0d);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) tooManyEvaluationsException7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = tooManyEvaluationsException7.getContext();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 2, (int) (short) 0, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        int int17 = nonMonotonousSequenceException15.getIndex();
        tooManyEvaluationsException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2 + "'", number16.equals(2));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1079574528L);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getMax();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        org.apache.commons.math.util.MathUtils.checkFinite(9.914443704113327E9d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-30145599));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 35.0f, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount(300);
        int int4 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.791759469228055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3385661990458504d + "'", double1 == 1.3385661990458504d);
    }
}

