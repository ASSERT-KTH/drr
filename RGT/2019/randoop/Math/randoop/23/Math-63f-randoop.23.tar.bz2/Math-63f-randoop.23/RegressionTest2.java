import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(640696287, 1074266112);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 4984363303356800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 971);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 971.0d + "'", double1 == 971.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.141592653589793d, 2.2204460492503128E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-449573849), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.2192169427871704d) + "'", double2 == (-2.2192169427871704d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.log1p(364.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.8998973535824915d + "'", double1 == 5.8998973535824915d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1000, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9092974268256817d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9194767093272557d + "'", double2 == 0.9194767093272557d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1528444620, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.52844462E9d + "'", double2 == 1.52844462E9d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 118800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6239635367704858d) + "'", double1 == (-0.6239635367704858d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-35L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1528444521);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.9991050130774393d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, (-449573949));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.floor(349.9541180407703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.0d + "'", double1 == 349.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1634508.6862362083d, 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.368684473529387E8d + "'", double2 == 8.368684473529387E8d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.8373983731296123d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5671648645968973d) + "'", double1 == (-0.5671648645968973d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.544137102816975d + "'", double1 == 7.544137102816975d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        long long1 = org.apache.commons.math.util.FastMath.abs((-35L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5806969933828852d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.326254638955107d + "'", double1 == 2.326254638955107d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 14386366368L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.389546815118596d + "'", double1 == 23.389546815118596d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1074266112, 0.0d, (-0.5674369031063846d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9259807453832821d, (-1.6055120681834575E-296d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-449573949));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1083215872), (long) 1528444520);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(9, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4711276743037347d, (-2.778448436856347E-163d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037345d + "'", double2 == 1.4711276743037345d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray35);
        int[] intArray41 = new int[] { (byte) 10, '#', 100 };
        int[] intArray48 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray48);
        int[] intArray53 = new int[] { (byte) 10, '#', 100 };
        int[] intArray60 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray60);
        try {
            int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 992.7844680493345d + "'", double37 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 992.7844680493345d + "'", double49 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 992.7844680493345d + "'", double61 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1091 + "'", int62 == 1091);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.7542986892173559d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8545852570089637d) + "'", double1 == (-0.8545852570089637d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 4984363303356800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(310400, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection6, false);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection13, true);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection20, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.0d, (java.lang.Number) (-0.5309649148733797d), 970, orderDirection27, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1) + "'", number23.equals((-1)));
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double2 = org.apache.commons.math.util.MathUtils.round(1059.9999999999998d, 95);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1059.9999999999998d + "'", double2 == 1059.9999999999998d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-2.778448436856347E-163d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.778448436856347E-163d) + "'", double1 == (-2.778448436856347E-163d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double2 = org.apache.commons.math.util.FastMath.atan2(970.6522901207366d, 1.9579677636223587d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5687791625354348d + "'", double2 == 1.5687791625354348d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.1653587046777794d, 0.5669767943827975d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.5671648645968973d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6369758722686701d) + "'", double1 == (-0.6369758722686701d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray30);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray27);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection43, false);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray27);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        double[] doubleArray53 = new double[] { (short) 0 };
        double[] doubleArray55 = new double[] { (short) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray53);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        double[] doubleArray65 = new double[] { (short) 0 };
        double[] doubleArray67 = new double[] { (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray60);
        double[] doubleArray73 = new double[] { (short) 0 };
        double[] doubleArray75 = new double[] { (short) 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray75);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray75);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 31 + "'", int79 == 31);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int16 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection20, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException22.getDirection();
        boolean boolean26 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException22.getDirection();
        java.lang.String str28 = nonMonotonousSequenceException22.toString();
        int int29 = nonMonotonousSequenceException22.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number31 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1 + "'", number23.equals(1));
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertNull(orderDirection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(orderDirection27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str28.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1 + "'", number31.equals(1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = org.apache.commons.math.util.FastMath.max((-9), 1528444620);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444620 + "'", int2 == 1528444620);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1528444521, (-1060), (-9));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.641588833612778d, (-1040904982), 1188);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int1 = org.apache.commons.math.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.23118034868692922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20797334230966952d + "'", double1 == 0.20797334230966952d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        int int10 = nonMonotonousSequenceException5.getIndex();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(orderDirection12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.7506872853494306d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1751854131 + "'", int1 == 1751854131);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-3.141592633570835d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(364.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20855.663742761964d + "'", double1 == 20855.663742761964d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) 'a', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.ulp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.074266112E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 370.9546370761337d + "'", double1 == 370.9546370761337d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1079427072, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.641588833612779d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int[] intArray4 = new int[] { (-1060), (byte) 100, 31, 31 };
        int[] intArray5 = null;
        try {
            double double6 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.688117141816136E43d, 1528444620, 1528444620);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9640275800758169d) + "'", double1 == (-0.9640275800758169d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-97L), (long) 1091);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-105827L) + "'", long2 == (-105827L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 990, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.math.util.FastMath.max(1528444521, 1076101088);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray40);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray35);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number48, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException51.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection52, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.8017288973886659d, (double) (-1983639665607471487L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.98363966560747136E18d) + "'", double2 == (-1.98363966560747136E18d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.log(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5350567286626973d + "'", double1 == 1.5350567286626973d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1188.0f, 0.9194767093272557d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        long long2 = org.apache.commons.math.util.FastMath.max(118800L, (long) 105827);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 118800L + "'", long2 == 118800L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9640275800758169d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1204413228389418d) + "'", double1 == (-1.1204413228389418d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1664L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1664.0f + "'", float1 == 1664.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.1653587046777794d, 0.7506872853494306d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1091, 30108800);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 8222818574190157425L, 349.0d, 20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection19, true);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.String str23 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str25 = nonMonotonousSequenceException21.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1) + "'", number22.equals((-1)));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8222818574190157425L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.0d + "'", double1 == 96.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray32 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray39);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray49 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray49);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (14,182,664,536,621,883,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4182664536621883E130d + "'", double50 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.7182818284590453d + "'", double51 == 1.7182818284590453d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1079427072, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(95, (-2));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 91L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray35);
        int[] intArray38 = null;
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 992.7844680493345d + "'", double37 == 992.7844680493345d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-105));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-35L), (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33950L) + "'", long2 == (-33950L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number11 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-62L), 3.01088E7f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.01088E7f + "'", float2 == 3.01088E7f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1079574528, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.6055120681834575E-296d), (-0.8373983731296123d), 12.645617067291202d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double2 = org.apache.commons.math.util.FastMath.min(7.600902709541988d, (double) 134L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.600902709541988d + "'", double2 == 7.600902709541988d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long1 = org.apache.commons.math.util.FastMath.round(2.0000000000000004d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1083215872));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 3628800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1072693279, (-1189));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1072693279, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693279 + "'", int2 == 1072693279);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 91L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 91.0d + "'", double1 == 91.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 8);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-449573981), 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 6L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1 == 6.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.930067261567154E14d), (java.lang.Number) 5L, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection9, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(orderDirection12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.17453292519943295d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-449573981), 1076101120);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.619275968248924E151d, (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray29 = new int[] { '4', 1079427072, (-449573981), 35 };
        try {
            double double30 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1189));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1189L + "'", long1 == 1189L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 960L, (java.lang.Number) 310400, 1751854131);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray26 = new double[] { (short) 0 };
        double[] doubleArray28 = new double[] { (short) 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray28);
        double[] doubleArray34 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray41);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        double[] doubleArray53 = new double[] { (short) 0 };
        double[] doubleArray55 = new double[] { (short) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray53);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray50);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray50);
        double[] doubleArray60 = null;
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray28);
        double[] doubleArray36 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray43);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray50);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray50);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray50);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 141.4213562373095d + "'", double64 == 141.4213562373095d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-105), (-33950L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 20);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(640696287, (-449573849));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8373983731296123d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-9L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.0000000000000004d, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9449930073175814d + "'", double2 == 1.9449930073175814d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 18, 20);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.801728897388666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7340177288724153d + "'", double1 == 0.7340177288724153d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.30539424285417d, 9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1751854131, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-6.691673596021348E41d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.746713800973678E13d) + "'", double1 == (-8.746713800973678E13d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1528444521, (long) 91);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-480542100132671815L) + "'", long2 == (-480542100132671815L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(104736);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1105934.8788361996d + "'", double1 == 1105934.8788361996d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 990, 1091);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-9L), 1.5687791625354348d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5663706143591725d + "'", double2 == 3.5663706143591725d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 100, 1079427072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079427172 + "'", int2 == 1079427172);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.802781989245806d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8027819892458061d + "'", double2 == 0.8027819892458061d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1188, 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.61066627123549E19d + "'", double2 == 9.61066627123549E19d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        long long1 = org.apache.commons.math.util.FastMath.round(970.6522901207366d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 971L + "'", long1 == 971L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 30108800);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.725290298461914E-9d + "'", double1 == 3.725290298461914E-9d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 310400);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 310400.0f + "'", float1 == 310400.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10325507102576029d + "'", double1 == 0.10325507102576029d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.7542986892173559d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1000, (float) 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1000.0f + "'", float2 == 1000.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3, 971L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 541611259 + "'", int2 == 541611259);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.068800536631989d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5843.095768877208d, (-1.538970890562367d), 91);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.0461741978670857E-6d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-948251051) + "'", int1 == (-948251051));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-948251051));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(97L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number21 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection25, false);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection32, true);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException34.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection39, true);
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException41.getDirection();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        int int45 = nonMonotonousSequenceException34.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection49, true);
        java.lang.Number number52 = nonMonotonousSequenceException51.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException51.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException51.getDirection();
        boolean boolean55 = nonMonotonousSequenceException51.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = nonMonotonousSequenceException51.getDirection();
        java.lang.String str57 = nonMonotonousSequenceException51.toString();
        int int58 = nonMonotonousSequenceException51.getIndex();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection64, true);
        java.lang.Throwable[] throwableArray67 = nonMonotonousSequenceException66.getSuppressed();
        boolean boolean68 = nonMonotonousSequenceException66.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection75, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection75, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = nonMonotonousSequenceException79.getDirection();
        nonMonotonousSequenceException66.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException79);
        java.lang.Class<?> wildcardClass82 = nonMonotonousSequenceException79.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = nonMonotonousSequenceException79.getDirection();
        nonMonotonousSequenceException51.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException79);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-3) + "'", number21.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1) + "'", number42.equals((-1)));
        org.junit.Assert.assertNull(orderDirection43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 1 + "'", number52.equals(1));
        org.junit.Assert.assertNull(orderDirection53);
        org.junit.Assert.assertNull(orderDirection54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(orderDirection56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str57.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 97 + "'", int58 == 97);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1983639665607471487L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.46210433380097E16d) + "'", double1 == (-3.46210433380097E16d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(6.691673596021348E41d, 0.0d, (-0.5674369031063846d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1528444620, 1188);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.log10(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 67.90664839220477d + "'", double1 == 67.90664839220477d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(orderDirection9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1076101120, (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.6789823271282946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9180673416562555d + "'", double1 == 1.9180673416562555d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double2 = org.apache.commons.math.util.FastMath.max((-4.703452711410479E-287d), (double) (-3));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.703452711410479E-287d) + "'", double2 == (-4.703452711410479E-287d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray19);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray14);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray29.getClass();
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray29);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray40);
        double[] doubleArray46 = new double[] { (short) 0 };
        double[] doubleArray48 = new double[] { (short) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray48);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray51);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray46);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray40);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.acos(5843.095768877208d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 640696287);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-449573849));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999642820723645d + "'", double1 == 0.999642820723645d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(360.0d, 0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 359.99999999999994d + "'", double2 == 359.99999999999994d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 9.619275968248924E151d, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (96,192,759,682,489,240,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (96,192,759,682,489,240,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= null)"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, 1079427072);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.4033482475752073d, 9.999999999999998d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1079574528);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1040904982), (long) 91);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5698529308483544d, (-7.774015254088967d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.774015254088967d) + "'", double2 == (-7.774015254088967d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1040904982), (float) 104736);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 104736.0f + "'", float2 == 104736.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1083215872), (java.lang.Number) 20855.663742761964d, 1528444521);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5397954653811572d + "'", double1 == 0.5397954653811572d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-2L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 14386366368L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.24278075415351E11d + "'", double1 == 8.24278075415351E11d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9991050130774393d + "'", double1 == 0.9991050130774393d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 8222818574190157425L, 105827);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.149548905166106d + "'", double1 == 1.149548905166106d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6255172032554649d, 364.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(100, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        java.lang.Class<?> wildcardClass11 = doubleArray6.getClass();
        double[] doubleArray15 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray22);
        double[] doubleArray32 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray40);
        double[] doubleArray48 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray55);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray64);
        double[] doubleArray67 = new double[] { (short) 0 };
        double[] doubleArray69 = new double[] { (short) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray62);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray62);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray62);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 6.283185307179586d);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray77);
        double[] doubleArray83 = new double[] { 0.5403023058681398d, (-0.6596727568297204d), 4294967296L, 35.0f };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4182664536621883E130d + "'", double33 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 4.294967296E9d + "'", double85 == 4.294967296E9d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.7340177288724153d, 1000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.86506314314109E300d + "'", double2 == 7.86506314314109E300d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2), (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1083215872));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.2807768825513602d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2772127258039435d) + "'", double1 == (-0.2772127258039435d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1079427072);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1L), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.rint(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.0d + "'", double1 == 11013.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(35, 1076101088);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.9451698451128283d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1000L, (long) 1079427172);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 18, (long) (-1040904982));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9368144838L + "'", long2 == 9368144838L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(310400, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 10, '#', 100 };
        int[] intArray11 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray16 = new int[] { (byte) 10, '#', 100 };
        int[] intArray23 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray23);
        int[] intArray29 = new int[] { (byte) 10, '#', 100 };
        int[] intArray36 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray36);
        int[] intArray41 = new int[] { (byte) 10, '#', 100 };
        int[] intArray48 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray29);
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 992.7844680493345d + "'", double12 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 992.7844680493345d + "'", double24 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1091 + "'", int25 == 1091);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 992.7844680493345d + "'", double37 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 992.7844680493345d + "'", double49 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1091 + "'", int50 == 1091);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray33);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double[] doubleArray45 = new double[] { (short) 0 };
        double[] doubleArray47 = new double[] { (short) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray45);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray42);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (-0.6596727568297204d));
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray42);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.1752011936438012d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.52844462E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray33);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray48);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray60);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double[] doubleArray67 = null;
        double[] doubleArray69 = new double[] { (short) 0 };
        double[] doubleArray71 = new double[] { (short) 1 };
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray71);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray71);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1072693279 + "'", int37 == 1072693279);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1072693279 + "'", int75 == 1072693279);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(97, 1528444620);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444717 + "'", int2 == 1528444717);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-2L), 8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int2 = org.apache.commons.math.util.FastMath.max((-948251051), 1528444717);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444717 + "'", int2 == 1528444717);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double2 = org.apache.commons.math.util.MathUtils.log(359.99999999999994d, (double) 970);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.168395263616004d + "'", double2 == 1.168395263616004d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '#', 1188);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1060, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.193831618625534E88d + "'", double2 == 7.193831618625534E88d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1091, (java.lang.Number) (byte) 1, 1091);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,090 and 1,091 are not strictly increasing (1 >= 1,091)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,090 and 1,091 are not strictly increasing (1 >= 1,091)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1091 + "'", number5.equals(1091));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-449573949), (-449573949));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 449573949 + "'", int2 == 449573949);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int1 = org.apache.commons.math.util.FastMath.abs(1074266112);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074266112 + "'", int1 == 1074266112);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-105));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1067827200) + "'", int1 == (-1067827200));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 104736);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707867789794372d + "'", double1 == 1.5707867789794372d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray20);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        double[] doubleArray32 = new double[] { (short) 0 };
        double[] doubleArray34 = new double[] { (short) 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray32);
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray40);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray29);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number45, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException48.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection49, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.053775679449293d), (java.lang.Number) 3.4657359027997265d, (-1), orderDirection49, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1040904982));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 194.0051545022222d + "'", double1 == 194.0051545022222d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 0.0f, (-0.9394587646078952d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(105827, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1000, (long) (-449573849));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 541611259);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 1, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.49638336960853463d, (-449573981), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1072693279, 21.147516401613185d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.37842716201023E190d + "'", double2 == 9.37842716201023E190d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 9);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (-2));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1528444521, 1189L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(32.0d, (double) 1188.0f, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4033482475752073d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.024493047472279896d + "'", double1 == 0.024493047472279896d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-7.774015254088967d), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6987274598742084d) + "'", double2 == (-1.6987274598742084d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int1 = org.apache.commons.math.util.MathUtils.hash(38.60606753595555d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-558349884) + "'", int1 == (-558349884));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-34.657359027997266d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.5663706143591725d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(10.0f, 0, 971);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 8800387989504L, (-449573949));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(9700, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77600 + "'", int2 == 77600);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(9700, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9665 + "'", int2 == 9665);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.FastMath.max(990, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 990 + "'", int2 == 990);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99627207622075d + "'", double1 == 0.99627207622075d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        long long2 = org.apache.commons.math.util.FastMath.min((-2L), (-480542100132671815L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-480542100132671815L) + "'", long2 == (-480542100132671815L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7224284372420832d) + "'", double1 == (-0.7224284372420832d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (-1189));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1189L) + "'", long2 == (-1189L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1040904982), (-97.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.04090496E9f) + "'", float2 == (-1.04090496E9f));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.log(20855.663742761964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.94538083267755d + "'", double1 == 9.94538083267755d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 449573949, (int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.49573952E8f + "'", float3 == 4.49573952E8f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.423035857164402d, (java.lang.Number) 0.10653763970030247d, (int) (short) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1188);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1188L + "'", long1 == 1188L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(971, (-449573949));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.930067261567154E14d), (java.lang.Number) 5L, 0, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 10, (-9), orderDirection14, true);
        java.lang.String str19 = nonMonotonousSequenceException18.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -10 and -9 are not strictly increasing (10 >= null)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -10 and -9 are not strictly increasing (10 >= null)"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.8998973535824915d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.2204460492503126E-16d, 0.0d, 1.0E9d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.MathUtils.round(5.8998973535824915d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.8998973536d + "'", double2 == 5.8998973536d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.4121184852417566d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7441732102173351d) + "'", double1 == (-0.7441732102173351d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 9701L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9701.0f + "'", float1 == 9701.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0726932790000001E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.793438406049756d + "'", double1 == 20.793438406049756d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8920048697881602d, 0.024493047472279896d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.024493047472279896d + "'", double2 == 0.024493047472279896d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 9665);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9665.0f + "'", float2 == 9665.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1060L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 1074266112);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(8, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9590413923210936d + "'", double1 == 1.9590413923210936d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray35);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray42 = new double[] { (short) 0 };
        double[] doubleArray44 = new double[] { (short) 1 };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray44);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray42);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray57);
        java.lang.Class<?> wildcardClass60 = doubleArray57.getClass();
        java.lang.Class<?> wildcardClass61 = doubleArray57.getClass();
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.7224284372420832d), 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 9700L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double2 = org.apache.commons.math.util.FastMath.max(4.440892098500626E-16d, (-0.6239635367704858d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.440892098500626E-16d + "'", double2 == 4.440892098500626E-16d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray29);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray41);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray38);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection54, false);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray38);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-2.778448436856347E-163d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 99L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int[] intArray4 = new int[] { (short) 1, '#', 104736, 970 };
        int[] intArray8 = new int[] { (byte) 10, '#', 100 };
        int[] intArray15 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (byte) 10, '#', 100 };
        int[] intArray27 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray27);
        int[] intArray33 = new int[] { (byte) 10, '#', 100 };
        int[] intArray40 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray40);
        int[] intArray45 = new int[] { (byte) 10, '#', 100 };
        int[] intArray52 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray52);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray33);
        try {
            int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 992.7844680493345d + "'", double16 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 992.7844680493345d + "'", double28 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1091 + "'", int29 == 1091);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 992.7844680493345d + "'", double41 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 992.7844680493345d + "'", double53 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1091 + "'", int54 == 1091);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.23118034868692922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.07684306900664609d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07403367632859821d + "'", double1 == 0.07403367632859821d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(100.0d, (int) (short) 10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.8813735870195429d), 0.2d, 0.9389941379013969d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-558349884));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5843.095768877208d, 8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.423035857164402d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double2 = org.apache.commons.math.util.FastMath.max(5.203976496118957d, 20855.663742761964d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20855.663742761964d + "'", double2 == 20855.663742761964d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        int int12 = nonMonotonousSequenceException5.getIndex();
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection20, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection20, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException24.getDirection();
        java.lang.Throwable[] throwableArray26 = nonMonotonousSequenceException24.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException24.getDirection();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.000000000000004d + "'", double1 == 31.000000000000004d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7340177288724153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6803122950877636d + "'", double1 == 0.6803122950877636d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 105, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(97.0d, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 9);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 1L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 1528444521);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger25);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1528444521);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (byte) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 1L);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) (byte) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger41);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger42);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 9);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-57.29577951308232d), (double) 1528444520, (double) 970);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2005.3522829578812d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray30);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray27);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection43, false);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray27);
        double[] doubleArray47 = null;
        double[] doubleArray49 = new double[] { (short) 0 };
        double[] doubleArray51 = new double[] { (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray51);
        double[] doubleArray54 = new double[] { (short) 0 };
        double[] doubleArray56 = new double[] { (short) 1 };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray54);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray61 = new double[] { (short) 0 };
        double[] doubleArray63 = new double[] { (short) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        double[] doubleArray66 = new double[] { (short) 0 };
        double[] doubleArray68 = new double[] { (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray61);
        double[] doubleArray74 = new double[] { (short) 0 };
        double[] doubleArray76 = new double[] { (short) 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray76);
        java.lang.Class<?> wildcardClass79 = doubleArray76.getClass();
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray76);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.718281828459045d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray33);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
        double[] doubleArray42 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray46);
        double[] doubleArray49 = new double[] { (short) 0 };
        double[] doubleArray51 = new double[] { (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray49);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray49);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        double[] doubleArray61 = new double[] { (short) 0 };
        double[] doubleArray63 = new double[] { (short) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray61);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray56);
        double[] doubleArray68 = null;
        double[] doubleArray70 = new double[] { (short) 0 };
        double[] doubleArray72 = new double[] { (short) 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray72);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray72);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 1.0f);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1072693279 + "'", int37 == 1072693279);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.6255172032554649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5589711503351747d + "'", double1 == 0.5589711503351747d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1368683772161603E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 3, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.8545852570089637d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4033482475752073d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8704237081963072d + "'", double1 == 0.8704237081963072d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 99, (long) (-449573849));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44507811051L + "'", long2 == 44507811051L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1060), 31);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.cos(7.0849142045682525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6954654336347881d + "'", double1 == 0.6954654336347881d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1072693279);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        long long2 = org.apache.commons.math.util.FastMath.max(1000L, 9368144838L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9368144838L + "'", long2 == 9368144838L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(8, (-449573949));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 6L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1.04090496E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 310400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.338764247848552d + "'", double1 == 13.338764247848552d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.461729143006029E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4104669019860253E43d + "'", double1 == 1.4104669019860253E43d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 'a', (double) '#', 2.4463520074491623d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(99, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 541611259);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 541611264 + "'", int1 == 541611264);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.2204460492503128E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1664.0f, 1.000048961966428d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1067827200), 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5413248546129181d + "'", double1 == 0.5413248546129181d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(77600, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1807321353334904E42d + "'", double2 == 2.1807321353334904E42d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray12);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray21);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (-0.6596727568297204d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection44, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection44, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 0.7258066738053498d, 0, orderDirection44, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.2807768825513602d), (java.lang.Number) 9.37842716201023E190d, 35, orderDirection44, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100, 1000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100000 + "'", int2 == 100000);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int1 = org.apache.commons.math.util.MathUtils.hash(359.99999999999994d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1081507840) + "'", int1 == (-1081507840));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        long long2 = org.apache.commons.math.util.MathUtils.pow(8800387989504L, (long) 541611264);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        int int10 = nonMonotonousSequenceException5.getIndex();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1 + "'", number12.equals(1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-948251051));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.5265890341390445d, 1.734723475976807E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5265890341390445d + "'", double2 == 0.5265890341390445d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1091, 1664L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-573L) + "'", long2 == (-573L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray33);
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray43);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray55);
        double[] doubleArray61 = new double[] { (short) 0 };
        double[] doubleArray63 = new double[] { (short) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray63);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray52);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray52);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1072693279 + "'", int69 == 1072693279);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9991050130774393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9997015819813576d + "'", double1 == 0.9997015819813576d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.000000000000004d + "'", double1 == 18.000000000000004d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.8390715290764524d), 3.01088E7d, (double) 5312841952574570497L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 20);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), number1, (int) (short) 1, orderDirection9, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not decreasing (null < -0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not decreasing (null < -0)"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double2 = org.apache.commons.math.util.FastMath.min(50.0d, 0.6427692249080461d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6427692249080461d + "'", double2 == 0.6427692249080461d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number21 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection25, false);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection32, true);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException34.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection39, true);
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException41.getDirection();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        int int45 = nonMonotonousSequenceException34.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection49, true);
        java.lang.Number number52 = nonMonotonousSequenceException51.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException51.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException51.getDirection();
        boolean boolean55 = nonMonotonousSequenceException51.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = nonMonotonousSequenceException51.getDirection();
        java.lang.String str57 = nonMonotonousSequenceException51.toString();
        int int58 = nonMonotonousSequenceException51.getIndex();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = nonMonotonousSequenceException18.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-3) + "'", number21.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1) + "'", number42.equals((-1)));
        org.junit.Assert.assertNull(orderDirection43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 1 + "'", number52.equals(1));
        org.junit.Assert.assertNull(orderDirection53);
        org.junit.Assert.assertNull(orderDirection54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(orderDirection56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str57.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 97 + "'", int58 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 9701.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.179984251961283d + "'", double1 == 9.179984251961283d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.7542986892173559d), (double) 449573949, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.641588833612779d, 1634508.6862362083d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9950547536867305d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(990, (-449573981));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6681539175313869d + "'", double1 == 0.6681539175313869d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.log10(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9542425094393249d + "'", double1 == 0.9542425094393249d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int1 = org.apache.commons.math.util.FastMath.round((-1189.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1189) + "'", int1 == (-1189));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, number1, (-1083215872));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1 + "'", number10.equals(1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 541611264, (double) (-1189L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5588463977399145d + "'", double1 == 0.5588463977399145d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 105, 1, 18);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 541611264);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.4752075402242797d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(541611264);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.7340177288724153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1342934503584864d) + "'", double1 == (-0.1342934503584864d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 100000, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 6.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.4742143377122356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9953395841106253d + "'", double1 == 0.9953395841106253d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1188, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 640696287);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 640696256 + "'", int1 == 640696256);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        java.lang.Class<?> wildcardClass22 = doubleArray3.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.326254638955107d, 0.6803122950877636d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.326254638955107d + "'", double2 == 2.326254638955107d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-573L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1067827200), 4984363303356800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 9700L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32657918471542563d + "'", double1 == 0.32657918471542563d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1060.0d, (-0.428182669496151d), (double) 104736);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray47);
        int[] intArray53 = new int[] { (byte) 10, '#', 100 };
        int[] intArray60 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray60);
        int[] intArray65 = new int[] { (byte) 10, '#', 100 };
        int[] intArray72 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray72);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray53);
        int[] intArray79 = new int[] { (byte) 10, '#', 100 };
        int[] intArray86 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray79);
        try {
            int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1091 + "'", int49 == 1091);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 992.7844680493345d + "'", double61 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 992.7844680493345d + "'", double73 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1091 + "'", int74 == 1091);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 992.7844680493345d + "'", double87 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        long long1 = org.apache.commons.math.util.FastMath.round(1.9449930073175814d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 9700L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1086517760 + "'", int1 == 1086517760);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 3.01088E7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException10.getSuppressed();
        boolean boolean13 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1040904982), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1040904982) + "'", int2 == (-1040904982));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1528444521, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        long long1 = org.apache.commons.math.util.FastMath.abs(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1083215872));
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= -1,083,215,872)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(104736.0f, (int) ' ', 640696287);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-8.746713800973678E13d), 97.0d, 0.9118468320146972d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        float float2 = org.apache.commons.math.util.FastMath.max(9665.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray4);
        double[] doubleArray8 = new double[] { (short) 0 };
        double[] doubleArray10 = new double[] { (short) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray10);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray13);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray20 = new double[] { (short) 0 };
        double[] doubleArray22 = new double[] { (short) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray22);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray22);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-0.6596727568297204d));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray22);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        double[] doubleArray46 = new double[] { (short) 0 };
        double[] doubleArray48 = new double[] { (short) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray46);
        java.lang.Class<?> wildcardClass51 = doubleArray41.getClass();
        double[] doubleArray55 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray57 = new double[] { (short) 0 };
        double[] doubleArray59 = new double[] { (short) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray59);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray62);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray62);
        double[] doubleArray69 = new double[] { (short) 0 };
        double[] doubleArray71 = new double[] { (short) 1 };
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray71);
        double[] doubleArray74 = new double[] { (short) 0 };
        double[] doubleArray76 = new double[] { (short) 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray74);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray71);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray62);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.expm1(43.42944819032518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2638973976934062E18d + "'", double1 == 7.2638973976934062E18d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.07403367632859821d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07410132444594272d + "'", double1 == 0.07410132444594272d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 31L + "'", long1 == 31L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', 971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94187 + "'", int2 == 94187);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray47);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray54 = new int[] { (byte) 10, '#', 100 };
        int[] intArray61 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray61);
        int[] intArray66 = new int[] { (byte) 10, '#', 100 };
        int[] intArray73 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray73);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray54);
        int[] intArray80 = new int[] { (byte) 10, '#', 100 };
        int[] intArray87 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray87);
        int[] intArray90 = null;
        try {
            double double91 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1091 + "'", int49 == 1091);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 992.7844680493345d + "'", double62 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 992.7844680493345d + "'", double74 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1091 + "'", int75 == 1091);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 992.7844680493345d + "'", double88 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 990 + "'", int89 == 990);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.801728897388666d, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.801728897388666d + "'", double2 == 0.801728897388666d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-558349884), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1079427072, (java.lang.Number) 35, (int) (short) -1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.99627207622075d, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 100L, (double) 10L, 3.174802103936399d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.4742143377122356d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-99885750) + "'", int1 == (-99885750));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1060, 15L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 0, 541611259);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 9.619275968248924E151d, (int) (byte) 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int1 = org.apache.commons.math.util.FastMath.abs(1076101120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-449573981));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-449573981) + "'", int2 == (-449573981));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-35L), 1634508.6862362083d, 8102.083927575384d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.4711276743037345d, (-449573949));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1469280909560382E290d) + "'", double2 == (-1.1469280909560382E290d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.5553480614894135d, 990);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7202988763954267E298d + "'", double2 == 3.7202988763954267E298d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.07140440247247d + "'", double1 == 36.07140440247247d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int1 = org.apache.commons.math.util.MathUtils.sign(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1091);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1091 + "'", int2 == 1091);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1664.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.11012689222978d + "'", double1 == 8.11012689222978d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9950547536867305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017366981689454632d + "'", double1 == 0.017366981689454632d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.6881171418161356E43d, 57.29577951308232d, (double) 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32L, (float) 8222818574190157425L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.2228187E18f + "'", float2 == 8.2228187E18f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(orderDirection7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5.0d, 9);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 5.0d + "'", number5.equals(5.0d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(91.0d, (double) 9701.0f, (double) (-1076101088));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1), (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-35L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 44507811051L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 541611264);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.73368768788199d + "'", double1 == 8.73368768788199d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double2 = org.apache.commons.math.util.FastMath.pow((-34.657359027997266d), 1.505149978319906d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-35L), (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-34.99999999999999d) + "'", double2 == (-34.99999999999999d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(8.73368768788199d, 1.5574077246549023d, 0.5170204982382923d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1076101088), 990);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-2L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray47);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray54 = new int[] { (byte) 10, '#', 100 };
        int[] intArray61 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray54);
        int[] intArray67 = new int[] { (byte) 10, '#', 100 };
        int[] intArray74 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray74);
        int[] intArray79 = new int[] { (byte) 10, '#', 100 };
        int[] intArray86 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray86);
        int[] intArray90 = null;
        try {
            double double91 = org.apache.commons.math.util.MathUtils.distance(intArray86, intArray90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1091 + "'", int49 == 1091);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 992.7844680493345d + "'", double62 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 992.7844680493345d + "'", double75 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 992.7844680493345d + "'", double87 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1091 + "'", int88 == 1091);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 990 + "'", int89 == 990);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (-10L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.930067261567154E14d), (java.lang.Number) 5L, 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 10, (-9), orderDirection6, true);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -10 and -9 are not strictly increasing (10 >= null)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -10 and -9 are not strictly increasing (10 >= null)"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-9) + "'", int12 == (-9));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-2.0d), 9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.619275968248924E151d + "'", double2 == 9.619275968248924E151d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.23118034868692922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4808121761009482d + "'", double1 == 0.4808121761009482d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.5669767943827975d, (double) 1000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-99885750), 1528444520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1428558770 + "'", int2 == 1428558770);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.9118468320146972d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1470363154 + "'", int1 == 1470363154);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int2 = org.apache.commons.math.util.FastMath.min(9665, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9665 + "'", int2 == 9665);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray40);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double[] doubleArray52 = new double[] { (short) 0 };
        double[] doubleArray54 = new double[] { (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray47);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray62);
        double[] doubleArray68 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray70 = new double[] { (short) 0 };
        double[] doubleArray72 = new double[] { (short) 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray72);
        double[] doubleArray75 = new double[] { (short) 0 };
        double[] doubleArray77 = new double[] { (short) 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray75);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray75);
        double[] doubleArray82 = new double[] { (short) 0 };
        double[] doubleArray84 = new double[] { (short) 1 };
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray84);
        double[] doubleArray87 = new double[] { (short) 0 };
        double[] doubleArray89 = new double[] { (short) 1 };
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray87, doubleArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray87);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray75, doubleArray84);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray84);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.0d + "'", double85 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.0d + "'", double90 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.0d + "'", double92 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, 9665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1306896481 + "'", int2 == 1306896481);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.4210854715202004E-14d);
        double[] doubleArray18 = null;
        try {
            double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1528444620, (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3056889240L) + "'", long2 == (-3056889240L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 971L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int2 = org.apache.commons.math.util.FastMath.max(1528444520, 30108800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444520 + "'", int2 == 1528444520);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 9665, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9630L + "'", long2 == 9630L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1073741824);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.697783723013432d + "'", double1 == 2.697783723013432d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-480542100132671815L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 64.0d + "'", double1 == 64.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1528444521);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1079427072);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.611168162149826d + "'", double1 == 4.611168162149826d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.294967296E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 134L, (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray41);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double[] doubleArray52 = new double[] { (short) 0 };
        double[] doubleArray54 = new double[] { (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray47);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray41);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 31 + "'", int34 == 31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202007E-14d + "'", double1 == 1.4210854715202007E-14d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray27);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray16);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (-0.6596727568297204d));
        java.lang.Class<?> wildcardClass33 = doubleArray32.getClass();
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 77600, 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-96L), (-0.1342934503584864d), 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7258066738053498d, number1, (-948251051), orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1528444620, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0460028648376465d) + "'", double2 == (-3.0460028648376465d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.7202988763954267E298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number21 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection25, false);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection32, true);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException34.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection39, true);
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException41.getDirection();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        int int45 = nonMonotonousSequenceException34.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection49, true);
        java.lang.Number number52 = nonMonotonousSequenceException51.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException51.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException51.getDirection();
        boolean boolean55 = nonMonotonousSequenceException51.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = nonMonotonousSequenceException51.getDirection();
        java.lang.String str57 = nonMonotonousSequenceException51.toString();
        int int58 = nonMonotonousSequenceException51.getIndex();
        nonMonotonousSequenceException34.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        java.lang.Number number61 = nonMonotonousSequenceException18.getArgument();
        java.lang.Class<?> wildcardClass62 = number61.getClass();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-3) + "'", number21.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1) + "'", number42.equals((-1)));
        org.junit.Assert.assertNull(orderDirection43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 1 + "'", number52.equals(1));
        org.junit.Assert.assertNull(orderDirection53);
        org.junit.Assert.assertNull(orderDirection54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(orderDirection56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str57.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 97 + "'", int58 == 97);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-3) + "'", number61.equals((-3)));
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.8373983731296123d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7429041126640108d) + "'", double1 == (-0.7429041126640108d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int1 = org.apache.commons.math.util.FastMath.abs(1233838437);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1233838437 + "'", int1 == 1233838437);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(18, (-105));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-87) + "'", int2 == (-87));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948963d + "'", double1 == 1.5707963267948963d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1079427072);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079427072 + "'", int1 == 1079427072);
    }
}

