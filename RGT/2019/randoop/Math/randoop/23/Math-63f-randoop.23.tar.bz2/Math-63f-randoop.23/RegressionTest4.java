import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test01");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.973493806989008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7243821522472935d + "'", double1 == 1.7243821522472935d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test02");
        int int1 = org.apache.commons.math.util.FastMath.abs(97100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97100 + "'", int1 == 97100);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test03");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test04");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.9180673416562555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9403049767853445d + "'", double1 == 0.9403049767853445d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test05");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 0, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test06");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(7.642595581083531E24d, 752720000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.600640513750609E63d) + "'", double2 == (-2.600640513750609E63d));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test07");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (3,631,948,698,846,703,100 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (3,631,948,698,846,703,100 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0f + "'", number9.equals(0.0f));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test08");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1236069535));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test09");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1060), (-449573849));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-449574909) + "'", int2 == (-449574909));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test10");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 32L, 0, 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test11");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1188.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test12");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1079574528, (long) (-99885750));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-107834111410176000L) + "'", long2 == (-107834111410176000L));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test13");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(96, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test14");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Class<?> wildcardClass21 = nonMonotonousSequenceException18.getClass();
        java.lang.String str22 = nonMonotonousSequenceException18.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (101 > -3)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (101 > -3)"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test15");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(97.0f, 18, 1528444520);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test16");
        double double1 = org.apache.commons.math.util.FastMath.ceil(349.9541180407703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 350.0d + "'", double1 == 350.0d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test17");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, (long) 752720000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test18");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 0, (-1040904982));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1040904982 + "'", int2 == 1040904982);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test19");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test20");
        long long2 = org.apache.commons.math.util.MathUtils.pow(9368144838L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9368144838L + "'", long2 == 9368144838L);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test21");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.9524513967534557d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test22");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3879224215064583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.006517545585557d + "'", double1 == 4.006517545585557d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test23");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4L, (-1.04090496E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.04090496E9f) + "'", float2 == (-1.04090496E9f));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test24");
        int int2 = org.apache.commons.math.util.FastMath.max(5, 104736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104736 + "'", int2 == 104736);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test25");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6012319514537295d + "'", double1 == 0.6012319514537295d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test26");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test27");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection3, false);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 5.0d, 9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test28");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(79);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 269.29109765101987d + "'", double1 == 269.29109765101987d);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test29");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int16 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection20, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException22.getDirection();
        boolean boolean26 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException22.getDirection();
        java.lang.String str28 = nonMonotonousSequenceException22.toString();
        int int29 = nonMonotonousSequenceException22.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1 + "'", number23.equals(1));
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertNull(orderDirection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(orderDirection27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str28.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test30");
        int int1 = org.apache.commons.math.util.FastMath.round(3.01088E7f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30108800 + "'", int1 == 30108800);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test31");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray26 = new double[] { (short) 0 };
        double[] doubleArray28 = new double[] { (short) 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray28);
        java.lang.Class<?> wildcardClass31 = doubleArray28.getClass();
        java.lang.Class<?> wildcardClass32 = doubleArray28.getClass();
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double[] doubleArray41 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray48);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray60);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray57);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray48);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test32");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1074266112);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test33");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.4908299469093809d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4908299469093809d) + "'", double2 == (-1.4908299469093809d));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test34");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 2.9734938069890076d, (int) (byte) -1);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test35");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.6055120681834575E-296d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test36");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1528444620);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.184249707593265d + "'", double1 == 9.184249707593265d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test37");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test38");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 105, 1857509505, 1073741824);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test39");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(5312841952574570497L, 9630L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5312841952574560867L + "'", long2 == 5312841952574560867L);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test40");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-307.6526555685888d), 0.1425465430742778d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test41");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test42");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.47381472041445105d, (double) (-1983639665607471487L), 0.0779666338315423d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test43");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 9700.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test44");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9999999999999991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01745329251994328d + "'", double1 == 0.01745329251994328d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test45");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1289568329), 1078836230);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test46");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test47");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test48");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-449573949), (long) (-9));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-449573958L) + "'", long2 == (-449573958L));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test49");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1306896481);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test50");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-97.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41032129904824216d + "'", double1 == 0.41032129904824216d);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test51");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1189, 1079427172);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4846747974448261775L) + "'", long2 == (-4846747974448261775L));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test52");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 17100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test53");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 91L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.317400098335743E39d + "'", double1 == 3.317400098335743E39d);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test54");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1079427072, 310400);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2841374.3026398476d + "'", double2 == 2841374.3026398476d);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test55");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.317400098335743E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.317400098335743E39d + "'", double1 == 3.317400098335743E39d);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test56");
        int int2 = org.apache.commons.math.util.FastMath.max((-1532789821), 9312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9312 + "'", int2 == 9312);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test57");
        double double1 = org.apache.commons.math.util.FastMath.log1p(9.184249707593265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.320842380553215d + "'", double1 == 2.320842380553215d);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test58");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 99L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test59");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1078836230);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test60");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test61");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10, 1079574528, 77600);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test62");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.0000000000000013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05235987755982991d + "'", double1 == 0.05235987755982991d);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test63");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1.0f, 3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test64");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.07403367632859821d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07389886024445848d + "'", double1 == 0.07389886024445848d);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test65");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1060));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test66");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, 1528444521);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test67");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1083215872));
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-490495387) + "'", int24 == (-490495387));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test68");
        double double1 = org.apache.commons.math.util.FastMath.asin(141.4213562373095d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test69");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(9, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-43) + "'", int2 == (-43));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test70");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.801728897388666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.890419598438728d + "'", double1 == 0.890419598438728d);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test71");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test72");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int[] intArray52 = new int[] { (byte) 10, '#', 100 };
        int[] intArray59 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray40);
        int[] intArray66 = new int[] { (-3), 1078525952, 310400 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray66);
        try {
            int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 992.7844680493345d + "'", double60 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1091 + "'", int61 == 1091);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1078836230 + "'", int67 == 1078836230);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test73");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection31, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test74");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) (-1076101088));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.076101088E9d) + "'", double2 == (-1.076101088E9d));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test75");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2L, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test76");
        float float3 = org.apache.commons.math.util.MathUtils.round(32.0f, (int) 'a', 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test77");
        long long1 = org.apache.commons.math.util.FastMath.round(8.24278075415351E11d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 824278075415L + "'", long1 == 824278075415L);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test78");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(5587200, 1528444620);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test79");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5671648645968973d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5132740998226375d) + "'", double1 == (-0.5132740998226375d));
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test80");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2261911708835171d + "'", double1 == 1.2261911708835171d);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test81");
        long long2 = org.apache.commons.math.util.MathUtils.pow(15L, 15L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 437893890380859375L + "'", long2 == 437893890380859375L);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test82");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.6205234402144832d, (double) 9368144838L, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }
}

