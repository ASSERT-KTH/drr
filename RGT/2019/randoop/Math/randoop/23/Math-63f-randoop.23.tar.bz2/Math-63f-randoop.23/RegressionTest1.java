import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray32 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray39);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray49 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray49);
        java.lang.Class<?> wildcardClass52 = doubleArray17.getClass();
        double[] doubleArray56 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray58 = new double[] { (short) 0 };
        double[] doubleArray60 = new double[] { (short) 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray60);
        double[] doubleArray63 = new double[] { (short) 0 };
        double[] doubleArray65 = new double[] { (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray63);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray63);
        double[] doubleArray70 = new double[] { (short) 0 };
        double[] doubleArray72 = new double[] { (short) 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray72);
        double[] doubleArray75 = new double[] { (short) 0 };
        double[] doubleArray77 = new double[] { (short) 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray75);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray70);
        double[] doubleArray82 = null;
        double[] doubleArray84 = new double[] { (short) 0 };
        double[] doubleArray86 = new double[] { (short) 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray84, doubleArray86);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray86);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4182664536621883E130d + "'", double50 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.7182818284590453d + "'", double51 == 1.7182818284590453d);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.0d + "'", double87 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.0d + "'", double89 == 1.0d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1072693279 + "'", int90 == 1072693279);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.0d + "'", double91 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, 1000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-903L) + "'", long2 == (-903L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 970, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(310400, 1091);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection19, true);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.String str23 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException21.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1) + "'", number22.equals((-1)));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.6319486988467031E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.560139705497413d + "'", double1 == 18.560139705497413d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.642769224908046d, (double) 1091);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6427692249080461d + "'", double2 == 0.6427692249080461d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-9.0f), (double) 31, (-2.778448436856347E-163d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.23118034868692922d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23118034868692922d + "'", double1 == 0.23118034868692922d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.floor(42.335616460753485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.0d + "'", double1 == 42.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.MathUtils.log(5.0d, 3.678982327128295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.809373360930001d + "'", double2 == 0.809373360930001d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(96, 1091);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104736 + "'", int2 == 104736);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int2 = org.apache.commons.math.util.FastMath.min(9, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5674369031063846d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5674369031063846d + "'", double1 == 0.5674369031063846d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 10.0f, 1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math.util.FastMath.min(4.9E-324d, 8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5.916079783099616d, 0.6931471805599453d, (-34.657359027997266d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.exp((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1353352832366127d + "'", double1 == 0.1353352832366127d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 9700L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9700 + "'", int1 == 9700);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-9.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1091);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 101L, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1528444521);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.23118034868692922d), (double) 1L, 0.5674369031063846d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double2 = org.apache.commons.math.util.FastMath.min(0.36787944117144233d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36787944117144233d + "'", double2 == 0.36787944117144233d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1528444521, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444520 + "'", int2 == 1528444520);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.423035857164402d, 0.0d, (-1.98363966560747136E18d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.49638336960853446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.642769224908046d + "'", double1 == 1.642769224908046d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(512.0d, 990.0d, (double) 1072693279L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) -1, 0.49638336960853446d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long1 = org.apache.commons.math.util.MathUtils.sign(5L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-9L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.log1p(18.560139705497413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9734938069890076d + "'", double1 == 2.9734938069890076d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        long long1 = org.apache.commons.math.util.MathUtils.sign(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4752075402242797d) + "'", double1 == (-1.4752075402242797d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1188);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1), 1188);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1189) + "'", int2 == (-1189));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) -1, (-1060));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1060 + "'", int2 == 1060);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        long long1 = org.apache.commons.math.util.MathUtils.sign(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.9451698451128283d), (-307.6526555685888d), 3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1060 + "'", int2 == 1060);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 310400, 118800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310400L + "'", long2 == 310400L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 310400);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9394587646078952d) + "'", double1 == (-0.9394587646078952d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.5674369031063846d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8278897878476718d) + "'", double1 == (-0.8278897878476718d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5170204982382923d, 990.0d, 3.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 30108800);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.01088E7f + "'", float1 == 3.01088E7f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8373983731296123d) + "'", double1 == (-0.8373983731296123d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1L, (long) 9700);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9701L + "'", long2 == 9701L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int2 = org.apache.commons.math.util.MathUtils.pow(990, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1189), Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-449573949) + "'", int1 == (-449573949));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.423035857164402d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7506872853494306d + "'", double1 == 0.7506872853494306d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.1752011936438014d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1528444520);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.52844452E9d + "'", double1 == 1.52844452E9d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(31, (long) (-449573949));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6065306597126334d + "'", double1 == 0.6065306597126334d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1189));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.774015254088967d) + "'", double1 == (-7.774015254088967d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        long long2 = org.apache.commons.math.util.FastMath.max(91L, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 91L + "'", long2 == 91L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.8813735870195429d), (-1.538970890562367d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-449573949), 95);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(32.0d, 1.4524424832623713E13d, 1000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        long long1 = org.apache.commons.math.util.FastMath.round((-34.657359027997266d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-35L) + "'", long1 == (-35L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) (-1189));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1189.0f) + "'", float2 == (-1189.0f));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(310400L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310400L + "'", long2 == 310400L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long1 = org.apache.commons.math.util.MathUtils.sign(101L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.9394587646078952d), (double) (-903L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9394587646078953d) + "'", double2 == (-0.9394587646078953d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.1752011936438014d), (double) 3, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1189));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1072693279, 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.589599181271048E253d + "'", double2 == 3.589599181271048E253d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(10.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(104736);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.5674369031063846d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1653587046777794d + "'", double1 == 1.1653587046777794d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8873940520506861d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7258066738053498d + "'", double1 == 0.7258066738053498d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 990);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 91L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 91 + "'", int1 == 91);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.8813735870195429d), 43.42944819032519d, 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.0d), 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.067661995777765d + "'", double1 == 10.067661995777765d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950547536867305d + "'", double1 == 0.9950547536867305d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.exp(10.067661995777765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23568.39729090051d + "'", double1 == 23568.39729090051d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.645617067291202d, (java.lang.Number) 3.174802103936399d, 310400);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int2 = org.apache.commons.math.util.MathUtils.pow(31, 1072693279L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 640696287 + "'", int2 == 640696287);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6427692249080461d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6427692249080461d + "'", double1 == 0.6427692249080461d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int2 = org.apache.commons.math.util.FastMath.min(9, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.4121184852417566d), (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(20, (long) (-449573949));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-7.930067261567154E14d), (double) (-9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.MathUtils.sign(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1189), 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math.util.MathUtils.round(Float.NaN, (int) '#');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 1072693279L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693279L + "'", long2 == 1072693279L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 1188);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1188.0f + "'", float2 == 1188.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1), (long) 91);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int1 = org.apache.commons.math.util.MathUtils.sign(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.203976496118957d + "'", double1 == 5.203976496118957d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray36);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double[] doubleArray52 = new double[] { (short) 0 };
        double[] doubleArray54 = new double[] { (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double[] doubleArray59 = new double[] { (short) 0 };
        double[] doubleArray61 = new double[] { (short) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray61);
        double[] doubleArray64 = new double[] { (short) 0 };
        double[] doubleArray66 = new double[] { (short) 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray64);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray59);
        double[] doubleArray74 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray76 = new double[] { (short) 0 };
        double[] doubleArray78 = new double[] { (short) 1 };
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray78);
        double[] doubleArray81 = new double[] { (short) 0 };
        double[] doubleArray83 = new double[] { (short) 1 };
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray81, doubleArray83);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray81);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        double[] doubleArray91 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray91);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray59);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray59);
        int int96 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.0d + "'", double84 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.4182664536621883E130d + "'", double92 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.7182818284590453d + "'", double93 == 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1074266112, (-9));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E9d + "'", double2 == 1.0E9d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 35, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-449573949), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-449573981) + "'", int2 == (-449573981));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.log((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1060, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1059.9999999999998d + "'", double2 == 1059.9999999999998d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-9), number1, (int) (short) 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1072693279, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection19, true);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.String str23 = nonMonotonousSequenceException21.toString();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str25 = nonMonotonousSequenceException12.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1) + "'", number22.equals((-1)));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6757942592282237d, 50.0d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-97L), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97L) + "'", long2 == (-97L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7350525871447157d + "'", double1 == 0.7350525871447157d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(8, 1188);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(310400, 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4984363303356800L + "'", long2 == 4984363303356800L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.462625387274655E114d + "'", double1 == 2.462625387274655E114d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2L, (long) 30108800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 96);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection16, true);
        java.lang.Number number19 = nonMonotonousSequenceException18.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        int int22 = nonMonotonousSequenceException18.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-3) + "'", number12.equals((-3)));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1 + "'", number19.equals(1));
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 97 + "'", int22 == 97);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.8017288973886659d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.801728897388666d + "'", double2 == 0.801728897388666d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (byte) 10, 9700);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1060));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, 640696287);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, (float) (-97L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-97.0f) + "'", float2 == (-97.0f));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.expm1(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-7.774015254088967d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9995794786277705d) + "'", double1 == (-0.9995794786277705d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.52844452E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 8L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) '#', 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', 1091);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 8102.083927575384d, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 1528444521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.5170204982382923d, (int) (byte) -1, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray32 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray39);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray49 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray49);
        java.lang.Class<?> wildcardClass52 = doubleArray17.getClass();
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4182664536621883E130d + "'", double50 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.7182818284590453d + "'", double51 == 1.7182818284590453d);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(96L, (long) (-449573949));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14386366368L + "'", long2 == 14386366368L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, 1072693279);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.exp((-7.930067261567154E14d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8920048697881602d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 8, 91L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3628800L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5553480614894135d + "'", double1 == 3.5553480614894135d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 91);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) '#', 100, 95);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5L, (float) (-9L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.0f) + "'", float2 == (-9.0f));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.423035857164402d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9118468320146972d + "'", double1 == 0.9118468320146972d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.6427692249080461d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 96L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (101 > -3)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (101 > -3)"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int16 = nonMonotonousSequenceException5.getIndex();
        int int17 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(42.0d, 40.792156108742276d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(42.0d, 1060);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6055120681834575E-296d) + "'", double2 == (-1.6055120681834575E-296d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1074266112, 4294967296L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8800387989504L + "'", long2 == 8800387989504L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double2 = org.apache.commons.math.util.MathUtils.log(9.0d, 1.4033482475752073d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15422228123186282d + "'", double2 == 0.15422228123186282d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(97L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.4033482475752073d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.068800536631989d + "'", double1 == 4.068800536631989d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long2 = org.apache.commons.math.util.MathUtils.pow(4984363303356800L, (long) 1000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1059.9999999999998d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1083215872) + "'", int1 == (-1083215872));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.4121184852417566d), (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4121184852417566d) + "'", double2 == (-0.4121184852417566d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 'a', 1074266112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5312841952574570497L + "'", long2 == 5312841952574570497L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int2 = org.apache.commons.math.util.MathUtils.pow(20, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9394587646078952d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9394587646078952d) + "'", double2 == (-0.9394587646078952d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.1653587046777794d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(990);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5843.095768877208d + "'", double1 == 5843.095768877208d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1060, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1060L + "'", long2 == 1060L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1528444520, (-9));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.338972390037892d, 1.0E9d, 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4463520074491623d + "'", double1 == 2.4463520074491623d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        long long1 = org.apache.commons.math.util.FastMath.abs(1188L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1188L + "'", long1 == 1188L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.9E-324d, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long2 = org.apache.commons.math.util.MathUtils.pow(9701L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8222818574190157425L + "'", long2 == 8222818574190157425L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4095289050836257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3432555386931701d + "'", double1 == 0.3432555386931701d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1188, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1188.0f + "'", float2 == 1188.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.809373360930001d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1074266112);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.074266112E9d + "'", double1 == 1.074266112E9d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 9700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9802322387695312E-8d + "'", double1 == 2.9802322387695312E-8d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) -1, 970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 990);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 990.0000000000001d + "'", double1 == 990.0000000000001d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-9), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.0f) + "'", float2 == (-9.0f));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.2736239505345667d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2807768825513602d) + "'", double1 == (-0.2807768825513602d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 3, (-1189));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6427692249080461d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9017399397933995d + "'", double1 == 0.9017399397933995d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1528444521);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(9, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1102230246251565E-16d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1188);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 118800L, 95);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        long long1 = org.apache.commons.math.util.FastMath.round(1059.9999999999998d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1060L + "'", long1 == 1060L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 360.0d + "'", double1 == 360.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1060));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-2L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.FastMath.log(7.0849142045682525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9579677636223587d + "'", double1 == 1.9579677636223587d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 8222818574190157425L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2018398.4441486439d + "'", double1 == 2018398.4441486439d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1528444520);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.147516401613185d + "'", double1 == 21.147516401613185d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', (-1189));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 100, 1072693279, 310400);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.7258066738053498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1091, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105827 + "'", int2 == 105827);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9389941379013969d + "'", double1 == 0.9389941379013969d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.17453292519943295d, (-0.5674369031063846d), 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-96L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.5788569702133275d) + "'", double1 == (-4.5788569702133275d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.MathUtils.sign(512.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.642769224908046d, (double) (-2L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3705500560893055d + "'", double2 == 0.3705500560893055d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0333147966386297E40d, (double) 1188);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07684306900664609d + "'", double2 == 0.07684306900664609d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-57.29577951308232d), 1091);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.703452711410479E-287d) + "'", double2 == (-4.703452711410479E-287d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1091, 105827);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(970.6522901207366d, (double) 1000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 30108800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-7.930067261567154E14d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.15422228123186282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.392711447798333d + "'", double1 == 0.392711447798333d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1091, 0, 1000);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.6319486988467031E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.acos((-34.657359027997266d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 10, '#', 100 };
        int[] intArray11 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray16 = new int[] { (byte) 10, '#', 100 };
        int[] intArray23 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray23);
        int[] intArray29 = new int[] { (byte) 10, '#', 100 };
        int[] intArray36 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray36);
        int[] intArray41 = new int[] { (byte) 10, '#', 100 };
        int[] intArray48 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray29);
        int[] intArray55 = new int[] { (byte) 10, '#', 100 };
        int[] intArray62 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray55);
        try {
            int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 992.7844680493345d + "'", double12 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 992.7844680493345d + "'", double24 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1091 + "'", int25 == 1091);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 992.7844680493345d + "'", double37 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 992.7844680493345d + "'", double49 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1091 + "'", int50 == 1091);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 992.7844680493345d + "'", double63 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.462625387274655E114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1060);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.rint(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 364.0d + "'", double1 == 364.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100L, 97.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3432555386931701d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35038084575911316d + "'", double1 == 0.35038084575911316d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 990);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-35L), 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-35.0d) + "'", double2 == (-35.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.801728897388666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013992808967815991d + "'", double1 == 0.013992808967815991d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.5440680443502757d, 9700);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.29011344422486E-163d) + "'", double2 == (-4.29011344422486E-163d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1189.0f), 105827);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.854167468791811E-199d) + "'", double2 == (-4.854167468791811E-199d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-2L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 20, (float) 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07610112E9f + "'", float2 == 1.07610112E9f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(9701L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9701L + "'", long2 == 9701L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612778d + "'", double1 == 4.641588833612778d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5574077246549023d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077246549023d + "'", double2 == 1.5574077246549023d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 20, (long) 990);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.678982327128295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 38.60606753595555d + "'", double1 == 38.60606753595555d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.009895611844382706d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000048961966428d + "'", double1 == 1.000048961966428d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1079427072, 96);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 100, (-449573949));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-449573849) + "'", int2 == (-449573849));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(8L, (long) 1074266112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8L, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2599210498948732d) + "'", double1 == (-1.2599210498948732d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int2 = org.apache.commons.math.util.FastMath.min(970, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-4.703452711410479E-287d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.69487989503184E-285d) + "'", double1 == (-2.69487989503184E-285d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 30108800);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.01088E7d + "'", double1 == 3.01088E7d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-97L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        long long2 = org.apache.commons.math.util.MathUtils.pow(96L, (long) 30108800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(91, 1528444521);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.649558242894909d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(35L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62L) + "'", long2 == (-62L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.floor(40.792156108742276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.0d + "'", double1 == 40.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9991050130774393d) + "'", double1 == (-0.9991050130774393d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.570442986354218d + "'", double1 == 7.570442986354218d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-35.0d), 9, 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6757942592282237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6255172032554649d + "'", double1 == 0.6255172032554649d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (float) (-9));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.0f) + "'", float2 == (-9.0f));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        long long2 = org.apache.commons.math.util.FastMath.min((-2L), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double3 = org.apache.commons.math.util.MathUtils.round((-0.6596727568297204d), 31, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6596727568297204d) + "'", double3 == (-0.6596727568297204d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-96L), 1074266112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(99L, (-35L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 134L + "'", long2 == 134L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.8414709848078965d, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02628990976125504d + "'", double2 == 0.02628990976125504d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(32, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1076101088) + "'", int2 == (-1076101088));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1079574528, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1083215872), 0.809373360930001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.809373360930001d + "'", double2 == 0.809373360930001d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray27);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray16);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (-0.6596727568297204d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection39, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.rint(1059.9999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1060.0d + "'", double1 == 1060.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.ulp(42.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1083215872));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray19);
        double[] doubleArray31 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray38);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray38);
        double[] doubleArray48 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray48);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray56);
        double[] doubleArray64 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray66 = new double[] { (short) 0 };
        double[] doubleArray68 = new double[] { (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray68);
        double[] doubleArray71 = new double[] { (short) 0 };
        double[] doubleArray73 = new double[] { (short) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray71);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray71);
        double[] doubleArray78 = new double[] { (short) 0 };
        double[] doubleArray80 = new double[] { (short) 1 };
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray80);
        double[] doubleArray83 = new double[] { (short) 0 };
        double[] doubleArray85 = new double[] { (short) 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray83, doubleArray85);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray83);
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray78);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray78);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray78);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 6.283185307179586d);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray93);
        double[] doubleArray96 = null;
        try {
            double double97 = org.apache.commons.math.util.MathUtils.distance1(doubleArray93, doubleArray96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.4182664536621883E130d + "'", double49 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1233838437 + "'", int94 == 1233838437);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 3.141592653589793d + "'", double95 == 3.141592653589793d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(18.560139705497413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 35, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray47);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray54 = new int[] { (byte) 10, '#', 100 };
        int[] intArray61 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray61);
        int[] intArray66 = new int[] { (byte) 10, '#', 100 };
        int[] intArray73 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray73);
        int[] intArray79 = new int[] { (byte) 10, '#', 100 };
        int[] intArray86 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray86);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1091 + "'", int49 == 1091);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 992.7844680493345d + "'", double62 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 992.7844680493345d + "'", double74 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1091 + "'", int75 == 1091);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 992.7844680493345d + "'", double87 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 992.7844680493345d + "'", double88 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 990 + "'", int89 == 990);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 1000L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-97L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.691673596021348E41d) + "'", double1 == (-6.691673596021348E41d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NEGATIVE_INFINITY, 3.589599181271048E253d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.068800536631989d, 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 100, 1528444520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444620 + "'", int2 == 1528444620);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 1528444521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 1076101120);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.8278897878476718d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7542986892173559d) + "'", double1 == (-0.7542986892173559d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-9.0f), (double) (-449573849));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592633570835d) + "'", double2 == (-3.141592633570835d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.2807768825513602d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0396774712305397d + "'", double1 == 1.0396774712305397d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1188);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.49638336960853446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49638336960853446d + "'", double1 == 0.49638336960853446d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 31, 9701L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9701L + "'", long2 == 9701L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.338972390037892d, 0.5265890341390445d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.36787944117144233d, (double) 8800387989504L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.180263888480858E-14d + "'", double2 == 4.180263888480858E-14d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.074266112E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8790518387946046d + "'", double1 == 0.8790518387946046d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double2 = org.apache.commons.math.util.MathUtils.round(Double.NEGATIVE_INFINITY, 96);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.2599210498948732d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.053775679449293d) + "'", double1 == (-1.053775679449293d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-35L), (float) (-97L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-97.0f) + "'", float2 == (-97.0f));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        java.lang.Class<?> wildcardClass11 = doubleArray1.getClass();
        try {
            double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 6.283185307179586d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.6789823271282946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-7.774015254088967d), (-0.9451698451128283d), 6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 9, (-1.6055120681834575E-296d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 43.42944819032519d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double2 = org.apache.commons.math.util.FastMath.pow(572.9577951308232d, (-2.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0461741978670857E-6d + "'", double2 == 3.0461741978670857E-6d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        long long2 = org.apache.commons.math.util.FastMath.min(1664L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.9579677636223587d, 0.15422228123186282d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-3), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-105) + "'", int2 == (-105));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-105), 8222818574190157425L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15L + "'", long2 == 15L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray11);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray11);
        double[] doubleArray21 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray21);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray29);
        double[] doubleArray37 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray51);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray51);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray51);
        try {
            double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4182664536621883E130d + "'", double22 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1188, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1000L, (float) 1074266112);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1000.0f + "'", float2 == 1000.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.util.FastMath.min(8.64289985028826d, (double) 1079427072);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.64289985028826d + "'", double2 == 8.64289985028826d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1233838437, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 35, (long) (-449573849));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-15735084715L) + "'", long2 == (-15735084715L));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.49638336960853463d, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.10653763970030247d + "'", double2 == 0.10653763970030247d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 95, (double) (-9));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94.99999999999999d + "'", double2 == 94.99999999999999d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 322.6634991267262d + "'", double1 == 322.6634991267262d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1091, (java.lang.Number) (byte) 1, 1091);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,090 and 1,091 are not strictly increasing (1 >= 1,091)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,090 and 1,091 are not strictly increasing (1 >= 1,091)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.1368683772161603E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.000048961966428d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7616147179586236d + "'", double1 == 0.7616147179586236d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray34);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        double[] doubleArray46 = new double[] { (short) 0 };
        double[] doubleArray48 = new double[] { (short) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray46);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray41);
        double[] doubleArray54 = new double[] { (short) 0 };
        double[] doubleArray56 = new double[] { (short) 1 };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray41);
        double[] doubleArray63 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray65 = new double[] { (short) 0 };
        double[] doubleArray67 = new double[] { (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray67);
        double[] doubleArray70 = new double[] { (short) 0 };
        double[] doubleArray72 = new double[] { (short) 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray70);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray70);
        double[] doubleArray77 = new double[] { (short) 0 };
        double[] doubleArray79 = new double[] { (short) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray79);
        double[] doubleArray82 = new double[] { (short) 0 };
        double[] doubleArray84 = new double[] { (short) 1 };
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray84);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray82);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray77);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray77);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray41);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.0d + "'", double80 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.0d + "'", double85 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1076101088));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101088 + "'", int1 == 1076101088);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int int2 = org.apache.commons.math.util.FastMath.max(1074266112, 1060);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074266112 + "'", int2 == 1074266112);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(101L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438012d), (java.lang.Number) 50.0d, 1188);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        java.lang.Class<?> wildcardClass11 = doubleArray6.getClass();
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        try {
            double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.23118034868692922d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.expm1(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.642595581083531E24d + "'", double1 == 7.642595581083531E24d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1189));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 7.570442986354218d, 5.916079783099616d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 31, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (-0.6596727568297204d));
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.01088E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707962935820154d + "'", double1 == 1.5707962935820154d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1189.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1190.0d) + "'", double1 == (-1190.0d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1072693279L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.988363373768195d) + "'", double1 == (-0.988363373768195d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray30);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray27);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection43, false);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray27);
        double[] doubleArray47 = null;
        try {
            double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(970, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 971 + "'", int2 == 971);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1072693279, 1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0726932790000001E9d + "'", double2 == 1.0726932790000001E9d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        int int2 = org.apache.commons.math.util.FastMath.max(9, 1528444521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.35038084575911316d, 15.211251338567996d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-35L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.283185307179586d, (double) (-903L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.9579677636223587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9259807453832821d + "'", double1 == 0.9259807453832821d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9389941379013969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4742143377122356d + "'", double1 == 1.4742143377122356d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.074266112E9d, (-1.2599210498948732d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.sinh(45.9356821340476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.452288290524476E19d + "'", double1 == 4.452288290524476E19d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.4463520074491623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4463520074491623d + "'", double1 == 2.4463520074491623d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-7.774015254088967d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999996463236135d) + "'", double1 == (-0.9999996463236135d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1528444520);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 2L, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(15L, (long) 1000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1015L + "'", long2 == 1015L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1233838437);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 310400L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int1 = org.apache.commons.math.util.FastMath.abs((-105));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 105 + "'", int1 == 105);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        long long1 = org.apache.commons.math.util.FastMath.round(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.8813735870195429d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1189.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray19);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray34);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray31);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1072693279 + "'", int46 == 1072693279);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray10);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray30);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray19);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (-0.6596727568297204d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection42, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection42, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection42, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 0.7258066738053498d, 0, orderDirection42, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection42, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.10653763970030247d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1040904982) + "'", int1 == (-1040904982));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.2146848510894035E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.214684851089401E-8d + "'", double1 == 4.214684851089401E-8d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        int int12 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 105827, 1000.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1000.0f + "'", float2 == 1000.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.009895611844382706d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.734723475976807E-18d + "'", double1 == 1.734723475976807E-18d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) 97L, (int) (short) 10, orderDirection14, false);
        java.lang.String str17 = nonMonotonousSequenceException16.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not increasing (97 > 0)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not increasing (97 > 0)"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double2 = org.apache.commons.math.util.FastMath.pow((-2.69487989503184E-285d), 40.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1079427072, 9700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.02628990976125504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35, (java.lang.Number) 990.0000000000001d, (int) ' ');
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(9700L, (-449573849));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double2 = org.apache.commons.math.util.FastMath.min((-34.657359027997266d), (-34.657359027997266d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-34.657359027997266d) + "'", double2 == (-34.657359027997266d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        long long1 = org.apache.commons.math.util.MathUtils.sign(134L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.505149978319906d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 95, (long) (-1076101088));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.2673631790022216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6587000491678714E39d + "'", double1 == 1.6587000491678714E39d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.atan(1060.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5698529308483544d + "'", double1 == 1.5698529308483544d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-449573981));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.575869169019466E10d) + "'", double1 == (-2.575869169019466E10d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray29);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray24);
        double[] doubleArray37 = new double[] { (short) 0 };
        double[] doubleArray39 = new double[] { (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray24);
        double[] doubleArray46 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        double[] doubleArray53 = new double[] { (short) 0 };
        double[] doubleArray55 = new double[] { (short) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray53);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray53);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        double[] doubleArray65 = new double[] { (short) 0 };
        double[] doubleArray67 = new double[] { (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray60);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray60);
        try {
            double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 1.000048961966428d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.2807768825513602d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2807768825513602d) + "'", double2 == (-0.2807768825513602d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.1752011936438012d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int2 = org.apache.commons.math.util.MathUtils.pow(310400, (long) 105827);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        long long2 = org.apache.commons.math.util.MathUtils.pow(5L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 15L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1634508.6862362083d + "'", double1 == 1634508.6862362083d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 99L, 40.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.802781989245806d + "'", double2 == 0.802781989245806d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray36);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double[] doubleArray52 = new double[] { (short) 0 };
        double[] doubleArray54 = new double[] { (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray52);
        double[] doubleArray59 = new double[] { (short) 0 };
        double[] doubleArray61 = new double[] { (short) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray61);
        double[] doubleArray64 = new double[] { (short) 0 };
        double[] doubleArray66 = new double[] { (short) 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray64);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray59);
        double[] doubleArray74 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray76 = new double[] { (short) 0 };
        double[] doubleArray78 = new double[] { (short) 1 };
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray78);
        double[] doubleArray81 = new double[] { (short) 0 };
        double[] doubleArray83 = new double[] { (short) 1 };
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray81, doubleArray83);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray81);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        double[] doubleArray91 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray91);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray59);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray59);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.0d + "'", double84 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.4182664536621883E130d + "'", double92 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.7182818284590453d + "'", double93 == 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray29);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray24);
        double[] doubleArray37 = new double[] { (short) 0 };
        double[] doubleArray39 = new double[] { (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray24);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (-1076101088));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int2 = org.apache.commons.math.util.MathUtils.pow(9700, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

