import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6931471805599453d, 4.294967296E9d, (double) 1060L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1306896481, 1528444620);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 35, 94187, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1083215872), 449573949);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1532789821) + "'", int2 == (-1532789821));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-87), 105827);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5163308428647085753L + "'", long2 == 5163308428647085753L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1751854131);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.9734938069890076d, 15.211251338567996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.973493806989008d + "'", double2 == 2.973493806989008d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 4.49573952E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 766.0675155854643d + "'", double1 == 766.0675155854643d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1079427172);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.2772127258039435d), 2.2204460492503128E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.60460290274525d + "'", double1 == 10.60460290274525d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(42.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.696374707602505E17d + "'", double1 == 8.696374707602505E17d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int int1 = org.apache.commons.math.util.FastMath.abs(104736);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 104736 + "'", int1 == 104736);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.FastMath.tan(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24503417392995128d) + "'", double1 == (-0.24503417392995128d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5.8998973536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4289704307792634d + "'", double1 == 2.4289704307792634d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, 1072693279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.signum(5843.095768877208d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5707962935820154d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray47);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray54 = new int[] { (byte) 10, '#', 100 };
        int[] intArray61 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray61);
        int[] intArray66 = new int[] { (byte) 10, '#', 100 };
        int[] intArray73 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray73);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray54);
        int[] intArray80 = new int[] { (byte) 10, '#', 100 };
        int[] intArray87 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray87);
        int[] intArray92 = new int[] { 1528444520, (short) 10 };
        try {
            int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1091 + "'", int24 == 1091);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1091 + "'", int49 == 1091);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 992.7844680493345d + "'", double62 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 992.7844680493345d + "'", double74 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1091 + "'", int75 == 1091);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 992.7844680493345d + "'", double88 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 990 + "'", int89 == 990);
        org.junit.Assert.assertNotNull(intArray92);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100000, 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.473814720414451d, (double) 449573949);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47381472041445105d + "'", double2 == 0.47381472041445105d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray11);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray11);
        double[] doubleArray21 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray21);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray29);
        double[] doubleArray37 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray51);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray51);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray51);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 6.283185307179586d);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) (-105827L));
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4182664536621883E130d + "'", double22 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 370.9546370761337d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 370.9546370761337d + "'", double2 == 370.9546370761337d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-105), 1086517760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1086517655 + "'", int2 == 1086517655);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1752011936438012d), (java.lang.Number) 50.0d, 1188);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1000L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        long long2 = org.apache.commons.math.util.FastMath.min(9701L, (long) 541611264);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9701L + "'", long2 == 9701L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948968d + "'", double1 == 1.5707963267948968d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, 31L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int[] intArray27 = new int[] { (byte) 10, '#', 100 };
        int[] intArray34 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray34);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int[] intArray52 = new int[] { (byte) 10, '#', 100 };
        int[] intArray59 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray40);
        int[] intArray66 = new int[] { (byte) 10, '#', 100 };
        int[] intArray73 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray73);
        int[] intArray78 = new int[] { (byte) 10, '#', 100 };
        int[] intArray85 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray78, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray85);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray66);
        try {
            int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 992.7844680493345d + "'", double35 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1091 + "'", int36 == 1091);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 992.7844680493345d + "'", double60 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1091 + "'", int61 == 1091);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 992.7844680493345d + "'", double74 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 992.7844680493345d + "'", double86 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1091 + "'", int87 == 1091);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-96L), (float) 1664L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-96.0f) + "'", float2 == (-96.0f));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.0d, 64.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0779666338315423d + "'", double2 == 0.0779666338315423d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1040904982));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(94187, 9700);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31226.588020970765d + "'", double2 == 31226.588020970765d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 94187);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 306.89900618933257d + "'", double1 == 306.89900618933257d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int1 = org.apache.commons.math.util.MathUtils.hash(50.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078525952 + "'", int1 == 1078525952);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5707963267948966d, 0.9017399397933995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0496646507836467d + "'", double2 == 1.0496646507836467d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 960L, (double) 1091);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0186279225488664d + "'", double2 == 1.0186279225488664d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 310400, (-903L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 280291200L + "'", long2 == 280291200L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1528444521);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 9);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 1L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 1528444521);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger26);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double2 = org.apache.commons.math.util.MathUtils.log((-2.69487989503184E-285d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 990, (long) 1072693279);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1061966346210L + "'", long2 == 1061966346210L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (-449573949));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1189L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1189 + "'", int1 == 1189);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.697783723013432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.3440585709080678E43d, 31226.588020970765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-573L), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.0000000000000004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8704237081963072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3879224215064583d + "'", double1 == 1.3879224215064583d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1.07610112E9f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 990, 8.24278075415351E11d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection14, true);
        java.lang.Number number17 = nonMonotonousSequenceException16.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException16.getDirection();
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException16.getSuppressed();
        int int21 = nonMonotonousSequenceException16.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection25, true);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        boolean boolean29 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number30 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertNull(orderDirection18);
        org.junit.Assert.assertNull(orderDirection19);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1) + "'", number30.equals((-1)));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0396774712305397d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0396774712305397d + "'", double1 == 1.0396774712305397d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.4182664536621883E130d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.877157801747449d + "'", double1 == 2.877157801747449d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-573L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.044033658705184d) + "'", double1 == (-7.044033658705184d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray19);
        try {
            double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 2.461729143006029E41d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int int2 = org.apache.commons.math.util.FastMath.min(77600, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(9700, 77600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 752720000 + "'", int2 == 752720000);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(541611259, 990);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) 9.619275968248924E151d, (int) (byte) 1);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.23118034868692922d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.793596329072449d + "'", double1 == 0.793596329072449d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1015L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.346544323973411d + "'", double1 == 9.346544323973411d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger8, (java.lang.Number) (-1.6055120681834575E-296d), (int) (short) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5309649148733797d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5562675674585376d) + "'", double1 == (-0.5562675674585376d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1189.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number21 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection25, false);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Number number29 = nonMonotonousSequenceException27.getPrevious();
        java.lang.String str30 = nonMonotonousSequenceException27.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-3) + "'", number21.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 3.678982327128295d + "'", number29.equals(3.678982327128295d));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,074,266,111 and 1,074,266,112 are not decreasing (3.679 < 8)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,074,266,111 and 1,074,266,112 are not decreasing (3.679 < 8)"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(18.000000000000004d, (-2.69487989503184E-285d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 95, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 950L + "'", long2 == 950L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.801728897388666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1034333410771124d + "'", double1 == 1.1034333410771124d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1236069535) + "'", int2 == (-1236069535));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.649558242894909d, 349.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.7202988763954267E298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.720298876395427E298d + "'", double1 == 3.720298876395427E298d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int2 = org.apache.commons.math.util.FastMath.max(1528444717, 310400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444717 + "'", int2 == 1528444717);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray9);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (-0.6596727568297204d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection41, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection41, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection41, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.71454639108536d, (java.lang.Number) 0.99627207622075d, 541611264, orderDirection41, true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double2 = org.apache.commons.math.util.FastMath.max((double) Float.POSITIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7506872853494306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013101964782205756d + "'", double1 == 0.013101964782205756d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.017366981689454632d, 0, 1428558770);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.4657359027997265d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(9.94538083267755d, (double) 1664L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2), (-0.24503417392995128d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5604874136486533d, (java.lang.Number) 8.73368768788199d, 96);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.FastMath.atanh(7.2638973976934062E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 2147483647, (-33950L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147449697L + "'", long2 == 2147449697L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4210854715202007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202007E-14d + "'", double1 == 1.4210854715202007E-14d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9451698451128283d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double1 = org.apache.commons.math.util.FastMath.tanh(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1 + "'", number7.equals(1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1428558770);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963260948905d + "'", double1 == 1.5707963260948905d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(752720000, 1079427072);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray22);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray12);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray35);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray42 = new double[] { (short) 0 };
        double[] doubleArray44 = new double[] { (short) 1 };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray44);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray42);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray30);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 31 + "'", int54 == 31);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 18, (long) 449573949);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 449573967L + "'", long2 == 449573967L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(541611264, 752720000);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(752720000, 1188);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double2 = org.apache.commons.math.util.FastMath.max(0.23118034868692922d, 3.725290298461914E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.23118034868692922d + "'", double2 == 0.23118034868692922d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray28);
        double[] doubleArray36 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray43);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray50);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray50);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray50);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 6.283185307179586d);
        double[] doubleArray66 = null;
        try {
            double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-9), (long) 105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1289568329) + "'", int2 == (-1289568329));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int[] intArray3 = new int[] { (byte) 10, '#', 100 };
        int[] intArray10 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray15 = new int[] { (byte) 10, '#', 100 };
        int[] intArray22 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray22);
        int[] intArray27 = new int[] { (byte) 10, '#', 100 };
        int[] intArray34 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray34);
        int[] intArray40 = new int[] { (byte) 10, '#', 100 };
        int[] intArray47 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray47);
        int[] intArray52 = new int[] { (byte) 10, '#', 100 };
        int[] intArray59 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray40);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray40);
        int[] intArray70 = new int[] { (-948251051), 1060, 1074266112, 9, 100000, 1 };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray70);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 992.7844680493345d + "'", double11 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 992.7844680493345d + "'", double23 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 992.7844680493345d + "'", double35 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1091 + "'", int36 == 1091);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 992.7844680493345d + "'", double48 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 992.7844680493345d + "'", double60 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1091 + "'", int61 == 1091);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2022518098 + "'", int71 == 2022518098);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double2 = org.apache.commons.math.util.FastMath.min(0.35038084575911316d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1189));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray26 = new double[] { (short) 0 };
        double[] doubleArray28 = new double[] { (short) 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray28);
        java.lang.Class<?> wildcardClass31 = doubleArray28.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection32, true);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray41);
        double[] doubleArray49 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray56);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray56);
        double[] doubleArray63 = new double[] { (short) 0 };
        double[] doubleArray65 = new double[] { (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray65);
        double[] doubleArray68 = new double[] { (short) 0 };
        double[] doubleArray70 = new double[] { (short) 1 };
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray68);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray63);
        double[] doubleArray78 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray80 = new double[] { (short) 0 };
        double[] doubleArray82 = new double[] { (short) 1 };
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray80, doubleArray82);
        double[] doubleArray85 = new double[] { (short) 0 };
        double[] doubleArray87 = new double[] { (short) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray85, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray85);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray85);
        double[] doubleArray95 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray78, doubleArray95);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray95);
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray63);
        double double99 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.0d + "'", double83 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.0d + "'", double88 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 1.4182664536621883E130d + "'", double96 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 1.7182818284590453d + "'", double97 == 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 1.0d + "'", double98 == 1.0d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-449573981), 1079427172);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 91, (long) (-1189));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1098L) + "'", long2 == (-1098L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray6);
        double[] doubleArray14 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray33);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray28);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray28);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-97.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5557.690612768985d) + "'", double1 == (-5557.690612768985d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        java.lang.Class<?> wildcardClass30 = doubleArray17.getClass();
        try {
            double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 1076101120);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(99, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 449573967L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray23);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray38);
        double[] doubleArray46 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        double[] doubleArray53 = new double[] { (short) 0 };
        double[] doubleArray55 = new double[] { (short) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray53);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray53);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        double[] doubleArray65 = new double[] { (short) 0 };
        double[] doubleArray67 = new double[] { (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray60);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray60);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray60);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1 + "'", number10.equals(1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1189.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.641588833612778d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        java.lang.Class<?> wildcardClass11 = doubleArray1.getClass();
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray29);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray36);
        double[] doubleArray49 = new double[] { (short) 0 };
        double[] doubleArray51 = new double[] { (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray36);
        double[] doubleArray58 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        double[] doubleArray65 = new double[] { (short) 0 };
        double[] doubleArray67 = new double[] { (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray65);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double[] doubleArray72 = new double[] { (short) 0 };
        double[] doubleArray74 = new double[] { (short) 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray74);
        double[] doubleArray77 = new double[] { (short) 0 };
        double[] doubleArray79 = new double[] { (short) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray77);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray72);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray72);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray36);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.0d + "'", double80 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.5707963267948966d, 77600);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1079427172, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.60732955122181d + "'", double2 == 60.60732955122181d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double1 = org.apache.commons.math.util.FastMath.ulp(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, 971);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97100 + "'", int2 == 97100);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 9700L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.4657359027997265d, (-1060));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.math.util.FastMath.min(1428558770, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray11);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray8);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray31);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray40);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray47 = new double[] { (short) 0 };
        double[] doubleArray49 = new double[] { (short) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double[] doubleArray52 = new double[] { (short) 0 };
        double[] doubleArray54 = new double[] { (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray47);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray35);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-449573981));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 7.570442986354218d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray11);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray8);
        double[] doubleArray20 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray27);
        double[] doubleArray37 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double[] doubleArray45 = new double[] { (short) 0 };
        double[] doubleArray47 = new double[] { (short) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray45);
        double[] doubleArray53 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        double[] doubleArray60 = new double[] { (short) 0 };
        double[] doubleArray62 = new double[] { (short) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray60);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray60);
        double[] doubleArray67 = new double[] { (short) 0 };
        double[] doubleArray69 = new double[] { (short) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray69);
        double[] doubleArray72 = new double[] { (short) 0 };
        double[] doubleArray74 = new double[] { (short) 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray72);
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray67);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray67);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray67);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 6.283185307179586d);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        try {
            double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 194.0051545022222d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.4182664536621883E130d + "'", double38 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 100.0d + "'", double83 == 100.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        long long1 = org.apache.commons.math.util.FastMath.round(0.009895611844382706d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-449573949), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-9.0f), 3.725290298461914E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.999999999999998d) + "'", double2 == (-8.999999999999998d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.FastMath.tan(7.193831618625534E88d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4608894344720868d + "'", double1 == 0.4608894344720868d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.999999999999998d, 1663.9999999999998d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(96, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9312 + "'", int2 == 9312);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-948251051), (long) 1528444717);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1861835813 + "'", int2 == 1861835813);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55576.90612768985d + "'", double1 == 55576.90612768985d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9950547536867305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0000000000000013d + "'", double1 == 3.0000000000000013d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 104736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.538970890562367d), (double) (-1067827200));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0678271999808795E9d) + "'", double2 == (-1.0678271999808795E9d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(60.60732955122181d, 0.642769224908046d, 13.338764247848552d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray32 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray39);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double[] doubleArray49 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray49);
        java.lang.Class<?> wildcardClass52 = doubleArray17.getClass();
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4182664536621883E130d + "'", double50 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.7182818284590453d + "'", double51 == 1.7182818284590453d);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 31 + "'", int53 == 31);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8222818574190157425L, (java.lang.Number) 1528444520, (-1076101088), orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 2.718281828459045d, 0, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 32.0d, (-3), orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 640696287, (java.lang.Number) 5.916079783099616d, (-449573849), orderDirection18, true);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 0, (double) 9665, (-0.7441732102173351d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5687791625354348d, (double) 280291200L, (double) (-105));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 310400);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray9);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray21);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray16);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray31);
        double[] doubleArray37 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray53);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray53);
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number63, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection67, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 13.338764247848552d, (java.lang.Number) (-7.044033658705184d), 1074266112, orderDirection67, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int16 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection20, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException22.getDirection();
        boolean boolean26 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException22.getDirection();
        java.lang.String str28 = nonMonotonousSequenceException22.toString();
        int int29 = nonMonotonousSequenceException22.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        int int31 = nonMonotonousSequenceException22.getIndex();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException22.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1 + "'", number23.equals(1));
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertNull(orderDirection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(orderDirection27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str28.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 97 + "'", int31 == 97);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.2146848510894035E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999991d + "'", double1 == 0.9999999999999991d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.720298876395427E298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.720298876395427E298d + "'", double1 == 3.720298876395427E298d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6803122950877636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-948251051), 1861835813);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-948251051));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        int int10 = nonMonotonousSequenceException5.getIndex();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3, 100000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double1 = org.apache.commons.math.util.FastMath.floor(43.42944819032518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.0d + "'", double1 == 43.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1078525952);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078525952 + "'", int1 == 1078525952);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 104736.0f, (double) 9665);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4787772968550505d + "'", double2 == 1.4787772968550505d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.368684473529387E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.368684473529387E8d + "'", double1 == 8.368684473529387E8d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1653587046777794d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0523330449637358d + "'", double1 == 1.0523330449637358d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (byte) 1, (double) 1086517655, 990.0000000000001d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1528444717, (long) 9665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95914541 + "'", int2 == 95914541);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 640696287);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (byte) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger18);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-0.9640275800758169d), (double) 8L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(970, 1076101088);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009430054193516519d + "'", double1 == 0.009430054193516519d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 0, (-1067827200), 95);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0186279225488664d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int2 = org.apache.commons.math.util.FastMath.max(1074266112, 1072693279);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074266112 + "'", int2 == 1074266112);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        java.lang.Class<?> wildcardClass34 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double2 = org.apache.commons.math.util.FastMath.max(194.0051545022222d, 1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0333147966386297E40d + "'", double2 == 1.0333147966386297E40d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(18, 310400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5587200 + "'", int2 == 5587200);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray28);
        double[] doubleArray36 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray43);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray50);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray50);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray50);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 6.283185307179586d);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-105827L));
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1857509505 + "'", int68 == 1857509505);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((-1.0f), 2147483647, 94187);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1086517655, 1751854131);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double2 = org.apache.commons.math.util.MathUtils.round(38.60606753595555d, 105827);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 38.60606753595555d + "'", double2 == 38.60606753595555d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number31, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException34.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection35, false);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number39, (java.lang.Number) 9.619275968248924E151d, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException42.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection43, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1072693279 + "'", int38 == 1072693279);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int2 = org.apache.commons.math.util.FastMath.max(1233838437, (-1289568329));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1233838437 + "'", int2 == 1233838437);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 96L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1289568329));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5806969933828852d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.326254638955107d + "'", double1 == 2.326254638955107d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.6587000491678714E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 91.0d + "'", double1 == 91.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-2L), 5587200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.32657918471542563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3154436812901073d + "'", double1 == 0.3154436812901073d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.149548905166106d, 1.5604874136486533d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1233838437, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1004311523) + "'", int2 == (-1004311523));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-7.774015254088967d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4908299469093809d) + "'", double2 == (-1.4908299469093809d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.105427357601002E-15d, (java.lang.Number) (-0.7429041126640108d), 100, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 9312, (float) (-449573849));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.49573856E8f) + "'", float2 == (-4.49573856E8f));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 99, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1795512867667309079L) + "'", long2 == (-1795512867667309079L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray26 = new double[] { (short) 0 };
        double[] doubleArray28 = new double[] { (short) 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray28);
        double[] doubleArray34 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double[] doubleArray41 = new double[] { (short) 0 };
        double[] doubleArray43 = new double[] { (short) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray41);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        double[] doubleArray53 = new double[] { (short) 0 };
        double[] doubleArray55 = new double[] { (short) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray53);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray50);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray50);
        double[] doubleArray61 = new double[] { (short) 0 };
        double[] doubleArray63 = new double[] { (short) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        double[] doubleArray66 = new double[] { (short) 0 };
        double[] doubleArray68 = new double[] { (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray73 = new double[] { (short) 0 };
        double[] doubleArray75 = new double[] { (short) 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray75);
        double[] doubleArray78 = new double[] { (short) 0 };
        double[] doubleArray80 = new double[] { (short) 1 };
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray80);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray78);
        double[] doubleArray84 = new double[] { (short) 0 };
        double[] doubleArray86 = new double[] { (short) 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray84, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray75, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray75);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (-0.6596727568297204d));
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.0d + "'", double87 == 1.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.0d + "'", double89 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-307.6526555685888d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0455997439439243E133d) + "'", double1 == (-2.0455997439439243E133d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5574077246549023d, (java.lang.Number) 22025.465794806718d, 1074266112);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(18, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.930067261567154E14d), (java.lang.Number) 5L, 0, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.649558242894909d, (java.lang.Number) (-7.774015254088967d), 971, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1528444521, (java.lang.Number) 990.0000000000001d, 1233838437, orderDirection15, false);
        java.lang.String str22 = nonMonotonousSequenceException21.toString();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,233,838,436 and 1,233,838,437 are not increasing (990 > 1,528,444,521)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,233,838,436 and 1,233,838,437 are not increasing (990 > 1,528,444,521)"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        long long1 = org.apache.commons.math.util.MathUtils.sign(4984363303356800L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 91L, (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6757942592282237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6757942592282237d + "'", double1 == 0.6757942592282237d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-6.691673596021348E41d), (double) (-1.0f), 1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double2 = org.apache.commons.math.util.FastMath.min(0.1353352832366127d, (-0.9394587646078952d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9394587646078952d) + "'", double2 == (-0.9394587646078952d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray38 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double[] doubleArray45 = new double[] { (short) 0 };
        double[] doubleArray47 = new double[] { (short) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray45);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double[] doubleArray52 = new double[] { (short) 0 };
        double[] doubleArray54 = new double[] { (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        double[] doubleArray57 = new double[] { (short) 0 };
        double[] doubleArray59 = new double[] { (short) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray57);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray52);
        double[] doubleArray64 = null;
        double[] doubleArray66 = new double[] { (short) 0 };
        double[] doubleArray68 = new double[] { (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray68);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray68);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 5843.095768877208d);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 364.0d);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 31 + "'", int34 == 31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1072693279 + "'", int77 == 1072693279);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-4.5788569702133275d), 0.009430054193516519d, (double) 9700L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8414709848078965d, 1.4742143377122356d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.asin(5.267884728309446d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray14);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray23);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray35);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray30);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray18);
        double[] doubleArray45 = new double[] { (short) 0 };
        double[] doubleArray47 = new double[] { (short) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray47);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray50);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray57 = new double[] { (short) 0 };
        double[] doubleArray59 = new double[] { (short) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray59);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray62);
        double[] doubleArray68 = new double[] { (short) 0 };
        double[] doubleArray70 = new double[] { (short) 1 };
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray59);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (-0.6596727568297204d));
        java.lang.Class<?> wildcardClass76 = doubleArray75.getClass();
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.6596727568297204d + "'", double77 == 0.6596727568297204d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-0.7441732102173351d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-573L), 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 95914541);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.495498393234494E9d + "'", double1 == 5.495498393234494E9d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 10, '#', 100 };
        int[] intArray11 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray16 = new int[] { (byte) 10, '#', 100 };
        int[] intArray23 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int[] intArray28 = new int[] { (byte) 10, '#', 100 };
        int[] intArray35 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray35);
        int[] intArray41 = new int[] { (byte) 10, '#', 100 };
        int[] intArray48 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray48);
        int[] intArray53 = new int[] { (byte) 10, '#', 100 };
        int[] intArray60 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray41);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray41);
        int[] intArray68 = new int[] { (byte) 10, '#', 100 };
        int[] intArray75 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray75);
        int[] intArray80 = new int[] { (byte) 10, '#', 100 };
        int[] intArray87 = new int[] { 1000, (byte) -1, '#', (byte) 100, (byte) -1, (byte) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray87);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray87);
        try {
            double double91 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 992.7844680493345d + "'", double12 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 992.7844680493345d + "'", double24 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 992.7844680493345d + "'", double36 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1091 + "'", int37 == 1091);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 992.7844680493345d + "'", double49 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 992.7844680493345d + "'", double61 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1091 + "'", int62 == 1091);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 992.7844680493345d + "'", double76 == 992.7844680493345d);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 992.7844680493345d + "'", double88 == 992.7844680493345d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1091 + "'", int89 == 1091);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 992.7844680493345d + "'", double90 == 992.7844680493345d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 9);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 94187);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray11);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray8);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray23);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray35);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray30);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(15.211251338567996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.26548641920640625d + "'", double1 == 0.26548641920640625d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-9), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 44507811051L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 6L, 1076101120);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 9700);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9700.0f + "'", float1 == 9700.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5589711503351747d, 1.5707867789794372d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5589711503351749d + "'", double2 == 0.5589711503351749d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.30539424285417d, 0.6681539175313869d, (-0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6596727568297204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41601138990780057d) + "'", double1 == (-0.41601138990780057d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(99, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79 + "'", int2 == 79);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1428558770, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 9312, (float) 1072693279);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9312.0f + "'", float2 == 9312.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 35.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 950L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 54430.9905374282d + "'", double1 == 54430.9905374282d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1072693279 + "'", int5 == 1072693279);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double1 = org.apache.commons.math.util.FastMath.exp((-34.657359027997266d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001244E-16d + "'", double1 == 8.881784197001244E-16d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.734723475976807E-18d, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.938893903907228E-18d + "'", double2 == 6.938893903907228E-18d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 5312841952574570497L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.3128418E18f + "'", float2 == 5.3128418E18f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 9700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9700.000000000002d + "'", double1 == 9700.000000000002d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9017399397933995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015738330946130256d + "'", double1 == 0.015738330946130256d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1086517760);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.00000000000001d + "'", double1 == 96.00000000000001d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 640696287);
        java.math.BigInteger bigInteger11 = null;
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.71454639108536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.71454639108536d + "'", double1 == 3.71454639108536d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-449573949), 104736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1566276225 + "'", int2 == 1566276225);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 752720000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean12 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(42.335616460753485d, (double) 1076101088, (double) 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 2147449697L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.8998973535824915d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.899897353582492d + "'", double1 == 5.899897353582492d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 3, 101L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-98L) + "'", long2 == (-98L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray35);
        double[] doubleArray43 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray45 = new double[] { (short) 0 };
        double[] doubleArray47 = new double[] { (short) 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray47);
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray50);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        double[] doubleArray57 = new double[] { (short) 0 };
        double[] doubleArray59 = new double[] { (short) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray59);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray62);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray57);
        double[] doubleArray72 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray74 = new double[] { (short) 0 };
        double[] doubleArray76 = new double[] { (short) 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray76);
        double[] doubleArray79 = new double[] { (short) 0 };
        double[] doubleArray81 = new double[] { (short) 1 };
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray79);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray79);
        double[] doubleArray89 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray72, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray89);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray57);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.4182664536621883E130d + "'", double90 == 1.4182664536621883E130d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.7182818284590453d + "'", double91 == 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.0d + "'", double92 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 9);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 1751854131);
        java.math.BigInteger bigInteger21 = null;
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 971);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 971L + "'", long1 == 971L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-99885750));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.9590413923210936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.475765671468706d + "'", double1 == 3.475765671468706d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(640696287, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5707963267948963d, 0.024493047472279896d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948963d + "'", double2 == 1.5707963267948963d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-105827L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8255527075764691d + "'", double1 == 0.8255527075764691d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5707963267948967d + "'", double1 == 0.5707963267948967d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.7506872853494306d, 5.495498393234494E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3660040120721378E-10d + "'", double2 == 1.3660040120721378E-10d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.802781989245806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5585053606381855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.848048096156426d + "'", double1 == 0.848048096156426d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 950L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.4463520074491623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6271203734056552d + "'", double1 == 1.6271203734056552d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-87));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1091);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int int1 = org.apache.commons.math.util.FastMath.abs(100000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100000 + "'", int1 == 100000);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.FastMath.log10(970.6522901207366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.987063683537267d + "'", double1 == 2.987063683537267d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5152978215491797d + "'", double1 == 1.5152978215491797d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0333147966386297E40d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.asin(11013.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        int int2 = org.apache.commons.math.util.FastMath.max(1073741824, 1073741824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray17);
        double[] doubleArray23 = new double[] { (short) 0 };
        double[] doubleArray25 = new double[] { (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray25);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray30);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9451698451128283d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9451698451128283d + "'", double1 == 0.9451698451128283d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1189));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1189 + "'", int1 == 1189);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1663.9999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 95340.17710976896d + "'", double1 == 95340.17710976896d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(105827);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1118551.6318926318d + "'", double1 == 1118551.6318926318d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 9665, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        int int1 = org.apache.commons.math.util.FastMath.abs(79);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79 + "'", int1 == 79);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1), 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8) + "'", int2 == (-8));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 1086517655);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-3));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 1528444521);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        float float2 = org.apache.commons.math.util.FastMath.max(1.07610112E9f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1079427072, (double) 950L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079427072E9d + "'", double2 == 1.079427072E9d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 35L, (-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray33);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1072693279 + "'", int37 == 1072693279);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 94187, 1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.730165733925067d + "'", double1 == 1.730165733925067d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double2 = org.apache.commons.math.util.FastMath.min(1.079427072E9d, 20855.663742761964d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20855.663742761964d + "'", double2 == 20855.663742761964d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.847379800543134d) + "'", double1 == (-13.847379800543134d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double1 = org.apache.commons.math.util.FastMath.expm1(91.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.317400098335743E39d + "'", double1 == 3.317400098335743E39d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1072693279, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.072693279E9d + "'", double2 == 1.072693279E9d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1040904982));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (-1098L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1098L + "'", long2 == 1098L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        float float1 = org.apache.commons.math.util.MathUtils.sign(31.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.75d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2946832846768448d + "'", double1 == 1.2946832846768448d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.49638336960853446d, 3.01088E7d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1060, (long) 95);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1060L + "'", long2 == 1060L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        int int2 = org.apache.commons.math.util.FastMath.min(1233838437, 1528444520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1233838437 + "'", int2 == 1233838437);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(77600, 9700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77600 + "'", int2 == 77600);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection17, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number24 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection28, true);
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException30.getSuppressed();
        boolean boolean32 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException43.getDirection();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number46 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection50, false);
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        java.lang.Number number54 = nonMonotonousSequenceException52.getPrevious();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        java.lang.Throwable[] throwableArray56 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1) + "'", number20.equals((-1)));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1 + "'", number24.equals(1));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-3) + "'", number46.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 3.678982327128295d + "'", number54.equals(3.678982327128295d));
        org.junit.Assert.assertNotNull(throwableArray56);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        long long1 = org.apache.commons.math.util.MathUtils.sign(8L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(15L, (long) (-1532789821));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1306896481, (float) (-1040904982));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.04090496E9f) + "'", float2 == (-1.04090496E9f));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray19);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray14);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray29.getClass();
        java.lang.Class<?> wildcardClass33 = doubleArray29.getClass();
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray29);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 79, (double) 4.49573952E8f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.9579677636223587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.338972390037892d, 1528444620, 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.cosh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1236069535), (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1236069535L) + "'", long2 == (-1236069535L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.4463520074491623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963267948968d, (double) 9312, 4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), number1, (int) (short) 1, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.0d) + "'", number13.equals((-0.0d)));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 104736, (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int int2 = org.apache.commons.math.util.FastMath.max(20, (-1040904982));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1040904982));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1040904982 + "'", int1 == 1040904982);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-449573981), 1091);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 414803195 + "'", int2 == 414803195);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double1 = org.apache.commons.math.util.FastMath.log10((-4.703452711410479E-287d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 101L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 1528444521);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.20797334230966952d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1040904982);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.763356347677618d + "'", double1 == 20.763356347677618d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-449573949), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-449573949L) + "'", long2 == (-449573949L));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1086517760, (long) 1306896481);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45805362486709760L + "'", long2 == 45805362486709760L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection17, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number24 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection28, true);
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException30.getSuppressed();
        boolean boolean32 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException43.getDirection();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number46 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection50, false);
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        java.lang.Number number54 = nonMonotonousSequenceException52.getPrevious();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = nonMonotonousSequenceException12.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1) + "'", number20.equals((-1)));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1 + "'", number24.equals(1));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-3) + "'", number46.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 3.678982327128295d + "'", number54.equals(3.678982327128295d));
        org.junit.Assert.assertNull(orderDirection56);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int2 = org.apache.commons.math.util.FastMath.max(100, 1857509505);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1857509505 + "'", int2 == 1857509505);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (3,631,948,698,846,703,100 > 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (3,631,948,698,846,703,100 > 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.4289704307792634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6205234402144832d + "'", double1 == 1.6205234402144832d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double1 = org.apache.commons.math.util.FastMath.sinh(13.338764247848552d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 310399.99999838934d + "'", double1 == 310399.99999838934d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 9);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (-1040904982));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection17, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number24 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection28, true);
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException30.getSuppressed();
        boolean boolean32 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException43.getDirection();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number46 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection50, false);
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        java.lang.Number number54 = nonMonotonousSequenceException52.getPrevious();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        java.lang.Number number56 = nonMonotonousSequenceException52.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1) + "'", number20.equals((-1)));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1 + "'", number24.equals(1));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-3) + "'", number46.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 3.678982327128295d + "'", number54.equals(3.678982327128295d));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 8 + "'", number56.equals(8));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1428558770, (-1236069535));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 8800387989504L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1083215872));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray22);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray12);
        double[] doubleArray29 = null;
        double[] doubleArray31 = new double[] { (short) 0 };
        double[] doubleArray33 = new double[] { (short) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double[] doubleArray36 = new double[] { (short) 0 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray36);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray48);
        double[] doubleArray54 = new double[] { (short) 0 };
        double[] doubleArray56 = new double[] { (short) 1 };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray45);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray45);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray64);
        double[] doubleArray67 = new double[] { (short) 0 };
        double[] doubleArray69 = new double[] { (short) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        double[] doubleArray73 = new double[] { (short) 0 };
        double[] doubleArray75 = new double[] { (short) 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray75);
        double[] doubleArray78 = new double[] { (short) 0 };
        double[] doubleArray80 = new double[] { (short) 1 };
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray80);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray78);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray73);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray67);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 9312, (long) 1528444520);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1528444520L + "'", long2 == 1528444520L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1074266112);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection14, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection14, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number21 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection25, true);
        java.lang.Number number28 = nonMonotonousSequenceException27.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException27.getDirection();
        boolean boolean31 = nonMonotonousSequenceException27.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException27.getDirection();
        java.lang.String str33 = nonMonotonousSequenceException27.toString();
        int int34 = nonMonotonousSequenceException27.getIndex();
        boolean boolean35 = nonMonotonousSequenceException27.getStrict();
        java.lang.Throwable[] throwableArray36 = nonMonotonousSequenceException27.getSuppressed();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-3) + "'", number21.equals((-3)));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1 + "'", number28.equals(1));
        org.junit.Assert.assertNull(orderDirection29);
        org.junit.Assert.assertNull(orderDirection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(orderDirection32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-105));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1664L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 449573949);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray12 = new double[] { (short) 0 };
        double[] doubleArray14 = new double[] { (short) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray24 = new double[] { (short) 0 };
        double[] doubleArray26 = new double[] { (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray26);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray29);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray26);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number42, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = nonMonotonousSequenceException45.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection46, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection46, true);
        double[] doubleArray54 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        double[] doubleArray61 = new double[] { (short) 0 };
        double[] doubleArray63 = new double[] { (short) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray61);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray61);
        double[] doubleArray68 = new double[] { (short) 0 };
        double[] doubleArray70 = new double[] { (short) 1 };
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray70);
        double[] doubleArray73 = new double[] { (short) 0 };
        double[] doubleArray75 = new double[] { (short) 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray73);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray70);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 18);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(541611264);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 971L, 40.792156108742276d, 0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1074266112);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.542318636580439d) + "'", double1 == (-0.542318636580439d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 1428558770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int int2 = org.apache.commons.math.util.FastMath.min((-3), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3) + "'", int2 == (-3));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0678271999808795E9d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0678271999808794E9d) + "'", double2 == (-1.0678271999808794E9d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.4808121761009482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6173874723496303d + "'", double1 == 0.6173874723496303d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray7);
        double[] doubleArray15 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray17 = new double[] { (short) 0 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray22);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray34);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray29);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray29);
        double[] doubleArray43 = new double[] { (short) 0 };
        double[] doubleArray45 = new double[] { (short) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray45);
        double[] doubleArray48 = new double[] { (short) 0 };
        double[] doubleArray50 = new double[] { (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray48);
        double[] doubleArray54 = new double[] { (short) 0 };
        double[] doubleArray56 = new double[] { (short) 1 };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        double[] doubleArray59 = new double[] { (short) 0 };
        double[] doubleArray61 = new double[] { (short) 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray61);
        double[] doubleArray64 = new double[] { (short) 0 };
        double[] doubleArray66 = new double[] { (short) 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray64);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray61);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray54);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray54);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-105));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 971, (-1236069535), 1040904982);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1664L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.417580402414544d + "'", double1 == 7.417580402414544d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 101L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 9);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.024493047472279896d, 0.23118034868692922d, 3.725290298461914E-9d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray19);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray14);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray29.getClass();
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray29);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.32657918471542563d, (-449573981));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.928085566756922E279d) + "'", double2 == (-5.928085566756922E279d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1528444520, 1091);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 990);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.86506314314109E300d, 971.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009927756388448549d + "'", double2 == 0.009927756388448549d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int int2 = org.apache.commons.math.util.MathUtils.pow(91, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double double1 = org.apache.commons.math.util.FastMath.floor(9700.000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9700.0d + "'", double1 == 9700.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 77600, 0.0d, (-0.9394587646078952d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        double[] doubleArray3 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray5 = new double[] { (short) 0 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        double[] doubleArray20 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1083215872));
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double[] doubleArray30 = new double[] { (short) 0 };
        double[] doubleArray32 = new double[] { (short) 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray30);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray37 = new double[] { (short) 0 };
        double[] doubleArray39 = new double[] { (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray39);
        double[] doubleArray44 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray46 = new double[] { (short) 0 };
        double[] doubleArray48 = new double[] { (short) 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray48);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray51);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray58 = new double[] { (short) 0 };
        double[] doubleArray60 = new double[] { (short) 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray60);
        double[] doubleArray63 = new double[] { (short) 0 };
        double[] doubleArray65 = new double[] { (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray63);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray60);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray51);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray72 = new double[] { (short) 0 };
        double[] doubleArray74 = new double[] { (short) 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray74);
        double[] doubleArray77 = new double[] { (short) 0 };
        double[] doubleArray79 = new double[] { (short) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray77);
        double[] doubleArray83 = new double[] { (short) 0 };
        double[] doubleArray85 = new double[] { (short) 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray83, doubleArray85);
        double[] doubleArray88 = new double[] { (short) 0 };
        double[] doubleArray90 = new double[] { (short) 1 };
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray88, doubleArray90);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray88);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray77, doubleArray83);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray77);
        int int96 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray51);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4182664536621883E130d + "'", double21 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 31 + "'", int70 == 31);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.0d + "'", double80 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.0d + "'", double91 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 6L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 640696287, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 32.00000000000001d, (int) (byte) 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32.00000000000001d + "'", number6.equals(32.00000000000001d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5674369031063846d, (double) 1188.0f, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.691673596021348E41d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.973493806989008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16730829662099556d + "'", double1 == 0.16730829662099556d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double1 = org.apache.commons.math.util.FastMath.ulp(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9721522630525295E-31d + "'", double1 == 1.9721522630525295E-31d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1189);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 8.2228187E18f, 0.07403367632859821d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.2228186546018703E18d + "'", double2 == 8.2228186546018703E18d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1083215872));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1083215872) + "'", int2 == (-1083215872));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 15L, 1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0333147966386297E40d + "'", double2 == 1.0333147966386297E40d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number11, (java.lang.Number) 9.619275968248924E151d, (int) (byte) 1);
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException14.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(79);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double1 = org.apache.commons.math.util.FastMath.asin(970.6522901207366d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double double1 = org.apache.commons.math.util.FastMath.log1p(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 20);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) '4');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 2);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, 1074266112);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double1 = org.apache.commons.math.util.FastMath.ulp(306.89900618933257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-62L), 960L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 898L + "'", long2 == 898L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 100, (-97L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double2 = org.apache.commons.math.util.FastMath.min((-8.746713800973678E13d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.746713800973678E13d) + "'", double2 == (-8.746713800973678E13d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8920048697881602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6376370445101797d + "'", double1 == 0.6376370445101797d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 1, 1306896481);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1306896482 + "'", int2 == 1306896482);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.641588833612779d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(31L, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 22L + "'", long2 == 22L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray8 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray10 = new double[] { (short) 0 };
        double[] doubleArray12 = new double[] { (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double[] doubleArray15 = new double[] { (short) 0 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 0 };
        double[] doubleArray24 = new double[] { (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        double[] doubleArray35 = new double[] { (short) 0 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray37);
        double[] doubleArray40 = new double[] { (short) 0 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray40);
        double[] doubleArray48 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray50 = new double[] { (short) 0 };
        double[] doubleArray52 = new double[] { (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray52);
        double[] doubleArray55 = new double[] { (short) 0 };
        double[] doubleArray57 = new double[] { (short) 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray55);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double[] doubleArray62 = new double[] { (short) 0 };
        double[] doubleArray64 = new double[] { (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray64);
        double[] doubleArray67 = new double[] { (short) 0 };
        double[] doubleArray69 = new double[] { (short) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray62);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray62);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection76, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(359.99999999999994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 22L, (float) 1079574528);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(96L, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 5.3128418E18f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5312841834681073664L + "'", long1 == 5312841834681073664L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.346544323973411d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.577864041769d + "'", double1 == 5729.577864041769d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(15.211251338567996d, (-1.6055120681834575E-296d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1040904982, (-948251051));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1989156033 + "'", int2 == 1989156033);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 91L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 91.0f + "'", float1 == 91.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double double1 = org.apache.commons.math.util.FastMath.log1p(91.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5217885770490405d + "'", double1 == 4.5217885770490405d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1060), (float) 4984363303356800L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.9843632E15f + "'", float2 == 4.9843632E15f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.49638336960853463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 310400L, (float) 1073741824);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 310400.0f + "'", float2 == 310400.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (byte) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 1L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (byte) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1528444521);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (byte) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 1L);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) (byte) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger41);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger42);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 9);
        java.math.BigInteger bigInteger46 = null;
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) (byte) 0);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 1L);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 1528444521);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1098L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013367172257978635d + "'", double1 == 0.013367172257978635d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-1076101088));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double2 = org.apache.commons.math.util.FastMath.max(1.168395263616004d, (-4.5788569702133275d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.168395263616004d + "'", double2 == 1.168395263616004d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1091, (java.lang.Number) (byte) 1, 1091);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.3124383412727525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.4752075402242797d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02574722872716037d) + "'", double1 == (-0.02574722872716037d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-98L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        long long1 = org.apache.commons.math.util.FastMath.abs(9368144838L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9368144838L + "'", long1 == 9368144838L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1091);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6468503591892605d) + "'", double1 == (-0.6468503591892605d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(Float.POSITIVE_INFINITY, 95, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.987063683537267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3830550410675577d + "'", double1 == 1.3830550410675577d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1428558770);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int2 = org.apache.commons.math.util.FastMath.min(77600, 1189);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1189 + "'", int2 == 1189);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 104736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(5587200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        double double1 = org.apache.commons.math.util.FastMath.cosh(310399.99999838934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.460139105621001d + "'", double1 == 1.460139105621001d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.41601138990780057d), (-1532789821));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.2433293015763816E289d) + "'", double2 == (-3.2433293015763816E289d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-99885750));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9, (int) ' ', 1076101120);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 105);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(23.389546815118596d, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1076101088), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 3, (long) 1074266112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3222798336L + "'", long2 == 3222798336L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 104736);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        double double1 = org.apache.commons.math.util.FastMath.log10(9.61066627123549E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.982753496710245d + "'", double1 == 19.982753496710245d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.848048096156426d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9208952688316006d + "'", double1 == 0.9208952688316006d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9259807453832821d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9259807453832821d + "'", double2 == 0.9259807453832821d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 414803195);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 0 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double double5 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray7 = new double[] { (short) 0 };
        double[] doubleArray9 = new double[] { (short) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray7);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray14 = new double[] { (short) 0 };
        double[] doubleArray16 = new double[] { (short) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray16);
        double[] doubleArray19 = new double[] { (short) 0 };
        double[] doubleArray21 = new double[] { (short) 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 0 };
        double[] doubleArray27 = new double[] { (short) 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray27);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray16);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray16);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        double[] doubleArray38 = new double[] { (short) 0 };
        double[] doubleArray40 = new double[] { (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray46);
        double[] doubleArray49 = new double[] { (short) 0 };
        double[] doubleArray51 = new double[] { (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray49);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray44);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray38);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray15);
        double[] doubleArray18 = new double[] { (short) 0 };
        double[] doubleArray20 = new double[] { (short) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray18);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray26 = new double[] { (short) 0 };
        double[] doubleArray28 = new double[] { (short) 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection40, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException44.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) 97L, (int) (short) 10, orderDirection45, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection45, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 449573967L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        try {
            double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (-34.99999999999999d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.720298876395427E298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-449573949), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 449573949 + "'", int2 == 449573949);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 35L, (-1004311523));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1060), 1189);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int int2 = org.apache.commons.math.util.MathUtils.pow(9665, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 837426945 + "'", int2 == 837426945);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1566276225, 1566276225);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.429208453471192E202d) + "'", double2 == (-1.429208453471192E202d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        double double1 = org.apache.commons.math.util.FastMath.exp(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8103.083927575384d + "'", double1 == 8103.083927575384d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(950L, (long) 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17100L + "'", long2 == 17100L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray9);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray21);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray16);
        double[] doubleArray29 = new double[] { (short) 0 };
        double[] doubleArray31 = new double[] { (short) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray31);
        double[] doubleArray37 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        double[] doubleArray44 = new double[] { (short) 0 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray44);
        double[] doubleArray51 = new double[] { (short) 0 };
        double[] doubleArray53 = new double[] { (short) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double[] doubleArray56 = new double[] { (short) 0 };
        double[] doubleArray58 = new double[] { (short) 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray53);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray53);
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number63, (java.lang.Number) 8.64289985028826d, 3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection67, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.570442986354218d, (java.lang.Number) 2.462625387274655E114d, 1470363154, orderDirection67, false);
        java.lang.Class<?> wildcardClass72 = nonMonotonousSequenceException71.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass72);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        double[] doubleArray4 = new double[] { (short) 0 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray9);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        double[] doubleArray27 = new double[] { (short) 0 };
        double[] doubleArray29 = new double[] { (short) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray18);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (-0.6596727568297204d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection41, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection41, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection41, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 0.7258066738053498d, 0, orderDirection41, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = nonMonotonousSequenceException49.getDirection();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1079574528);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07957453E9f + "'", float1 == 1.07957453E9f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) (byte) 0, (-1), orderDirection9, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), number4, (int) (short) 1, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 310400L, (java.lang.Number) 45.9356821340476d, 449573949, orderDirection12, true);
        java.lang.String str17 = nonMonotonousSequenceException16.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 449,573,948 and 449,573,949 are not strictly decreasing (45.936 <= 310,400)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 449,573,948 and 449,573,949 are not strictly decreasing (45.936 <= 310,400)"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 20, 91, 1072693279);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1528444521);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 9);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 1233838437);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection10, true);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection17, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number24 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection28, true);
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException30.getSuppressed();
        boolean boolean32 = nonMonotonousSequenceException30.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException43.getDirection();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        java.lang.Number number46 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8, (java.lang.Number) 3.678982327128295d, 1074266112, orderDirection50, false);
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        java.lang.Number number54 = nonMonotonousSequenceException52.getPrevious();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        boolean boolean56 = nonMonotonousSequenceException52.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1) + "'", number20.equals((-1)));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1 + "'", number24.equals(1));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-3) + "'", number46.equals((-3)));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 3.678982327128295d + "'", number54.equals(3.678982327128295d));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6757942592282237d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(9700, 77600);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-3.0460028648376465d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9524513967534557d) + "'", double1 == (-0.9524513967534557d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 22.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.584912845131592E9d + "'", double1 == 3.584912845131592E9d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double[] doubleArray1 = new double[] { (short) 0 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray6 = new double[] { (short) 0 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray6);
        double[] doubleArray14 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        double[] doubleArray31 = new double[] { 1.7182818284590453d, 1.4182664536621883E130d, (-1L), (byte) 0 };
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray31);
        double[] doubleArray34 = new double[] { (short) 0 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray39);
        double[] doubleArray47 = new double[] { 100L, 0.0f, 100.0d };
        double[] doubleArray49 = new double[] { (short) 0 };
        double[] doubleArray51 = new double[] { (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray51);
        double[] doubleArray54 = new double[] { (short) 0 };
        double[] doubleArray56 = new double[] { (short) 1 };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray54);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray54);
        double[] doubleArray61 = new double[] { (short) 0 };
        double[] doubleArray63 = new double[] { (short) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        double[] doubleArray66 = new double[] { (short) 0 };
        double[] doubleArray68 = new double[] { (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray61);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray61);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray61);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 6.283185307179586d);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-105827L));
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.4182664536621883E130d + "'", double32 == 1.4182664536621883E130d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 52913.50000000001d + "'", double79 == 52913.50000000001d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        double double1 = org.apache.commons.math.util.FastMath.tan((-3.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1425465430742778d + "'", double1 == 0.1425465430742778d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.462625387274655E114d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 95);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 35L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(104736, 9312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10159392 + "'", int2 == 10159392);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.941052877636353d) + "'", double1 == (-0.941052877636353d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 1, (int) 'a', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        double[] doubleArray16 = new double[] { (short) 0 };
        double[] doubleArray18 = new double[] { (short) 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray18);
        double[] doubleArray21 = new double[] { (short) 0 };
        double[] doubleArray23 = new double[] { (short) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray21);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray28 = new double[] { (short) 0 };
        double[] doubleArray30 = new double[] { (short) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray30);
        double[] doubleArray33 = new double[] { (short) 0 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray33);
        double[] doubleArray39 = new double[] { (short) 0 };
        double[] doubleArray41 = new double[] { (short) 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray30);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (-0.6596727568297204d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 3.6319486988467031E18d, 100, orderDirection53, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 101L, 1, orderDirection53, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray30, orderDirection53, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 0.7258066738053498d, 0, orderDirection53, true);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException61);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly decreasing (1 <= -1)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }
}

