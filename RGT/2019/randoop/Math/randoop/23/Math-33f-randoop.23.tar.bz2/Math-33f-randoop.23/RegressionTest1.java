import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        double double7 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray10 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix11, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix11);
        try {
            array2DRowRealMatrix3.addToEntry(5, (int) ' ', (-10.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 110.0d + "'", double7 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("hi!", (int) (short) -1);
        java.lang.String str3 = mathParseException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.MathParseException: illegal state: string \"hi!\" unparseable (from position -1)" + "'", str3.equals("org.apache.commons.math3.exception.MathParseException: illegal state: string \"hi!\" unparseable (from position -1)"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix8.transpose();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getDataRef();
        double[] doubleArray37 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        double[] doubleArray42 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix43.subtract(array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        boolean boolean51 = array2DRowRealMatrix48.isTransposable();
        double[] doubleArray54 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray56 = array2DRowRealMatrix48.preMultiply(doubleArray54);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction58 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray56, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair60 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray56, 3.4359738368E10d);
        double[] doubleArray61 = pointValuePair60.getPointRef();
        double[] doubleArray62 = array2DRowRealMatrix39.operate(doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector64 = array2DRowRealMatrix39.getColumnVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix8.add(array2DRowRealMatrix39);
        int int66 = array2DRowRealMatrix39.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor12 = null;
        try {
            double double13 = array2DRowRealMatrix8.walkInOptimizedOrder(realMatrixPreservingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector18.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector18.mapMultiplyToSelf((double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double34 = arrayRealVector31.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        arrayRealVector31.setEntry((int) '#', (double) 2.0f);
        java.lang.String str38 = arrayRealVector31.toString();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector31.mapAdd((double) (short) 10);
        double double41 = arrayRealVector31.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str38.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix12.scalarMultiply((double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double double12 = blockRealMatrix10.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix10.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double15 = blockRealMatrix13.walkInRowOrder(realMatrixChangingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 110.0d + "'", double12 == 110.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", "org.apache.commons.math3.exception.MathParseException: illegal state: string \"hi!\" unparseable (from position -1)", "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception");
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((-1.0d), (double) 100.0f, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix10.getColumnMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) '#', (int) '#');
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix5 = openMapRealMatrix2.createMatrix(30, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        double[] doubleArray9 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.copy();
        boolean boolean13 = array2DRowRealMatrix10.isTransposable();
        double[][] doubleArray14 = array2DRowRealMatrix10.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 1, (double) (-1));
        try {
            org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector2.getSubVector((int) ' ', 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0.0f);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        array2DRowRealMatrix8.setRow(0, doubleArray42);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix44);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (short) 10);
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
        maxCountExceededException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException3);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.5440680443502757d, (-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix36.subtract(array2DRowRealMatrix41);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix41.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = array2DRowRealMatrix9.subtract(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        java.text.NumberFormat numberFormat11 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double19 = arrayRealVector16.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        arrayRealVector16.setEntry((int) '#', (double) 2.0f);
        arrayRealVector16.unitize();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector14.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.lang.String str25 = realVectorFormat12.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double26 = arrayRealVector14.getLInfNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector1.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double28 = arrayRealVector14.getLInfNorm();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str25.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 1076101120, 0);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        java.text.NumberFormat numberFormat3 = realVectorFormat2.getFormat();
        java.lang.StringBuffer stringBuffer4 = null;
        java.text.FieldPosition fieldPosition5 = null;
        try {
            java.lang.StringBuffer stringBuffer6 = org.apache.commons.math3.util.CompositeFormat.formatDouble(10100.0d, numberFormat3, stringBuffer4, fieldPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0, (java.lang.Number) 1076101120, (java.lang.Number) 1.560895660206908d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        java.text.NumberFormat numberFormat2 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector7.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector7.setEntry((int) '#', (double) 2.0f);
        arrayRealVector7.unitize();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector5.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        java.lang.String str16 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double double17 = arrayRealVector5.getLInfNorm();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getDataRef();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix21.subtract(array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.copy();
        boolean boolean29 = array2DRowRealMatrix26.isTransposable();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[] doubleArray34 = array2DRowRealMatrix26.preMultiply(doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double39 = arrayRealVector36.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, arrayRealVector36);
        boolean boolean41 = arrayRealVector36.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector36.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5, arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector1.append((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double54 = arrayRealVector51.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        arrayRealVector51.setEntry((int) '#', (double) 2.0f);
        arrayRealVector51.unitize();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector49.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double69 = arrayRealVector66.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        arrayRealVector66.setEntry((int) '#', (double) 2.0f);
        arrayRealVector66.unitize();
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector64.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector66.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double77 = arrayRealVector62.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        double[] doubleArray80 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        double[][] doubleArray82 = array2DRowRealMatrix81.getDataRef();
        double[] doubleArray85 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = array2DRowRealMatrix81.subtract(array2DRowRealMatrix86);
        org.apache.commons.math3.linear.RealMatrix realMatrix88 = array2DRowRealMatrix86.copy();
        boolean boolean89 = array2DRowRealMatrix86.isTransposable();
        double[] doubleArray92 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix93 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray92);
        double[] doubleArray94 = array2DRowRealMatrix86.preMultiply(doubleArray92);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62, doubleArray92);
        try {
            double double96 = arrayRealVector51.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 54");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str16.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.4210854715202004E-14d + "'", double77 == 1.4210854715202004E-14d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix87);
        org.junit.Assert.assertNotNull(realMatrix88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        double double1 = org.apache.commons.math3.util.FastMath.atan(100.00999950005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607976598582913d + "'", double1 == 1.5607976598582913d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Double[] doubleArray3 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, (java.lang.Object[]) doubleArray3);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        double[] doubleArray19 = null;
        try {
            double double20 = linearObjectiveFunction18.getValue(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getWrongDimensions();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray6);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        double double10 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double32 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, arrayRealVector29);
        boolean boolean34 = arrayRealVector29.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector29.mapSubtractToSelf(0.5585053606381855d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix6, realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 1 != 52");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.00999950005d + "'", double10 == 100.00999950005d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        java.lang.Object[] objArray7 = new java.lang.Object[] { numberIsTooSmallException5, 100 };
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException(localizable1, objArray7);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException9.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathArithmeticException9.getContext();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double18 = arrayRealVector15.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        arrayRealVector15.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double24 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double29 = arrayRealVector26.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        arrayRealVector26.setEntry((int) '#', (double) 2.0f);
        java.lang.String str33 = arrayRealVector26.toString();
        double double34 = arrayRealVector23.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector23.append(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double43 = arrayRealVector40.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        arrayRealVector40.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double49 = arrayRealVector40.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double54 = arrayRealVector51.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        arrayRealVector51.setEntry((int) '#', (double) 2.0f);
        java.lang.String str58 = arrayRealVector51.toString();
        double double59 = arrayRealVector48.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double64 = arrayRealVector61.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        arrayRealVector61.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray68 = arrayRealVector61.getDataRef();
        double double69 = arrayRealVector51.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector23.combine(1.5440680443502757d, 3.4359738368E10d, (org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        double[] doubleArray71 = arrayRealVector23.getDataRef();
        try {
            array2DRowRealMatrix8.setRow((int) 'a', doubleArray71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str33.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str58.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        double[][] doubleArray22 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.30816907111598496d, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray24);
        try {
            blockRealMatrix9.setSubMatrix(doubleArray24, 30, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("; ", "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", "Array2DRowRealMatrix{{100.0},{10.0}}");
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception", "hi!", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = blockRealMatrix9.walkInRowOrder(realMatrixChangingVisitor10, 0, 1076101151, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (short) 10);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (short) 10 + "'", number2.equals((short) 10));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        java.text.NumberFormat numberFormat11 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double19 = arrayRealVector16.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        arrayRealVector16.setEntry((int) '#', (double) 2.0f);
        arrayRealVector16.unitize();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector14.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.lang.String str25 = realVectorFormat12.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double26 = arrayRealVector14.getLInfNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector1.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray28 = arrayRealVector14.toArray();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str25.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        java.lang.String str10 = blockRealMatrix9.toString();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BlockRealMatrix{{100.0},{10.0}}" + "'", str10.equals("BlockRealMatrix{{100.0},{10.0}}"));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = realVector7.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector11 = realVector7.mapDivide((double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction12 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector1, (double) (short) 100);
        double double13 = linearObjectiveFunction12.getConstantTerm();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix23.subtract(array2DRowRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.copy();
        double[][] doubleArray31 = array2DRowRealMatrix28.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix19.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix28);
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix36.subtract(array2DRowRealMatrix41);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix41.copy();
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[][] doubleArray48 = array2DRowRealMatrix47.getDataRef();
        double[] doubleArray51 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix47.subtract(array2DRowRealMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix52.copy();
        boolean boolean55 = array2DRowRealMatrix52.isTransposable();
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[] doubleArray60 = array2DRowRealMatrix52.preMultiply(doubleArray58);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = array2DRowRealMatrix41.subtract(array2DRowRealMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = array2DRowRealMatrix19.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix61);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = array2DRowRealMatrix61.getRowMatrix((int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(realMatrix64);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver2 = new org.apache.commons.math3.optimization.linear.SimplexSolver(10.0d, (int) '#');
        simplexSolver2.setMaxIterations((int) (short) 10);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction44 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray42, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, 3.4359738368E10d);
        double[] doubleArray47 = pointValuePair46.getPointRef();
        double[] doubleArray48 = array2DRowRealMatrix25.operate(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix15.preMultiply(doubleArray48);
        double[] doubleArray52 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getDataRef();
        double[] doubleArray57 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = array2DRowRealMatrix53.subtract(array2DRowRealMatrix58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = array2DRowRealMatrix58.copy();
        boolean boolean61 = array2DRowRealMatrix58.isTransposable();
        double[] doubleArray64 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        double[] doubleArray66 = array2DRowRealMatrix58.preMultiply(doubleArray64);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction68 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray66, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair70 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray66, 3.4359738368E10d);
        double[] doubleArray71 = pointValuePair70.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double76 = arrayRealVector73.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        arrayRealVector73.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double82 = arrayRealVector73.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double87 = arrayRealVector84.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        arrayRealVector84.setEntry((int) '#', (double) 2.0f);
        java.lang.String str91 = arrayRealVector84.toString();
        double double92 = arrayRealVector81.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray71, arrayRealVector81);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, arrayRealVector93);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 2.0d + "'", double82 == 2.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str91.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        int int21 = blockRealMatrix10.getColumnDimension();
        double double22 = blockRealMatrix10.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix10.createMatrix((int) (short) -1, 1076101151);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 110.0d + "'", double22 == 110.0d);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double21 = array2DRowRealMatrix20.getNorm();
        boolean boolean22 = array2DRowRealMatrix20.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10100.0d + "'", double21 == 10100.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.294967296E10d + "'", double2 == 4.294967296E10d);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 1L, (float) 1076101151);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction44 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray42, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, 3.4359738368E10d);
        double[] doubleArray47 = pointValuePair46.getPointRef();
        double[] doubleArray48 = array2DRowRealMatrix25.operate(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix15.preMultiply(doubleArray48);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor50 = null;
        try {
            double double55 = array2DRowRealMatrix15.walkInColumnOrder(realMatrixPreservingVisitor50, 1, 30, (int) '4', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        java.lang.String str8 = arrayRealVector1.toString();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector1.mapAdd((double) (short) 10);
        double double11 = arrayRealVector1.getMaxValue();
        double double12 = arrayRealVector1.getLInfNorm();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str8.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.EQ;
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.EQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.EQ));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 3.4359738368E10d, (java.lang.Number) 52, (java.lang.Number) Double.NaN);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 52 + "'", number6.equals(52));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[][] doubleArray29 = array2DRowRealMatrix28.getDataRef();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = array2DRowRealMatrix28.subtract(array2DRowRealMatrix33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix33.copy();
        boolean boolean36 = array2DRowRealMatrix33.isTransposable();
        double[] doubleArray39 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix33.preMultiply(doubleArray39);
        org.apache.commons.math3.optimization.linear.Relationship relationship43 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[][] doubleArray48 = array2DRowRealMatrix47.getDataRef();
        double[] doubleArray51 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix47.subtract(array2DRowRealMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix52.copy();
        boolean boolean55 = array2DRowRealMatrix52.isTransposable();
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[] doubleArray60 = array2DRowRealMatrix52.preMultiply(doubleArray58);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint62 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray39, 0.0d, relationship43, doubleArray58, (double) 0);
        java.lang.String str63 = relationship43.toString();
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint65 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector24, relationship43, (double) (byte) 0);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction67 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector24, Double.NaN);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + relationship43 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship43.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + ">=" + "'", str63.equals(">="));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        try {
            blockRealMatrix9.addToEntry((int) 'a', 1076101151, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, 1.4E-45f, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        int[] intArray17 = new int[] { '4', 'a', 100, (byte) -1, '#', 1 };
        int[] intArray24 = new int[] { 5, 'a', 2, (byte) -10, '#', 100 };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix25 = blockRealMatrix9.getSubMatrix(intArray17, intArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[][] doubleArray23 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) array2DRowRealMatrix19, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix10.getColumnMatrix(1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,076,101,120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double6 = arrayRealVector3.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        arrayRealVector3.setEntry((int) '#', (double) 2.0f);
        arrayRealVector3.unitize();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector1.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector3.getSubVector(10, (int) (short) 10);
        double double16 = arrayRealVector3.getEntry((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[][] doubleArray23 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) array2DRowRealMatrix19, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix10.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math3.exception.NullArgumentException(localizable32, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable31, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        double double41 = blockRealMatrix40.getFrobeniusNorm();
        try {
            blockRealMatrix10.setRowMatrix((int) (short) 1, blockRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.4987562112089d + "'", double41 == 100.4987562112089d);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 1086568991);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.08656896E9f + "'", float1 == 1.08656896E9f);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.000003814697266d + "'", double1 == 35.000003814697266d);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 32);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix8.transpose();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getDataRef();
        double[] doubleArray37 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        double[] doubleArray42 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix43.subtract(array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        boolean boolean51 = array2DRowRealMatrix48.isTransposable();
        double[] doubleArray54 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray56 = array2DRowRealMatrix48.preMultiply(doubleArray54);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction58 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray56, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair60 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray56, 3.4359738368E10d);
        double[] doubleArray61 = pointValuePair60.getPointRef();
        double[] doubleArray62 = array2DRowRealMatrix39.operate(doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector64 = array2DRowRealMatrix39.getColumnVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix8.add(array2DRowRealMatrix39);
        double[][] doubleArray66 = array2DRowRealMatrix65.getData();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        boolean boolean34 = array2DRowRealMatrix9.equals((java.lang.Object) 5.298342365610589d);
        double[][] doubleArray41 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 1);
        try {
            array2DRowRealMatrix9.copySubMatrix(0, (int) (byte) 10, 10, (int) (short) 10, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        org.apache.commons.math3.optimization.linear.SimplexSolver simplexSolver0 = new org.apache.commons.math3.optimization.linear.SimplexSolver();
        int int1 = simplexSolver0.getIterations();
        int int2 = simplexSolver0.getIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100L);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        double double1 = org.apache.commons.math3.util.FastMath.rint((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray21 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix27.copy();
        boolean boolean30 = array2DRowRealMatrix27.isTransposable();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray35 = array2DRowRealMatrix27.preMultiply(doubleArray33);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint37 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray14, 0.0d, relationship18, doubleArray33, (double) 0);
        org.apache.commons.math3.linear.RealVector realVector38 = linearConstraint37.getCoefficients();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) ' ', 20.796610301702525d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.796610301702525d + "'", double2 == 20.796610301702525d);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double21 = array2DRowRealMatrix20.getNorm();
        double double22 = array2DRowRealMatrix20.getNorm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10100.0d + "'", double21 == 10100.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10100.0d + "'", double22 == 10100.0d);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        java.text.NumberFormat numberFormat11 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double19 = arrayRealVector16.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        arrayRealVector16.setEntry((int) '#', (double) 2.0f);
        arrayRealVector16.unitize();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector14.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.lang.String str25 = realVectorFormat12.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double26 = arrayRealVector14.getLInfNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector1.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        java.text.NumberFormat numberFormat28 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat29 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double36 = arrayRealVector33.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        arrayRealVector33.setEntry((int) '#', (double) 2.0f);
        arrayRealVector33.unitize();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector31.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        java.lang.String str42 = realVectorFormat29.format((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double43 = arrayRealVector31.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double48 = arrayRealVector45.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        arrayRealVector45.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double54 = arrayRealVector45.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        java.text.NumberFormat numberFormat55 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat56 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double63 = arrayRealVector60.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        arrayRealVector60.setEntry((int) '#', (double) 2.0f);
        arrayRealVector60.unitize();
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector58.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        java.lang.String str69 = realVectorFormat56.format((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        double double70 = arrayRealVector58.getLInfNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = arrayRealVector45.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector31, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector1.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector45.mapDivideToSelf(1.2d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str25.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(numberFormat28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str42.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertNotNull(numberFormat55);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str69.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(arrayRealVector73);
        org.junit.Assert.assertNotNull(realVector75);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 5, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double15 = arrayRealVector12.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        arrayRealVector12.setEntry((int) '#', (double) 2.0f);
        java.lang.String str19 = arrayRealVector12.toString();
        double double20 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double25 = arrayRealVector22.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        arrayRealVector22.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray29 = arrayRealVector22.getDataRef();
        double double30 = arrayRealVector12.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        arrayRealVector12.addToEntry(0, (double) 1L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double38 = arrayRealVector35.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        arrayRealVector35.setEntry((int) '#', (double) 2.0f);
        java.lang.String str42 = arrayRealVector35.toString();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector35.mapAdd((double) (short) 10);
        double double45 = arrayRealVector35.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double50 = arrayRealVector47.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector49.mapMultiplyToSelf(0.020341793137738453d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double57 = arrayRealVector54.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector49.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector35.append(arrayRealVector49);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 104");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str19.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str42.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 35.000004f, (double) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(4.294967296E10d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.294967295999999E10d + "'", double2 == 4.294967295999999E10d);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 10, (int) (byte) 0, 10);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test82");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        java.text.NumberFormat numberFormat3 = realVectorFormat2.getFormat();
        java.lang.StringBuffer stringBuffer4 = null;
        java.text.FieldPosition fieldPosition5 = null;
        try {
            java.lang.StringBuffer stringBuffer6 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 1086568991, numberFormat3, stringBuffer4, fieldPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test83");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 1.2d, 20.796610301702525d, 5.298342365610589d, 110.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test84");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        int[] intArray34 = new int[] { 0, (byte) 1, 52, 52, 'a' };
        int[] intArray39 = new int[] { (short) 100, 52, 30, 1076101120 };
        double[] doubleArray42 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix43.subtract(array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        boolean boolean51 = array2DRowRealMatrix48.isTransposable();
        double[] doubleArray54 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray56 = array2DRowRealMatrix48.preMultiply(doubleArray54);
        double[][] doubleArray57 = array2DRowRealMatrix48.getData();
        try {
            array2DRowRealMatrix19.copySubMatrix(intArray34, intArray39, doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test85");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(0, (-1), 10, 10);
        try {
            int int6 = matrixDimensionMismatchException4.getWrongDimension(5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test86");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("Array2DRowRealMatrix{{100.0},{10.0}}", "; ", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test87");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (short) 100, 10);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test88");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray6, 1.1102230246251565E-16d);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, false);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector28.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector28);
        org.apache.commons.math3.exception.util.Localizable localizable31 = null;
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math3.exception.NullArgumentException(localizable32, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable31, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix40.copy();
        double double42 = blockRealMatrix41.getNorm();
        double[] doubleArray45 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray45);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair49 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray45, (double) (short) 0);
        double[] doubleArray50 = pointValuePair49.getKey();
        double[] doubleArray51 = blockRealMatrix41.preMultiply(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, true);
        double[] doubleArray57 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        double[][] doubleArray59 = array2DRowRealMatrix58.getDataRef();
        double[] doubleArray62 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = array2DRowRealMatrix58.subtract(array2DRowRealMatrix63);
        org.apache.commons.math3.linear.RealMatrix realMatrix65 = array2DRowRealMatrix63.copy();
        boolean boolean66 = array2DRowRealMatrix63.isTransposable();
        double[] doubleArray69 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        double[] doubleArray71 = array2DRowRealMatrix63.preMultiply(doubleArray69);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction73 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray71, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair75 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray71, 3.4359738368E10d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 110.0d + "'", double42 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(realMatrix65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
    }
}

