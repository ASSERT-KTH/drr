import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 10, (int) (short) 1, (int) (byte) 100, (int) (byte) 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math3.util.FastMath.abs((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 1, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.optimization.GoalType goalType0 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long1 = org.apache.commons.math3.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        double[] doubleArray6 = new double[] { (-1.0d), (short) -1, 100, (short) 10, 100.0f };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", (int) (short) -1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathParseException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            java.lang.String str3 = realVectorFormat1.format(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 1, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 10L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1L, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 100L, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix3.createMatrix((int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 100, 1.0f, (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        int[] intArray7 = new int[] { '#', ' ', (byte) 0 };
        int[] intArray10 = new int[] { (short) 10, '4' };
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix3.getSubMatrix(intArray7, intArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 10, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[] doubleArray8 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 1x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) '4', (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1654988945205933d + "'", double2 == 1.1654988945205933d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 1.0f, true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(32L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 1, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat1.parse("Array2DRowRealMatrix{{100.0},{10.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{100.0},{10.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 1);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 10, (int) (short) 0, doubleArray4, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix8.walkInRowOrder(realMatrixPreservingVisitor11, 0, 0, (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) (-1L), (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 97, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealVector realVector11 = null;
        try {
            array2DRowRealMatrix8.setRowVector(36, realVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) 'a');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(4.9E-324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("Array2DRowRealMatrix{{100.0},{10.0}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 100L, (double) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        try {
            array2DRowRealMatrix6.copySubMatrix((int) (byte) 100, 0, (int) (short) 0, 1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (short) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor10, 0, (int) (short) 100, (int) '4', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat1.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { (-1.0d), 100.0d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 20 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.8446214886716036d + "'", double0 == 0.8446214886716036d);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math3.util.FastMath.acos(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.optimization.linear.UnboundedSolutionException unboundedSolutionException0 = new org.apache.commons.math3.optimization.linear.UnboundedSolutionException();
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        org.apache.commons.math3.linear.RealVector realVector11 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = array2DRowRealMatrix8.operate(realVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix8.getRowMatrix((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        double[] doubleArray11 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        double[] doubleArray16 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.copy();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix6.multiply(array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(Double.NaN, (double) (byte) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 32L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        boolean boolean6 = array2DRowRealMatrix3.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.RealVector realVector8 = null;
        try {
            array2DRowRealMatrix3.setColumnVector(1, realVector8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.apache.commons.math3.optimization.linear.AbstractLinearOptimizer.DEFAULT_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        java.lang.String str5 = array2DRowRealMatrix3.toString();
        double[][] doubleArray6 = null;
        try {
            array2DRowRealMatrix3.setSubMatrix(doubleArray6, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{{100.0},{10.0}}" + "'", str5.equals("Array2DRowRealMatrix{{100.0},{10.0}}"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 36);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        try {
            double double4 = arrayRealVector1.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1, (-0.9999999999999999d), (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.1654988945205933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020341793137738453d + "'", double1 == 0.020341793137738453d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 'a', 0, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector5 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix6 = arrayRealVector3.outerProduct(realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("hi!", "Array2DRowRealMatrix{{100.0},{10.0}}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 2.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        java.lang.String str5 = array2DRowRealMatrix3.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix3.walkInRowOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{{100.0},{10.0}}" + "'", str5.equals("Array2DRowRealMatrix{{100.0},{10.0}}"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.String str3 = realVectorFormat1.getSeparator();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        try {
            java.lang.StringBuffer stringBuffer11 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5, stringBuffer9, fieldPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4221817809573358E-5d + "'", double1 == 2.4221817809573358E-5d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974484d + "'", double1 == 0.7853981633974484d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix4, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix19);
        try {
            double double29 = array2DRowRealMatrix19.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 1, Double.NaN, (double) (byte) 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix6.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 1L, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4359738368E10d + "'", double2 == 3.4359738368E10d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        int[] intArray15 = new int[] { (byte) 100, (byte) 100, (short) 100 };
        int[] intArray20 = new int[] { (-1), (short) 0, 36, (short) 0 };
        double[] doubleArray25 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        try {
            array2DRowRealMatrix8.copySubMatrix(intArray15, intArray20, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (short) 0);
        try {
            double[] doubleArray17 = array2DRowRealMatrix3.operate(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor11, (int) (byte) -1, (int) '#', (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int1 = org.apache.commons.math3.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) ' ', (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        int[] intArray20 = new int[] {};
        int[] intArray21 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.getSubMatrix(intArray20, intArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (short) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double3 = org.apache.commons.math3.util.Precision.round(6.283185307179586d, 0, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix19.walkInRowOrder(realMatrixPreservingVisitor20, (int) (byte) 0, 0, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double24 = arrayRealVector21.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        arrayRealVector21.setEntry((int) '#', (double) 2.0f);
        arrayRealVector21.unitize();
        try {
            org.apache.commons.math3.linear.RealVector realVector29 = array2DRowRealMatrix19.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        java.lang.String str5 = array2DRowRealMatrix3.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.subtract(realMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{{100.0},{10.0}}" + "'", str5.equals("Array2DRowRealMatrix{{100.0},{10.0}}"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 10, (int) (byte) 0, 10);
        try {
            int int6 = matrixDimensionMismatchException4.getExpectedDimension((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) '#', (double) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.000004f + "'", float2 == 35.000004f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 10, (int) (byte) 0, 10);
        int int6 = matrixDimensionMismatchException4.getExpectedDimension((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double[] doubleArray3 = new double[] { 2.2250738585072014E-308d, (byte) 100, 2.2250738585072014E-308d };
        org.apache.commons.math3.optimization.linear.Relationship relationship5 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray8 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getDataRef();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix9.subtract(array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        boolean boolean17 = array2DRowRealMatrix14.isTransposable();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix14.preMultiply(doubleArray20);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction24 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray22, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint27 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray3, (double) (short) 10, relationship5, doubleArray22, (-0.5872139151569291d));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + relationship5 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship5.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int2 = org.apache.commons.math3.util.FastMath.max(10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (-32L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double14 = arrayRealVector11.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        arrayRealVector11.setEntry((int) '#', (double) 2.0f);
        java.lang.String str18 = arrayRealVector11.toString();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector11.mapAdd((double) (short) 10);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix9, (org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 52");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str18.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 2.0f, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.30816907111598496d + "'", double2 == 0.30816907111598496d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-0.9999999999999999d), 1.1654988945205933d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.0000000000000002d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0739842733593692E16d + "'", double2 == 2.0739842733593692E16d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math3.util.FastMath.log(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.util.MathUtils.checkFinite(1.5707963267948966d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray21 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix27.copy();
        boolean boolean30 = array2DRowRealMatrix27.isTransposable();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray35 = array2DRowRealMatrix27.preMultiply(doubleArray33);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint37 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray14, 0.0d, relationship18, doubleArray33, (double) 0);
        java.lang.Object obj38 = null;
        boolean boolean39 = linearConstraint37.equals(obj38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        boolean boolean17 = array2DRowRealMatrix14.equals((java.lang.Object) (-1.0f));
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 10, (double) 1.0f, (double) 36);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        java.text.NumberFormat numberFormat3 = realVectorFormat2.getFormat();
        java.lang.StringBuffer stringBuffer4 = null;
        java.text.FieldPosition fieldPosition5 = null;
        try {
            java.lang.StringBuffer stringBuffer6 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 100L, numberFormat3, stringBuffer4, fieldPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) 1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.0d, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray5);
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) '4', (float) (short) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math3.util.FastMath.floor(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        double[] doubleArray36 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getDataRef();
        double[] doubleArray41 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = array2DRowRealMatrix37.subtract(array2DRowRealMatrix42);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = array2DRowRealMatrix42.copy();
        boolean boolean45 = array2DRowRealMatrix42.isTransposable();
        double[] doubleArray48 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix42.preMultiply(doubleArray48);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction52 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray50, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair54 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray50, 3.4359738368E10d);
        try {
            array2DRowRealMatrix9.setRow((int) (short) 10, doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1074790400), (-1074790400), 10, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 'a', 32.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math3.util.Precision.round(1.1654988945205933d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2d + "'", double2 == 1.2d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 10L, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) (byte) 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray5);
        double[] doubleArray10 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[][] doubleArray12 = array2DRowRealMatrix11.getDataRef();
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = array2DRowRealMatrix11.subtract(array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix16.copy();
        double[] doubleArray21 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix27.copy();
        boolean boolean30 = array2DRowRealMatrix27.isTransposable();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray35 = array2DRowRealMatrix27.preMultiply(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix16.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix27);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        java.lang.String str15 = realVectorFormat1.getPrefix();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{" + "'", str15.equals("{"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 32L, (java.lang.Number) 0.7853981633974484d, false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix9.walkInRowOrder(realMatrixChangingVisitor10, 1, 10, 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (short) 10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        java.io.ObjectInputStream objectInputStream24 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) doubleArray14, "Array2DRowRealMatrix{{100.0},{10.0}}", objectInputStream24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        double[][] doubleArray29 = array2DRowRealMatrix19.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        double[][] doubleArray29 = array2DRowRealMatrix19.getData();
        java.io.ObjectOutputStream objectOutputStream30 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19, objectOutputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, (int) '4', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 104 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double6 = arrayRealVector3.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        arrayRealVector3.setEntry((int) '#', (double) 2.0f);
        arrayRealVector3.unitize();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector1.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSeparator();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        double[] doubleArray11 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray11);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray11, (double) (short) 0);
        try {
            double[] doubleArray16 = array2DRowRealMatrix6.operate(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 10, (int) (byte) 0, 10);
        try {
            int int6 = matrixDimensionMismatchException4.getWrongDimension((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        double[][] doubleArray7 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, number1, (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        try {
            array2DRowRealMatrix8.setEntry((int) (short) 10, 100, 2.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        java.lang.String str15 = realVectorFormat1.getSeparator();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "; " + "'", str15.equals("; "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 1, (-32L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.util.MathUtils.checkFinite(10.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (short) 0);
        double[] doubleArray7 = pointValuePair6.getKey();
        double[] doubleArray8 = pointValuePair6.getKey();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double15 = arrayRealVector12.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        arrayRealVector12.setEntry((int) '#', (double) 2.0f);
        java.lang.String str19 = arrayRealVector12.toString();
        double double20 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction21 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector12.mapToSelf(univariateFunction21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str19.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.exception.MathParseException mathParseException27 = new org.apache.commons.math3.exception.MathParseException("hi!", (int) (short) -1);
        boolean boolean28 = arrayRealVector24.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (byte) 0, (double) ' ', (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getDataRef();
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix20.copy();
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix20.preMultiply(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double33 = arrayRealVector30.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26, arrayRealVector30);
        boolean boolean35 = arrayRealVector30.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector30.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector30.mapMultiplyToSelf((double) (byte) 1);
        try {
            arrayRealVector9.setSubVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (86)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) "{", localizable1, objArray2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        java.lang.Object[] objArray9 = new java.lang.Object[] { numberIsTooSmallException7, 100 };
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException(localizable3, objArray9);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 'a', localizable2, objArray9);
        org.apache.commons.math3.exception.ZeroException zeroException12 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 'a', (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.00000000000001d + "'", double2 == 97.00000000000001d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5, false);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInRowOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(Double.NaN, (double) (short) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.0d, (double) (short) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix19.walkInColumnOrder(realMatrixPreservingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.4210854715202004E-14d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.8446214886716036d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07333787354717161d) + "'", double1 == (-0.07333787354717161d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix19);
        double[] doubleArray31 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getDataRef();
        double[] doubleArray35 = array2DRowRealMatrix32.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8, realVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        double[] doubleArray31 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getDataRef();
        double[] doubleArray36 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = array2DRowRealMatrix37.copy();
        double[][] doubleArray40 = array2DRowRealMatrix37.getData();
        try {
            array2DRowRealMatrix19.setSubMatrix(doubleArray40, (int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        double[][] doubleArray29 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix19.walkInRowOrder(realMatrixPreservingVisitor30, (int) ' ', (-1), (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getWrongDimensions();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException11 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray12 = matrixDimensionMismatchException11.getWrongDimensions();
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 36, (-1074790400), (-1074790400), 36, 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException19 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray12, intArray18);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray6, intArray12);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getDataRef();
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix20.copy();
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix20.preMultiply(doubleArray26);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction30 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray28, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        try {
            array2DRowRealMatrix8.setColumn((int) (byte) 1, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(4.9E-324d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.450147717014403E-308d + "'", double2 == 4.450147717014403E-308d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[][] doubleArray5 = array2DRowRealMatrix4.getDataRef();
        double[][] doubleArray6 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray5);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathIllegalArgumentException7.getContext();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[][] doubleArray29 = array2DRowRealMatrix28.getDataRef();
        boolean boolean31 = array2DRowRealMatrix28.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix8.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double15 = arrayRealVector3.getLInfNorm();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
        boolean boolean27 = array2DRowRealMatrix24.isTransposable();
        double[] doubleArray30 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix24.preMultiply(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector34);
        boolean boolean39 = arrayRealVector34.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector34.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector34);
        int int45 = arrayRealVector34.getDimension();
        double double46 = arrayRealVector34.getNorm();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        int[] intArray12 = new int[] { 1, 1 };
        int[] intArray16 = new int[] { (-1074790400), (byte) 0, 1 };
        org.apache.commons.math3.exception.util.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math3.exception.NullArgumentException(localizable17, (java.lang.Object[]) doubleArray22);
        try {
            array2DRowRealMatrix6.copySubMatrix(intArray12, intArray16, doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.abs(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.283185307179586d + "'", double1 == 6.283185307179586d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Number number8 = notStrictlyPositiveException7.getMin();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        try {
            double double6 = arrayRealVector1.getEntry((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) -1, 0.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor13 = null;
        try {
            double double18 = array2DRowRealMatrix8.walkInRowOrder(realMatrixPreservingVisitor13, (int) (byte) 100, (int) ' ', 52, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long1 = org.apache.commons.math3.util.FastMath.round(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 57L + "'", long1 == 57L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix8.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor30, (-1074790400), 0, (-1074790400), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(1.9155040003582885E22d, 4.450147717014403E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(3.4359738368E10d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        java.lang.String str1 = relationship0.toString();
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ">=" + "'", str1.equals(">="));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(4.9E-324d, 0.0d, 1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double2 = org.apache.commons.math3.util.FastMath.min(1.5440680443502757d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5440680443502757d + "'", double2 == 1.5440680443502757d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (byte) 1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[][] doubleArray17 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix8.copy();
        try {
            array2DRowRealMatrix8.setEntry((int) '4', 0, 1.4210854715202004E-14d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector3.mapMultiplyToSelf(0.020341793137738453d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double11 = arrayRealVector8.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector3.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        double double14 = arrayRealVector3.getEntry((int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double9 = arrayRealVector6.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        arrayRealVector6.setEntry((int) '#', (double) 2.0f);
        arrayRealVector6.unitize();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector4.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        java.lang.String str15 = realVectorFormat2.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        double double16 = arrayRealVector4.getLInfNorm();
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix25.copy();
        boolean boolean28 = array2DRowRealMatrix25.isTransposable();
        double[] doubleArray31 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix25.preMultiply(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double38 = arrayRealVector35.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector35);
        boolean boolean40 = arrayRealVector35.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector35.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4, arrayRealVector35);
        int int46 = arrayRealVector35.getDimension();
        arrayRealVector35.setEntry((int) (short) 0, (double) (-1L));
        java.lang.StringBuffer stringBuffer50 = null;
        java.text.FieldPosition fieldPosition51 = null;
        try {
            java.lang.StringBuffer stringBuffer52 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector35, stringBuffer50, fieldPosition51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str15.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (short) 0);
        try {
            double[] doubleArray17 = array2DRowRealMatrix6.preMultiply(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(5, (int) (byte) 100);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        int int19 = org.apache.commons.math3.util.MathUtils.hash(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1086568991 + "'", int19 == 1086568991);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        java.lang.String str5 = array2DRowRealMatrix3.toString();
        double[] doubleArray8 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getDataRef();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix9.subtract(array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        boolean boolean17 = array2DRowRealMatrix14.isTransposable();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix14.preMultiply(doubleArray20);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction24 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray22, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, 3.4359738368E10d);
        double[] doubleArray27 = pointValuePair26.getPointRef();
        try {
            double[] doubleArray28 = array2DRowRealMatrix3.preMultiply(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{{100.0},{10.0}}" + "'", str5.equals("Array2DRowRealMatrix{{100.0},{10.0}}"));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math3.util.FastMath.max(572.9577951308232d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 572.9577951308232d + "'", double2 == 572.9577951308232d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", "hi!");
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix9.walkInColumnOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.1102230246251565E-16d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.12535577716556084d) + "'", double2 == (-0.12535577716556084d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        org.apache.commons.math3.linear.RealVector realVector34 = array2DRowRealMatrix9.getColumnVector((int) (byte) 0);
        java.lang.Double[] doubleArray36 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36);
        try {
            org.apache.commons.math3.linear.RealVector realVector38 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int6 = matrixDimensionMismatchException4.getWrongRowDimension();
        try {
            int int8 = matrixDimensionMismatchException4.getExpectedDimension((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.1102230246251565E-16d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}");
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[][] doubleArray17 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[][] doubleArray17 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix8.copy();
        try {
            double double19 = array2DRowRealMatrix8.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.optimization.linear.Relationship relationship21 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint23 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray16, relationship21, 97.00000000000001d);
        double double24 = linearConstraint23.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 97.00000000000001d + "'", double24 == 97.00000000000001d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 52, 32.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double6 = arrayRealVector3.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        arrayRealVector3.setEntry((int) '#', (double) 2.0f);
        arrayRealVector3.unitize();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector1.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getDataRef();
        double[] doubleArray19 = array2DRowRealMatrix16.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction22 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray19, 1.1102230246251565E-16d);
        arrayRealVector1.setSubVector((int) (short) 10, doubleArray19);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math3.util.FastMath.log(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) '#', (double) 100L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -10 + "'", byte2 == (byte) -10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealVector realVector5 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix28.walkInOptimizedOrder(realMatrixPreservingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.util.MathUtils.checkFinite(2.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor29, (int) ' ', (int) (short) -1, (-1), 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        double[][] doubleArray29 = array2DRowRealMatrix19.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix19.getSubMatrix((int) (short) -1, (int) (byte) -10, (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getDataRef();
        double[] doubleArray29 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix30);
        double[] doubleArray34 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[][] doubleArray36 = array2DRowRealMatrix35.getDataRef();
        double[] doubleArray39 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = array2DRowRealMatrix35.subtract(array2DRowRealMatrix40);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.copy();
        boolean boolean43 = array2DRowRealMatrix40.isTransposable();
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray48 = array2DRowRealMatrix40.preMultiply(doubleArray46);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction50 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray48, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair52 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray48, 3.4359738368E10d);
        double[] doubleArray53 = pointValuePair52.getPointRef();
        double[] doubleArray54 = array2DRowRealMatrix31.operate(doubleArray53);
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[][] doubleArray60 = array2DRowRealMatrix59.getDataRef();
        double[] doubleArray63 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix59.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = array2DRowRealMatrix64.copy();
        boolean boolean67 = array2DRowRealMatrix64.isTransposable();
        double[] doubleArray70 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double[] doubleArray72 = array2DRowRealMatrix64.preMultiply(doubleArray70);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction74 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray72, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair76 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray72, 3.4359738368E10d);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException81 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray82 = matrixDimensionMismatchException81.getWrongDimensions();
        int int83 = matrixDimensionMismatchException81.getExpectedRowDimension();
        boolean boolean84 = pointValuePair76.equals((java.lang.Object) int83);
        double[] doubleArray85 = pointValuePair76.getKey();
        array2DRowRealMatrix31.setRow((int) (byte) 0, doubleArray85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, doubleArray85);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair90 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) 100.0f, true);
        double[] doubleArray91 = pointValuePair90.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 100 + "'", int83 == 100);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        double[] doubleArray3 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[][] doubleArray5 = array2DRowRealMatrix4.getDataRef();
        double[] doubleArray8 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = array2DRowRealMatrix4.subtract(array2DRowRealMatrix9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        boolean boolean12 = array2DRowRealMatrix9.isTransposable();
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray17 = array2DRowRealMatrix9.preMultiply(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double22 = arrayRealVector19.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, arrayRealVector19);
        boolean boolean24 = arrayRealVector19.isInfinite();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, (org.apache.commons.math3.linear.RealVector) arrayRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 0 != 52");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        long long2 = org.apache.commons.math3.util.FastMath.min(1L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32L, (java.lang.Number) 8.881784197001252E-16d, false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1076101151 + "'", int8 == 1076101151);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        float float2 = org.apache.commons.math3.util.FastMath.max(1.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        try {
            double[] doubleArray30 = array2DRowRealMatrix8.getColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.power(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double32 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, arrayRealVector29);
        boolean boolean34 = arrayRealVector29.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector29.getSubVector((int) '4', 0);
        try {
            array2DRowRealMatrix6.setRowVector(1076101151, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double15 = arrayRealVector3.getLInfNorm();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
        boolean boolean27 = array2DRowRealMatrix24.isTransposable();
        double[] doubleArray30 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix24.preMultiply(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector34);
        boolean boolean39 = arrayRealVector34.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector34.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector34);
        int int45 = arrayRealVector3.getDimension();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix3.multiply(array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector18.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector18.mapMultiplyToSelf((double) (byte) 1);
        double double30 = arrayRealVector18.getLInfNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector18.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) '#', 1.4210854715202004E-14d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector1.mapMultiplyToSelf((double) (byte) -1);
        org.apache.commons.math3.linear.RealVector realVector13 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector1.projection(realVector13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 0, (double) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = nullArgumentException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getDataRef();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix21);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix21.copy();
        boolean boolean24 = array2DRowRealMatrix21.isTransposable();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray29 = array2DRowRealMatrix21.preMultiply(doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double34 = arrayRealVector31.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, arrayRealVector31);
        boolean boolean36 = arrayRealVector31.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector31.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector31.mapDivideToSelf((double) 1.4E-45f);
        try {
            array2DRowRealMatrix8.setRowVector(1086568991, (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,086,568,991)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) '4', (int) (short) -1, (int) (byte) 10, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        try {
            double[] doubleArray8 = array2DRowRealMatrix6.getColumn((-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (byte) 1, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector18.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector18.mapMultiplyToSelf((double) (byte) 1);
        double double30 = arrayRealVector18.getLInfNorm();
        arrayRealVector18.set((double) 57L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 1L, (float) (-32L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-32.0f) + "'", float2 == (-32.0f));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double33 = arrayRealVector30.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        arrayRealVector30.setEntry((int) '#', (double) 2.0f);
        arrayRealVector30.unitize();
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector28.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector30.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double41 = arrayRealVector26.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 52");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.4210854715202004E-14d + "'", double41 == 1.4210854715202004E-14d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        java.lang.String str8 = arrayRealVector1.toString();
        arrayRealVector1.setEntry((int) (short) 0, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str8.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[][] doubleArray17 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor18 = null;
        try {
            double double23 = array2DRowRealMatrix8.walkInRowOrder(realMatrixPreservingVisitor18, (int) (byte) 0, (int) (byte) -1, (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix23.subtract(array2DRowRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.copy();
        boolean boolean31 = array2DRowRealMatrix28.isTransposable();
        double[] doubleArray34 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix28.preMultiply(doubleArray34);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction38 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray36, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair40 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, 3.4359738368E10d);
        double[] doubleArray41 = pointValuePair40.getPointRef();
        double[] doubleArray42 = array2DRowRealMatrix19.operate(doubleArray41);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix9, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x1 but expected 2x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 0, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray6, 1.1102230246251565E-16d);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.Relationship relationship28 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray31 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getDataRef();
        double[] doubleArray36 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix37);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = array2DRowRealMatrix37.copy();
        boolean boolean40 = array2DRowRealMatrix37.isTransposable();
        double[] doubleArray43 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[] doubleArray45 = array2DRowRealMatrix37.preMultiply(doubleArray43);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint47 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray24, 0.0d, relationship28, doubleArray43, (double) 0);
        try {
            double double48 = linearObjectiveFunction9.getValue(doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + relationship28 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship28.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707055269350272d + "'", double1 == 1.5707055269350272d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector3.mapMultiplyToSelf(0.020341793137738453d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double11 = arrayRealVector8.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector3.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.RealVector.unmodifiableRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector12);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 100.0f, false);
        java.lang.Number number26 = numberIsTooSmallException25.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext27 = numberIsTooSmallException25.getContext();
        boolean boolean28 = pointValuePair20.equals((java.lang.Object) exceptionContext27);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 100.0f + "'", number26.equals(100.0f));
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, false);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[] doubleArray26 = array2DRowRealMatrix23.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction29 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 1.1102230246251565E-16d);
        arrayRealVector18.setSubVector(0, doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 1);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1.3440585709080678E43d, (java.lang.Object[]) doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double2 = org.apache.commons.math3.util.FastMath.min(5.298342365610589d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) -10, (float) 36, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) (byte) 1, (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 97, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair6 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (short) 0);
        double[] doubleArray7 = pointValuePair6.getKey();
        java.lang.Double double8 = pointValuePair6.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8.equals(0.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getDataRef();
        double[] doubleArray29 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix30);
        double[] doubleArray34 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[][] doubleArray36 = array2DRowRealMatrix35.getDataRef();
        double[] doubleArray39 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = array2DRowRealMatrix35.subtract(array2DRowRealMatrix40);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.copy();
        boolean boolean43 = array2DRowRealMatrix40.isTransposable();
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray48 = array2DRowRealMatrix40.preMultiply(doubleArray46);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction50 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray48, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair52 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray48, 3.4359738368E10d);
        double[] doubleArray53 = pointValuePair52.getPointRef();
        double[] doubleArray54 = array2DRowRealMatrix31.operate(doubleArray53);
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[][] doubleArray60 = array2DRowRealMatrix59.getDataRef();
        double[] doubleArray63 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix59.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = array2DRowRealMatrix64.copy();
        boolean boolean67 = array2DRowRealMatrix64.isTransposable();
        double[] doubleArray70 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double[] doubleArray72 = array2DRowRealMatrix64.preMultiply(doubleArray70);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction74 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray72, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair76 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray72, 3.4359738368E10d);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException81 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray82 = matrixDimensionMismatchException81.getWrongDimensions();
        int int83 = matrixDimensionMismatchException81.getExpectedRowDimension();
        boolean boolean84 = pointValuePair76.equals((java.lang.Object) int83);
        double[] doubleArray85 = pointValuePair76.getKey();
        array2DRowRealMatrix31.setRow((int) (byte) 0, doubleArray85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, doubleArray85);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair90 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) 100.0f, true);
        java.lang.Double double91 = pointValuePair90.getValue();
        double[] doubleArray92 = pointValuePair90.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 100 + "'", int83 == 100);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 100.0d + "'", double91.equals(100.0d));
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5, false);
        boolean boolean9 = array2DRowRealMatrix7.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(52, (-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,074,790,400 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix23.subtract(array2DRowRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.copy();
        double[][] doubleArray31 = array2DRowRealMatrix28.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix19.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix28);
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix36.subtract(array2DRowRealMatrix41);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix41.copy();
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[][] doubleArray48 = array2DRowRealMatrix47.getDataRef();
        double[] doubleArray51 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix47.subtract(array2DRowRealMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix52.copy();
        boolean boolean55 = array2DRowRealMatrix52.isTransposable();
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[] doubleArray60 = array2DRowRealMatrix52.preMultiply(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = array2DRowRealMatrix41.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = array2DRowRealMatrix41.transpose();
        double[] doubleArray65 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[][] doubleArray67 = array2DRowRealMatrix66.getDataRef();
        double[] doubleArray70 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = array2DRowRealMatrix66.subtract(array2DRowRealMatrix71);
        double[] doubleArray75 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray75);
        double[][] doubleArray77 = array2DRowRealMatrix76.getDataRef();
        double[] doubleArray80 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = array2DRowRealMatrix76.subtract(array2DRowRealMatrix81);
        org.apache.commons.math3.linear.RealMatrix realMatrix83 = array2DRowRealMatrix81.copy();
        boolean boolean84 = array2DRowRealMatrix81.isTransposable();
        double[] doubleArray87 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix88 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray87);
        double[] doubleArray89 = array2DRowRealMatrix81.preMultiply(doubleArray87);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction91 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray89, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair93 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray89, 3.4359738368E10d);
        double[] doubleArray94 = pointValuePair93.getPointRef();
        double[] doubleArray95 = array2DRowRealMatrix72.operate(doubleArray94);
        org.apache.commons.math3.linear.RealVector realVector97 = array2DRowRealMatrix72.getColumnVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix98 = array2DRowRealMatrix41.add(array2DRowRealMatrix72);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix99 = array2DRowRealMatrix28.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix82);
        org.junit.Assert.assertNotNull(realMatrix83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(realVector97);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix98);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.optimization.linear.Relationship relationship0 = org.apache.commons.math3.optimization.linear.Relationship.LEQ;
        org.junit.Assert.assertTrue("'" + relationship0 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship0.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math3.util.FastMath.log10(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49714987269413385d + "'", double1 == 0.49714987269413385d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        array2DRowRealMatrix8.setRow(0, doubleArray42);
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[][] doubleArray48 = array2DRowRealMatrix47.getDataRef();
        double[] doubleArray51 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix47.subtract(array2DRowRealMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix52.copy();
        boolean boolean55 = array2DRowRealMatrix52.isTransposable();
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[] doubleArray60 = array2DRowRealMatrix52.preMultiply(doubleArray58);
        double[][] doubleArray61 = array2DRowRealMatrix52.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = array2DRowRealMatrix52.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix63 = array2DRowRealMatrix8.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realMatrix62);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) '#');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix12, (org.apache.commons.math3.linear.AnyMatrix) realMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 35x35");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5707963267948966d, 1.1654988945205933d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.40529743227430326d + "'", double2 == 0.40529743227430326d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixChangingVisitor4, (int) (short) 10, (int) (short) 0, (int) 'a', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (short) 10, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.util.MathUtils.checkFinite(0.30816907111598496d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.String str3 = realVectorFormat1.getSeparator();
        java.text.NumberFormat numberFormat4 = realVectorFormat1.getFormat();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix3.walkInRowOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 52, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1484630505472706E60d + "'", double2 == 1.1484630505472706E60d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double15 = arrayRealVector12.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        arrayRealVector12.setEntry((int) '#', (double) 2.0f);
        java.lang.String str19 = arrayRealVector12.toString();
        double double20 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector12.mapAdd((double) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector24 = realVector22.mapAdd(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str19.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (short) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[][] doubleArray5 = array2DRowRealMatrix4.getDataRef();
        double[][] doubleArray6 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(2.0d, 0.5585053606381855d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray5 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[][] doubleArray7 = array2DRowRealMatrix6.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray7);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        boolean boolean10 = array2DRowRealMatrix9.isTransposable();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix9.walkInRowOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = blockRealMatrix9.walkInRowOrder(realMatrixPreservingVisitor10, 10, (-1), (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getDataRef();
        double[] doubleArray37 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = array2DRowRealMatrix38.copy();
        double[][] doubleArray41 = array2DRowRealMatrix38.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix29.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix38);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix9.multiply(realMatrix42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getDataRef();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = array2DRowRealMatrix15.copy();
        boolean boolean18 = array2DRowRealMatrix15.isTransposable();
        double[] doubleArray21 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray23 = array2DRowRealMatrix15.preMultiply(doubleArray21);
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[][] doubleArray28 = array2DRowRealMatrix27.getDataRef();
        boolean boolean30 = array2DRowRealMatrix27.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix15, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix27);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix6.add(array2DRowRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x4 but expected 2x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        try {
            double double12 = blockRealMatrix9.getEntry(52, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        java.lang.String str5 = array2DRowRealMatrix3.toString();
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double14 = arrayRealVector11.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        arrayRealVector11.setEntry((int) '#', (double) 2.0f);
        arrayRealVector11.unitize();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        java.lang.String str20 = realVectorFormat7.format((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double double21 = arrayRealVector9.getLInfNorm();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getDataRef();
        double[] doubleArray29 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix30);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix30.copy();
        boolean boolean33 = array2DRowRealMatrix30.isTransposable();
        double[] doubleArray36 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray38 = array2DRowRealMatrix30.preMultiply(doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double43 = arrayRealVector40.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36, arrayRealVector40);
        boolean boolean45 = arrayRealVector40.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector40.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector40);
        try {
            org.apache.commons.math3.linear.RealVector realVector51 = array2DRowRealMatrix3.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{{100.0},{10.0}}" + "'", str5.equals("Array2DRowRealMatrix{{100.0},{10.0}}"));
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str20.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(realVector49);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector5.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double16 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix25.copy();
        boolean boolean28 = array2DRowRealMatrix25.isTransposable();
        double[] doubleArray31 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix25.preMultiply(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray31);
        java.text.NumberFormat numberFormat35 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat36 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double43 = arrayRealVector40.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        arrayRealVector40.setEntry((int) '#', (double) 2.0f);
        arrayRealVector40.unitize();
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector38.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        java.lang.String str49 = realVectorFormat36.format((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double double50 = arrayRealVector38.getLInfNorm();
        double[] doubleArray53 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray53);
        double[][] doubleArray55 = array2DRowRealMatrix54.getDataRef();
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = array2DRowRealMatrix54.subtract(array2DRowRealMatrix59);
        org.apache.commons.math3.linear.RealMatrix realMatrix61 = array2DRowRealMatrix59.copy();
        boolean boolean62 = array2DRowRealMatrix59.isTransposable();
        double[] doubleArray65 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray67 = array2DRowRealMatrix59.preMultiply(doubleArray65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double72 = arrayRealVector69.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, arrayRealVector69);
        boolean boolean74 = arrayRealVector69.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector69);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector69.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector38, arrayRealVector69);
        int int80 = arrayRealVector69.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector34, arrayRealVector69);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4210854715202004E-14d + "'", double16 == 1.4210854715202004E-14d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(numberFormat35);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str49.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 52 + "'", int80 == 52);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        try {
            double double27 = array2DRowRealMatrix20.getEntry((int) (short) 10, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector18.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector18.mapMultiplyToSelf((double) (byte) 1);
        double double30 = arrayRealVector18.getLInfNorm();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[][] doubleArray35 = array2DRowRealMatrix34.getDataRef();
        double[] doubleArray38 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = array2DRowRealMatrix34.subtract(array2DRowRealMatrix39);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = array2DRowRealMatrix39.copy();
        boolean boolean42 = array2DRowRealMatrix39.isTransposable();
        double[] doubleArray45 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        double[] doubleArray47 = array2DRowRealMatrix39.preMultiply(doubleArray45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double52 = arrayRealVector49.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45, arrayRealVector49);
        boolean boolean54 = arrayRealVector49.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49);
        double double56 = arrayRealVector49.getL1Norm();
        double[] doubleArray59 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        double[][] doubleArray61 = array2DRowRealMatrix60.getDataRef();
        double[] doubleArray64 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = array2DRowRealMatrix60.subtract(array2DRowRealMatrix65);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix65.copy();
        boolean boolean68 = array2DRowRealMatrix65.isTransposable();
        double[] doubleArray71 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray71);
        double[] doubleArray73 = array2DRowRealMatrix65.preMultiply(doubleArray71);
        org.apache.commons.math3.optimization.linear.Relationship relationship75 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray78 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray78);
        double[][] doubleArray80 = array2DRowRealMatrix79.getDataRef();
        double[] doubleArray83 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray83);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = array2DRowRealMatrix79.subtract(array2DRowRealMatrix84);
        org.apache.commons.math3.linear.RealMatrix realMatrix86 = array2DRowRealMatrix84.copy();
        boolean boolean87 = array2DRowRealMatrix84.isTransposable();
        double[] doubleArray90 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray90);
        double[] doubleArray92 = array2DRowRealMatrix84.preMultiply(doubleArray90);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint94 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray71, 0.0d, relationship75, doubleArray90, (double) 0);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint96 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector49, relationship75, (double) 1L);
        double double97 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix66);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + relationship75 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship75.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix85);
        org.junit.Assert.assertNotNull(realMatrix86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double14 = arrayRealVector11.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        arrayRealVector11.setEntry((int) '#', (double) 2.0f);
        java.lang.String str18 = arrayRealVector11.toString();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix6, (org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 1 != 52");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str18.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 'a', 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix9.getSubMatrix(1, (int) (byte) 0, (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        java.lang.String str2 = mathArithmeticException0.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception" + "'", str2.equals("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(2.2250738585072014E-308d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2250738585072014E-308d + "'", double2 == 2.2250738585072014E-308d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[][] doubleArray17 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix8.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor19, (int) (byte) 1, (int) (byte) 10, (int) (short) 1, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        try {
            blockRealMatrix9.multiplyEntry((int) (short) 0, (int) (byte) 10, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 52.0f, (double) (short) 10, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10, (java.lang.Number) 10L, true);
        java.lang.Throwable throwable4 = null;
        try {
            numberIsTooLargeException3.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-0.07333787354717161d), (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        java.lang.String str5 = array2DRowRealMatrix3.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{{100.0},{10.0}}" + "'", str5.equals("Array2DRowRealMatrix{{100.0},{10.0}}"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getDataRef();
        double[] doubleArray29 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix30);
        double[] doubleArray34 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[][] doubleArray36 = array2DRowRealMatrix35.getDataRef();
        double[] doubleArray39 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = array2DRowRealMatrix35.subtract(array2DRowRealMatrix40);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.copy();
        boolean boolean43 = array2DRowRealMatrix40.isTransposable();
        double[] doubleArray46 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray48 = array2DRowRealMatrix40.preMultiply(doubleArray46);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction50 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray48, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair52 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray48, 3.4359738368E10d);
        double[] doubleArray53 = pointValuePair52.getPointRef();
        double[] doubleArray54 = array2DRowRealMatrix31.operate(doubleArray53);
        double[] doubleArray58 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[][] doubleArray60 = array2DRowRealMatrix59.getDataRef();
        double[] doubleArray63 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix59.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.RealMatrix realMatrix66 = array2DRowRealMatrix64.copy();
        boolean boolean67 = array2DRowRealMatrix64.isTransposable();
        double[] doubleArray70 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double[] doubleArray72 = array2DRowRealMatrix64.preMultiply(doubleArray70);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction74 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray72, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair76 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray72, 3.4359738368E10d);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException81 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray82 = matrixDimensionMismatchException81.getWrongDimensions();
        int int83 = matrixDimensionMismatchException81.getExpectedRowDimension();
        boolean boolean84 = pointValuePair76.equals((java.lang.Object) int83);
        double[] doubleArray85 = pointValuePair76.getKey();
        array2DRowRealMatrix31.setRow((int) (byte) 0, doubleArray85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, doubleArray85);
        double[] doubleArray88 = arrayRealVector87.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 100 + "'", int83 == 100);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix9.walkInColumnOrder(realMatrixChangingVisitor10, 32, 1, (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(0, (-1), 10, 10);
        int int5 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.createMatrix((int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 36, (float) '4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) (byte) 10, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10L + "'", number5.equals(10L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double26 = arrayRealVector23.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        arrayRealVector23.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double32 = arrayRealVector23.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        arrayRealVector34.setEntry((int) '#', (double) 2.0f);
        java.lang.String str41 = arrayRealVector34.toString();
        double double42 = arrayRealVector31.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        java.text.NumberFormat numberFormat46 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat47 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double54 = arrayRealVector51.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        arrayRealVector51.setEntry((int) '#', (double) 2.0f);
        arrayRealVector51.unitize();
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector49.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        java.lang.String str60 = realVectorFormat47.format((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        double double61 = arrayRealVector49.getLInfNorm();
        double[] doubleArray64 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        double[][] doubleArray66 = array2DRowRealMatrix65.getDataRef();
        double[] doubleArray69 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = array2DRowRealMatrix65.subtract(array2DRowRealMatrix70);
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = array2DRowRealMatrix70.copy();
        boolean boolean73 = array2DRowRealMatrix70.isTransposable();
        double[] doubleArray76 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        double[] doubleArray78 = array2DRowRealMatrix70.preMultiply(doubleArray76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double83 = arrayRealVector80.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray76, arrayRealVector80);
        boolean boolean85 = arrayRealVector80.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector80);
        org.apache.commons.math3.linear.RealVector realVector89 = arrayRealVector80.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector49, arrayRealVector80);
        org.apache.commons.math3.linear.RealVector realVector91 = arrayRealVector45.append((org.apache.commons.math3.linear.RealVector) arrayRealVector90);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = arrayRealVector43.add((org.apache.commons.math3.linear.RealVector) arrayRealVector90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 53 != 104");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str41.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str60.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix71);
        org.junit.Assert.assertNotNull(realMatrix72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(realVector89);
        org.junit.Assert.assertNotNull(realVector91);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        double double7 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray10 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix11, (int) (byte) 0);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix3, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix11);
        try {
            array2DRowRealMatrix11.multiplyEntry(5, 0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 110.0d + "'", double7 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 1086568991, (double) 2.0f, (double) 1076101151);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4281861168052193d) + "'", double1 == (-0.4281861168052193d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix23.subtract(array2DRowRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.copy();
        double[][] doubleArray31 = array2DRowRealMatrix28.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix19.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix28);
        double[] doubleArray34 = array2DRowRealMatrix19.getColumn(0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray6, 1.1102230246251565E-16d);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, false);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector28.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            double[] doubleArray33 = array2DRowRealMatrix31.getColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double[] doubleArray4 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix6, 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int1 = org.apache.commons.math3.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 32L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix10.getColumnMatrix((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double19 = arrayRealVector16.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        arrayRealVector16.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double25 = arrayRealVector16.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double30 = arrayRealVector27.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        arrayRealVector27.setEntry((int) '#', (double) 2.0f);
        java.lang.String str34 = arrayRealVector27.toString();
        double double35 = arrayRealVector24.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double40 = arrayRealVector37.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        arrayRealVector37.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray44 = arrayRealVector37.getDataRef();
        double double45 = arrayRealVector27.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        java.lang.String str46 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double55 = arrayRealVector52.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        arrayRealVector52.setEntry((int) '#', (double) 2.0f);
        arrayRealVector52.unitize();
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector50.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector52.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double63 = arrayRealVector48.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        double double64 = arrayRealVector48.getMinValue();
        java.lang.StringBuffer stringBuffer65 = null;
        java.text.FieldPosition fieldPosition66 = null;
        try {
            java.lang.StringBuffer stringBuffer67 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector48, stringBuffer65, fieldPosition66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str34.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str46.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.4210854715202004E-14d + "'", double63 == 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix3, (int) (byte) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.power((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getDataRef();
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix20.copy();
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix20.preMultiply(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double33 = arrayRealVector30.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26, arrayRealVector30);
        boolean boolean35 = arrayRealVector30.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30);
        try {
            blockRealMatrix9.setRowVector((-1074790400), (org.apache.commons.math3.linear.RealVector) arrayRealVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        double[] doubleArray9 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.copy();
        boolean boolean13 = array2DRowRealMatrix10.isTransposable();
        double[] doubleArray16 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray18 = array2DRowRealMatrix10.preMultiply(doubleArray16);
        org.apache.commons.math3.optimization.linear.Relationship relationship20 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[][] doubleArray25 = array2DRowRealMatrix24.getDataRef();
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix24.subtract(array2DRowRealMatrix29);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = array2DRowRealMatrix29.copy();
        boolean boolean32 = array2DRowRealMatrix29.isTransposable();
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray37 = array2DRowRealMatrix29.preMultiply(doubleArray35);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint39 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray16, 0.0d, relationship20, doubleArray35, (double) 0);
        org.apache.commons.math3.optimization.linear.Relationship relationship40 = relationship20.oppositeRelationship();
        double[] doubleArray43 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[][] doubleArray45 = array2DRowRealMatrix44.getDataRef();
        double[] doubleArray48 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = array2DRowRealMatrix44.subtract(array2DRowRealMatrix49);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = array2DRowRealMatrix49.copy();
        boolean boolean52 = array2DRowRealMatrix49.isTransposable();
        double[] doubleArray55 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray57 = array2DRowRealMatrix49.preMultiply(doubleArray55);
        try {
            org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint59 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray0, 10100.0d, relationship20, doubleArray57, 97.00000000000001d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + relationship20 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship20.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + relationship40 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship40.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException6 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException6.getWrongDimensions();
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 36, (-1074790400), (-1074790400), 36, 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray13);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException19 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray20 = matrixDimensionMismatchException19.getExpectedDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray13, intArray20);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException26 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray27 = matrixDimensionMismatchException26.getWrongDimensions();
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException28 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray20, intArray27);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 35.0d, (java.lang.Object[]) intArray27);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double15 = arrayRealVector3.getLInfNorm();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
        boolean boolean27 = array2DRowRealMatrix24.isTransposable();
        double[] doubleArray30 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix24.preMultiply(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector34);
        boolean boolean39 = arrayRealVector34.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector34.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector34.mapDivide(0.0d);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(realVector46);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) '#', (int) '#');
        try {
            openMapRealMatrix2.addToEntry((int) (byte) 100, (int) (short) 1, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) array2DRowRealMatrix8, localizable13, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor18 = null;
        try {
            double double19 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 1, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        int int6 = matrixDimensionMismatchException4.getWrongRowDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1.4E-45f, (-6.053272382792838d), 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        java.lang.Double[] doubleArray15 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) array2DRowRealMatrix8, localizable13, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 1076101151);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610301702525d + "'", double1 == 20.796610301702525d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int1 = org.apache.commons.math3.util.FastMath.round(52.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getDataRef();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix21);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix21.copy();
        boolean boolean24 = array2DRowRealMatrix21.isTransposable();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray29 = array2DRowRealMatrix21.preMultiply(doubleArray27);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction31 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray29, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix12, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[][] doubleArray12 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray16 = new double[] {};
        try {
            array2DRowRealMatrix14.setColumn((int) (byte) 1, doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector5.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double16 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix25.copy();
        boolean boolean28 = array2DRowRealMatrix25.isTransposable();
        double[] doubleArray31 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix25.preMultiply(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, doubleArray31);
        java.text.NumberFormat numberFormat35 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat36 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double43 = arrayRealVector40.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        arrayRealVector40.setEntry((int) '#', (double) 2.0f);
        arrayRealVector40.unitize();
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector38.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        java.lang.String str49 = realVectorFormat36.format((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double double50 = arrayRealVector38.getLInfNorm();
        try {
            double double51 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 54 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4210854715202004E-14d + "'", double16 == 1.4210854715202004E-14d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(numberFormat35);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str49.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.4987562112089d, 0.0d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, (int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 36 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8049501319758164d + "'", double1 == 0.8049501319758164d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[][] doubleArray16 = array2DRowRealMatrix14.getDataRef();
        try {
            blockRealMatrix9.setSubMatrix(doubleArray16, 0, (int) (byte) -10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(0, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = blockRealMatrix10.walkInRowOrder(realMatrixPreservingVisitor11, (int) (byte) -1, (int) (byte) -10, 5, (int) (byte) -10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        try {
            double double22 = array2DRowRealMatrix19.getEntry((int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction9 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray6, 1.1102230246251565E-16d);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, false);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector28.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector28);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            array2DRowRealMatrix31.multiplyEntry((-1074790400), 0, (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,074,790,400)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        try {
            org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix10.getRowVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        int int29 = array2DRowRealMatrix8.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = blockRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor11, (int) (short) 1, 52, 1086568991, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.4987562112089d + "'", double10 == 100.4987562112089d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[] doubleArray27 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix23.subtract(array2DRowRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.copy();
        double[][] doubleArray31 = array2DRowRealMatrix28.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix19.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix19.copy();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor12, (int) (byte) 1, (int) '#', (int) (byte) -10, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        double double25 = arrayRealVector18.getL1Norm();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector18.append((double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 1076101151);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        try {
            double[] doubleArray22 = blockRealMatrix10.getRow(1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = blockRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor11, 1076101151, 32, 10, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.4987562112089d + "'", double10 == 100.4987562112089d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        boolean boolean6 = array2DRowRealMatrix3.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double16 = arrayRealVector13.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        arrayRealVector13.setEntry((int) '#', (double) 2.0f);
        arrayRealVector13.unitize();
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector11.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector13.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double24 = arrayRealVector9.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        try {
            array2DRowRealMatrix3.setRowVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.4210854715202004E-14d + "'", double24 == 1.4210854715202004E-14d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}");
        double[] doubleArray6 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getDataRef();
        double[] doubleArray10 = array2DRowRealMatrix7.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        java.lang.StringBuffer stringBuffer12 = null;
        java.text.FieldPosition fieldPosition13 = null;
        try {
            java.lang.StringBuffer stringBuffer14 = realVectorFormat3.format(realVector11, stringBuffer12, fieldPosition13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double15 = arrayRealVector12.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        arrayRealVector12.setEntry((int) '#', (double) 2.0f);
        java.lang.String str19 = arrayRealVector12.toString();
        double double20 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double25 = arrayRealVector22.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        arrayRealVector22.setEntry((int) '#', (double) 2.0f);
        java.lang.String str29 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector22.mapAdd((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector12.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str19.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str29.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray8 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getDataRef();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix9.subtract(array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        boolean boolean17 = array2DRowRealMatrix14.isTransposable();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix14.preMultiply(doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[][] doubleArray27 = array2DRowRealMatrix26.getDataRef();
        boolean boolean29 = array2DRowRealMatrix26.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        boolean boolean31 = array2DRowRealMatrix3.equals((java.lang.Object) array2DRowRealMatrix26);
        double[] doubleArray35 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getDataRef();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix36.subtract(array2DRowRealMatrix41);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix41.copy();
        boolean boolean44 = array2DRowRealMatrix41.isTransposable();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix41.preMultiply(doubleArray47);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction51 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray49, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math3.optimization.linear.Relationship relationship54 = null;
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint56 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray49, relationship54, 97.00000000000001d);
        try {
            array2DRowRealMatrix26.setColumn((int) (short) 0, doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 2x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector18.mapAdd((double) 0L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[][] doubleArray23 = array2DRowRealMatrix19.getData();
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 1.5707963267948966d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) array2DRowRealMatrix19, localizable24, (java.lang.Object[]) doubleArray26);
        try {
            blockRealMatrix9.setColumnMatrix(5, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) -1, (float) (short) -1, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math3.util.FastMath.pow(1.5707963267948966d, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963238707607d + "'", double2 == 1.5707963238707607d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector1.set(10.0d);
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.RealVector.unmodifiableRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5, false);
        array2DRowRealMatrix7.setEntry((int) (short) 0, 1, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.450147717014403E-308d, (java.lang.Number) (-32L), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-32L) + "'", number5.equals((-32L)));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray8 = arrayRealVector1.getDataRef();
        double[] doubleArray9 = arrayRealVector1.getDataRef();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = matrixDimensionMismatchException4.getContext();
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException25 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray26 = matrixDimensionMismatchException25.getWrongDimensions();
        int int27 = matrixDimensionMismatchException25.getExpectedRowDimension();
        boolean boolean28 = pointValuePair20.equals((java.lang.Object) int27);
        double[] doubleArray29 = pointValuePair20.getKey();
        java.lang.Double double30 = pointValuePair20.getValue();
        double[] doubleArray31 = pointValuePair20.getPoint();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.4359738368E10d + "'", double30.equals(3.4359738368E10d));
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat2 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat1);
        java.text.NumberFormat numberFormat3 = realVectorFormat2.getFormat();
        java.text.ParsePosition parsePosition4 = null;
        try {
            java.lang.Number number5 = org.apache.commons.math3.util.CompositeFormat.parseNumber("Array2DRowRealMatrix{{100.0},{10.0}}", numberFormat3, parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double15 = arrayRealVector3.getLInfNorm();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
        boolean boolean27 = array2DRowRealMatrix24.isTransposable();
        double[] doubleArray30 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix24.preMultiply(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector34);
        boolean boolean39 = arrayRealVector34.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector34.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector34);
        int int45 = arrayRealVector34.getDimension();
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction47 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction((org.apache.commons.math3.linear.RealVector) arrayRealVector34, 0.7615941559557649d);
        org.apache.commons.math3.linear.RealVector realVector48 = linearObjectiveFunction47.getCoefficients();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray8 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getDataRef();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix9.subtract(array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        boolean boolean17 = array2DRowRealMatrix14.isTransposable();
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix14.preMultiply(doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[][] doubleArray27 = array2DRowRealMatrix26.getDataRef();
        boolean boolean29 = array2DRowRealMatrix26.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        boolean boolean31 = array2DRowRealMatrix3.equals((java.lang.Object) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix26.scalarAdd((double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) '#', (int) '#');
        double double5 = openMapRealMatrix2.getEntry((int) (byte) 0, 32);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = openMapRealMatrix2.createMatrix((int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.util.Localizable localizable9 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException14 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray15 = matrixDimensionMismatchException14.getExpectedDimensions();
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalArgumentException8, localizable9, (java.lang.Object[]) intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 'a', (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7522203923062136d + "'", double2 == 2.7522203923062136d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-6.053272382792838d), 1.1654988945205933d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        int int21 = blockRealMatrix10.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double23 = blockRealMatrix10.walkInRowOrder(realMatrixChangingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double15 = arrayRealVector3.getLInfNorm();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
        boolean boolean27 = array2DRowRealMatrix24.isTransposable();
        double[] doubleArray30 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix24.preMultiply(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector34);
        boolean boolean39 = arrayRealVector34.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector34.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector34);
        int int45 = arrayRealVector34.getDimension();
        arrayRealVector34.setEntry((int) (short) 0, (double) (-1L));
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector34.mapAddToSelf(0.0d);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector18.mapSubtractToSelf(0.5585053606381855d);
        double double27 = arrayRealVector18.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-0.5585053606381855d) + "'", double27 == (-0.5585053606381855d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5, false);
        double[] doubleArray10 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[][] doubleArray12 = array2DRowRealMatrix11.getDataRef();
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = array2DRowRealMatrix11.subtract(array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix16.copy();
        boolean boolean19 = array2DRowRealMatrix16.isTransposable();
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray24 = array2DRowRealMatrix16.preMultiply(doubleArray22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double29 = arrayRealVector26.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector26);
        boolean boolean31 = arrayRealVector26.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26);
        try {
            org.apache.commons.math3.linear.RealVector realVector33 = array2DRowRealMatrix7.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = blockRealMatrix9.walkInRowOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, false);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector18.unitVector();
        try {
            double double21 = arrayRealVector18.getEntry(1076101151);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(57L, (long) 1086568991);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57L + "'", long2 == 57L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        double[] doubleArray9 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = array2DRowRealMatrix5.subtract(array2DRowRealMatrix10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.copy();
        double[][] doubleArray13 = array2DRowRealMatrix10.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 0, (int) (short) 1, doubleArray13, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double double15 = arrayRealVector3.getLInfNorm();
        double double17 = arrayRealVector3.getEntry(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double27 = arrayRealVector24.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        arrayRealVector24.setEntry((int) '#', (double) 2.0f);
        arrayRealVector24.unitize();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector22.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector24.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double35 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        try {
            arrayRealVector3.setSubVector((int) (byte) -10, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4210854715202004E-14d + "'", double35 == 1.4210854715202004E-14d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0, (-0.4281861168052193d), (double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        boolean boolean34 = array2DRowRealMatrix9.equals((java.lang.Object) 5.298342365610589d);
        org.apache.commons.math3.exception.util.Localizable localizable35 = null;
        double[] doubleArray38 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[][] doubleArray40 = array2DRowRealMatrix39.getDataRef();
        double[] doubleArray43 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = array2DRowRealMatrix39.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix44.copy();
        double[][] doubleArray47 = array2DRowRealMatrix44.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        double[][] doubleArray49 = array2DRowRealMatrix48.getDataRef();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) boolean34, localizable35, (java.lang.Object[]) doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix8.walkInRowOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(4.450147717014403E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        boolean boolean4 = array2DRowRealMatrix3.isSquare();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector5.mapMultiplyToSelf(1.4210854715202004E-14d);
        double double16 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double double17 = arrayRealVector1.getMinValue();
        double[] doubleArray18 = arrayRealVector1.toArray();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4210854715202004E-14d + "'", double16 == 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) 2.2250738585072014E-308d, true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double double12 = arrayRealVector1.getEntry(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double17 = arrayRealVector14.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        arrayRealVector14.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double23 = arrayRealVector14.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double28 = arrayRealVector25.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        arrayRealVector25.setEntry((int) '#', (double) 2.0f);
        java.lang.String str32 = arrayRealVector25.toString();
        double double33 = arrayRealVector22.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector22.append(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double42 = arrayRealVector39.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        arrayRealVector39.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double48 = arrayRealVector39.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double53 = arrayRealVector50.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        arrayRealVector50.setEntry((int) '#', (double) 2.0f);
        java.lang.String str57 = arrayRealVector50.toString();
        double double58 = arrayRealVector47.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double63 = arrayRealVector60.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        arrayRealVector60.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray67 = arrayRealVector60.getDataRef();
        double double68 = arrayRealVector50.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector22.combine(1.5440680443502757d, 3.4359738368E10d, (org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector69);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str32.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str57.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector69);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix1 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction44 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray42, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, 3.4359738368E10d);
        double[] doubleArray47 = pointValuePair46.getPointRef();
        double[] doubleArray48 = array2DRowRealMatrix25.operate(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix15.preMultiply(doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        java.text.NumberFormat numberFormat53 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat54 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double61 = arrayRealVector58.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        arrayRealVector58.setEntry((int) '#', (double) 2.0f);
        arrayRealVector58.unitize();
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector56.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        java.lang.String str67 = realVectorFormat54.format((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        double double68 = arrayRealVector56.getLInfNorm();
        double[] doubleArray71 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray71);
        double[][] doubleArray73 = array2DRowRealMatrix72.getDataRef();
        double[] doubleArray76 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix72.subtract(array2DRowRealMatrix77);
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = array2DRowRealMatrix77.copy();
        boolean boolean80 = array2DRowRealMatrix77.isTransposable();
        double[] doubleArray83 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray83);
        double[] doubleArray85 = array2DRowRealMatrix77.preMultiply(doubleArray83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double90 = arrayRealVector87.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector89);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray83, arrayRealVector87);
        boolean boolean92 = arrayRealVector87.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector87);
        org.apache.commons.math3.linear.RealVector realVector96 = arrayRealVector87.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector56, arrayRealVector87);
        org.apache.commons.math3.linear.RealVector realVector98 = arrayRealVector52.append((org.apache.commons.math3.linear.RealVector) arrayRealVector97);
        try {
            array2DRowRealMatrix15.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x52 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(numberFormat53);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str67.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(realVector96);
        org.junit.Assert.assertNotNull(realVector98);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 33 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray6 = array2DRowRealMatrix3.getRow(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.transpose();
        double[] doubleArray11 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        double[] doubleArray16 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.copy();
        boolean boolean20 = array2DRowRealMatrix17.isTransposable();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix17.preMultiply(doubleArray23);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction27 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray25, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double30 = array2DRowRealMatrix29.getNorm();
        try {
            array2DRowRealMatrix3.setColumnMatrix(100, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 10100.0d + "'", double30 == 10100.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix8.transpose();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getDataRef();
        double[] doubleArray37 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        double[] doubleArray42 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix43.subtract(array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        boolean boolean51 = array2DRowRealMatrix48.isTransposable();
        double[] doubleArray54 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray56 = array2DRowRealMatrix48.preMultiply(doubleArray54);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction58 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray56, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair60 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray56, 3.4359738368E10d);
        double[] doubleArray61 = pointValuePair60.getPointRef();
        double[] doubleArray62 = array2DRowRealMatrix39.operate(doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector64 = array2DRowRealMatrix39.getColumnVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix8.add(array2DRowRealMatrix39);
        double[] doubleArray68 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[][] doubleArray70 = array2DRowRealMatrix69.getDataRef();
        double[] doubleArray73 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = array2DRowRealMatrix69.subtract(array2DRowRealMatrix74);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = array2DRowRealMatrix74.copy();
        boolean boolean77 = array2DRowRealMatrix74.isTransposable();
        double[] doubleArray80 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        double[] doubleArray82 = array2DRowRealMatrix74.preMultiply(doubleArray80);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double87 = arrayRealVector84.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray80, arrayRealVector84);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.RealVector) arrayRealVector88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 54");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.3440585709080678E43d, (double) 1086568991, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.util.MathUtils.checkFinite(3.141592653589793d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector24.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector18.getSubVector((int) (short) 10, (int) ' ');
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray32 = array2DRowRealMatrix29.getRow(1);
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction35 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray32, 1.1102230246251565E-16d);
        double[] doubleArray38 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[][] doubleArray40 = array2DRowRealMatrix39.getDataRef();
        double[] doubleArray43 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = array2DRowRealMatrix39.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = array2DRowRealMatrix44.copy();
        boolean boolean47 = array2DRowRealMatrix44.isTransposable();
        double[] doubleArray50 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        double[] doubleArray52 = array2DRowRealMatrix44.preMultiply(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, false);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector54.unitVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, arrayRealVector54);
        org.apache.commons.math3.exception.util.Localizable localizable57 = null;
        org.apache.commons.math3.exception.util.Localizable localizable58 = null;
        double[] doubleArray61 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray61);
        double[][] doubleArray63 = array2DRowRealMatrix62.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException64 = new org.apache.commons.math3.exception.NullArgumentException(localizable58, (java.lang.Object[]) doubleArray63);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException65 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable57, (java.lang.Object[]) doubleArray63);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix66.copy();
        double double68 = blockRealMatrix67.getNorm();
        double[] doubleArray71 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray71);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair75 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray71, (double) (short) 0);
        double[] doubleArray76 = pointValuePair75.getKey();
        double[] doubleArray77 = blockRealMatrix67.preMultiply(doubleArray76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray76);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector18.append((org.apache.commons.math3.linear.RealVector) arrayRealVector78);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 110.0d + "'", double68 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector79);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 1, (java.lang.Number) 3.4359738368E10d);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.4359738368E10d + "'", number5.equals(3.4359738368E10d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 36, (java.lang.Number) 1.1102230246251565E-16d, true);
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 36, "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        try {
            double[] doubleArray12 = blockRealMatrix10.getRow(1076101151);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix8.transpose();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getDataRef();
        double[] doubleArray37 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        double[] doubleArray42 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix43.subtract(array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        boolean boolean51 = array2DRowRealMatrix48.isTransposable();
        double[] doubleArray54 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray56 = array2DRowRealMatrix48.preMultiply(doubleArray54);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction58 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray56, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair60 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray56, 3.4359738368E10d);
        double[] doubleArray61 = pointValuePair60.getPointRef();
        double[] doubleArray62 = array2DRowRealMatrix39.operate(doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector64 = array2DRowRealMatrix39.getColumnVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix8.add(array2DRowRealMatrix39);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix8.getRowMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getDataRef();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor25 = null;
        try {
            double double26 = array2DRowRealMatrix20.walkInColumnOrder(realMatrixChangingVisitor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double26 = arrayRealVector23.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        arrayRealVector23.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double32 = arrayRealVector23.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        arrayRealVector34.setEntry((int) '#', (double) 2.0f);
        java.lang.String str41 = arrayRealVector34.toString();
        double double42 = arrayRealVector31.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, arrayRealVector31);
        try {
            arrayRealVector31.setEntry(1076101151, 97.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str41.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector18.mapSubtractToSelf((double) 10);
        double double25 = realVector24.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-10.0d) + "'", double25 == (-10.0d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double21 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector18);
        boolean boolean23 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18);
        double double25 = arrayRealVector18.getL1Norm();
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        org.apache.commons.math3.optimization.linear.Relationship relationship44 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        double[][] doubleArray49 = array2DRowRealMatrix48.getDataRef();
        double[] doubleArray52 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix53);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = array2DRowRealMatrix53.copy();
        boolean boolean56 = array2DRowRealMatrix53.isTransposable();
        double[] doubleArray59 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        double[] doubleArray61 = array2DRowRealMatrix53.preMultiply(doubleArray59);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint63 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray40, 0.0d, relationship44, doubleArray59, (double) 0);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint65 = new org.apache.commons.math3.optimization.linear.LinearConstraint((org.apache.commons.math3.linear.RealVector) arrayRealVector18, relationship44, (double) 1L);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector18.mapMultiply(0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + relationship44 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship44.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector67);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, 3.4359738368E10d);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        java.lang.Double double22 = pointValuePair20.getValue();
        java.lang.Double double23 = pointValuePair20.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.4359738368E10d + "'", double22.equals(3.4359738368E10d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.4359738368E10d + "'", double23.equals(3.4359738368E10d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction18 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray16, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray22 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getDataRef();
        double[][] doubleArray25 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        try {
            array2DRowRealMatrix19.setSubMatrix(doubleArray24, (int) (byte) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        double[] doubleArray36 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getDataRef();
        double[] doubleArray41 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = array2DRowRealMatrix37.subtract(array2DRowRealMatrix42);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = array2DRowRealMatrix42.copy();
        boolean boolean45 = array2DRowRealMatrix42.isTransposable();
        double[] doubleArray48 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix42.preMultiply(doubleArray48);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction52 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray50, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair54 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray50, 3.4359738368E10d);
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException59 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 0, 1, (int) (short) 100, 1);
        java.lang.Integer[] intArray60 = matrixDimensionMismatchException59.getWrongDimensions();
        int int61 = matrixDimensionMismatchException59.getExpectedRowDimension();
        boolean boolean62 = pointValuePair54.equals((java.lang.Object) int61);
        double[] doubleArray63 = pointValuePair54.getKey();
        array2DRowRealMatrix9.setRow((int) (byte) 0, doubleArray63);
        try {
            double[] doubleArray66 = array2DRowRealMatrix9.getRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double8 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        arrayRealVector5.setEntry((int) '#', (double) 2.0f);
        arrayRealVector5.unitize();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector3.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.lang.String str14 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double19 = arrayRealVector16.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        arrayRealVector16.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double25 = arrayRealVector16.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double30 = arrayRealVector27.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        arrayRealVector27.setEntry((int) '#', (double) 2.0f);
        java.lang.String str34 = arrayRealVector27.toString();
        double double35 = arrayRealVector24.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double40 = arrayRealVector37.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        arrayRealVector37.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray44 = arrayRealVector37.getDataRef();
        double double45 = arrayRealVector27.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        java.lang.String str46 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = realVectorFormat1.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str14.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str34.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str46.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double4 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        arrayRealVector1.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double10 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        arrayRealVector1.set(10.0d);
        double[] doubleArray17 = new double[] { (-1L), 100.0d, (-1), 4.9E-324d };
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.scalarAdd((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix19.copy();
        boolean boolean23 = arrayRealVector1.equals((java.lang.Object) realMatrix22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1, 100, 1076101151, 36, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = blockRealMatrix10.scalarMultiply(0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(10100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10100.0d + "'", double1 == 10100.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 1076101151, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double double12 = blockRealMatrix10.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix10.transpose();
        try {
            org.apache.commons.math3.linear.RealVector realVector15 = blockRealMatrix10.getColumnVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 110.0d + "'", double12 == 110.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[] doubleArray13 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getDataRef();
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix19.copy();
        boolean boolean22 = array2DRowRealMatrix19.isTransposable();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray27 = array2DRowRealMatrix19.preMultiply(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix8.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix8.transpose();
        double[] doubleArray32 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getDataRef();
        double[] doubleArray37 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        double[] doubleArray42 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[][] doubleArray44 = array2DRowRealMatrix43.getDataRef();
        double[] doubleArray47 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix43.subtract(array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = array2DRowRealMatrix48.copy();
        boolean boolean51 = array2DRowRealMatrix48.isTransposable();
        double[] doubleArray54 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray56 = array2DRowRealMatrix48.preMultiply(doubleArray54);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction58 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray56, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair60 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray56, 3.4359738368E10d);
        double[] doubleArray61 = pointValuePair60.getPointRef();
        double[] doubleArray62 = array2DRowRealMatrix39.operate(doubleArray61);
        org.apache.commons.math3.linear.RealVector realVector64 = array2DRowRealMatrix39.getColumnVector((int) (byte) 0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix8.add(array2DRowRealMatrix39);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(32);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (org.apache.commons.math3.linear.AnyMatrix) realMatrix67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 32");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        double[][] doubleArray11 = array2DRowRealMatrix8.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[][] doubleArray20 = array2DRowRealMatrix19.getDataRef();
        double[] doubleArray23 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix19.subtract(array2DRowRealMatrix24);
        double[] doubleArray28 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getDataRef();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix34);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix34.copy();
        boolean boolean37 = array2DRowRealMatrix34.isTransposable();
        double[] doubleArray40 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix34.preMultiply(doubleArray40);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction44 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray42, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, 3.4359738368E10d);
        double[] doubleArray47 = pointValuePair46.getPointRef();
        double[] doubleArray48 = array2DRowRealMatrix25.operate(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix15.preMultiply(doubleArray48);
        java.text.NumberFormat numberFormat50 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat51 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double58 = arrayRealVector55.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        arrayRealVector55.setEntry((int) '#', (double) 2.0f);
        arrayRealVector55.unitize();
        org.apache.commons.math3.linear.RealVector realVector63 = arrayRealVector53.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        java.lang.String str64 = realVectorFormat51.format((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        double double65 = arrayRealVector53.getLInfNorm();
        double[] doubleArray68 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[][] doubleArray70 = array2DRowRealMatrix69.getDataRef();
        double[] doubleArray73 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = array2DRowRealMatrix69.subtract(array2DRowRealMatrix74);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = array2DRowRealMatrix74.copy();
        boolean boolean77 = array2DRowRealMatrix74.isTransposable();
        double[] doubleArray80 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        double[] doubleArray82 = array2DRowRealMatrix74.preMultiply(doubleArray80);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double87 = arrayRealVector84.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray80, arrayRealVector84);
        boolean boolean89 = arrayRealVector84.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector84);
        org.apache.commons.math3.linear.RealVector realVector93 = arrayRealVector84.getSubVector((int) '4', 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector53, arrayRealVector84);
        int int95 = arrayRealVector84.getDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15, (org.apache.commons.math3.linear.RealVector) arrayRealVector84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: 2 != 52");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(numberFormat50);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str64.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(realVector93);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 52 + "'", int95 == 52);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable12, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable11, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix20.copy();
        double double22 = blockRealMatrix21.getNorm();
        double[] doubleArray25 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, (double) (short) 0);
        double[] doubleArray30 = pointValuePair29.getKey();
        double[] doubleArray31 = blockRealMatrix21.preMultiply(doubleArray30);
        int int32 = blockRealMatrix21.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix9.add(blockRealMatrix21);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor34 = null;
        try {
            double double35 = blockRealMatrix33.walkInRowOrder(realMatrixPreservingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 110.0d + "'", double22 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        double[] doubleArray12 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getDataRef();
        double[] doubleArray17 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix13.subtract(array2DRowRealMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.copy();
        boolean boolean21 = array2DRowRealMatrix18.isTransposable();
        double[] doubleArray24 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix18.preMultiply(doubleArray24);
        org.apache.commons.math3.optimization.linear.LinearObjectiveFunction linearObjectiveFunction28 = new org.apache.commons.math3.optimization.linear.LinearObjectiveFunction(doubleArray26, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, 3.4359738368E10d);
        double[] doubleArray31 = pointValuePair30.getPointRef();
        double[] doubleArray32 = array2DRowRealMatrix9.operate(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double37 = arrayRealVector34.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        arrayRealVector34.setEntry((int) '#', (double) 2.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double43 = arrayRealVector34.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double48 = arrayRealVector45.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        arrayRealVector45.setEntry((int) '#', (double) 2.0f);
        java.lang.String str52 = arrayRealVector45.toString();
        double double53 = arrayRealVector42.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4');
        double double58 = arrayRealVector55.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        arrayRealVector55.setEntry((int) '#', (double) 2.0f);
        double[] doubleArray62 = arrayRealVector55.getDataRef();
        double double63 = arrayRealVector45.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}" + "'", str52.equals("{0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = blockRealMatrix10.walkInOptimizedOrder(realMatrixChangingVisitor11, (int) '4', (int) (byte) 10, (int) '#', 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray4 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getDataRef();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        double double11 = blockRealMatrix10.getNorm();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray14);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair18 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) (short) 0);
        double[] doubleArray19 = pointValuePair18.getKey();
        double[] doubleArray20 = blockRealMatrix10.preMultiply(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix10.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 110.0d + "'", double11 == 110.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray3 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[][] doubleArray5 = array2DRowRealMatrix4.getDataRef();
        double[] doubleArray8 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = array2DRowRealMatrix4.subtract(array2DRowRealMatrix9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        boolean boolean12 = array2DRowRealMatrix9.isTransposable();
        double[] doubleArray15 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray17 = array2DRowRealMatrix9.preMultiply(doubleArray15);
        double[] doubleArray20 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getDataRef();
        boolean boolean24 = array2DRowRealMatrix21.equals((java.lang.Object) (-1.0f));
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix9, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix21);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(10100.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.560895660206908d + "'", double2 == 1.560895660206908d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(2.0f, 0.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double[] doubleArray2 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
        double[][] doubleArray4 = array2DRowRealMatrix3.getDataRef();
        double[] doubleArray7 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix3.subtract(array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        boolean boolean11 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray14 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix8.preMultiply(doubleArray14);
        org.apache.commons.math3.optimization.linear.Relationship relationship18 = org.apache.commons.math3.optimization.linear.Relationship.GEQ;
        double[] doubleArray21 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[][] doubleArray23 = array2DRowRealMatrix22.getDataRef();
        double[] doubleArray26 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix27.copy();
        boolean boolean30 = array2DRowRealMatrix27.isTransposable();
        double[] doubleArray33 = new double[] { 100.0d, (short) 10 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray35 = array2DRowRealMatrix27.preMultiply(doubleArray33);
        org.apache.commons.math3.optimization.linear.LinearConstraint linearConstraint37 = new org.apache.commons.math3.optimization.linear.LinearConstraint(doubleArray14, 0.0d, relationship18, doubleArray33, (double) 0);
        java.lang.String str38 = relationship18.toString();
        org.apache.commons.math3.optimization.linear.Relationship relationship39 = relationship18.oppositeRelationship();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + relationship18 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.GEQ + "'", relationship18.equals(org.apache.commons.math3.optimization.linear.Relationship.GEQ));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + ">=" + "'", str38.equals(">="));
        org.junit.Assert.assertTrue("'" + relationship39 + "' != '" + org.apache.commons.math3.optimization.linear.Relationship.LEQ + "'", relationship39.equals(org.apache.commons.math3.optimization.linear.Relationship.LEQ));
    }
}

